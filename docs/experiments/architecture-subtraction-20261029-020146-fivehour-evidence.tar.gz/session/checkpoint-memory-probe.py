"""Retained Python allocations of Microduck atomic checkpoint publication."""
import gc,hashlib,json,os,sys,tracemalloc
from pathlib import Path
from types import SimpleNamespace
source,output=map(Path,sys.argv[1:3]);count=int(sys.argv[3]);sys.path.insert(0,str(source))
import torch
from embodiedforge.locomotion.microduck import checkpoint as micro
output.mkdir();torch.set_num_threads(1)
index=0
# Equal unique names isolate source changes from random UUID differences.
def unique_name():
 global index
 index+=1
 return SimpleNamespace(hex=f'{index:032x}')
micro.uuid4=unique_name
parameter=torch.nn.Parameter(torch.ones(1));optimizer=torch.optim.Adam([parameter]);parameter.grad=torch.ones(1);optimizer.step()
checkpoint={'model_state_dict':{'weight':torch.arange(8,dtype=torch.float32)},'optimizer_state_dict':optimizer.state_dict()}
target=output/'model.pt'
def publish(step):
 checkpoint['iteration']=step
 micro.atomic_save(lambda path,infos:torch.save({**checkpoint,'infos':infos},path),target,{'counter':step})
for step in range(64):publish(step)
gc.collect();tracemalloc.start();before=tracemalloc.get_traced_memory()[0]
for step in range(64,64+count):publish(step)
gc.collect();after,peak=tracemalloc.get_traced_memory();snapshot=tracemalloc.take_snapshot()
saved=torch.load(target,weights_only=True,map_location='cpu');assert saved['iteration']==count+63
result={'python':sys.version,'source':str(source),'publications':count,'retained_python_bytes':after-before,'peak_traced_bytes':peak,'checkpoint_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'top_allocations':[str(s) for s in snapshot.statistics('lineno')[:10]],'scope':'Fresh CPython3.12.0 CPU Adam serialization; deterministic unique UUID strings isolate pathname retention, not RSS, VRAM or training speed.'}
(output/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
