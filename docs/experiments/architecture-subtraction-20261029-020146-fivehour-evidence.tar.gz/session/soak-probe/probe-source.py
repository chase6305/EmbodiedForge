"""Private sustained CPU file publication/copy acceptance; no robot training."""
import errno,gc,hashlib,json,logging,os,shutil,signal,sys,time,tracemalloc
from datetime import datetime,timezone
from pathlib import Path
source,output,fixtures=map(Path,sys.argv[1:4]);seconds=float(sys.argv[4]);sys.path.insert(0,str(source))
import torch
import numpy as np
from embodiedforge import _motion_clips as motion, _go1_implementation as go1
from embodiedforge.locomotion.microduck import checkpoint as micro
from embodiedforge.runtime.artifacts import write_json
from embodiedforge.runtime.hashing import file_sha256
from embodiedforge.runtime.process import termination_signals,ProcessInterrupted
logging.disable(logging.CRITICAL);torch.set_num_threads(1)
output.mkdir(parents=True);shutil.copyfile(__file__,output/'probe-source.py');work=output/'work';shutil.copytree(fixtures,work)
manifest=json.loads((work/'manifest.json').read_text());layout=json.loads((work/'layout.json').read_text());library=motion.import_weave(work/'weave.npz',layout)
parameter=torch.nn.Parameter(torch.ones(1));optimizer=torch.optim.Adam([parameter]);parameter.grad=torch.ones(1);optimizer.step()
checkpoint={'weights':torch.arange(8,dtype=torch.float32),'optimizer_state_dict':optimizer.state_dict()}
target=work/'model.pt';snapshot=work/'motion.npz';private=work/'private';source_leaf=work/'run/implementation/locomotion/go1.py';source_bytes=source_leaf.read_bytes();iteration=0
counts=dict.fromkeys(['checkpoint_success','checkpoint_write_failure','checkpoint_rename_failure','real_sigterm','motion_success','motion_write_failure','motion_close_failure','actual_enospc','implementation_success','implementation_corrupt_source','implementation_fifo','existing_private_target'],0)
def read(path):
 with open(path,'rb') as f:return f.read()
def save(path,infos):torch.save({**checkpoint,'infos':infos},path)
def publish(callback=save):
 global iteration
 iteration+=1;checkpoint['iteration']=iteration;micro.atomic_save(callback,target,{'counter':iteration})
def check_checkpoint():
 value=torch.load(target,weights_only=True,map_location='cpu');assert value['infos']['counter']==value['iteration'];assert torch.equal(value['weights'],checkpoint['weights']);return value

def cleanup_failure(*args,**kwargs):raise [PermissionError('cleanup denied'),KeyboardInterrupt('cleanup cancelled'),SystemExit(3)][iteration%3]
def remove_owned():
 for name in os.listdir(work):
  if name.endswith('.tmp'):os.unlink(work/name)
 if snapshot.exists():snapshot.unlink()
 if private.exists():shutil.rmtree(private)
def cycle():
 publish();assert check_checkpoint()['iteration']==iteration;counts['checkpoint_success']+=1
 previous=read(target);primary=OSError('checkpoint save failed');unlink=os.unlink
 def failed_save(path,infos):save(path,infos);raise primary
 try:
  os.unlink=cleanup_failure
  try:publish(failed_save)
  except BaseException as error:assert error is primary
  else:raise AssertionError('save failure accepted')
 finally:os.unlink=unlink;remove_owned()
 assert read(target)==previous;check_checkpoint();counts['checkpoint_write_failure']+=1
 primary=OSError('checkpoint rename failed');replace=Path.replace
 def failed_replace(path,destination):
  if Path(destination)==target:raise primary
  return replace(path,destination)
 try:
  Path.replace,os.unlink=failed_replace,cleanup_failure
  try:publish()
  except BaseException as error:assert error is primary
  else:raise AssertionError('rename failure accepted')
 finally:Path.replace,os.unlink=replace,unlink;remove_owned()
 assert read(target)==previous;counts['checkpoint_rename_failure']+=1
 def terminate(path,infos):save(path,infos);os.kill(os.getpid(),signal.SIGTERM)
 try:
  os.unlink=cleanup_failure
  with termination_signals():
   try:publish(terminate)
   except ProcessInterrupted as error:assert error.signum==signal.SIGTERM
   else:raise AssertionError('SIGTERM not observed')
 finally:os.unlink=unlink;remove_owned()
 assert read(target)==previous;counts['real_sigterm']+=1
 library.save(snapshot);loaded=motion.MotionClips.load(snapshot)
 assert np.array_equal(loaded.arrays['joint_pos'],library.arrays['joint_pos'])
 assert loaded.sha256==file_sha256(snapshot)
 assert loaded.frames([0,1],[0,0],[0,1])['joint_pos'].shape==(2,2,2)
 snapshot.unlink();counts['motion_success']+=1
 original_save=np.savez_compressed;primary=OSError('motion write failed')
 def failed_motion(stream,**kwargs):stream.write(b'partial motion');raise primary
 try:
  np.savez_compressed,os.unlink=failed_motion,cleanup_failure
  try:library.save(snapshot)
  except BaseException as error:assert error is primary
  else:raise AssertionError('motion write failure accepted')
 finally:np.savez_compressed,os.unlink=original_save,unlink;remove_owned()
 counts['motion_write_failure']+=1
 original_open=Path.open;primary=OSError('motion close failed')
 class FailedClose:
  def __init__(self,stream):self.stream=stream
  def __enter__(self):return self.stream
  def __exit__(self,*args):self.stream.close();raise primary
 def failed_close(path,*args,**kwargs):
  stream=original_open(path,*args,**kwargs)
  return FailedClose(stream) if path==snapshot else stream
 try:
  Path.open=failed_close
  try:library.save(snapshot)
  except BaseException as error:assert error is primary
  else:raise AssertionError('close failure accepted')
 finally:Path.open=original_open
 assert not snapshot.exists();counts['motion_close_failure']+=1
 # Borrow the device stream only; publication and cleanup always use our file.
 def full_sink(path,*args,**kwargs):
  if path==snapshot and args and args[0]=='xb':
   owned=original_open(path,*args,**kwargs);owned.close()
   return original_open(Path('/dev/full'),'wb')
  return original_open(path,*args,**kwargs)
 try:
  Path.open=full_sink
  try:library.save(snapshot)
  except OSError as error:assert error.errno==errno.ENOSPC
  else:raise AssertionError('real ENOSPC not observed')
 finally:Path.open=original_open
 assert not snapshot.exists();counts['actual_enospc']+=1
 copied=go1.copy_go1_implementation(work/'run',manifest,private)
 assert copied['files']==manifest['implementation']['files']
 assert all(file_sha256(private/name)==sha for name,sha in copied['files'].items())
 shutil.rmtree(private);counts['implementation_success']+=1
 try:
  source_leaf.write_bytes(b'corrupted source')
  try:go1.copy_go1_implementation(work/'run',manifest,private)
  except ValueError:pass
  else:raise AssertionError('corrupt source accepted')
 finally:source_leaf.write_bytes(source_bytes);remove_owned()
 counts['implementation_corrupt_source']+=1
 original_is_file=Path.is_file;injected=False
 def swapped(path):
  nonlocal injected
  value=original_is_file(path)
  if path==source_leaf and not injected:
   injected=True;source_leaf.unlink();os.mkfifo(source_leaf)
  return value
 try:
  Path.is_file=swapped
  try:go1.copy_go1_implementation(work/'run',manifest,private)
  except ValueError:assert injected
  else:raise AssertionError('FIFO accepted')
 finally:
  Path.is_file=original_is_file;source_leaf.unlink();source_leaf.write_bytes(source_bytes);remove_owned()
 counts['implementation_fifo']+=1
 existing=private/'locomotion/__init__.py';existing.parent.mkdir(parents=True);existing.write_bytes(b'previous private source')
 try:
  try:go1.copy_go1_implementation(work/'run',manifest,private)
  except FileExistsError:pass
  else:raise AssertionError('existing target overwritten')
  assert existing.read_bytes()==b'previous private source'
 finally:remove_owned()
 counts['existing_private_target']+=1

def resources():
 result={}
 with open('/proc/self/status') as f:
  for line in f:
   if line.startswith(('VmRSS:','Threads:')):
    key,value=line.split(':',1);result[key]=value.strip()
 result['fds']=len(os.listdir('/proc/self/fd'));result['traced_bytes'],result['traced_peak']=tracemalloc.get_traced_memory();return result
for _ in range(8):cycle()
gc.collect();tracemalloc.start();started=time.monotonic();started_at=datetime.now(timezone.utc).isoformat();initial=resources();cycles=0;last_sample=started-60
with open(output/'samples.jsonl','x') as samples:
 while time.monotonic()-started<seconds:
  cycle();cycles+=1;now=time.monotonic()
  if now-last_sample>=60:
   gc.collect();samples.write(json.dumps({'seconds':now-started,'cycles':cycles,'counts':counts,**resources()})+'\n');samples.flush();last_sample=now
  time.sleep(.25)
check_checkpoint();gc.collect()
summary={'status':'complete','scope':'Private valid NPZ and tiny CPU Adam checkpoint/source-copy fixtures, not robot training or policy inference.','requested_seconds':seconds,'seconds':time.monotonic()-started,'started_at':started_at,'finished_at':datetime.now(timezone.utc).isoformat(),'cycles':cycles,'warmup_cycles':8,'scenario_counts_including_warmup':counts,'initial_resources':initial,'final_resources':resources(),'python':sys.version,'probe_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
write_json(output/'summary.json',summary);print(json.dumps(summary),flush=True)
