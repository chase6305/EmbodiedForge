import json,os,subprocess
from pathlib import Path
root=Path(__file__).parent;repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');python=repo/'.cache/external/mjbatch/.venv/bin/python';results={}
for count in (1000,4000):
 results[str(count)]={}
 for label,source in [('baseline',root/'baseline/src'),('candidate',repo/'src')]:
  output=root/f'memory-final-{label}-{count}'
  with (root/f'memory-final-{label}-{count}.log').open('x') as log:
   child=subprocess.run([str(python),'-I',str(root/'checkpoint-memory-probe.py'),str(source),str(output),str(count)],stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
  assert child.returncode==0,(count,label,child.returncode)
  value=json.loads((output/'result.json').read_text());value['actual_child_wait_returncode']=child.returncode;results[str(count)][label]=value
 assert results[str(count)]['baseline']['checkpoint_sha256']==results[str(count)]['candidate']['checkpoint_sha256']
# Both implementations are measured without assuming an allocation reduction.
(root/'checkpoint-memory-validation.json').write_text(json.dumps({'results':results,'serialized_checkpoint_bytes_exact':True,'scope':'Both implementations retain bounded allocations here; no measured memory improvement, RSS/VRAM or robot learning claim.'},indent=2)+'\n')
print(json.dumps({n:{k:v['retained_python_bytes'] for k,v in row.items()} for n,row in results.items()}))
