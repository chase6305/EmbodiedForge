"""Observe fresh legacy/current processes, including only our owned FIFO worker."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
import numpy as np
root=Path(__file__).parent
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge')
fixtures=root/'shared-fixtures-final';fixtures.mkdir()
layout={'robot':'fixture','joint_names':['hip','knee'],'body_names':['pelvis','foot'],'quaternion_order':'wxyz','coordinate_frame':'world'}
arrays={'fps':np.array(50.),'motion_lengths':np.array([2,3]),'motion_names':np.array(['lift','carry']),'object_names':np.array(['box','box']),'joint_pos':np.arange(10,dtype=np.float64).reshape(5,2),'joint_vel':np.zeros((5,2)),'body_pos_w':np.zeros((5,2,3)),'body_quat_w':np.tile([1.,0,0,0],(5,2,1)),'body_lin_vel_w':np.zeros((5,2,3)),'body_ang_vel_w':np.zeros((5,2,3)),'object_pos_w':np.zeros((5,3)),'object_quat_w':np.tile([1.,0,0,0],(5,1)),'object_lin_vel_w':np.zeros((5,3)),'object_ang_vel_w':np.zeros((5,3)),'contact_label':np.zeros((5,2))}
np.savez(fixtures/'weave.npz',**arrays)
(fixtures/'layout.json').write_text(json.dumps(layout))
(fixtures/'component.py').write_text('VALUE = 17\n')
files={'locomotion/__init__.py':'','locomotion/go1.py':'VALUE = 17\n','locomotion/go1_config.py':'VALUE = 17\n','locomotion/go1_ppo.py':'VALUE = 17\n','locomotion/go1_scene.xml':'<mujoco/>\n'}
hashes={}
for name,content in files.items():
 path=fixtures/'run/implementation'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(content);hashes[name]=hashlib.sha256(path.read_bytes()).hexdigest()
manifest={'implementation':{'path':'implementation','files':hashes}}
(fixtures/'manifest.json').write_text(json.dumps(manifest))
interpreter=repo/'.cache/external/mjbatch/.venv/bin/python'
results={}
for label,source in [('baseline',root/'baseline/src'),('candidate',repo/'src')]:
 results[label]={}
 for mode in ('stable','cleanup-interrupt','motion-close','existing-destination','fifo-substitution'):
  # FIFO cancellation can leave its source as a pipe; give each probe owned data.
  working=fixtures if mode=='stable' else root/(label+'-final-'+mode+'-fixtures')
  if working!=fixtures:shutil.copytree(fixtures,working)
  output=root/('control-final-'+label+'-'+mode)
  with (root/('control-final-'+label+'-'+mode+'.log')).open('x') as log:
   child=subprocess.Popen([str(interpreter),'-I',str(root/'compatibility-probe.py'),str(source),str(output),str(working),mode],stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
   timed_out=False
   try:code=child.wait(timeout=15 if mode!='fifo-substitution' else 4)
   except subprocess.TimeoutExpired:
    assert mode=='fifo-substitution' and label=='baseline' and (output/'ready').exists()
    child.kill();code=child.wait();timed_out=True
  value={'actual_child_wait_returncode':code,'timed_out':timed_out}
  if timed_out:assert code==-9
  else:
   assert code==0,(label,mode,code)
   value.update(json.loads((output/'result.json').read_text()))
  results[label][mode]=value
stable=('motion_metadata','motion_sha256','motion_arrays','checkpoint_sha256','implementation_files','component')
assert all(results['baseline']['stable'][k]==results['candidate']['stable'][k] for k in stable)
assert not results['baseline']['cleanup-interrupt']['primary_preserved'] and results['candidate']['cleanup-interrupt']['primary_preserved']
assert not results['baseline']['motion-close']['owned_partial_removed'] and results['candidate']['motion-close']['owned_partial_removed']
assert not results['baseline']['existing-destination']['previous_intact'] and results['candidate']['existing-destination']['previous_intact'] and results['candidate']['existing-destination']['rejected']
assert results['baseline']['fifo-substitution']['timed_out'] and results['candidate']['fifo-substitution']['rejected']
assert results['baseline']['stable']['logical_content_passes']=={'source_hashes':5,'copies':5,'target_hashes':5}
assert results['candidate']['stable']['logical_content_passes']=={'source_hashes':0,'copies':5,'target_hashes':5}
summary={'stable_outputs_exact':True,'cleanup_priority_reproduced_and_fixed':True,'motion_close_partial_reproduced_and_fixed':True,'existing_private_destination_preserved':True,'fifo_substitution_reproduced_and_fixed':True,'results':results,'scope':'CPU serialized files and source-copy fixtures; no SDK inference/training. Content passes are logical operations, not syscall counts or measured latency.'}
(root/'compatibility-validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print('All legacy/current file compatibility and failure controls passed.')
