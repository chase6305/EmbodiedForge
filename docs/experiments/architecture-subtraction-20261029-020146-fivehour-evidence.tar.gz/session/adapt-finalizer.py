"""Prepare this session's local report publisher from the tested archive format."""
from pathlib import Path
root=Path(__file__).parent
s=Path('/tmp/embodiedforge-subtraction-20261028-143545-fivehour/finalize-evidence.py').read_text()
s=s.replace('architecture-subtraction-20261028-143545-fivehour','architecture-subtraction-20261029-020146-fivehour')
s=s.replace('publication-fingerprint-soak.py','publication-motion-soak.py')
s=s.replace("read('fingerprint-compatibility.json')","read('compatibility-validation.json')")
s=s.replace("('stable_fingerprints_exact', 'linked_checkpoint_support_preserved',\n                'processor_race_reproduced_and_fixed', 'cleanup_error_priority_reproduced_and_fixed',\n                'fifo_blocking_reproduced_and_fixed')", "('stable_outputs_exact', 'cleanup_priority_reproduced_and_fixed',\n                'motion_close_partial_reproduced_and_fixed', 'existing_private_destination_preserved',\n                'fifo_substitution_reproduced_and_fixed')")
s=s.replace("wheel['stdlib_only']", "wheel['stdlib_checkpoint_entry']")
s=s.replace("read('checkpoint-memory-observed.json')", "read('checkpoint-memory-validation.json')")
s=s.replace("assert all(memory['artifact_bytes_equal'].values())\n    assert all(v['actual_child_wait_returncode'] == 0 for v in memory['results'].values())", "assert memory['serialized_checkpoint_bytes_exact']\n    assert all(v['actual_child_wait_returncode'] == 0 for row in memory['results'].values() for v in row.values())")
s=s.replace('training-parity-supervised/summary.json','training-parity/summary.json')
s=s.replace("'backflip-acceptance", "'final-backflip-acceptance")
s=s.replace("'main-supervisor'", "'final-main-supervisor'").replace("'native-supervisor'", "'final-native-supervisor'").replace("'source-isolated-supervisor'", "'source-supervisor'").replace("'backflip-supervisor'", "'final-backflip-supervisor'").replace("'soak-probe-supervisor'", "'final-probe-supervisor'")
s=s.replace("'main-tests.xml'", "'final-main-tests.xml'").replace("'native-tests.xml'", "'final-native-tests.xml'").replace("'source-isolated-tests.xml'", "'source-tests.xml'")
s=s.replace("'main-supervisor/command.log'", "'final-main-supervisor/command.log'").replace("'native-supervisor/command.log'", "'final-native-supervisor/command.log'").replace("'source-isolated-supervisor/command.log'", "'source-supervisor/command.log'")
s=s.replace("read('soak/summary.json')", "read('soak-final/summary.json')").replace("soak['seconds'] >= 14400", "soak['seconds'] >= 16200").replace("observed('soak-supervisor')", "observed('soak-final-supervisor')")
s=s.replace("('main_original', 'native_original', 'source_isolated_original', 'parity_observed_original',\n                 'backflip_original', 'distribution_original', 'checkpoint_memory_observed_original', 'soak_original')", "('main_original', 'native_original', 'source_original', 'parity_original',\n                 'backflip_final_original', 'distribution_original', 'memory_original', 'final_compatibility_original', 'wheel_original', 'soak_original')")
start=s.index("              'changes': [");end=s.index("              'metrics':",start)
s=s[:start]+'''              'changes': [
                  'Reuse runtime stream hashing for motion imports/loaders and source provenance; keep file descriptors, digest fields and array precision unchanged.',
                  'Microduck checkpoints and motion output cleanup reuse the existing runtime artifacts helper; preserve active save errors when deletion is interrupted.',
                  'Catch motion stream-close failures after owning a new output, remove the partial file and allow retry; preserve existing exclusive-create behavior.',
                  'Go1 recorded implementation copies hash the same bounded regular source read and independently verify destination bytes; logical content passes drop from three to two per file.',
                  'Go1 private implementation targets reject preexisting files and substituted FIFOs instead of overwriting private source or blocking in a hash read.'
              ],
'''+s[end:]
s=s.replace("'fingerprint_controls'", "'file_compatibility_controls'")
s=s.replace("'Memory results measure retained Python allocations for CPU checkpoint publication, not RSS, GPU memory or training throughput.'", "'Memory controls found no allocation improvement for the original with_name temporary paths. Path construction remains unchanged; no RSS, GPU memory or training speed gain is claimed.'")
s=s.replace("'The sustained fixture uses tiny valid CPU Adam checkpoints and file/process faults; it does not train ACT or a robot policy.'", "'The sustained fixture uses valid NPZ data, tiny CPU Adam checkpoints and source-copy/file faults; it does not train a robot policy.'")
# Keep old and final small fixtures as evidence, but avoid nested package trees and test payloads.
a=s.index('    excluded_prefixes = (');b=s.index('    for path in ROOT.rglob',a)
s=s[:a]+'''    excluded_prefixes = ('baseline/', 'release-source/', 'source-release/', 'installed-wheel/',
                         'shared-fixtures/', 'shared-fixtures-final/', 'soak/work/', 'soak-final/work/',
                         'soak-probe/work/', 'final-probe/work/')
'''+s[b:]
s=s.replace("if name.startswith(excluded_prefixes) or '__pycache__' in path.parts:", "if name.startswith(excluded_prefixes) or '-fixtures/' in name or '__pycache__' in path.parts:")
s=s.replace('five-hour subtraction evidence', 'five-hour subtraction evidence')
(root/'finalize-evidence.py').write_text(s)
