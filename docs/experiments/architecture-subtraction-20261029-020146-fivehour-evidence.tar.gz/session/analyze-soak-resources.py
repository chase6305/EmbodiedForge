"""Summarize real process samples without treating RSS changes as causal gains."""
import json
from pathlib import Path
root=Path(__file__).parent
samples=[json.loads(line) for line in (root/'soak-final/samples.jsonl').read_text().splitlines()]
summary=json.loads((root/'soak-final/summary.json').read_text())
assert summary['status']=='complete' and summary['seconds']>=16200
assert {int(s['Threads']) for s in samples}=={2}
assert {s['fds'] for s in samples}=={18}
late=[s for s in samples if s['seconds']>=1800]
result={'scope':'Observed resources of the private CPU fault fixture; RSS varies with allocator and host pressure and is not an optimization gain.',
        'samples':len(samples),'last_sample_seconds':samples[-1]['seconds'],
        'sample_threads_min_max':[min(int(s['Threads']) for s in samples),max(int(s['Threads']) for s in samples)],
        'sample_fds_min_max':[min(s['fds'] for s in samples),max(s['fds'] for s in samples)],
        'sample_rss_kib_min_max':[min(int(s['VmRSS'].split()[0]) for s in samples),max(int(s['VmRSS'].split()[0]) for s in samples)],
        'traced_python_bytes_after_30min_min_max':[min(s['traced_bytes'] for s in late),max(s['traced_bytes'] for s in late)],
        'initial_resources':summary['initial_resources'],'final_resources':summary['final_resources'],
        'scenario_counts_including_warmup':summary['scenario_counts_including_warmup'],
        'total_scenarios_including_warmup':sum(summary['scenario_counts_including_warmup'].values())}
(root/'soak-resource-observations.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
