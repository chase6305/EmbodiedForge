"""Verify physical package assets and run file workflows from actual wheel."""
import hashlib,json,os,shutil,subprocess,sys,zipfile
from pathlib import Path
root=Path(__file__).parent;repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');distribution=json.loads((root/'distribution-validation.json').read_text());wheel=root/'installed-wheel';python=repo/'.cache/external/mjbatch/.venv/bin/python';resources=json.loads((root/'selected-resource-hashes.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with zipfile.ZipFile(distribution['wheel']['path']) as archive:
 for name,digest in resources.items():
  assert sha(repo/name)==sha(Path(distribution['source_release_root'])/name)==digest
  assert hashlib.sha256(archive.read(name.removeprefix('src/'))).hexdigest()==digest
(root/'release-resource-validation.json').write_text(json.dumps({'resources':len(resources),'workspace_source_and_wheel_exact':True},indent=2)+'\n')
results={}
fixtures=root/'shared-fixtures-final'
for mode in ('stable','cleanup-interrupt','motion-close','fifo-substitution','existing-destination'):
 working=fixtures if mode=='stable' else root/('wheel-'+mode+'-fixtures')
 if working!=fixtures:shutil.copytree(fixtures,working)
 output=root/('wheel-'+mode)
 with (root/('wheel-'+mode+'.log')).open('x') as log:
  child=subprocess.run([str(python),'-I',str(root/'compatibility-probe.py'),str(wheel),str(output),str(working),mode],stdout=log,stderr=subprocess.STDOUT,timeout=30,env={**os.environ,'OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
 assert child.returncode==0,(mode,child.returncode)
 value=json.loads((output/'result.json').read_text());value['actual_child_wait_returncode']=child.returncode;results[mode]=value
baseline=json.loads((root/'compatibility-validation.json').read_text())['results']['baseline']['stable']
assert all(results['stable'][key]==baseline[key] for key in ('motion_metadata','motion_sha256','motion_arrays','checkpoint_sha256','implementation_files','component'))
assert results['cleanup-interrupt']['primary_preserved'] and results['cleanup-interrupt']['previous_intact']
assert results['motion-close']['owned_partial_removed']
assert results['fifo-substitution']['rejected']
assert results['existing-destination']['previous_intact'] and results['existing-destination']['rejected']
stdlib_code='''import sys,tempfile,os
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from embodiedforge.locomotion.microduck.checkpoint import atomic_save
with tempfile.TemporaryDirectory() as temporary:
 target=Path(temporary)/'model.pt'
 atomic_save(lambda path,infos:Path(path).write_bytes(b'complete'),target)
 assert target.read_bytes()==b'complete'
 assert len(os.listdir(temporary))==1
assert not any(n.split('.')[0] in {'numpy','torch','mjlab','mujoco'} for n in sys.modules)
'''
with (root/'wheel-stdlib.log').open('x') as log:
 child=subprocess.run([sys.executable,'-I','-S','-c',stdlib_code,str(wheel)],stdout=log,stderr=subprocess.STDOUT)
assert child.returncode==0
(root/'installed-wheel-validation.json').write_text(json.dumps({'all_fixture_scenarios_passed':True,'stdlib_checkpoint_entry':True,'stdlib_actual_child_wait_returncode':child.returncode,'scenarios':results,'scope':'Actual extracted wheel, CPU serialization/source-copy and NPZ fixtures; no SDK/robot inference or training.'},indent=2)+'\n')
print('Installed wheel file workflows and stdlib checkpoint entry passed;49 resource bytes match.')
