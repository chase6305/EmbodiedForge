"""Publish this session's subtraction evidence only after its actual five-hour window."""
import argparse
from datetime import datetime, timezone
import difflib
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).parent
REPO = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
STEM = 'architecture-subtraction-20261029-020146-fivehour'
RUN = REPO / 'runs' / STEM

def read(name):
    return json.loads((ROOT / name).read_text())

def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def test_result(name, log):
    suites = ET.parse(ROOT / name).getroot().findall('testsuite')
    value = {k: sum(int(s.attrib[k]) for s in suites)
             for k in ('tests', 'skipped', 'failures', 'errors')}
    assert value['failures'] == value['errors'] == 0, (name, value)
    value['non_skipped_xml_cases'] = value['tests'] - value['skipped']
    value['pytest_summary'] = re.findall(r'\d+ passed, [^\n]+', (ROOT / log).read_text())[-1]
    return value

def observed(name):
    value = read(name + '/result.json')
    assert value['process_returncode'] == 0 and value['exit_observed'] and value['completed_successfully'], value
    return value

def owned_processes():
    result = []
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            args = (path / 'cmdline').read_bytes().split(b'\0')
            names = {Path(a.decode(errors='replace')).name for a in args}
            if names & {'publication-motion-soak.py', 'process_supervisor.py', 'architecture_parity.py',
                        'check-checkpoint-memory.py', 'checkpoint-memory-probe.py'}:
                if any(str(ROOT).encode() in a for a in args):
                    result.append(int(path.name))
        except (OSError, ValueError):
            pass
    return result

def audit_static():
    selected, release, baseline, historical = (read(n) for n in
        ('selected-source-hashes.json', 'selected-release-hashes.json', 'baseline-hashes.json', 'history-hashes.json'))
    current = {str(p.relative_to(REPO)): sha(p) for p in (REPO / 'src/embodiedforge').rglob('*.py')}
    assert current == selected, 'Production files differ from validated source'
    for name, digest in release.items():
        assert sha(REPO / name) == digest, name
    for name, digest in baseline.items():
        assert sha(ROOT / 'baseline' / name) == digest, name
    for name, digest in historical.items():
        assert sha(REPO / name) == digest, name
    for name in ('supermimic', 'pyproject.toml', 'MANIFEST.in',
                 'src/embodiedforge/locomotion/go1_ppo.py', 'src/embodiedforge/locomotion/h1_ppo.py',
                 'src/embodiedforge/training.py'):
        assert sha(REPO / name) == baseline[name], name
    resources = read('selected-resource-hashes.json')
    assert all(sha(REPO / n) == h for n, h in resources.items()), 'Package resources changed'
    model = read('preserved-model.json')
    assert sha(REPO / 'runs/supermimic/tasks/backflip/reference/current.json') == model['registry_sha256']
    assert sha(REPO / model['registry']['checkpoint']) == model['registry']['checkpoint_sha256']
    distribution = read('distribution-validation.json')
    assert not distribution['removed_members'] and not distribution['added_members']
    for label in ('before', 'after', 'wheel'):
        assert distribution[label]['actual_build_wait_returncode'] == 0
        assert sha(distribution[label]['path']) == distribution[label]['sha256']
    archive = read('release-source-validation.json')
    assert archive['all_selected_release_files_exact'] == len(release)
    assert archive['source_archive_sha256'] == distribution['after']['sha256']
    assert set(read('style-check-exits.json')['actual_child_waits'].values()) == {0}
    fingerprints = read('compatibility-validation.json')
    for key in ('stable_outputs_exact', 'cleanup_priority_reproduced_and_fixed',
                'motion_close_partial_reproduced_and_fixed', 'existing_private_destination_preserved',
                'fifo_substitution_reproduced_and_fixed'):
        assert fingerprints[key], key
    wheel = read('installed-wheel-validation.json')
    assert wheel['stdlib_checkpoint_entry'] and wheel['all_fixture_scenarios_passed']
    memory = read('checkpoint-memory-validation.json')
    assert memory['serialized_checkpoint_bytes_exact']
    assert all(v['actual_child_wait_returncode'] == 0 for row in memory['results'].values() for v in row.values())
    parity = read('training-parity/summary.json')
    assert len(parity['comparisons']) == 9 and all(x['match'] for x in parity['comparisons'])
    backflip = json.loads((RUN / 'final-backflip-acceptance/result.json').read_text())
    assert backflip['checkpoint_sha256'] == model['registry']['checkpoint_sha256']
    physical = backflip['physical_quality']
    assert len(physical['checks']) == 16 and all(physical['checks'].values())
    assert physical['ported_quality_passed'] and not physical['strict_v14_equivalence'] and not physical['physical_robot_tested']
    supervisors = {n: observed(n) for n in ('final-main-supervisor', 'final-native-supervisor', 'source-supervisor',
                                          'parity-supervisor', 'final-backflip-supervisor', 'final-probe-supervisor')}
    tests = {label: test_result(xml, log) for label, xml, log in (
        ('main', 'final-main-tests.xml', 'final-main-supervisor/command.log'),
        ('native', 'final-native-tests.xml', 'final-native-supervisor/command.log'),
        ('source_release', 'source-tests.xml', 'source-supervisor/command.log'))}
    return {'selected_modules': len(selected), 'selected_release_files': len(release),
            'historical_files_preserved': len(historical), 'package_resources_preserved': len(resources), 'tests': tests,
            'supervised_validation': supervisors, 'current_owned_jobs': owned_processes()}

def full_report():
    static = audit_static()
    soak = read('soak-final/summary.json')
    assert soak['status'] == 'complete' and soak['seconds'] >= 16200
    assert len(set(soak['scenario_counts_including_warmup'].values())) == 1
    assert set(soak['scenario_counts_including_warmup'].values()) == {soak['cycles'] + soak['warmup_cycles']}
    static['soak_supervisor'] = observed('soak-final-supervisor')
    assert not static['current_owned_jobs'], static['current_owned_jobs']
    state = read('work-state.json')
    for name in ('main_original', 'native_original', 'source_original', 'parity_original',
                 'backflip_final_original', 'distribution_original', 'memory_original', 'final_compatibility_original', 'wheel_original', 'soak_original'):
        assert state[name]['observed_exit'] == 0, (name, state[name])
    static['observed_original_exits'] = {k: v for k, v in state.items() if k.endswith('_original')}
    memory = read('checkpoint-memory-validation.json')
    backflip = json.loads((RUN / 'final-backflip-acceptance/result.json').read_text())
    control = read('control.json')
    now = datetime.now(timezone.utc)
    result = {'status': 'validated_awaiting_requested_deadline', 'objective': control['objective'],
              'started_at': control['started_at'], 'requested_deadline': control['deadline'],
              'audited_at': now.isoformat(),
              'elapsed_seconds': (now-datetime.fromisoformat(control['started_at'])).total_seconds(),
              'changes': [
                  'Reuse runtime stream hashing for motion imports/loaders and source provenance; keep file descriptors, digest fields and array precision unchanged.',
                  'Microduck checkpoints and motion output cleanup reuse the existing runtime artifacts helper; preserve active save errors when deletion is interrupted.',
                  'Catch motion stream-close failures after owning a new output, remove the partial file and allow retry; preserve existing exclusive-create behavior.',
                  'Go1 recorded implementation copies hash the same bounded regular source read and independently verify destination bytes; logical content passes drop from three to two per file.',
                  'Go1 private implementation targets reject preexisting files and substituted FIFOs instead of overwriting private source or blocking in a hash read.'
              ],
              'metrics': read('source-change-summary.json'),
              'validation': {**static, 'sustained_fixture': soak,
                             'file_compatibility_controls': {k:v for k,v in read('compatibility-validation.json').items() if k!='results'},
                             'checkpoint_memory': memory,
                             'resource_observations': read('soak-resource-observations.json'),
                             'backflip': {'ported_checks_passed': 16, 'checkpoint_sha256': backflip['checkpoint_sha256'],
                                          'strict_v14_equivalence': False, 'physical_robot_tested': False}},
              'distribution': read('distribution-validation.json'), 'preserved_model': read('preserved-model.json'),
              'preserved': ['Training and evaluation commands, dependency declarations, learner/MDP implementations and checkpoint schemas.',
                            'All preexisting historical evidence and registered backflip model bytes.',
                            'Preexisting unrelated workspace changes; no reset, commit, push or foreign-process termination.'],
              'scope_limits': ['Memory controls found no allocation improvement for the original with_name temporary paths. Path construction remains unchanged; no RSS, GPU memory or training speed gain is claimed.',
                               'The sustained fixture uses valid NPZ data, tiny CPU Adam checkpoints and source-copy/file faults; it does not train a robot policy.',
                               'One G1 evaluation verifies current ported gates; prior GPU run-to-run variation remains and bitwise GPU repeatability is not claimed.',
                               'No strict IsaacLab3 V14 equivalence, independent-seed learning improvement or physical-robot success is claimed.',
                               'Source package archive exclusion was retained from earlier work; no new package-size reduction is claimed.']}
    return result

def evidence(report):
    paths = []
    excluded_prefixes = ('baseline/', 'release-source/', 'source-release/', 'installed-wheel/',
                         'shared-fixtures/', 'shared-fixtures-final/', 'soak/work/', 'soak-final/work/',
                         'soak-probe/work/', 'final-probe/work/')
    for path in ROOT.rglob('*'):
        if not path.is_file() or path.is_symlink():
            continue
        name = str(path.relative_to(ROOT))
        if name.startswith(excluded_prefixes) or '-fixtures/' in name or '__pycache__' in path.parts:
            continue
        if path.suffix in ('.json', '.jsonl', '.py', '.xml', '.log', '.txt', '.patch'):
            paths.append(('session/' + name, path))
    # Current distribution only: baseline archive retained privately, not nested here.
    for label in ('after', 'wheel'):
        path = Path(report['distribution'][label]['path'])
        paths.append(('release/' + path.name, path))
    for name in report['metrics']['changed_files']:
        paths.append(('selected/' + name, REPO / name))
        paths.append(('before/' + name, ROOT / 'baseline' / name))
    for path in (RUN / 'final-backflip-acceptance').rglob('*'):
        if path.is_file() and path.suffix in ('.json', '.log'):
            paths.append(('backflip/' + str(path.relative_to(RUN / 'final-backflip-acceptance')), path))
    entries = {name: {'sha256': sha(path), 'bytes': path.stat().st_size} for name, path in paths}
    assert len(entries) == len(paths)
    bundle = REPO / 'docs/experiments' / (STEM + '-evidence.tar.gz')
    assert not bundle.exists()
    with tarfile.open(bundle, 'w:gz') as tar:
        for name, path in sorted(paths):
            tar.add(path, arcname=name, recursive=False)
        payload = (json.dumps(entries, indent=2) + '\n').encode()
        info = tarfile.TarInfo('manifest.json'); info.size = len(payload)
        tar.addfile(info, io.BytesIO(payload))
    with tarfile.open(bundle, 'r|gz') as tar:
        actual, restored = {}, None
        for member in tar:
            assert member.isfile()
            stream = tar.extractfile(member)
            if member.name == 'manifest.json':
                assert restored is None
                restored = json.load(stream)
                continue
            assert member.name not in actual
            digest, size = hashlib.sha256(), 0
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(block)
                size += len(block)
            actual[member.name] = {'sha256': digest.hexdigest(), 'bytes': size}
        assert restored == entries and actual == entries
    return {'path': str(bundle.relative_to(REPO)), 'bytes': bundle.stat().st_size,
            'sha256': sha(bundle), 'verified_manifest_members': len(entries)}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--static', action='store_true')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    if args.static:
        print(json.dumps(audit_static(), indent=2)); return
    report = full_report()
    if args.dry_run:
        write(ROOT / 'report-draft.json', report)
        print('All validation passed; waiting for requested five-hour deadline.'); return
    now = datetime.now(timezone.utc)
    assert now >= datetime.fromisoformat(read('control.json')['deadline']), 'Requested five-hour window is still active'
    report['status'] = 'complete'
    report['published_at'] = now.isoformat()
    report['elapsed_seconds'] = (now-datetime.fromisoformat(report['started_at'])).total_seconds()
    # The draft is evidence; the final report hash is recorded separately to avoid circularity.
    write(ROOT / 'report-draft.json', report)
    report['evidence_bundle'] = evidence(report)
    output = REPO / 'docs/experiments' / (STEM + '.json')
    assert not output.exists()
    write(output, report)
    write(RUN / 'optimization.json', report)
    audit_static()
    assert not owned_processes()
    write(ROOT / 'publication-verification.json', {'status':'complete','report':str(output),
         'report_sha256':sha(output),'bundle':report['evidence_bundle'],
         'owned_processes_absent':True,'verified_at':datetime.now(timezone.utc).isoformat()})
    print(json.dumps({'report':str(output),'bundle':report['evidence_bundle']}))

if __name__ == '__main__':
    main()
