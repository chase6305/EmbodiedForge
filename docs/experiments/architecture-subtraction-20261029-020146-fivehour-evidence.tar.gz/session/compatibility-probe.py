"""SDK-free legacy/current file identity and publication fault controls."""
import hashlib
import json
import logging
import os
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace
import uuid

source, output, fixtures = map(Path,sys.argv[1:4])
mode=sys.argv[4]
sys.path.insert(0,str(source))
from embodiedforge import _motion_clips as motion
from embodiedforge import _go1_implementation as go1
from embodiedforge.locomotion.microduck import checkpoint as micro
from embodiedforge.runtime.implementation import component
import numpy as np
logging.disable(logging.CRITICAL)
output.mkdir(parents=True)
record=json.loads((fixtures/'manifest.json').read_text())
result={'mode':mode,'source':str(source)}
if mode=='stable':
 import torch
 torch.set_num_threads(1)
 library=motion.import_weave(fixtures/'weave.npz',json.loads((fixtures/'layout.json').read_text()))
 target=output/'library.npz'
 library.save(target)
 loaded=motion.MotionClips.load(target)
 result['motion_metadata']=loaded.metadata
 result['motion_sha256']=loaded.sha256
 result['motion_arrays']={k:hashlib.sha256(v.tobytes()).hexdigest() for k,v in loaded.arrays.items()}
 micro.uuid4=lambda:uuid.UUID(int=37)
 payload={'iteration':17,'weights':torch.arange(8,dtype=torch.float32)}
 micro.atomic_save(lambda path,infos:torch.save({**payload,'infos':infos},path),output/'model.pt',{'counter':42})
 restored=torch.load(output/'model.pt',weights_only=True)
 assert restored['infos']=={'counter':42} and torch.equal(restored['weights'],payload['weights'])
 result['checkpoint_sha256']=hashlib.sha256((output/'model.pt').read_bytes()).hexdigest()
 counts={'source_hashes':0,'copies':0,'target_hashes':0}
 old_hash=go1.sha256
 def count_hash(path):
  counts['source_hashes' if Path(path).is_relative_to(fixtures/'run') else 'target_hashes']+=1
  return old_hash(path)
 go1.sha256=count_hash
 if hasattr(go1,'copy_file_snapshot'):
  original_copy=go1.copy_file_snapshot
  def copy(*args,**kwargs):
   counts['copies']+=1
   return original_copy(*args,**kwargs)
  go1.copy_file_snapshot=copy
 else:
  original_copy=go1.shutil.copyfile
  def copy(*args,**kwargs):
   counts['copies']+=1
   return original_copy(*args,**kwargs)
  go1.shutil.copyfile=copy
 copied=go1.copy_go1_implementation(fixtures/'run',record,output/'private')
 result['implementation_files']=copied['files']
 result['logical_content_passes']=counts
 module=ModuleType('stable_fixture_component');module.__file__=str(fixtures/'component.py')
 result['component']=component(module)
elif mode=='cleanup-interrupt':
 target=output/'model.pt';target.write_bytes(b'previous')
 primary=OSError('original checkpoint save failure')
 unlink,path_unlink=os.unlink,Path.unlink
 def cleanup(*args,**kwargs):raise KeyboardInterrupt('cleanup interrupted')
 def save(path,infos):
  with open(path,'wb') as f:f.write(b'partial')
  raise primary
 try:
  os.unlink,Path.unlink=cleanup,cleanup
  try:micro.atomic_save(save,target)
  except BaseException as error:result.update(primary_preserved=error is primary,observed_error=type(error).__name__)
 finally:os.unlink,Path.unlink=unlink,path_unlink
 result['previous_intact']=target.read_bytes()==b'previous'
elif mode=='motion-close':
 library=motion.import_weave(fixtures/'weave.npz',json.loads((fixtures/'layout.json').read_text()))
 target=output/'close.npz'
 original=Path.open
 primary=OSError('original close failure')
 class FailedClose:
  def __init__(self,stream):self.stream=stream
  def __enter__(self):return self.stream
  def __exit__(self,*args):
   self.stream.close()
   raise primary
 def failing(path,*args,**kwargs):
  stream=original(path,*args,**kwargs)
  return FailedClose(stream) if path==target else stream
 try:
  Path.open=failing
  try:library.save(target)
  except OSError as error:result['primary_preserved']=error is primary
 finally:Path.open=original
 result['owned_partial_removed']=not target.exists()
elif mode=='fifo-substitution':
 original_is_file=Path.is_file
 target=fixtures/'run/implementation/locomotion/go1.py'
 original_bytes=target.read_bytes()
 injected=False
 def is_file(path):
  global injected
  value=original_is_file(path)
  if path==target and not injected:
   injected=True;path.unlink();os.mkfifo(path);(output/'ready').touch()
  return value
 try:
  Path.is_file=is_file
  try:go1.copy_go1_implementation(fixtures/'run',record,output/'private')
  except ValueError as error:result.update(rejected=True,error=str(error))
 finally:
  Path.is_file=original_is_file
  target.unlink();target.write_bytes(original_bytes)
elif mode=='existing-destination':
 target=output/'private/locomotion/go1.py';target.parent.mkdir(parents=True);target.write_bytes(b'previous private source')
 try:go1.copy_go1_implementation(fixtures/'run',record,output/'private')
 except FileExistsError:result['rejected']=True
 result['previous_intact']=target.read_bytes()==b'previous private source'
else:raise ValueError(mode)
(output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
