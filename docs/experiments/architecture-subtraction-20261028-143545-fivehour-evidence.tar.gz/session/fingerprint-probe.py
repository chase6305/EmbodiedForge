"""Probe saved fingerprint compatibility and two original failure windows."""
import json
import os
from pathlib import Path
import sys

source, output = map(Path, sys.argv[1:3])
mode = sys.argv[3]
sys.path.insert(0, str(source))
from embodiedforge import _act_dataset as dataset
from embodiedforge import _act_checkpoints as checkpoints
from embodiedforge.runtime import artifacts

output.mkdir(parents=True)
data = output / 'dataset'
model = output / 'model'
model.mkdir()
for name, content in {'embodiedforge.json': b'{}', 'meta/info.json': b'{"fps":50}',
                      'data/episode.parquet': b'fixed data bytes'}.items():
    path = data / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content)
for name, content in {'config.json': b'{}', 'model.safetensors': b'fixed weights',
                      'stats.bin': b'fixed processor state', 'replacement.bin': b'other state',
                      'policy_preprocessor.json': b'{"steps":[{"state_file":"stats.bin"}]}',
                      'policy_postprocessor.json': b'{"steps":[]}'}.items():
    (model / name).write_bytes(content)
result = {'mode': mode, 'source': str(source)}
if mode == 'stable':
    result.update(dataset=dataset.fingerprint_dataset(data), checkpoint=checkpoints.inference_fingerprint(model))
    target = output / 'cached-weights'
    (model / 'model.safetensors').rename(target)
    (model / 'model.safetensors').symlink_to(target)
    result['linked_checkpoint'] = checkpoints.inference_fingerprint(model)
elif mode == 'processor-change':
    original = json.loads
    injected = False
    def mutate(payload, *args, **kwargs):
        global injected
        value = original(payload, *args, **kwargs)
        if not injected and isinstance(value, dict) and 'steps' in value:
            injected = True
            (model / 'policy_preprocessor.json').write_text('{"steps":[{"state_file":"replacement.bin"}]}')
        return value
    json.loads = mutate
    try:
        result['fingerprint'] = checkpoints.inference_fingerprint(model)
        result['rejected'] = False
    except ValueError as error:
        result.update(rejected=True, error=str(error))
    finally:
        json.loads = original
elif mode == 'cleanup-interrupt':
    path = output / 'run.json'
    artifacts.write_json(path, {'status': 'running'})
    primary = OSError('original publication failure')
    replace, unlink = os.replace, os.unlink
    def fail_replace(*args):
        raise primary
    def fail_unlink(*args):
        raise KeyboardInterrupt('interrupted cleanup')
    try:
        os.replace, os.unlink = fail_replace, fail_unlink
        try:
            artifacts.write_json(path, {'status': 'complete'})
        except BaseException as error:
            result.update(primary_preserved=error is primary, observed_error_type=type(error).__name__)
    finally:
        os.replace, os.unlink = replace, unlink
    result['previous_record_intact'] = json.loads(path.read_text()) == {'status': 'running'}
elif mode == 'fifo-substitution':
    files = dataset._files(data)
    target = data / 'data/episode.parquet'
    target.unlink()
    os.mkfifo(target)
    dataset._files = lambda _: files
    (output / 'ready').touch()
    try:
        dataset.fingerprint_dataset(data)
    except ValueError as error:
        result.update(rejected=True, error=str(error))
else:
    raise ValueError(mode)
(output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
