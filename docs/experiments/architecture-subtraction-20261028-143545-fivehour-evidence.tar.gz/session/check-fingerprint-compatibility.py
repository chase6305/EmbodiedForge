"""Compare unchanged formats and observe old/new failure behavior in isolation."""
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).parent
repo = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
results = {}
for label, source in [('baseline', root / 'baseline/src'), ('candidate', repo / 'src')]:
    results[label] = {}
    for mode in ('stable', 'processor-change', 'cleanup-interrupt', 'fifo-substitution'):
        output = root / 'fingerprint-probes' / f'{label}-{mode}'
        with (root / f'fingerprint-{label}-{mode}.log').open('x') as log:
            child = subprocess.Popen([sys.executable, '-I', str(root / 'fingerprint-probe.py'),
                                      str(source), str(output), mode], stdout=log,
                                     stderr=subprocess.STDOUT, start_new_session=True)
            timed_out = False
            try:
                code = child.wait(timeout=3 if mode == 'fifo-substitution' else 20)
            except subprocess.TimeoutExpired:
                timed_out = True
                child.kill()
                code = child.wait()
        if timed_out:
            assert label == 'baseline' and mode == 'fifo-substitution' and (output / 'ready').exists()
            observed = {'blocked_on_substituted_fifo': True, 'actual_child_wait_returncode': code,
                        'owned_child_killed_after_timeout': True}
        else:
            assert code == 0, (label, mode, code)
            observed = {**json.loads((output / 'result.json').read_text()), 'actual_child_wait_returncode': code}
        results[label][mode] = observed
for name in ('dataset', 'checkpoint', 'linked_checkpoint'):
    assert results['baseline']['stable'][name] == results['candidate']['stable'][name], name
assert not results['baseline']['processor-change']['rejected']
assert results['candidate']['processor-change']['rejected']
assert not results['baseline']['cleanup-interrupt']['primary_preserved']
assert results['candidate']['cleanup-interrupt']['primary_preserved']
assert results['baseline']['fifo-substitution']['blocked_on_substituted_fifo']
assert results['candidate']['fifo-substitution']['rejected']
summary = {'stable_fingerprints_exact': True, 'linked_checkpoint_support_preserved': True,
           'processor_race_reproduced_and_fixed': True, 'cleanup_error_priority_reproduced_and_fixed': True,
           'fifo_blocking_reproduced_and_fixed': True, 'results': results,
           'scope': 'SDK-free fixture fingerprints and real file/process behavior; no ACT training or policy inference.'}
(root / 'fingerprint-compatibility.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k: v for k, v in summary.items() if k != 'results'}))
