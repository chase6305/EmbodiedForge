"""Read-only selected-release and sustained-fixture observer; never signals jobs."""
from datetime import datetime,timezone
import hashlib,json,time
from pathlib import Path
root=Path(__file__).parent
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge')
selected=json.loads((root/'selected-source-hashes.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
current={str(p.relative_to(repo)):sha(p) for p in (repo/'src/embodiedforge').rglob('*.py')}
assert current==selected,'Production files changed after validation'
release=json.loads((root/'selected-release-hashes.json').read_text())
assert all(sha(repo/n)==h for n,h in release.items()),'Selected release changed'
resources=json.loads((root/'selected-resource-hashes.json').read_text())
assert all(sha(repo/n)==h for n,h in resources.items()),'Package resources changed'
model=json.loads((root/'preserved-model.json').read_text())
assert sha(repo/'runs/supermimic/tasks/backflip/reference/current.json')==model['registry_sha256']
samples=root/'soak/samples.jsonl'
sample=json.loads(samples.read_text().splitlines()[-1])
summary_path=root/'soak/summary.json'
assert summary_path.exists() or time.time()-samples.stat().st_mtime<120,'Sustained fixture stopped publishing samples'
record={'utc':datetime.now(timezone.utc).isoformat(),'modules_frozen':len(current),'release_files_frozen':len(release),
        'soak_minutes':round(sample['seconds']/60,1),'scenarios':sum(sample['counts'].values()),
        'threads':sample['Threads'],'fds':sample['fds'],'rss':sample['VmRSS'],'traced_bytes':sample['traced_bytes'],
        'summary_ready':summary_path.exists()}
result=root/'soak-supervisor/result.json'
if result.exists():
 value=json.loads(result.read_text())
 assert value['exit_observed'] and value['process_returncode']==0 and value['completed_successfully'],value
if summary_path.exists():
 summary=json.loads(summary_path.read_text())
 assert summary['status']=='complete' and summary['seconds']>=14400
 record.update(soak_minutes=round(summary['seconds']/60,2),scenarios=sum(summary['scenario_counts_including_warmup'].values()),final_resources=summary['final_resources'])
with (root/'freeze-watch.jsonl').open('a') as stream:
 stream.write(json.dumps(record)+'\n')
print(json.dumps(record))
