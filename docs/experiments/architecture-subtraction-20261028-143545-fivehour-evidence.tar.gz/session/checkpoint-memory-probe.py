"""Measure retained Python allocations in real Go1 receipt/checkpoint writes."""
import gc
import json
import os
from pathlib import Path
import sys
import tracemalloc

source, output = map(Path, sys.argv[1:3])
count = int(sys.argv[3])
sys.path.insert(0, str(source))
import torch
from embodiedforge._go1_recovery import publish_training_checkpoint

torch.set_num_threads(1)
output.mkdir(parents=True)
os.chdir(output)
for name in ('runtime.json', 'assets.json', 'request.json'):
    Path(name).write_text('{}')
parameter = torch.nn.Parameter(torch.ones(1))
optimizer = torch.optim.Adam([parameter])
parameter.grad = torch.ones(1)
optimizer.step()
request = {'start_iteration': 0}
checkpoint = {'optimizer_state_dict': optimizer.state_dict(),
              'model_state_dict': {'mean': torch.zeros(50), 'var': torch.ones(50),
                                   'count': torch.tensor(1.), 'log_std': torch.zeros(12)},
              'task_semantics': 'transition-v2', 'reward_profile': 'original',
              'command_profile': 'original', 'learning_rate_override': None}
def publish(index):
    checkpoint['iteration'] = index
    publish_training_checkpoint(checkpoint, optimizer=optimizer, request=request)
for i in range(64):
    publish(i)
gc.collect()
tracemalloc.start()
before = tracemalloc.get_traced_memory()[0]
for i in range(64, 64 + count):
    publish(i)
gc.collect()
after, peak = tracemalloc.get_traced_memory()
snapshot = tracemalloc.take_snapshot()
receipt = json.loads(Path('recovery.json').read_text())
saved = torch.load(receipt['result']['checkpoint'], map_location='cpu', weights_only=True)
assert saved['iteration'] == 63 + count
result = {'python': sys.version, 'source': str(source), 'iterations': count,
          'retained_python_bytes': after - before, 'peak_traced_bytes': peak,
          'last_iteration': saved['iteration'],
          'checkpoint_snapshots_retained': len(os.listdir('checkpoints')),
          'top_allocations': [str(x) for x in snapshot.statistics('lineno')[:10]]}
Path('probe.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
