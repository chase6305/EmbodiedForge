"""Private sustained CPU publication/fingerprint fault acceptance; no robot training."""
import builtins
import errno
import gc
import hashlib
import json
import logging
import os
from pathlib import Path
import shutil
import signal
import sys
import time
import tracemalloc
from datetime import datetime, timezone

source, destination = map(Path, sys.argv[1:3])
seconds = float(sys.argv[3])
sys.path.insert(0, str(source))
import torch
from embodiedforge import _act_dataset as dataset, _act_checkpoints as act
from embodiedforge import _go1_recovery as recovery
from embodiedforge._go1_implementation import _REQUIRED
from embodiedforge.runtime import artifacts
from embodiedforge.runtime.hashing import file_sha256
from embodiedforge.runtime.process import termination_signals, ProcessInterrupted

torch.set_num_threads(1)
logging.disable(logging.CRITICAL)
destination.mkdir(parents=True)
shutil.copyfile(__file__, destination / 'probe-source.py')
work = destination / 'work'
work.mkdir()
os.chdir(work)
request = {'start_iteration': 0, 'updates': 100000000, 'go1_semantics': 'transition-v2',
           'go1_reward_profile': 'original', 'go1_command_profile': 'original',
           'go1_learning_rate': None}
for name, value in [('request', request), ('runtime', {}), ('assets', {})]:
    artifacts.write_json(name + '.json', value)
implementation = {}
for name in _REQUIRED:
    target = work / 'implementation' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source / 'embodiedforge' / name, target)
    implementation[name] = file_sha256(target)
manifest = {'status': 'interrupted', 'recipe': 'go1-joystick', 'request': request,
            'implementation': {'path': 'implementation', 'files': implementation}}
parameter = torch.nn.Parameter(torch.ones(1))
optimizer = torch.optim.Adam([parameter])
parameter.grad = torch.ones(1)
optimizer.step()
checkpoint = {'optimizer_state_dict': optimizer.state_dict(),
              'model_state_dict': {'mean': torch.zeros(50), 'var': torch.ones(50),
                                   'count': torch.tensor(1.), 'log_std': torch.zeros(12)},
              'task_semantics': 'transition-v2', 'reward_profile': 'original',
              'command_profile': 'original', 'learning_rate_override': None}
data = work / 'dataset'
for name, content in {'embodiedforge.json': b'{}', 'meta/info.json': b'{"fps":50}',
                      'data/episode.parquet': b'fixed data bytes'}.items():
    target = data / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
model = work / 'act-model'
model.mkdir()
for name, content in {'config.json': b'{}', 'model.safetensors': b'fixed weights',
                      'stats.bin': b'fixed processor state', 'replacement.bin': b'other state',
                      'policy_preprocessor.json': b'{"steps":[{"state_file":"stats.bin"}]}',
                      'policy_postprocessor.json': b'{"steps":[]}'}.items():
    (model / name).write_bytes(content)
weights = work / 'cached-weights'
(model / 'model.safetensors').rename(weights)
(model / 'model.safetensors').symlink_to(weights)
expected_data = dataset.fingerprint_dataset(data)
expected_act = act.inference_fingerprint(model)
selector = model / 'policy_preprocessor.json'
selector_bytes = selector.read_bytes()
leaf = data / 'data/episode.parquet'
leaf_bytes = leaf.read_bytes()
iteration = 0
counts = dict.fromkeys(['stable_fingerprints', 'selector_mutation', 'fifo_substitution',
                       'checkpoint_publish', 'receipt_failure', 'signal_during_alias',
                       'checkpoint_write_failure', 'actual_enospc'], 0)

def publish():
    global iteration
    iteration += 1
    checkpoint['iteration'] = iteration
    recovery.publish_training_checkpoint(checkpoint, optimizer=optimizer, request=request)

def read(name):
    with open(name, 'rb') as stream:
        return stream.read()

def verified():
    value = json.loads(read('recovery.json'))['result']
    assert file_sha256(value['checkpoint']) == value['checkpoint_sha256']
    saved = torch.load(value['checkpoint'], weights_only=True, map_location='cpu')
    assert saved['iteration'] == value['checkpoint_iteration']
    assert value['completed_updates'] == saved['iteration'] + 1
    return value

def cleanup_owned():
    # The fault injection deliberately prevented removal of these private files.
    for directory in ('.', 'checkpoints'):
        with os.scandir(directory) as entries:
            leftovers = [entry.path for entry in entries if entry.name.endswith('.tmp')]
        for path in leftovers:
            os.unlink(path)

def cleanup_failure(*args, **kwargs):
    raise [KeyboardInterrupt('cleanup'), SystemExit(3), PermissionError('cleanup')][iteration % 3]

def cycle():
    assert dataset.fingerprint_dataset(data) == expected_data
    assert act.inference_fingerprint(model) == expected_act
    counts['stable_fingerprints'] += 1
    loads = json.loads
    injected = False
    def changed(payload, *args, **kwargs):
        nonlocal injected
        value = loads(payload, *args, **kwargs)
        if not injected and isinstance(value, dict) and 'steps' in value:
            injected = True
            selector.write_bytes(b'{"steps":[{"state_file":"replacement.bin"}]}')
        return value
    try:
        json.loads = changed
        try:
            act.inference_fingerprint(model)
        except ValueError as error:
            assert 'Checkpoint changed while fingerprinting' in str(error)
        else:
            raise AssertionError('changed selector accepted')
    finally:
        json.loads = loads
        selector.write_bytes(selector_bytes)
    counts['selector_mutation'] += 1
    files, original_files = dataset._files(data), dataset._files
    try:
        leaf.unlink()
        os.mkfifo(leaf)
        dataset._files = lambda _: files
        try:
            dataset.fingerprint_dataset(data)
        except ValueError as error:
            assert 'Dataset changed while computing fingerprint' in str(error)
        else:
            raise AssertionError('FIFO accepted')
    finally:
        dataset._files = original_files
        leaf.unlink()
        leaf.write_bytes(leaf_bytes)
    counts['fifo_substitution'] += 1
    publish()
    good = verified()
    assert read('model.pt') == read(good['checkpoint'])
    assert len(os.listdir('checkpoints')) == 2
    counts['checkpoint_publish'] += 1
    previous_receipt, previous_alias = read('recovery.json'), read('model.pt')
    primary = OSError('injected receipt rename error')
    replace, unlink = os.replace, os.unlink
    def fail_receipt(src, dst, *args, **kwargs):
        if os.fspath(dst) == 'recovery.json':
            raise primary
        return replace(src, dst, *args, **kwargs)
    try:
        os.replace, os.unlink = fail_receipt, cleanup_failure
        try:
            publish()
        except BaseException as error:
            assert error is primary
        else:
            raise AssertionError('receipt failure accepted')
    finally:
        os.replace, os.unlink = replace, unlink
        cleanup_owned()
    assert read('recovery.json') == previous_receipt
    assert read('model.pt') == previous_alias
    verified()
    counts['receipt_failure'] += 1
    copyfile = shutil.copyfile
    def terminate_alias(src, dst, *args, **kwargs):
        result = copyfile(src, dst, *args, **kwargs)
        if os.fspath(dst) == 'model.pt.tmp':
            os.kill(os.getpid(), signal.SIGTERM)
        return result
    try:
        shutil.copyfile, os.unlink = terminate_alias, cleanup_failure
        with termination_signals():
            try:
                publish()
            except ProcessInterrupted as error:
                assert error.signum == signal.SIGTERM
            else:
                raise AssertionError('real SIGTERM not observed')
    finally:
        shutil.copyfile, os.unlink = copyfile, unlink
        cleanup_owned()
    assert read('model.pt') == previous_alias
    assert verified()['checkpoint_iteration'] == iteration
    counts['signal_during_alias'] += 1
    previous_receipt = read('recovery.json')
    save = torch.save
    primary = OSError('injected checkpoint write error')
    def fail_save(*args, **kwargs):
        save(*args, **kwargs)
        raise primary
    try:
        torch.save, os.unlink = fail_save, cleanup_failure
        try:
            publish()
        except BaseException as error:
            assert error is primary
        else:
            raise AssertionError('checkpoint failure accepted')
    finally:
        torch.save, os.unlink = save, unlink
        cleanup_owned()
    assert read('recovery.json') == previous_receipt
    assert read('model.pt') == previous_alias
    verified()
    counts['checkpoint_write_failure'] += 1
    artifacts.write_json('full-record.json', {'status': 'previous'})
    old_full, original_open = read('full-record.json'), builtins.open
    def full_file(path, mode='r', *args, **kwargs):
        if os.path.basename(os.fspath(path)).startswith('full-record.json.') and mode == 'x':
            return original_open('/dev/full', 'w', *args, **kwargs)
        return original_open(path, mode, *args, **kwargs)
    try:
        builtins.open = full_file
        try:
            artifacts.write_json('full-record.json', {'status': 'new'})
        except OSError as error:
            assert error.errno == errno.ENOSPC
        else:
            raise AssertionError('ENOSPC not observed')
    finally:
        builtins.open = original_open
    assert read('full-record.json') == old_full
    counts['actual_enospc'] += 1

def resources():
    values = {}
    with open('/proc/self/status') as stream:
        for line in stream:
            if line.startswith(('VmRSS:', 'Threads:')):
                key, value = line.split(':', 1)
                values[key] = value.strip()
    values['fds'] = len(os.listdir('/proc/self/fd'))
    values['traced_bytes'], values['traced_peak'] = tracemalloc.get_traced_memory()
    return values

# Establish at least two valid versions before the first success assertion.
publish()
publish()
for _ in range(8):
    cycle()
gc.collect()
tracemalloc.start()
started = time.monotonic()
started_at = datetime.now(timezone.utc).isoformat()
initial = resources()
cycles = 0
last_sample = started - 60
with open(destination / 'samples.jsonl', 'x') as samples:
    while time.monotonic() - started < seconds:
        cycle()
        cycles += 1
        now = time.monotonic()
        if now - last_sample >= 60:
            assert recovery.recovery_result(work, manifest) == verified()
            gc.collect()
            samples.write(json.dumps({'seconds': now - started, 'cycles': cycles,
                                      'counts': counts, **resources()}) + '\n')
            samples.flush()
            last_sample = now
        time.sleep(.25)
assert recovery.recovery_result(work, manifest) == verified()
gc.collect()
summary = {'status': 'complete', 'scope': 'private CPU checkpoint publication and ACT file fixtures; no robot training',
           'requested_seconds': seconds, 'seconds': time.monotonic() - started,
           'started_at': started_at, 'finished_at': datetime.now(timezone.utc).isoformat(),
           'cycles': cycles, 'warmup_cycles': 8, 'scenario_counts_including_warmup': counts,
           'initial_resources': initial, 'final_resources': resources(),
           'last_iteration': iteration, 'python': sys.version,
           'probe_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
artifacts.write_json(destination / 'summary.json', summary)
print(json.dumps(summary), flush=True)
