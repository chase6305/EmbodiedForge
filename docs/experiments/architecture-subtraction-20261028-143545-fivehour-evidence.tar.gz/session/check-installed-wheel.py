"""Exercise ACT identity and cleanup using only stdlib from the extracted wheel."""
import json
from pathlib import Path
import subprocess
import sys
root=Path(__file__).parent
wheel=root/'installed-wheel'
results={}
for mode in ('stable','processor-change','cleanup-interrupt','fifo-substitution'):
 output=root/('wheel-'+mode)
 command=[sys.executable,'-I','-S','-c',
          'import runpy,sys;sys.argv=sys.argv[1:];runpy.run_path(sys.argv[0],run_name="__main__");assert not any(n.split(".")[0] in {"torch","numpy","lerobot"} for n in sys.modules)',
          str(root/'fingerprint-probe.py'),str(wheel),str(output),mode]
 with (root/('wheel-'+mode+'.log')).open('x') as log:
  child=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=20)
 assert child.returncode==0,(mode,child.returncode)
 value=json.loads((output/'result.json').read_text())
 value['actual_child_wait_returncode']=child.returncode
 results[mode]=value
baseline=json.loads((root/'fingerprint-compatibility.json').read_text())['results']['baseline']['stable']
assert all(results['stable'][key]==baseline[key] for key in ('dataset','checkpoint','linked_checkpoint'))
assert results['processor-change']['rejected']
assert results['cleanup-interrupt']['primary_preserved'] and results['cleanup-interrupt']['previous_record_intact']
assert results['fifo-substitution']['rejected']
summary={'stdlib_only':True,'all_fixture_scenarios_passed':True,'scenarios':results,
         'scope':'Actual extracted wheel ACT fingerprint and JSON publication code; no SDK or ML inference.'}
(root/'installed-wheel-validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print('4 installed-wheel scenarios passed using stdlib only')
