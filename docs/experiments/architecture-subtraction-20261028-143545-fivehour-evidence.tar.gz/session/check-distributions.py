"""Build baseline/current releases, retaining the existing archive exclusion."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import zipfile

repo = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
root = Path(__file__).parent
baseline = root / 'baseline'
stage = root / 'release-source'
stage.mkdir()
for name in ('src', 'tests', 'benchmarks', 'examples', 'configs', 'docs'):
    source = repo / name
    shutil.copytree(source, stage / name,
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '*.egg-info', '*.tar.gz'))
    for path in (stage / name).rglob('*'):
        if path.is_file():
            relative = path.relative_to(stage)
            target = baseline / relative
            if not target.exists():
                # The baseline already owns all original Python/current-guide
                # bytes; fill only its immutable resources and historical docs.
                assert relative.as_posix() not in json.loads((root / 'baseline-hashes.json').read_text())
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, target)
for name in ('pyproject.toml', 'MANIFEST.in', 'README.md', 'README.en.md', 'supermimic'):
    shutil.copy2(repo / name, stage / name)
summary = {}
for label, project in (('before', baseline), ('after', stage)):
    target = root / ('distribution-' + label)
    target.mkdir()
    command = [sys.executable, '-c', 'import setuptools.build_meta as b,sys;print(b.build_sdist(sys.argv[1]))', str(target)]
    with (root / ('distribution-' + label + '-build.log')).open('x') as log:
        child = subprocess.run(command, cwd=project, stdout=log, stderr=subprocess.STDOUT)
    assert child.returncode == 0, (label, child.returncode)
    archive = next(target.glob('*.tar.gz'))
    with tarfile.open(archive) as tar:
        members = tar.getmembers()
        assert not any(m.name.endswith('.tar.gz') for m in members)
    summary[label] = {'actual_build_wait_returncode': child.returncode, 'path': str(archive),
                      'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                      'members': len(members), 'nested_historical_archives': 0}
wheelhouse = root / 'wheel'
wheelhouse.mkdir()
with (root / 'wheel-build.log').open('x') as log:
    child = subprocess.run([sys.executable, '-m', 'pip', 'wheel', '--no-deps', '--no-build-isolation',
                            '--no-cache-dir', '--wheel-dir', str(wheelhouse), str(stage)],
                           cwd=stage, stdout=log, stderr=subprocess.STDOUT)
assert child.returncode == 0
wheel = next(wheelhouse.glob('*.whl'))
modules = {str(p.relative_to(repo / 'src')): hashlib.sha256(p.read_bytes()).hexdigest()
           for p in (repo / 'src/embodiedforge').rglob('*.py')}
installed = root / 'installed-wheel'
retired = ('_microduck_inputs', '_hashing', '_adam_checkpoint', '_ppo_parameters', '_training_runtime', '_microduck_process')
with zipfile.ZipFile(wheel) as opened:
    assert opened.testzip() is None
    for name, sha in modules.items():
        assert hashlib.sha256(opened.read(name)).hexdigest() == sha, name
    assert all('embodiedforge/' + name + '.py' not in opened.namelist() for name in retired)
    opened.extractall(installed)
summary['wheel'] = {'actual_build_wait_returncode': child.returncode, 'path': str(wheel),
                    'bytes': wheel.stat().st_size, 'sha256': hashlib.sha256(wheel.read_bytes()).hexdigest(),
                    'current_modules_exact': len(modules), 'retired_aliases_absent': list(retired),
                    'installed_root': str(installed)}
unpack = root / 'source-release'
unpack.mkdir()
with tarfile.open(summary['after']['path']) as tar:
    for member in tar:
        assert (unpack / member.name).resolve().is_relative_to(unpack.resolve())
        assert member.isfile() or member.isdir()
    tar.extractall(unpack)
summary['source_release_root'] = str(next(unpack.iterdir()))
sets = {}
for label in ('before', 'after'):
    with tarfile.open(summary[label]['path']) as tar:
        sets[label] = {m.name.split('/', 1)[1] for m in tar if m.isfile()}
summary['removed_members'] = sorted(sets['before'] - sets['after'])
summary['added_members'] = sorted(sets['after'] - sets['before'])
assert not summary['removed_members']
assert not summary['added_members']
(root / 'distribution-validation.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
