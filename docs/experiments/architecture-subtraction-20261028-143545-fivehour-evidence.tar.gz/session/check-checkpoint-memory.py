"""Observe two fresh 4000-publication processes and compare serialized bytes."""
import hashlib,json,os
from pathlib import Path
import subprocess
import sys
root=Path(__file__).parent
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge')
interpreter=repo/'.cache/external/mjbatch/.venv/bin/python'
results={}
for label,source in [('baseline',root/'baseline/src'),('candidate',repo/'src')]:
 output=root/('checkpoint-memory-observed-'+label)
 with (root/('checkpoint-memory-observed-'+label+'.log')).open('x') as log:
  child=subprocess.run([str(interpreter),'-I',str(root/'checkpoint-memory-probe.py'),str(source),str(output),'4000'],stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
 assert child.returncode==0,(label,child.returncode)
 value=json.loads((output/'probe.json').read_text())
 value['actual_child_wait_returncode']=child.returncode
 results[label]=value
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
equal={}
for name in ('recovery.json','model.pt','checkpoints/model-000004063.pt'):
 equal[name]=sha(root/'checkpoint-memory-observed-baseline'/name)==sha(root/'checkpoint-memory-observed-candidate'/name)
 assert equal[name],name
report={'results':results,'artifact_bytes_equal':equal,'scope':'Retained Python allocations for fresh CPython3.12.0 CPU checkpoint publication; not RSS, VRAM or robot training throughput.'}
(root/'checkpoint-memory-observed.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({label:v['retained_python_bytes'] for label,v in results.items()}))
