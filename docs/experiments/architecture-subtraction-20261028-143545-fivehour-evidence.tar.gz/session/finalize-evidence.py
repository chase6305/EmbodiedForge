"""Publish this session's subtraction evidence only after its actual five-hour window."""
import argparse
from datetime import datetime, timezone
import difflib
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).parent
REPO = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
STEM = 'architecture-subtraction-20261028-143545-fivehour'
RUN = REPO / 'runs' / STEM

def read(name):
    return json.loads((ROOT / name).read_text())

def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def test_result(name, log):
    suites = ET.parse(ROOT / name).getroot().findall('testsuite')
    value = {k: sum(int(s.attrib[k]) for s in suites)
             for k in ('tests', 'skipped', 'failures', 'errors')}
    assert value['failures'] == value['errors'] == 0, (name, value)
    value['non_skipped_xml_cases'] = value['tests'] - value['skipped']
    value['pytest_summary'] = re.findall(r'\d+ passed, [^\n]+', (ROOT / log).read_text())[-1]
    return value

def observed(name):
    value = read(name + '/result.json')
    assert value['process_returncode'] == 0 and value['exit_observed'] and value['completed_successfully'], value
    return value

def owned_processes():
    result = []
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            args = (path / 'cmdline').read_bytes().split(b'\0')
            names = {Path(a.decode(errors='replace')).name for a in args}
            if names & {'publication-fingerprint-soak.py', 'process_supervisor.py', 'architecture_parity.py',
                        'check-checkpoint-memory.py', 'checkpoint-memory-probe.py'}:
                if any(str(ROOT).encode() in a for a in args):
                    result.append(int(path.name))
        except (OSError, ValueError):
            pass
    return result

def audit_static():
    selected, release, baseline, historical = (read(n) for n in
        ('selected-source-hashes.json', 'selected-release-hashes.json', 'baseline-hashes.json', 'history-hashes.json'))
    current = {str(p.relative_to(REPO)): sha(p) for p in (REPO / 'src/embodiedforge').rglob('*.py')}
    assert current == selected, 'Production files differ from validated source'
    for name, digest in release.items():
        assert sha(REPO / name) == digest, name
    for name, digest in baseline.items():
        assert sha(ROOT / 'baseline' / name) == digest, name
    for name, digest in historical.items():
        assert sha(REPO / name) == digest, name
    for name in ('supermimic', 'pyproject.toml', 'MANIFEST.in',
                 'src/embodiedforge/locomotion/go1_ppo.py', 'src/embodiedforge/locomotion/h1_ppo.py',
                 'src/embodiedforge/training.py'):
        assert sha(REPO / name) == baseline[name], name
    resources = read('selected-resource-hashes.json')
    assert all(sha(REPO / n) == h for n, h in resources.items()), 'Package resources changed'
    model = read('preserved-model.json')
    assert sha(REPO / 'runs/supermimic/tasks/backflip/reference/current.json') == model['registry_sha256']
    assert sha(REPO / model['registry']['checkpoint']) == model['registry']['checkpoint_sha256']
    distribution = read('distribution-validation.json')
    assert not distribution['removed_members'] and not distribution['added_members']
    for label in ('before', 'after', 'wheel'):
        assert distribution[label]['actual_build_wait_returncode'] == 0
        assert sha(distribution[label]['path']) == distribution[label]['sha256']
    archive = read('release-source-validation.json')
    assert archive['all_selected_release_files_exact'] == len(release)
    assert archive['source_archive_sha256'] == distribution['after']['sha256']
    assert set(read('style-check-exits.json')['actual_child_waits'].values()) == {0}
    fingerprints = read('fingerprint-compatibility.json')
    for key in ('stable_fingerprints_exact', 'linked_checkpoint_support_preserved',
                'processor_race_reproduced_and_fixed', 'cleanup_error_priority_reproduced_and_fixed',
                'fifo_blocking_reproduced_and_fixed'):
        assert fingerprints[key], key
    wheel = read('installed-wheel-validation.json')
    assert wheel['stdlib_only'] and wheel['all_fixture_scenarios_passed']
    memory = read('checkpoint-memory-observed.json')
    assert all(memory['artifact_bytes_equal'].values())
    assert all(v['actual_child_wait_returncode'] == 0 for v in memory['results'].values())
    parity = read('training-parity-supervised/summary.json')
    assert len(parity['comparisons']) == 9 and all(x['match'] for x in parity['comparisons'])
    backflip = json.loads((RUN / 'backflip-acceptance/result.json').read_text())
    assert backflip['checkpoint_sha256'] == model['registry']['checkpoint_sha256']
    physical = backflip['physical_quality']
    assert len(physical['checks']) == 16 and all(physical['checks'].values())
    assert physical['ported_quality_passed'] and not physical['strict_v14_equivalence'] and not physical['physical_robot_tested']
    supervisors = {n: observed(n) for n in ('main-supervisor', 'native-supervisor', 'source-isolated-supervisor',
                                          'parity-supervisor', 'backflip-supervisor', 'soak-probe-supervisor')}
    tests = {label: test_result(xml, log) for label, xml, log in (
        ('main', 'main-tests.xml', 'main-supervisor/command.log'),
        ('native', 'native-tests.xml', 'native-supervisor/command.log'),
        ('source_release', 'source-isolated-tests.xml', 'source-isolated-supervisor/command.log'))}
    return {'selected_modules': len(selected), 'selected_release_files': len(release),
            'historical_files_preserved': len(historical), 'package_resources_preserved': len(resources), 'tests': tests,
            'supervised_validation': supervisors, 'current_owned_jobs': owned_processes()}

def full_report():
    static = audit_static()
    soak = read('soak/summary.json')
    assert soak['status'] == 'complete' and soak['seconds'] >= 14400
    assert len(set(soak['scenario_counts_including_warmup'].values())) == 1
    assert set(soak['scenario_counts_including_warmup'].values()) == {soak['cycles'] + soak['warmup_cycles']}
    static['soak_supervisor'] = observed('soak-supervisor')
    assert not static['current_owned_jobs'], static['current_owned_jobs']
    state = read('work-state.json')
    for name in ('main_original', 'native_original', 'source_isolated_original', 'parity_observed_original',
                 'backflip_original', 'distribution_original', 'checkpoint_memory_observed_original', 'soak_original'):
        assert state[name]['observed_exit'] == 0, (name, state[name])
    static['observed_original_exits'] = {k: v for k, v in state.items() if k.endswith('_original')}
    memory = read('checkpoint-memory-observed.json')
    backflip = json.loads((RUN / 'backflip-acceptance/result.json').read_text())
    control = read('control.json')
    now = datetime.now(timezone.utc)
    result = {'status': 'validated_awaiting_requested_deadline', 'objective': control['objective'],
              'started_at': control['started_at'], 'requested_deadline': control['deadline'],
              'audited_at': now.isoformat(),
              'elapsed_seconds': (now-datetime.fromisoformat(control['started_at'])).total_seconds(),
              'changes': [
                  'ACT dataset and inference fingerprints reuse bounded regular-file snapshot hashing; old schema and stable digest dictionaries remain exact.',
                  'Parse processor JSON from its hashed bytes once and recheck selector identity after dependencies; keep linked cached model files supported.',
                  'Replace duplicated core/Go1 partial-file cleanup with the existing runtime artifacts module; preserve active publication errors and interruptions.',
                  'Publish Go1 recovery.json atomically once, removing the redundant second temporary receipt and rename.',
                  'Keep high-volume Go1 checkpoint names as filesystem strings during save and pruning, removing per-checkpoint pathlib component retention on CPython3.12.0.'
              ],
              'metrics': read('source-change-summary.json'),
              'validation': {**static, 'sustained_fixture': soak,
                             'fingerprint_controls': {k:v for k,v in read('fingerprint-compatibility.json').items() if k!='results'},
                             'checkpoint_memory': memory,
                             'resource_observations': read('soak-resource-observations.json'),
                             'backflip': {'ported_checks_passed': 16, 'checkpoint_sha256': backflip['checkpoint_sha256'],
                                          'strict_v14_equivalence': False, 'physical_robot_tested': False}},
              'distribution': read('distribution-validation.json'), 'preserved_model': read('preserved-model.json'),
              'preserved': ['Training and evaluation commands, dependency declarations, learner/MDP implementations and checkpoint schemas.',
                            'All preexisting historical evidence and registered backflip model bytes.',
                            'Preexisting unrelated workspace changes; no reset, commit, push or foreign-process termination.'],
              'scope_limits': ['Memory results measure retained Python allocations for CPU checkpoint publication, not RSS, GPU memory or training throughput.',
                               'The sustained fixture uses tiny valid CPU Adam checkpoints and file/process faults; it does not train ACT or a robot policy.',
                               'One G1 evaluation verifies current ported gates; prior GPU run-to-run variation remains and bitwise GPU repeatability is not claimed.',
                               'No strict IsaacLab3 V14 equivalence, independent-seed learning improvement or physical-robot success is claimed.',
                               'Source package archive exclusion was retained from earlier work; no new package-size reduction is claimed.']}
    return result

def evidence(report):
    paths = []
    excluded_prefixes = ('baseline/', 'release-source/', 'source-release/', 'installed-wheel/', 'fingerprint-probes/',
                         'checkpoint-memory-baseline/', 'checkpoint-memory-candidate/', 'checkpoint-memory-baseline-4000/',
                         'checkpoint-memory-candidate-4000/', 'checkpoint-memory-observed-baseline/',
                         'checkpoint-memory-observed-candidate/', 'soak/work/', 'soak-probe/work/')
    for path in ROOT.rglob('*'):
        if not path.is_file() or path.is_symlink():
            continue
        name = str(path.relative_to(ROOT))
        if name.startswith(excluded_prefixes) or '__pycache__' in path.parts:
            continue
        if path.suffix in ('.json', '.jsonl', '.py', '.xml', '.log', '.txt', '.patch'):
            paths.append(('session/' + name, path))
    # Current distribution only: baseline archive retained privately, not nested here.
    for label in ('after', 'wheel'):
        path = Path(report['distribution'][label]['path'])
        paths.append(('release/' + path.name, path))
    for name in report['metrics']['changed_files']:
        paths.append(('selected/' + name, REPO / name))
        paths.append(('before/' + name, ROOT / 'baseline' / name))
    for path in (RUN / 'backflip-acceptance').rglob('*'):
        if path.is_file() and path.suffix in ('.json', '.log'):
            paths.append(('backflip/' + str(path.relative_to(RUN / 'backflip-acceptance')), path))
    entries = {name: {'sha256': sha(path), 'bytes': path.stat().st_size} for name, path in paths}
    assert len(entries) == len(paths)
    bundle = REPO / 'docs/experiments' / (STEM + '-evidence.tar.gz')
    assert not bundle.exists()
    with tarfile.open(bundle, 'w:gz') as tar:
        for name, path in sorted(paths):
            tar.add(path, arcname=name, recursive=False)
        payload = (json.dumps(entries, indent=2) + '\n').encode()
        info = tarfile.TarInfo('manifest.json'); info.size = len(payload)
        tar.addfile(info, io.BytesIO(payload))
    with tarfile.open(bundle, 'r|gz') as tar:
        actual, restored = {}, None
        for member in tar:
            assert member.isfile()
            stream = tar.extractfile(member)
            if member.name == 'manifest.json':
                assert restored is None
                restored = json.load(stream)
                continue
            assert member.name not in actual
            digest, size = hashlib.sha256(), 0
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(block)
                size += len(block)
            actual[member.name] = {'sha256': digest.hexdigest(), 'bytes': size}
        assert restored == entries and actual == entries
    return {'path': str(bundle.relative_to(REPO)), 'bytes': bundle.stat().st_size,
            'sha256': sha(bundle), 'verified_manifest_members': len(entries)}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--static', action='store_true')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    if args.static:
        print(json.dumps(audit_static(), indent=2)); return
    report = full_report()
    if args.dry_run:
        write(ROOT / 'report-draft.json', report)
        print('All validation passed; waiting for requested five-hour deadline.'); return
    now = datetime.now(timezone.utc)
    assert now >= datetime.fromisoformat(read('control.json')['deadline']), 'Requested five-hour window is still active'
    report['status'] = 'complete'
    report['published_at'] = now.isoformat()
    report['elapsed_seconds'] = (now-datetime.fromisoformat(report['started_at'])).total_seconds()
    # The draft is evidence; the final report hash is recorded separately to avoid circularity.
    write(ROOT / 'report-draft.json', report)
    report['evidence_bundle'] = evidence(report)
    output = REPO / 'docs/experiments' / (STEM + '.json')
    assert not output.exists()
    write(output, report)
    write(RUN / 'optimization.json', report)
    audit_static()
    assert not owned_processes()
    write(ROOT / 'publication-verification.json', {'status':'complete','report':str(output),
         'report_sha256':sha(output),'bundle':report['evidence_bundle'],
         'owned_processes_absent':True,'verified_at':datetime.now(timezone.utc).isoformat()})
    print(json.dumps({'report':str(output),'bundle':report['evidence_bundle']}))

if __name__ == '__main__':
    main()
