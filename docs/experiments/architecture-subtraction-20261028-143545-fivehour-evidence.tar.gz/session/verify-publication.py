"""Independently verify the delivered report and every evidence payload."""
from datetime import datetime,timezone
import hashlib,json,tarfile
from pathlib import Path
root=Path(__file__).parent
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
verification=json.loads((root/'publication-verification.json').read_text())
report_path=Path(verification['report'])
assert sha(report_path)==verification['report_sha256']
report=json.loads(report_path.read_text())
assert report['status']=='complete'
assert datetime.fromisoformat(report['published_at'])>=datetime.fromisoformat(report['requested_deadline'])
assert report['elapsed_seconds']>=18000
assert sha(repo/'runs/architecture-subtraction-20261028-143545-fivehour/optimization.json')==verification['report_sha256']
bundle=repo/report['evidence_bundle']['path']
assert sha(bundle)==report['evidence_bundle']['sha256']==verification['bundle']['sha256']
actual,manifest={},None
with tarfile.open(bundle,'r|gz') as tar:
 for member in tar:
  assert member.isfile()
  stream=tar.extractfile(member)
  if member.name=='manifest.json':
   assert manifest is None
   manifest=json.load(stream)
  else:
   assert member.name not in actual
   digest,size=hashlib.sha256(),0
   for block in iter(lambda:stream.read(1024*1024),b''):
    digest.update(block);size+=len(block)
   actual[member.name]={'sha256':digest.hexdigest(),'bytes':size}
assert actual==manifest
assert len(actual)==report['evidence_bundle']['verified_manifest_members']
result={'status':'complete','verified_at':datetime.now(timezone.utc).isoformat(),'report_sha256':sha(report_path),
        'bundle_sha256':sha(bundle),'verified_manifest_members':len(actual),'requested_deadline_respected':True}
(root/'independent-publication-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
