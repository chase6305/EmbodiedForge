"""Reconcile current evidence; completion requires two hours and observed exit."""
import argparse
import ast
import hashlib
import json
import runpy
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
WORK = Path('/tmp/embodiedforge-subtraction-20261030-023637-twohour')
STEM = 'architecture-subtraction-20261030-023637-twohour'


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--final', action='store_true')
args = parser.parse_args()
state = read(WORK / 'state.json')
now = datetime.now(timezone.utc)
elapsed = (now - datetime.fromisoformat(state['started_at'])).total_seconds()
if args.final:
    assert now >= datetime.fromisoformat(state['deadline']) and elapsed >= 7200
baseline = read(WORK / 'baseline-files.json')
changed = sorted(name for name, old in baseline.items() if not (ROOT / name).is_file() or digest(ROOT / name) != old['sha256'])
assert set(changed) == set(state['changed_files_this_round']) | set(state.get('generated_build_files', [])), changed
history = read(WORK / 'historical-files.json')
assert all(digest(ROOT / name) == value for name, value in history.items())
for row in state['preserved_models'] + state['preserved_data']:
    path = Path(row['path'])
    assert digest(path if path.is_absolute() else ROOT / path) == row['sha256'], path
modules = sorted((ROOT / 'src/embodiedforge').rglob('*.py'))
for path in modules:
    assert digest(path) == digest(WORK / 'candidate' / path.relative_to(ROOT)), path
    old = ast.parse((WORK / 'baseline' / path.relative_to(ROOT)).read_text())
    new = ast.parse(path.read_text())
    def declarations(tree):
        return {node.name: ast.dump(node.args, include_attributes=False) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) else 'class'
                for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}
    a, b = declarations(old), declarations(new)
    assert all(name in b and value == b[name] for name, value in a.items()), path
after_lines = sum(len(path.read_text().splitlines()) for path in modules)
state['metrics'] = {'modules_before': state['baseline_modules'], 'modules_after': len(modules),
                    'source_lines_before': state['baseline_source_lines'], 'source_lines_after': after_lines,
                    'production_net_lines_removed': state['baseline_source_lines'] - after_lines}
graph_tools = runpy.run_path(str(ROOT / 'tests/test_architecture.py'))
graph = graph_tools['GRAPH']
assert not graph_tools['cycles'](graph)
state['validation']['architecture'] = {'modules': len(graph), 'explicit_import_edges': sum(map(len, graph.values())),
                                      'cycles': [], 'existing_top_level_declarations_and_signatures_retained': True,
                                      'method': 'Existing architecture test graph; dynamic imports are checked by runtime tests.'}
summary = read(Path(state['numerical_job']['summary']))
assert not summary['failures']
observed_path = Path(state['numerical_job']['supervisor']) / 'result.json'
state['validation']['numerical_sustained'] = {'summary': summary, 'supervisor': read(observed_path) if observed_path.exists() else None}
if args.final:
    observed = state['validation']['numerical_sustained']['supervisor']
    assert summary['status'] == 'complete' and summary['seconds'] >= 5400
    assert {'cpu', 'cuda'} <= set(summary['devices'])
    assert observed['exit_observed'] and observed['completed_successfully']
    assert observed['process_returncode'] == 0 and not observed['timed_out'] and observed['supervisor_signal'] is None
    assert state['validation']['numerical_supervisor_tool_exit'] == 0
    assert state['validation']['candidate-full']['failures'] == state['validation']['candidate-full']['errors'] == 0
    assert state['validation']['release']['status'] == 'passed'
    state.update(status='complete', finished_at=now.isoformat())
state['preservation'] = {'checked_at': now.isoformat(), 'baseline_files_checked': len(baseline),
                         'expected_changed_files': changed, 'unexpected_changes': [],
                         'generated_build_files': state.get('generated_build_files', []),
                         'historical_files_unchanged': len(history), 'models_and_registry': len(state['preserved_models']),
                         'reference_data_files': len(state['preserved_data']),
                         'frozen_production_source_matches': True}
state['limits'] = [
    'The 90-minute differential uses private tensor environments and extracted source functions; it compares exact tensor/gradient/reset/RNG bytes on CPU and CUDA, not learned walking or robot skill quality.',
    'Hash allocation measurements isolate the actual old/new hash expression over one existing 71 MB compiled geometry model, not whole-training memory or throughput.',
    'The main suite skips optional SDK dependencies; the real Microduck and Light Loco environments supply separate targeted coverage. Counts are not summed across overlapping test suites.',
    'Initial test/probe fixture failures are retained separately with their corrections; they are not counted as final passes.',
    'No model training or default task parameter tuning was performed in this subtraction round.',
]
state.update(elapsed_seconds=elapsed, last_updated_at=now.isoformat())
for path in [WORK / 'state.json', ROOT / 'runs' / STEM / 'optimization.json', ROOT / 'docs/experiments' / (STEM + '.json')]:
    write(path, state)
print(json.dumps({'status': state['status'], 'elapsed_minutes': elapsed / 60, 'metrics': state['metrics'],
                  'history_preserved': len(history), 'numerical_minutes': summary['seconds'] / 60,
                  'numerical_cycles': summary['cycles'], 'numerical_status': summary['status']}, indent=2))
