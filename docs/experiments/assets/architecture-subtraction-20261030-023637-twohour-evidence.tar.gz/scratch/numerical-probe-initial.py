"""Compare old/new task tensors, gradients, reset state and RNG; CPU/CUDA fixtures."""
import argparse
import ast
import hashlib
import json
import math
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--baseline', type=Path, required=True)
parser.add_argument('--candidate', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--seconds', type=float, required=True)
args = parser.parse_args()
args.output.mkdir(parents=True)
torch.set_num_threads(1)
devices = ['cpu'] + (['cuda'] if torch.cuda.is_available() else [])
names = {'_servo_joint_ids', '_servo_joint_pos', '_servo_default_joint_pos',
         '_quat_from_roll_pitch', '_crouch_pose_error', '_phase_pose_error',
         'crouch_pose_blend', 'phase_pose_blend', 'phase_pose_track', 'phase_pose_track_l1',
         'randomize_base_orientation', 'set_random_ground_state', 'set_random_crouch_state',
         'reset_roulade_state', '_roulade_state'}


def load(path):
    tree = ast.parse(path.read_text())
    namespace = {'torch': torch, 'np': np, 'math': math,
                 '_DEFAULT_ASSET_CFG': SimpleNamespace(name='robot')}
    body = [ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0)]
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id in {'_CROUCH_ANCHOR_BY_NAME', '_ROULADE_FWD_SIGN'} for t in node.targets):
            body.append(node)
        elif isinstance(node, ast.FunctionDef) and node.name in names:
            assert not node.decorator_list, node.name
            body.append(node)
    exec(compile(ast.fix_missing_locations(ast.Module(body=body, type_ignores=[])), str(path), 'exec'), namespace)
    return namespace


before, after = load(args.baseline), load(args.candidate)
joint_names = list(before['_CROUCH_ANCHOR_BY_NAME'])
joint_names.insert(3, 'passive_hinge')
joint_names += ['head_yaw', 'head_roll']


def environment(dtype, device, batch=19, gradients=False):
    count = len(joint_names)
    default = torch.linspace(-0.3, 0.3, batch * count, device=device, dtype=dtype).reshape(batch, count).requires_grad_(gradients)
    pos = torch.linspace(-0.5, 0.5, batch * count, device=device, dtype=dtype).reshape(batch, count).requires_grad_(gradients)
    phase = torch.linspace(0, 1, batch, device=device, dtype=dtype)
    command = torch.stack([torch.cos(phase * 2 * torch.pi), torch.sin(phase * 2 * torch.pi)], dim=-1).detach().requires_grad_(gradients)
    def find(pattern):
        patterns = [pattern] if isinstance(pattern, str) else pattern
        ids = [i for i, name in enumerate(joint_names) if any(re.fullmatch(p, name) for p in patterns)]
        return ids, [joint_names[i] for i in ids]
    asset = SimpleNamespace(data=SimpleNamespace(joint_pos=pos, default_joint_pos=default), find_joints=find)
    return SimpleNamespace(
        num_envs=batch, device=device, scene={'robot': asset},
        command_manager=SimpleNamespace(get_command=lambda _: command),
        sim=SimpleNamespace(data=SimpleNamespace(
            qpos=torch.linspace(-1, 1, batch * (7 + count), device=device, dtype=dtype).reshape(batch, 7 + count),
            qvel=torch.ones((batch, 6 + count), device=device, dtype=dtype))),
    )


def exact(a, b, label):
    if a is None or b is None:
        assert a is b, label
        return
    assert a.dtype == b.dtype and a.shape == b.shape, label
    assert torch.equal(a.detach().contiguous().cpu().view(torch.uint8), b.detach().contiguous().cpu().view(torch.uint8)), label


def phase_case(dtype, device, seed):
    names_order = [joint_names[i] for i in [5, 0, 8, 2]]
    target = {name: (i - 1) * 0.23 for i, name in enumerate(names_order)}
    source = {names_order[1]: 0.17, 'ignored_joint': 2.0} if seed % 2 else None
    for reward in ['phase_pose_track', 'phase_pose_track_l1']:
        results = []
        for namespace in [before, after]:
            env = environment(dtype, device, gradients=True)
            result = namespace[reward](env, target_pose=target, source_pose=source)
            data = env.scene['robot'].data
            gradients = torch.autograd.grad(result.sum(), [data.joint_pos, data.default_joint_pos, env.command_manager.get_command('twist')], allow_unused=True)
            results.append((result, gradients, data.default_joint_pos))
        exact(results[0][0], results[1][0], reward + ':values')
        for i, (a, b) in enumerate(zip(results[0][1], results[1][1])):
            exact(a, b, reward + ':gradient' + str(i))
        exact(results[0][2], results[1][2], reward + ':defaults')


reset_cases = [
    ('randomize_base_orientation', {'max_pitch_deg': 70.0, 'max_roll_deg': 40.0}),
    ('set_random_ground_state', {'sitting_tilt_max': 0.3, 'face_up_roll_max': 0.9, 'standing_prob': 0.3, 'sitting_joint_noise_std': 0.04, 'sitting_joint_overrides': {0: 0.7, 4: -0.6}}),
    ('set_random_ground_state', {'sitting_tilt_max': 0.0, 'face_down_prob': 0.0, 'face_up_prob': 0.0, 'sitting_prob': 1.0}),
    ('set_random_crouch_state', {'depth_min': 0.1, 'depth_max': 1.2, 'pitch_max_deg': 75.0}),
    ('reset_roulade_state', {'joint_noise_std': 0.07, 'tuck_overrides': {0: 0.6, 4: -0.8}, 'forward_vel_range': (0.1, 0.5), 'midroll_omega_range': (0.2, 1.0)}),
    ('reset_roulade_state', {'standing_prob': 0.0, 'midroll_prob': 1.0}),
]


def reset_case(dtype, device, seed, case, selection):
    name, options = reset_cases[case]
    results = []
    for namespace in [before, after]:
        env = environment(dtype, device)
        ids = None if selection == 0 else torch.tensor([] if selection == 1 else [0, 2, 5, 11, 18], dtype=torch.long, device=device)
        torch.manual_seed(seed)
        namespace[name](env, ids, **options)
        tensors = {'qpos': env.sim.data.qpos, 'qvel': env.sim.data.qvel, 'cpu_rng': torch.get_rng_state()}
        if device == 'cuda':
            tensors['cuda_rng'] = torch.cuda.get_rng_state()
        for key, value in vars(env).items():
            if key.startswith('_roulade') and isinstance(value, torch.Tensor):
                tensors[key] = value
        results.append(tensors)
    assert results[0].keys() == results[1].keys(), name
    for key in results[0]:
        exact(results[0][key], results[1][key], name + ':' + key)


watched = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [args.baseline, args.candidate]}
counts = {'phase_cases': 0, 'reset_cases': 0}
samples = []
started = time.monotonic()
began = datetime.now(timezone.utc).isoformat()
failures = []


def sample(status):
    values = dict(line.split(':', 1) for line in Path('/proc/self/status').read_text().splitlines() if ':' in line)
    row = {'seconds': time.monotonic() - started, 'cycles': cycles, 'rss_kib': int(values['VmRSS'].split()[0]), 'fds': len(os.listdir('/proc/self/fd')), 'time': datetime.now(timezone.utc).isoformat()}
    samples.append(row)
    with (args.output / 'samples.jsonl').open('a') as stream:
        stream.write(json.dumps(row) + '\n')
    result = {'status': status, 'started_at': began, 'seconds': row['seconds'], 'requested_seconds': args.seconds, 'cycles': cycles, 'counts': counts, 'devices': devices, 'last_sample': row, 'source_hashes': watched, 'failures': failures, 'scope': __doc__, 'comparison': 'Exact tensor bytes, including gradient tensors and CPU/CUDA RNG state. Private tensor environments; not robot training.'}
    temporary = args.output / 'summary.tmp'
    temporary.write_text(json.dumps(result, indent=2) + '\n')
    temporary.replace(args.output / 'summary.json')
    print(json.dumps(row), flush=True)


cycles = 0
last_sample = 0
try:
    # Exercise every reset, environment selection and dtype before the timed loop.
    for device in devices:
        for dtype in [torch.float32, torch.float64]:
            phase_case(dtype, device, 0)
            counts['phase_cases'] += 1
            for case in range(len(reset_cases)):
                for selection in range(3):
                    reset_case(dtype, device, case, case, selection)
                    counts['reset_cases'] += 1
    sample('running')
    while time.monotonic() - started < args.seconds:
        device = devices[cycles % len(devices)]
        dtype = [torch.float32, torch.float64][(cycles // len(devices)) % 2]
        phase_case(dtype, device, cycles)
        counts['phase_cases'] += 1
        reset_case(dtype, device, cycles, cycles % len(reset_cases), 2)
        counts['reset_cases'] += 1
        cycles += 1
        if time.monotonic() - last_sample >= 30:
            sample('running')
            last_sample = time.monotonic()
        time.sleep(0.05)
    assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == value for path, value in watched.items())
    sample('complete')
except BaseException as error:
    failures.append({'type': type(error).__name__, 'error': str(error)})
    sample('failed')
    raise
