"""Read-only heartbeat and observed-exit checks for the owned numerical job."""
import json
from datetime import datetime, timezone
from pathlib import Path

work = Path('/tmp/embodiedforge-subtraction-20261030-023637-twohour')
state = json.loads((work / 'state.json').read_text())
job = state['numerical_job']
summary = json.loads(Path(job['summary']).read_text())
assert not summary['failures']
now = datetime.now(timezone.utc)
result = Path(job['supervisor']) / 'result.json'
if result.exists():
    observed = json.loads(result.read_text())
    assert summary['status'] == 'complete' and summary['seconds'] >= job['requested_seconds']
    assert observed['exit_observed'] and observed['completed_successfully']
    assert observed['process_returncode'] == 0 and not observed['timed_out']
elif summary['status'] == 'running':
    assert (now - datetime.fromisoformat(summary['last_sample']['time'])).total_seconds() < 90
    started = json.loads((Path(job['supervisor']) / 'started.json').read_text())
    command = Path('/proc') / str(started['supervisor_pid']) / 'cmdline'
    assert command.exists() and b'process_supervisor.py' in command.read_bytes()
else:
    assert summary['status'] == 'complete'
print(now.isoformat(), 'goal_minutes=', round((now - datetime.fromisoformat(state['started_at'])).total_seconds() / 60, 1))
print('CPU/CUDA numerical', summary['status'], 'minutes=', round(summary['seconds'] / 60, 1),
      'cycles=', summary['cycles'], 'fds=', summary['last_sample']['fds'],
      'failures=', len(summary['failures']), 'observed_normal_exit=', result.exists())
