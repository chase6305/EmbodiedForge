"""Fresh-process allocation control for the actual saved geometry model hash."""
import argparse
import ast
import gc
import hashlib
import json
import resource
import subprocess
import sys
import time
import tracemalloc
from pathlib import Path

work = Path('/tmp/embodiedforge-subtraction-20261030-023637-twohour')
model = Path('/home/ubuntu/workspace/chase/EmbodiedForge/runs/architecture-subtraction-20261029-095651-fivehour/backflip-acceptance/physics-model.mjb')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--method', choices=['baseline', 'candidate'])
args = parser.parse_args()
if args.method:
    sys.path.insert(0, str(work / 'candidate/src'))
    from embodiedforge.runtime.hashing import file_sha256
    source = work / ('baseline' if args.method == 'baseline' else 'candidate') / 'src/embodiedforge/workflows/supermimic_contacts.py'
    tree = ast.parse(source.read_text())
    values = [value for node in ast.walk(tree) if isinstance(node, ast.Dict)
              for key, value in zip(node.keys, node.values)
              if isinstance(key, ast.Constant) and key.value == 'compiled_cpu_geometry_model_sha256']
    assert len(values) == 1
    expression = compile(ast.Expression(values[0]), str(source), 'eval')
    assert not {'torch', 'numpy', 'mujoco'} & sys.modules.keys()
    gc.collect()
    tracemalloc.start()
    began = time.perf_counter()
    digest = eval(expression, {'hashlib': hashlib, 'file_sha256': file_sha256, 'output': model.parent})
    seconds = time.perf_counter() - began
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    print(json.dumps({'method': args.method, 'sha256': digest, 'file_bytes': model.stat().st_size,
                      'python_peak_bytes': peak, 'rss_peak_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                      'seconds': seconds, 'python': sys.version}))
else:
    results = []
    for repetition in range(3):
        for method in ['baseline', 'candidate']:
            done = subprocess.run([sys.executable, '-I', '-S', __file__, '--method', method],
                                  capture_output=True, text=True, timeout=30, check=True)
            results.append({**json.loads(done.stdout), 'repetition': repetition, 'returncode': done.returncode})
    assert len({row['sha256'] for row in results}) == 1
    original = json.loads(model.with_name('contact-force-audit.json').read_text())
    assert results[0]['sha256'] == original['compiled_cpu_geometry_model_sha256']
    result = {'scope': 'Only the original/candidate hash expression, over the existing 71 MB compiled geometry model. Python allocation peaks are not whole-training memory or a throughput benchmark.',
              'model': str(model), 'results': results}
    (work / 'hash-allocation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'sha256': results[0]['sha256'], 'bytes': results[0]['file_bytes'],
                      'peak_python_bytes': {method: [row['python_peak_bytes'] for row in results if row['method'] == method]
                                            for method in ['baseline', 'candidate']}}, indent=2))
