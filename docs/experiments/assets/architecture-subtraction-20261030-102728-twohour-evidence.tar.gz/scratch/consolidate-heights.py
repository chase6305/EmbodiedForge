"""Replace only the 27 byte-equivalent height expressions identified by AST."""
import ast
from pathlib import Path

root = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
work = Path('/tmp/embodiedforge-subtraction-20261030-102728-twohour')
relative = Path('src/embodiedforge/locomotion/microduck/tasks/mdp.py')
path = root / relative
text = path.read_text()
assert text == (work / 'baseline' / relative).read_text()
target = 'torch.nan_to_num(asset.data.root_link_pos_w[:, 2] - env.scene.terrain.env_origins[:, 2], nan=0.0)'
lines = text.splitlines(keepends=True)
offsets = [0]
for line in lines:
    offsets.append(offsets[-1] + len(line))
changes = []
for node in ast.walk(ast.parse(text)):
    if isinstance(node, ast.Call) and ast.unparse(node) == target:
        # AST column offsets count UTF-8 bytes; these expression lines are ASCII.
        assert lines[node.lineno - 1].isascii() and lines[node.end_lineno - 1].isascii()
        changes.append((offsets[node.lineno - 1] + node.col_offset,
                        offsets[node.end_lineno - 1] + node.end_col_offset))
assert len(changes) == 27
for start, end in sorted(changes, reverse=True):
    text = text[:start] + '_relative_root_height(env, asset)' + text[end:]
path.write_text(text)
print('replaced exact height expressions', len(changes))
