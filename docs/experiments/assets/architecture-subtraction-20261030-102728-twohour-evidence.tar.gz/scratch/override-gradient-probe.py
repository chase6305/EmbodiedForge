"""Check tensor-valued/aliased overrides through fixed and interpolated rewards."""
import json
import runpy
import sys
from pathlib import Path

import torch

work = Path('/tmp/embodiedforge-subtraction-20261030-102728-twohour')
relative = 'src/embodiedforge/locomotion/microduck/tasks/mdp.py'
sys.argv = ['numerical-soak.py', '--baseline', str(work / 'baseline' / relative),
            '--candidate', str(work / 'candidate' / relative),
            '--output', str(work / 'numerical-override-warmup-final'), '--seconds', '0']
scope = runpy.run_path(str(work / 'numerical-soak.py'))


def exact(a, b, label):
    if isinstance(a, (tuple, list)):
        assert type(a) is type(b) and len(a) == len(b), label
        for i, (left, right) in enumerate(zip(a, b)):
            exact(left, right, label + ':' + str(i))
    elif a is None or b is None:
        assert a is b, label
    else:
        assert a.dtype == b.dtype and a.shape == b.shape, label
        assert torch.equal(a.detach().reshape(-1).contiguous().cpu().view(torch.uint8),
                           b.detach().reshape(-1).contiguous().cpu().view(torch.uint8)), label


count = 0
for device in scope['devices']:
    for dtype in [torch.float32, torch.float64]:
        for seed in range(30):
            for reward in ['interpolated_pose_target_match', 'interpolated_pose_l1_penalty',
                           'pose_target_match', 'pose_l1_penalty', 'multistage_pose_target_match']:
                results = []
                for namespace in [scope['before'], scope['after']]:
                    env, inputs = scope['environment'](dtype, device, seed)
                    default = inputs[1]
                    scalar = torch.tensor(.25, dtype=dtype, device=device, requires_grad=True)
                    overrides = {0: default[:, 2], -1: scalar}
                    options = dict(target_overrides=overrides)
                    if reward.startswith('interpolated'):
                        options['source_overrides'] = {0: scalar, 2: default[:, 1]}
                    if reward.startswith('multistage'):
                        options = dict(waypoints=[dict(frac=0, overrides=None),
                                                 dict(frac=.4, overrides=overrides),
                                                 dict(frac=.8, overrides={2: scalar})])
                    output = namespace[reward](env, **options)
                    gradient = torch.autograd.grad(output.sum(), inputs + [scalar], allow_unused=True)
                    results.append((output, gradient))
                exact(results[0], results[1], reward + ':tensor-override:' + str(seed))
                count += 1
result = {'status': 'passed', 'cases': count, 'devices': scope['devices'],
          'dtypes': ['float32', 'float64'], 'seeds': 30, 'rewards': 5,
          'checks': ['exact reward bytes', 'exact gradients including scalar tensor and default-pose aliases'],
          'scope': __doc__}
(work / 'override-gradient-probe.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
