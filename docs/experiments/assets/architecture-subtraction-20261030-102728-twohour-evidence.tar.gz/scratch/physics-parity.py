"""Evaluate old/new rewards on the same real mjlab/MuJoCo-Warp robot states."""
import hashlib
import importlib.util
import json
import sys
import time
from pathlib import Path

import torch
from mjlab.envs import ManagerBasedRlEnv
from mjlab.managers import SceneEntityCfg
from mjlab.utils.torch import configure_torch_backends

from embodiedforge._microduck_worker import close_environment
from embodiedforge.locomotion.microduck.tasks.microduck_velocity_env_cfg import make_microduck_velocity_env_cfg

work = Path('/tmp/embodiedforge-subtraction-20261030-102728-twohour')
relative = Path('src/embodiedforge/locomotion/microduck/tasks/mdp.py')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


before = load('subtraction_before_mdp', work / 'baseline' / relative)
after = load('subtraction_after_mdp', work / 'candidate' / relative)
configure_torch_backends(allow_tf32=False)
torch.set_num_threads(1)
cfg = make_microduck_velocity_env_cfg(play=False)
cfg.scene.num_envs = 32
cfg.seed = 9281
began = time.monotonic()
env = ManagerBasedRlEnv(cfg=cfg, device='cuda:0')
result = {'scope': __doc__, 'num_envs': 32, 'steps': 0, 'reward_comparisons': 0,
          'source_hashes': {kind: hashlib.sha256((work / kind / relative).read_bytes()).hexdigest() for kind in ['baseline', 'candidate']}}
try:
    env.reset()
    generator = torch.Generator(device='cuda:0').manual_seed(9281)
    subset = [0, 2, 5, 10, 13]
    waypoints = [dict(frac=0.0, overrides=None), dict(frac=.4, overrides={0: .2, 5: -.3}), dict(frac=.8, overrides={2: -.2})]
    heights = [dict(frac=0.0, height=.12), dict(frac=.4, height=.06), dict(frac=.8, height=.12)]
    cases = [
        ('standing_composite_score', dict(target_height=.12, height_std=.03, upright_std=.5, pose_std=.3, joint_indices=subset, target_overrides={0: .2})),
        ('standing_success_bonus', dict(target_height=.12, height_tol=.03, upright_threshold=.5, pose_tol=.3, joint_indices=subset)),
        ('interpolated_pose_target_match', dict(source_overrides={0: .1}, target_overrides={5: -.3}, joint_indices=subset)),
        ('interpolated_pose_l1_penalty', dict(source_overrides={0: .1}, target_overrides={5: -.3}, joint_indices=subset)),
        ('multistage_pose_target_match', dict(waypoints=waypoints)),
        ('multistage_pose_l1_penalty', dict(waypoints=waypoints)),
        ('pose_target_match', dict(target_overrides={0: .2, -1: -.1})),
        ('pose_l1_penalty', dict(target_overrides={0: .2, -1: -.1})),
        ('phase_pose_match', dict(command_name='twist', target_overrides={0: .2})),
        ('height_target_gaussian', dict(target_height=.11)),
        ('height_l1_penalty', dict(target_height=.11)),
        ('interpolated_height_target', dict(start_height=.12, end_height=.06)),
        ('interpolated_height_l1_penalty', dict(start_height=.12, end_height=.06)),
        ('multistage_height_target', dict(waypoints=heights)),
        ('multistage_height_l1_penalty', dict(waypoints=heights)),
        ('phase_height_track', dict(command_name='twist', stand_z=.12, sit_z=.06)),
        ('upright_gaussian_at_height', dict(std=.5, height_low=.07, height_high=.12)),
        ('upright_while_tall', dict(height_low=.07, height_high=.12)),
        ('com_height_target', {}),
        ('com_upward_velocity', dict(max_height=.08, gate_z_below=.1, max_vz=.3)),
        ('seated_stillness', {}),
    ]
    resets = 0
    with torch.inference_mode():
        for step in range(512):
            action = torch.randn(env.action_space.shape, device='cuda:0', generator=generator) * .05
            observation, reward, terminated, truncated, info = env.step(action)
            resets += int((terminated | truncated).sum().item())
            assert torch.isfinite(env.sim.data.qpos).all(), 'nonfinite physics qpos'
            assert torch.isfinite(reward).all(), 'nonfinite configured reward'
            defaults = env.scene['robot'].data.default_joint_pos.clone()
            for name, options in cases:
                a, b = getattr(before, name)(env, **options), getattr(after, name)(env, **options)
                assert a.dtype == b.dtype and a.shape == b.shape, name
                assert torch.equal(a.contiguous().view(torch.uint8), b.contiguous().view(torch.uint8)), name
                result['reward_comparisons'] += 1
            assert torch.equal(defaults, env.scene['robot'].data.default_joint_pos), 'default pose mutated'
            result['steps'] += 1
            if step % 64 == 0:
                print(json.dumps({'steps': step + 1, 'seconds': time.monotonic() - began}), flush=True)
    result.update(status='passed', physics_transitions=32 * result['steps'], reset_events=resets, seconds=time.monotonic() - began,
                  values_bitwise_identical=True, default_poses_unchanged=True, finite_qpos_and_configured_rewards=True,
                  limitation='Same real physics states; small random actions, no trained actor and no training-quality claim.')
finally:
    close_environment(env)
(work / 'physics-parity.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2), flush=True)
