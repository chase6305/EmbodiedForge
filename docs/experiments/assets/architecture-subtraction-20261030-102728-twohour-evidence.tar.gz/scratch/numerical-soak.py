"""Old/new reward values, gradients, storage and RNG on CPU/CUDA tensor fixtures."""
import argparse
import ast
import hashlib
import json
import math
import os
import re
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

import torch

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--baseline', type=Path, required=True)
parser.add_argument('--candidate', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--seconds', type=float, required=True)
args = parser.parse_args()
args.output.mkdir(parents=True)
torch.set_num_threads(1)
devices = ['cpu'] + (['cuda'] if torch.cuda.is_available() else [])
names = {
    '_servo_joint_ids', '_servo_joint_pos', '_servo_default_joint_pos',
    '_relative_root_height', '_pose_override', '_fallen_mask',
    'standing_composite_score', 'standing_success_bonus',
    'interpolated_pose_target_match', 'interpolated_pose_l1_penalty',
    'interpolated_height_target', 'interpolated_height_l1_penalty',
    '_multistage_target_pose', '_multistage_target_height',
    'multistage_pose_target_match', 'multistage_pose_l1_penalty',
    'multistage_height_target', 'multistage_height_l1_penalty',
    'pose_target_match', 'pose_l1_penalty', 'phase_pose_match',
    'height_target_gaussian', 'height_l1_penalty',
    'phase_height_track', '_posture_blend', '_posture_height',
    'upright_gaussian_at_height', 'upright_while_tall',
    'com_height_target', 'com_upward_velocity', 'seated_stillness',
}


def load(path):
    tree = ast.parse(path.read_text())
    namespace = {'torch': torch, 'math': math,
                 '_DEFAULT_ASSET_CFG': SimpleNamespace(name='robot')}
    body = [ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0)]
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in names:
            assert not node.decorator_list
            body.append(node)
    exec(compile(ast.fix_missing_locations(ast.Module(body=body, type_ignores=[])), str(path), 'exec'), namespace)
    if '_relative_root_height' not in namespace:
        exec('def _relative_root_height(env, asset):\n return torch.nan_to_num(asset.data.root_link_pos_w[:, 2] - env.scene.terrain.env_origins[:, 2], nan=0.0)', namespace)
    return namespace


before, after = load(args.baseline), load(args.candidate)
joint_names = ['servo_' + str(i) for i in range(14)]
joint_names.insert(3, 'passive_hinge')
asset_cfg = SimpleNamespace(name='robot')


class Scene(dict):
    pass


def environment(dtype, device, seed, nonfinite=False):
    generator = torch.Generator(device=device).manual_seed(seed)
    batch, count = 19, len(joint_names)
    def rand(shape, scale=1):
        return torch.randn(shape, generator=generator, dtype=dtype, device=device) * scale
    default = rand((batch, count), .2).requires_grad_()
    pos = rand((batch, count), .4).requires_grad_()
    origins = rand((batch, 3), .1).requires_grad_()
    root = (origins.detach() + rand((batch, 3), .1)).requires_grad_()
    if nonfinite:
        with torch.no_grad():
            root[:3, 2] = torch.tensor([float('nan'), float('inf'), -float('inf')], dtype=dtype, device=device)
    quat = rand((batch, 4))
    quat = (quat / quat.norm(dim=-1, keepdim=True)).detach().requires_grad_()
    velocity = rand((batch, 3), .1).requires_grad_()
    phase = torch.linspace(0, 1, batch, device=device, dtype=dtype)
    command = torch.stack([torch.cos(phase * 2 * torch.pi), torch.sin(phase * 2 * torch.pi), torch.zeros_like(phase)], dim=-1).detach().requires_grad_()
    blend = phase.detach().requires_grad_()
    def find(pattern):
        ids = [i for i, name in enumerate(joint_names) if re.fullmatch(pattern, name)]
        return ids, [joint_names[i] for i in ids]
    asset = SimpleNamespace(data=SimpleNamespace(
        joint_pos=pos, default_joint_pos=default, root_link_pos_w=root,
        root_link_quat_w=quat, root_link_lin_vel_w=velocity), find_joints=find)
    scene = Scene(robot=asset)
    scene.terrain = SimpleNamespace(env_origins=origins)
    term = SimpleNamespace(alpha=blend) if seed % 2 else SimpleNamespace()
    env = SimpleNamespace(
        num_envs=batch, device=device, scene=scene,
        episode_length_buf=torch.tensor([-1, 0, 1, 10, 20, 25, 30, 40, 49, 50, 51, 60, 70, 75, 80, 90, 99, 100, 101], device=device),
        max_episode_length=100,
        command_manager=SimpleNamespace(get_command=lambda _: command, get_term=lambda _: term),
    )
    inputs = [pos, default, root, origins, quat, velocity, command, blend]
    return env, inputs


def exact(a, b, label):
    if isinstance(a, (tuple, list)):
        assert type(a) == type(b) and len(a) == len(b), label
        for i, (left, right) in enumerate(zip(a, b)):
            exact(left, right, label + ':' + str(i))
        return
    if a is None or b is None:
        assert a is b, label
        return
    assert a.dtype == b.dtype and a.shape == b.shape, label
    assert torch.equal(a.detach().contiguous().cpu().view(torch.uint8), b.detach().contiguous().cpu().view(torch.uint8)), label


def cases(seed):
    override = [None, {}, {0: .7, 5: -.3, -1: .4}][seed % 3]
    source = [None, {}, {2: -.25, 7: .1}][(seed // 3) % 3]
    subset = None if seed % 2 else [0, 2, 5, 10, 13]
    ramp = {'ramp_start_frac': .2, 'ramp_end_frac': .2 if seed % 5 == 0 else .8}
    pose_options = dict(source_overrides=source, target_overrides=override, joint_indices=subset, **ramp)
    points = [dict(frac=.1, overrides=source), dict(frac=.4, overrides=override),
              dict(frac=.4 if seed % 5 == 0 else .8, overrides={1: -.2, 3: .6})]
    heights = [dict(frac=.1, height=.12), dict(frac=.4, height=.06),
               dict(frac=.4 if seed % 5 == 0 else .8, height=.1)]
    return [
        ('_relative_root_height', {}, 'asset'),
        ('standing_composite_score', dict(target_height=.12, height_std=.03, upright_std=.5, pose_std=.3, joint_indices=subset or list(range(14)), target_overrides=override), ''),
        ('standing_success_bonus', dict(target_height=.12, height_tol=.03, upright_threshold=.5, pose_tol=.3, joint_indices=subset or list(range(14)), target_overrides=override), ''),
        ('interpolated_pose_target_match', pose_options, ''),
        ('interpolated_pose_l1_penalty', pose_options, ''),
        ('_multistage_target_pose', dict(asset_cfg=asset_cfg, waypoints=points), ''),
        ('multistage_pose_target_match', dict(waypoints=points, joint_indices=subset), ''),
        ('multistage_pose_l1_penalty', dict(waypoints=points, joint_indices=subset), ''),
        ('pose_target_match', dict(target_overrides=override, joint_indices=subset), ''),
        ('pose_l1_penalty', dict(target_overrides=override, joint_indices=subset), ''),
        ('phase_pose_match', dict(target_overrides=override, joint_indices=subset, phase='return' if seed % 2 else 'approach'), ''),
        ('height_target_gaussian', dict(target_height=.11), ''),
        ('height_l1_penalty', dict(target_height=.11), ''),
        ('interpolated_height_target', dict(start_height=.12, end_height=.06, **ramp), ''),
        ('interpolated_height_l1_penalty', dict(start_height=.12, end_height=.06, **ramp), ''),
        ('multistage_height_target', dict(waypoints=heights), ''),
        ('multistage_height_l1_penalty', dict(waypoints=heights), ''),
        ('phase_height_track', dict(command_name='phase', stand_z=.12, sit_z=.06), ''),
        ('_posture_height', dict(command_name='phase', stand_z=.12, sit_z=.06), ''),
        ('upright_gaussian_at_height', dict(std=.5, height_low=.07, height_high=.12), ''),
        ('upright_while_tall', dict(height_low=.07, height_high=.12), ''),
        ('com_height_target', {}, ''),
        ('com_upward_velocity', dict(max_height=.08, gate_z_below=.1, max_vz=.3), ''),
        ('seated_stillness', {}, ''),
    ]


counts = Counter()
checks = Counter()


def compare(dtype, device, seed, case_index, nonfinite=False):
    name, options, mode = cases(seed)[case_index]
    results = []
    rng = [torch.get_rng_state().clone()] + ([torch.cuda.get_rng_state().clone()] if device == 'cuda' else [])
    for namespace in [before, after]:
        env, inputs = environment(dtype, device, seed, nonfinite)
        defaults = inputs[1].detach().clone()
        output = namespace[name](env, env.scene['robot'], **options) if mode == 'asset' else namespace[name](env, **options)
        outputs = output if isinstance(output, tuple) else (output,)
        differentiable = [v for v in outputs if v.requires_grad]
        gradients = torch.autograd.grad(sum(v.sum() for v in differentiable), inputs, allow_unused=True) if differentiable else (None,) * len(inputs)
        exact(inputs[1], defaults, name + ':mutated-default')
        results.append((output, gradients))
    exact(results[0], results[1], name + ':' + device + ':' + str(dtype) + ':' + str(seed))
    current = [torch.get_rng_state()] + ([torch.cuda.get_rng_state()] if device == 'cuda' else [])
    exact(rng, current, name + ':global-rng')
    counts[name] += 1
    checks[device + '/' + str(dtype)] += 1


watched = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [args.baseline, args.candidate]}
started = time.monotonic()
began = datetime.now(timezone.utc).isoformat()
cycles, failures = 0, []


def sample(status):
    values = dict(line.split(':', 1) for line in Path('/proc/self/status').read_text().splitlines() if ':' in line)
    row = {'seconds': time.monotonic() - started, 'cycles': cycles, 'checks': sum(counts.values()), 'rss_kib': int(values['VmRSS'].split()[0]), 'fds': len(os.listdir('/proc/self/fd')), 'time': datetime.now(timezone.utc).isoformat()}
    with (args.output / 'samples.jsonl').open('a') as stream:
        stream.write(json.dumps(row) + '\n')
    result = {'status': status, 'started_at': began, 'seconds': row['seconds'], 'requested_seconds': args.seconds, 'cycles': cycles, 'checks': sum(counts.values()), 'counts': dict(counts), 'precision_devices': dict(checks), 'devices': devices, 'last_sample': row, 'source_hashes': watched, 'failures': failures, 'scope': __doc__, 'comparison': 'Exact tensor bytes including gradients and signed zeros, default pose immutability and no global RNG advancement. Private tensor fixtures, not robot training.', 'torch': torch.__version__, 'cuda': torch.version.cuda}
    temporary = args.output / 'summary.tmp'
    temporary.write_text(json.dumps(result, indent=2) + '\n')
    temporary.replace(args.output / 'summary.json')
    print(json.dumps(row), flush=True)


try:
    for device in devices:
        for dtype in [torch.float32, torch.float64]:
            for seed in range(9):
                for case_index in range(len(cases(seed))):
                    compare(dtype, device, seed, case_index)
            # Nonfinite height conversion is checked directly; nonlinear reward
            # gradients at infinities are outside the finite training contract.
            compare(dtype, device, 91, 0, nonfinite=True)
    sample('running')
    last_sample = time.monotonic()
    while time.monotonic() - started < args.seconds:
        device = devices[(cycles // 24) % len(devices)]
        dtype = [torch.float32, torch.float64][(cycles // (24 * len(devices))) % 2]
        compare(dtype, device, cycles // 24 + 100, cycles % 24)
        cycles += 1
        if time.monotonic() - last_sample >= 30:
            sample('running')
            last_sample = time.monotonic()
        time.sleep(.04)
    assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == value for path, value in watched.items())
    sample('complete')
except BaseException as error:
    failures.append({'type': type(error).__name__, 'error': str(error)})
    sample('failed')
    raise
