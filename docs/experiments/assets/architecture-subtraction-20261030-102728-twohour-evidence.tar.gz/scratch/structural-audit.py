"""Verify mechanical height extraction and unchanged public signatures."""
import ast
import copy
import hashlib
import json
from pathlib import Path

root = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
work = Path('/tmp/embodiedforge-subtraction-20261030-102728-twohour')
relative = Path('src/embodiedforge/locomotion/microduck/tasks/mdp.py')
old = ast.parse((work / 'baseline' / relative).read_text())
new = ast.parse((root / relative).read_text())
dump = lambda node: ast.dump(node, include_attributes=False) if node is not None else None
expression = ast.parse('torch.nan_to_num(asset.data.root_link_pos_w[:, 2] - env.scene.terrain.env_origins[:, 2], nan=0.0)', mode='eval').body
original_sites = [n.lineno for n in ast.walk(old) if dump(n) == dump(expression)]
calls = [n for n in ast.walk(new) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == '_relative_root_height']
assert len(original_sites) == len(calls) == 27


class InlineHeight(ast.NodeTransformer):
    def visit_Call(self, node):
        if isinstance(node.func, ast.Name) and node.func.id == '_relative_root_height':
            assert not node.keywords
            assert [dump(v) for v in node.args] == [dump(ast.Name(id='env', ctx=ast.Load())), dump(ast.Name(id='asset', ctx=ast.Load()))]
            return copy.deepcopy(expression)
        return self.generic_visit(node)


expanded = InlineHeight().visit(copy.deepcopy(new))
old_defs = {n.name: n for n in old.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
new_defs = {n.name: n for n in new.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
expanded_defs = {n.name: n for n in expanded.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
assert old_defs.keys() <= new_defs.keys()
assert new_defs.keys() - old_defs.keys() == {'_relative_root_height', '_pose_override'}
public = [n for n in old_defs.values() if isinstance(n, ast.FunctionDef) and not n.name.startswith('_')]
for node in public:
    assert dump(node.args) == dump(new_defs[node.name].args), node.name
    assert dump(node.returns) == dump(new_defs[node.name].returns), node.name
remaining = [name for name in old_defs if dump(old_defs[name]) != dump(expanded_defs[name])]
expected_pose_changes = {
    'standing_composite_score', 'standing_success_bonus',
    'interpolated_pose_target_match', 'interpolated_pose_l1_penalty',
    '_multistage_target_pose', 'pose_target_match', 'pose_l1_penalty', 'phase_pose_match',
}
assert set(remaining) == expected_pose_changes, remaining
height_helper = new_defs['_relative_root_height']
assert dump(height_helper.body[-1].value) == dump(expression)
local_builder = next(n for n in old_defs['_multistage_target_pose'].body if isinstance(n, ast.FunctionDef) and n.name == 'build_pose')
pose_helper = new_defs['_pose_override']
assert [dump(n) for n in local_builder.body] == [dump(n) for n in pose_helper.body[1:]]
assert dump(old_defs['SitStandCommand']) == dump(expanded_defs['SitStandCommand'])
modules = sorted((root / 'src/embodiedforge').rglob('*.py'))
lines = sum(len(p.read_text().splitlines()) for p in modules)
result = {
    'status': 'passed', 'exact_height_expression_sites': len(calls),
    'old_height_lines': sorted(original_sites),
    'public_function_signatures_preserved': len(public),
    'height_helper_ast_equals_original_expression': True,
    'pose_helper_ast_equals_original_local_builder': True,
    'all_other_top_level_definitions_ast_identical_after_height_inlining': True,
    'remaining_pose_definitions': sorted(remaining),
    'sitstand_command_distinct_nan_policy_preserved': True,
    'source_modules': len(modules), 'source_lines': lines,
    'source_line_delta': lines - 37915,
    'source_sha256': hashlib.sha256((root / relative).read_bytes()).hexdigest(),
}
(work / 'structural-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
