"""Watch frozen source, sustained comparison and preservation until the deadline."""
import hashlib
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

root = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
work = Path('/tmp/embodiedforge-subtraction-20261030-102728-twohour')
state = json.loads((work / 'state.json').read_text())
deadline = datetime.fromisoformat(state['deadline']).timestamp()
watched = {p.relative_to(work / 'candidate'): hashlib.sha256(p.read_bytes()).hexdigest()
           for p in (work / 'candidate').rglob('*.py')}
last_integrity = 0
samples = 0
first = time.monotonic()
try:
    while True:
        now = datetime.now(timezone.utc)
        summary = json.loads((work / 'numerical-soak/summary.json').read_text())
        assert not summary['failures'] and summary['status'] in {'running', 'complete'}
        assert all(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest for name, digest in watched.items()), 'frozen source changed'
        integrity = False
        if time.monotonic() - last_integrity >= 600:
            subprocess.run([sys.executable, str(work / 'refresh-report.py')], check=True, stdout=subprocess.DEVNULL, timeout=60)
            last_integrity = time.monotonic()
            integrity = True
        result_path = work / 'soak-supervisor/result.json'
        observed = json.loads(result_path.read_text()) if result_path.exists() else None
        if observed:
            assert observed['completed_successfully'] and observed['process_returncode'] == 0
        row = {'time': now.isoformat(), 'comparison_minutes': round(summary['seconds'] / 60, 2),
               'checks': summary['checks'], 'status': summary['status'],
               'rss_kib': summary['last_sample']['rss_kib'], 'fds': summary['last_sample']['fds'],
               'failures': len(summary['failures']), 'source_files_verified': len(watched),
               'full_preservation_check': integrity, 'supervised_exit': observed['process_returncode'] if observed else None,
               'remaining_minutes': round(max(0, deadline - now.timestamp()) / 60, 2)}
        with (work / 'monitor-samples.jsonl').open('a') as stream:
            stream.write(json.dumps(row) + '\n')
        print(json.dumps(row), flush=True)
        samples += 1
        if now.timestamp() >= deadline:
            assert summary['status'] == 'complete' and observed is not None
            break
        time.sleep(min(45, max(.1, deadline - time.time())))
    (work / 'monitor-result.json').write_text(json.dumps({'status': 'complete', 'samples': samples, 'monitor_seconds': time.monotonic() - first, 'last_sample': row}, indent=2) + '\n')
except BaseException as error:
    (work / 'monitor-result.json').write_text(json.dumps({'status': 'failed', 'error': repr(error)}, indent=2) + '\n')
    raise
