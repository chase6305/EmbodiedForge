"""Paired CPU call latency: subtraction must preserve practical reward cost."""
import json
import os
import runpy
import statistics
import sys
import time
from pathlib import Path

import torch

work = Path('/tmp/embodiedforge-subtraction-20261030-102728-twohour')
relative = 'src/embodiedforge/locomotion/microduck/tasks/mdp.py'
sys.argv = ['numerical-soak.py', '--baseline', str(work / 'baseline' / relative),
            '--candidate', str(work / 'candidate' / relative),
            '--output', str(work / 'numerical-latency-warmup'), '--seconds', '0']
scope = runpy.run_path(str(work / 'numerical-soak.py'))
available = os.sched_getaffinity(0)
core = max(available)
os.sched_setaffinity(0, {core})
env, _ = scope['environment'](torch.float32, 'cpu', 105)
results = []
selected = [0, 1, 3, 5, 8, 10, 13, 15]
loops, repeats = 1000, 11
with torch.inference_mode():
    for index in selected:
        name, options, mode = scope['cases'](105)[index]
        def invoke(namespace):
            if mode == 'asset':
                return namespace[name](env, env.scene['robot'], **options)
            return namespace[name](env, **options)
        for _ in range(30):
            invoke(scope['before'])
            invoke(scope['after'])
        timings = {'before': [], 'after': []}
        for repeat in range(repeats):
            for key in (['before', 'after'] if repeat % 2 == 0 else ['after', 'before']):
                namespace = scope[key]
                started = time.perf_counter_ns()
                for _ in range(loops):
                    invoke(namespace)
                timings[key].append((time.perf_counter_ns() - started) / loops / 1000)
        medians = {key: statistics.median(values) for key, values in timings.items()}
        results.append({'function': name, 'baseline_kind': 'inline expression wrapped by probe' if name == '_relative_root_height' else 'original source function', 'microseconds_per_call': timings,
                        'median_microseconds': medians, 'candidate_over_baseline': medians['after'] / medians['before']})
result = {'status': 'measured', 'scope': __doc__, 'device': 'cpu', 'dtype': 'float32',
          'batch_size': 19, 'torch_threads': 1, 'affinity_core': core,
          'iterations_per_sample': loops, 'paired_samples': repeats,
          'torch': torch.__version__, 'results': results,
          'limits': 'Private tensor fixtures and a shared host. CPU calls only, no training-throughput or GPU-performance claim.'}
(work / 'cpu-call-cost.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({row['function']: round(row['candidate_over_baseline'], 4) for row in results}, indent=2))
