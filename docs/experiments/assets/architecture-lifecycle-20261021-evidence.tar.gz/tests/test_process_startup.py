"""Real child startup failures must not hang while unwinding Popen ownership."""

import os
import signal
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

from embodiedforge.runtime import process


@pytest.mark.skipif(os.name != "posix", reason="POSIX process ownership")
@pytest.mark.parametrize("stage", ["construct", "start", "started"])
def test_log_thread_startup_failure_stops_and_reaps_the_owned_child(tmp_path, stage):
    ready = tmp_path / "child.pid"
    child = (
        "import os,time;from pathlib import Path;"
        f"Path({str(ready)!r}).write_text(str(os.getpid()));time.sleep(30)"
    )
    wrapper = textwrap.dedent(f"""
        import os,sys,time
        from pathlib import Path
        sys.path.insert(0, {str(Path(__file__).resolve().parents[1] / "src")!r})
        from embodiedforge.runtime import process
        original = process.threading.Thread
        primary = RuntimeError('log thread startup failed')
        def wait_ready():
            deadline=time.monotonic()+3
            while not Path({str(ready)!r}).is_file():
                if time.monotonic()>deadline: raise AssertionError('child not ready')
                time.sleep(.01)
        class Thread(original):
            def __init__(self, *args, **kwargs):
                if {stage!r}=='construct':
                    wait_ready()
                    raise primary
                super().__init__(*args,**kwargs)
            def start(self):
                if {stage!r}=='started': super().start()
                wait_ready()
                raise primary
        process.threading.Thread=Thread
        try:
            process.run_process([sys.executable,'-c',{child!r}],cwd=Path({str(tmp_path)!r}),
                env=os.environ.copy(),log_path=Path({str(tmp_path / "output.log")!r}))
        except RuntimeError as error:
            assert error is primary, repr(error)
        else:
            raise AssertionError('startup error was hidden')
        assert not any(t.is_alive() for t in process.threading.enumerate()
                       if t is not process.threading.main_thread())
        print('original error preserved; reader stopped; child reaped')
    """)
    owner = subprocess.Popen(
        [sys.executable, "-c", wrapper],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        start_new_session=True,
    )
    stalled = False
    try:
        try:
            stdout, stderr = owner.communicate(timeout=3)
        except subprocess.TimeoutExpired:
            stalled = True
            # Reap the baseline failure's child through its still-owning wrapper.
            if ready.exists():
                try:
                    os.killpg(int(ready.read_text()), signal.SIGKILL)
                except ProcessLookupError:
                    pass
            stdout, stderr = owner.communicate(timeout=3)
    finally:
        if owner.poll() is None:
            os.killpg(owner.pid, signal.SIGKILL)
            owner.communicate(timeout=3)
    assert not stalled, f"Startup failure left Popen waiting for its child: {stderr}"
    assert owner.returncode == 0, stderr
    assert "child reaped" in stdout
    with pytest.raises(ProcessLookupError):
        os.kill(int(ready.read_text()), 0)


@pytest.mark.skipif(os.name != "posix", reason="POSIX termination handlers")
@pytest.mark.parametrize("after_install", [False, True])
def test_partial_termination_handler_setup_restores_previous_handlers(
    monkeypatch, after_install
):
    original = signal.signal
    saved = {sig: signal.getsignal(sig) for sig in (signal.SIGTERM, signal.SIGHUP)}
    primary = OSError("handler installation failed")
    injected = False

    def fail(sig, handler):
        nonlocal injected
        if sig == signal.SIGHUP and not injected:
            injected = True
            if after_install:
                original(sig, handler)
            raise primary
        return original(sig, handler)

    try:
        original(signal.SIGHUP, signal.SIG_DFL)
        monkeypatch.setattr(process.signal, "signal", fail)
        with pytest.raises(OSError) as caught:
            with process.termination_signals():
                pytest.fail("Partial setup entered the protected body")
        assert caught.value is primary
        assert signal.getsignal(signal.SIGTERM) == saved[signal.SIGTERM]
        assert signal.getsignal(signal.SIGHUP) == signal.SIG_DFL
    finally:
        for sig, handler in saved.items():
            original(sig, handler)


@pytest.mark.skipif(os.name != "posix", reason="POSIX termination handlers")
@pytest.mark.parametrize(
    "primary", [None, RuntimeError("worker failed"), KeyboardInterrupt()]
)
@pytest.mark.parametrize("after_restore", [False, True])
def test_signal_restore_failure_attempts_all_handlers_and_keeps_primary_error(
    monkeypatch, caplog, primary, after_restore
):
    original = signal.signal
    saved = {sig: signal.getsignal(sig) for sig in (signal.SIGTERM, signal.SIGHUP)}
    restore_error = OSError("signal restore failed")
    restored = []

    def fail(sig, handler):
        if handler == signal.SIG_DFL:
            restored.append(sig)
            if sig == signal.SIGTERM:
                if after_restore:
                    original(sig, handler)
                raise restore_error
        return original(sig, handler)

    try:
        for sig in saved:
            original(sig, signal.SIG_DFL)
        monkeypatch.setattr(process.signal, "signal", fail)
        expected = primary if primary is not None else restore_error
        with pytest.raises(type(expected)) as caught:
            with process.termination_signals():
                if primary is not None:
                    raise primary
        assert caught.value is expected
        assert restored == [signal.SIGTERM, signal.SIGHUP]
        assert signal.getsignal(signal.SIGHUP) == signal.SIG_DFL
        assert "signal restore failed" in caplog.text
    finally:
        for sig, handler in saved.items():
            original(sig, handler)
