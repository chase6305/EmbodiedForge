"""Real process groups, inherited locks and lifecycle records; bounded probe data."""

import argparse
import ctypes
import gc
import json
import os
import shutil
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

from embodiedforge.runtime.artifacts import write_json
from embodiedforge.runtime.process import run_process
from embodiedforge.runtime.records import managed_run, read_run, run_identity


def resources():
    proc = Path("/proc/self")
    status = dict(
        line.split(":", 1) for line in (proc / "status").read_text().splitlines()
    )
    return {
        "rss_bytes": int(status["VmRSS"].split()[0]) * 1024,
        "threads": int(status["Threads"]),
        "fds": len(list((proc / "fd").iterdir())),
    }


def probe(root, mode):
    import fcntl

    # Reap the deliberately orphaned fixture descendant instead of relying on PID 1.
    assert ctypes.CDLL(None).prctl(36, 1, 0, 0, 0) == 0
    root.mkdir()
    descendant_code = "import os,signal,time;from pathlib import Path;signal.signal(signal.SIGINT,signal.SIG_IGN);Path('descendant.pid').write_text(str(os.getpid()));time.sleep(30)"
    child_code = """import fcntl,os,signal,subprocess,sys,time
from pathlib import Path
assert os.fstat(int(sys.argv[3])).st_ino==Path('inherited.lock').stat().st_ino
lock=Path('inherited.lock').open('a')
try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
except BlockingIOError: pass
else: raise AssertionError('trainer did not inherit the run lock')
def stop(*args):
    Path('cleaned').touch()
    raise SystemExit(0)
signal.signal(signal.SIGINT,stop)
subprocess.Popen([sys.executable,'-c',sys.argv[1]],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
while not Path('descendant.pid').exists(): time.sleep(.005)
Path('ready').touch()
os.write(1, bytes((255,10)))
if sys.argv[2]=='success': raise SystemExit(0)
if sys.argv[2]=='failure': raise SystemExit(7)
time.sleep(30)
"""
    trigger = None
    triggered = []

    def interrupt():
        deadline = time.monotonic() + 8
        while not (root / "ready").exists():
            if time.monotonic() >= deadline:
                return
            time.sleep(0.005)
        triggered.append(True)
        os.kill(os.getpid(), signal.SIGTERM)

    caught = None
    try:
        with managed_run(root, run_identity("probe", mode)):
            if mode == "interrupt":
                trigger = threading.Thread(target=interrupt)
                trigger.start()
            with (root / "inherited.lock").open("a") as lock:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                run_process(
                    [
                        sys.executable,
                        "-c",
                        child_code,
                        descendant_code,
                        mode,
                        str(lock.fileno()),
                    ],
                    cwd=root,
                    env=os.environ.copy(),
                    log_path=root / "worker.log",
                    echo=True,
                    timeout=1.0 if mode == "timeout" else 10,
                    pass_fds=(lock.fileno(),),
                )
    except BaseException as error:
        caught = error
    finally:
        if trigger is not None:
            trigger.join(timeout=9)
    assert threading.enumerate() == [threading.main_thread()]
    assert (root / "worker.log").read_bytes() == bytes((255, 10))
    expected = {
        "success": "complete",
        "failure": "failed",
        "timeout": "timed_out",
        "interrupt": "interrupted",
    }[mode]
    observed = read_run(root)
    assert observed["status"] == expected, (mode, observed, caught)
    if mode == "success":
        assert caught is None
    elif mode == "failure":
        assert (
            isinstance(caught, subprocess.CalledProcessError) and caught.returncode == 7
        ), caught
    elif mode == "timeout":
        assert isinstance(caught, subprocess.TimeoutExpired), caught
    else:
        assert (
            triggered
            and isinstance(caught, KeyboardInterrupt)
            and caught.signum == signal.SIGTERM
        ), caught
    if mode in ("timeout", "interrupt"):
        assert (root / "cleaned").is_file()
    pid = int((root / "descendant.pid").read_text())
    deadline = time.monotonic() + 3
    reaped = 0
    while not reaped and time.monotonic() < deadline:
        reaped, _ = os.waitpid(pid, os.WNOHANG)
        if not reaped:
            time.sleep(0.005)
    if not reaped:
        os.kill(pid, signal.SIGKILL)
        os.waitpid(pid, 0)
        raise AssertionError("owned descendant survived process-group cleanup")
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        pass
    else:
        raise AssertionError("reaped descendant still exists")
    with (root / "inherited.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    write_json(
        root / "verified.json",
        {
            "mode": mode,
            "status": observed["status"],
            "descendant_reaped": True,
            "lock_released": True,
        },
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--worker", choices=["success", "failure", "timeout", "interrupt"]
    )
    parser.add_argument("--duration", type=float, default=3600)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output = args.output.resolve()
    if args.worker:
        probe(args.output, args.worker)
        return
    args.output.mkdir(parents=True)
    shutil.copyfile(__file__, args.output / "benchmark.py")
    began = time.monotonic()
    samples = []
    cycles = 0
    modes = ["success", "failure", "timeout", "interrupt"]
    with managed_run(
        args.output, run_identity("benchmark", "validate", "process-lifecycle")
    ) as record:
        initial = resources()
        with (args.output / "samples.jsonl").open("x") as log:
            while time.monotonic() - began < args.duration:
                cycle = args.output / "cycle"
                cycle.mkdir()
                for mode in modes:
                    run_process(
                        [
                            sys.executable,
                            str(Path(__file__).resolve()),
                            "--worker",
                            mode,
                            "--output",
                            str(cycle / mode),
                        ],
                        cwd=args.output,
                        env=os.environ.copy(),
                        log_path=cycle / (mode + ".log"),
                        echo=False,
                        timeout=20,
                    )
                    assert json.loads((cycle / mode / "verified.json").read_text())[
                        "descendant_reaped"
                    ]
                shutil.rmtree(cycle)
                cycles += 1
                gc.collect()
                sample = {
                    "seconds": time.monotonic() - began,
                    "cycles": cycles,
                    "verified_scenarios": cycles * len(modes),
                    "resources": resources(),
                }
                log.write(json.dumps(sample) + "\n")
                log.flush()
                if not samples or sample["seconds"] - samples[-1]["seconds"] >= 30:
                    samples.append(sample)
                    print(json.dumps(sample), flush=True)
        result = {
            "scope": "Linux captured logs with invalid UTF-8, joined reader threads, real worker groups, orphan reaping, inherited locks and lifecycle records",
            "cycles": cycles,
            "verified_scenarios": cycles * len(modes),
            "seconds": time.monotonic() - began,
            "initial_resources": initial,
            "final_resources": resources(),
            "samples": samples,
            "all_scenarios_passed": True,
        }
        write_json(args.output / "summary.json", result)
        record.update(cycles=cycles, verified_scenarios=cycles * len(modes))
        print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
