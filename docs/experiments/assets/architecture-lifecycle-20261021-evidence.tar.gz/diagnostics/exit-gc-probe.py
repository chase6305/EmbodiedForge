import argparse,gc,os,subprocess,time
from pathlib import Path
import numpy
p=argparse.ArgumentParser();p.add_argument('--mode',required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
args.output.mkdir()
if args.mode!='bare':
    from embodiedforge.runtime.process import run_process
start=time.monotonic()
for i in range(3000):
    if args.mode=='bare': subprocess.run(['/usr/bin/true'],check=True,start_new_session=True)
    else: run_process(['/usr/bin/true'],cwd=args.output,env=os.environ.copy(),log_path=args.output/'worker.log',echo=False,append_log=True)
    if i%4==0: gc.collect()
print(args.mode,'passed 3000 launches',time.monotonic()-start,flush=True)
