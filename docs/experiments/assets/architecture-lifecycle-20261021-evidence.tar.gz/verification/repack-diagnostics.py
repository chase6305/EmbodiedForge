import hashlib,json,tarfile
from pathlib import Path
root=Path('/tmp/embodiedforge-architecture-20261021')
report=Path('docs/experiments/architecture-lifecycle-20261021.json')
data=json.loads(report.read_text())
diagnosis=json.loads((root/'captured-exit-diagnosis.json').read_text())
diagnosis['short_rechecks']['python310_60s']=0
diagnosis['rapid_launch_rechecks']={'current_3000':0,'baseline_3000':0,'bare_subprocess_3000':0}
(root/'captured-exit-diagnosis.json').write_text(json.dumps(diagnosis,indent=2)+'\n')
archive=report.parent/data['evidence']['path']
temporary=archive.with_name(archive.name+'.repack.tmp')
with tarfile.open(archive) as old,tarfile.open(temporary,'w:gz') as new:
    for member in old:
        if member.name=='diagnostics/captured-exit-diagnosis.json':continue
        new.addfile(member,old.extractfile(member) if member.isfile() else None)
    for filename in ('captured-exit-diagnosis.json','gc-current.log','gc-baseline.log','gc-bare.log','exit-gc-probe.py'):
        new.add(root/filename,arcname='diagnostics/'+filename)
    new.add(Path(__file__),arcname='verification/repack-diagnostics.py')
temporary.replace(archive)
data['evidence']['sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
data['evidence']['bytes']=archive.stat().st_size
data['open_issue']['follow_up_diagnostics']=diagnosis
temporary=report.with_name(report.name+'.tmp')
temporary.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
temporary.replace(report)
with tarfile.open(archive) as source:
    count=0
    for member in source:
        if member.isfile():source.extractfile(member).read()
        count+=1
print('Updated and verified evidence:',count,'entries',data['evidence'])
