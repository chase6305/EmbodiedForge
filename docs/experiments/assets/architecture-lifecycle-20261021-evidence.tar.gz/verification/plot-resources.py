"""Plot resource observations from the completed architecture probes."""

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

parser = argparse.ArgumentParser()
parser.add_argument("--root", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
names = {
    "core-recording": "Core RGB/depth",
    "go1-recording": "Go1",
    "h1-recording": "H1",
    "process-lifecycle": "Quiet workers",
    "process-lifecycle-captured": "Captured workers",
}
fig, axes = plt.subplots(2, 2, figsize=(12, 7), layout="constrained")
colors = plt.get_cmap("tab10").colors
for index, (name, label) in enumerate(names.items()):
    rows = [
        json.loads(line)
        for line in (args.root / name / "samples.jsonl").read_text().splitlines()
    ]
    # Downsample the drawing only; raw samples remain in the evidence archive.
    selected = []
    for row in rows:
        if not selected or row["seconds"] - selected[-1]["seconds"] >= 10:
            selected.append(row)
    if selected[-1] is not rows[-1]:
        selected.append(rows[-1])
    reference = next((row for row in rows if row["seconds"] >= 300), rows[0])[
        "resources"
    ]
    t = [row["seconds"] / 60 for row in selected]
    r = [row["resources"] for row in selected]
    color = colors[index]
    axes[0, 0].plot(
        t,
        [(v["rss_bytes"] - reference["rss_bytes"]) / 1024**2 for v in r],
        label=label,
        color=color,
        lw=1.2,
    )
    if "python_traced_bytes" in reference:
        axes[0, 1].plot(
            t,
            [
                (v["python_traced_bytes"] - reference["python_traced_bytes"]) / 1024
                for v in r
            ],
            label=label,
            color=color,
            lw=1.2,
        )
    axes[1, 0].plot(t, [v["threads"] for v in r], label=label, color=color, lw=1.2)
    fd = "file_descriptors" if "file_descriptors" in reference else "fds"
    axes[1, 1].plot(t, [v[fd] for v in r], label=label, color=color, lw=1.2)
for axis, title, ylabel in zip(
    axes.flat,
    [
        "Resident memory",
        "Python live allocations",
        "Process thread count",
        "Open file descriptors",
    ],
    [
        "RSS change from 5-minute reference (MiB)",
        "Change from 5-minute reference (KiB)",
        "Threads",
        "Descriptors",
    ],
    strict=True,
):
    axis.set(title=title, xlabel="Elapsed time (minutes)", ylabel=ylabel)
    axis.grid(alpha=0.25)
    axis.legend(fontsize=7, loc="best")
axes[1, 0].yaxis.set_major_locator(MaxNLocator(integer=True))
axes[1, 1].yaxis.set_major_locator(MaxNLocator(integer=True))
fig.suptitle(
    "EmbodiedForge: sustained recording and process lifecycle validation", fontsize=13
)
fig.supxlabel(
    "CPU zero policies; CRC + SHA256 verification and allocation tracing enabled. Resource observations include benchmark bookkeeping.",
    fontsize=8,
)
args.output.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(args.output.with_suffix(".svg"))
fig.savefig(args.output.with_suffix(".png"), dpi=150)
plt.close(fig)
