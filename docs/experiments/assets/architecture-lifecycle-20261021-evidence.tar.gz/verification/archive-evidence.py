"""Publish the completed validation report and its reviewable local evidence."""

import difflib
import hashlib
import json
import tarfile
from pathlib import Path

REPO = Path("/home/ubuntu/workspace/chase/EmbodiedForge")
TEMP = Path("/tmp/embodiedforge-architecture-20261021")
RUNS = REPO / "runs/architecture-optimization-20261021"
ASSETS = REPO / "docs/experiments/assets"
NAME = "architecture-lifecycle-20261021"


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024**2):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    summary = json.loads((RUNS / "evidence/summary.json").read_text())
    for name in summary["sustained"]:
        record = json.loads((RUNS / "final" / name / "run.json").read_text())
        assert record["status"] == "complete", (name, record)
    differences = []
    changed = []
    baseline = TEMP / "reference"
    for folder in ("src", "tests", "docs", "benchmarks", ".github"):
        for path in sorted((REPO / folder).rglob("*")):
            if (
                not path.is_file()
                or path.suffix not in (".py", ".md", ".toml", ".yml", ".yaml", ".in")
                or "__pycache__" in path.parts
            ):
                continue
            relative = path.relative_to(REPO)
            previous = baseline / relative
            old = previous.read_text() if previous.is_file() else ""
            new = path.read_text()
            if old == new:
                continue
            changed.append(str(relative))
            differences.extend(
                difflib.unified_diff(
                    old.splitlines(True),
                    new.splitlines(True),
                    fromfile="baseline/" + str(relative),
                    tofile="candidate/" + str(relative),
                )
            )
    diff = RUNS / "evidence/workspace-changes.diff"
    diff.write_text("".join(differences))
    summary["changed_files"] = changed
    archive = ASSETS / (NAME + "-evidence.tar.gz")
    ASSETS.mkdir(exist_ok=True)
    assert not archive.exists(), archive
    with tarfile.open(archive, "x:gz") as out:
        out.add(RUNS / "evidence/summary.json", arcname="summary.json")
        out.add(diff, arcname="workspace-changes.diff")
        for name in summary["sustained"]:
            root = RUNS / "final" / name
            for filename in (
                "summary.json",
                "samples.jsonl",
                "allocations.json",
                "run.json",
                "benchmark.py",
            ):
                path = root / filename
                if path.is_file():
                    out.add(path, arcname=f"probes/{name}/{filename}")
        for filename in ("architecture_parity.py", "native_recording_soak.py"):
            out.add(REPO / "benchmarks" / filename, arcname="benchmarks/" + filename)
        for path in sorted((RUNS / "training-parity").rglob("result.json")):
            out.add(
                path,
                arcname="training-parity/"
                + str(path.relative_to(RUNS / "training-parity")),
            )
        out.add(
            RUNS / "training-parity/summary.json",
            arcname="training-parity/summary.json",
        )
        out.add(RUNS / "existing-runs.json", arcname="existing-runs.json")
        out.add(RUNS / "legacy-datasets.json", arcname="legacy-datasets.json")
        out.add(RUNS / "process-exit-codes.json", arcname="process-exit-codes.json")
        out.add(
            TEMP / "captured-exit-kernel.log",
            arcname="diagnostics/captured-exit-kernel.log",
        )
        for filename in (
            "captured-exit-diagnosis.json",
            "captured-exit-check.log",
            "captured-single-blas.log",
            "captured-python310.log",
        ):
            out.add(TEMP / filename, arcname="diagnostics/" + filename)
        for filename in (
            "process-soak.py",
            "process-soak-captured.py",
            "collect-evidence.py",
            "archive-evidence.py",
            "plot-resources.py",
            "check-installed-wheel.py",
            "distribution-integrity.json",
            "environments.json",
        ):
            out.add(TEMP / filename, arcname="verification/" + filename)
        for name in (
            "final-main-suite",
            "final-act-sdk",
            "microduck-sdk",
            "native-contracts",
            "sdist-validation",
        ):
            for suffix in (".xml", ".log"):
                path = TEMP / (name + suffix)
                if path.exists():
                    out.add(path, arcname="tests/" + path.name)
        for name in ("installed-wheel.log", "native-startup.log"):
            out.add(TEMP / name, arcname="tests/" + name)
        for label, root in (
            ("baseline", TEMP / "reference/src/embodiedforge"),
            ("candidate", TEMP / "final-soak/src/embodiedforge"),
        ):
            for path in sorted(root.rglob("*")):
                if (
                    path.is_file()
                    and (
                        path.suffix in (".py", ".xml")
                        or path.name.startswith("LICENSE")
                    )
                    and "__pycache__" not in path.parts
                ):
                    out.add(
                        path,
                        arcname=f"source/{label}/src/embodiedforge/"
                        + str(path.relative_to(root)),
                    )
        for relative in changed:
            if relative.startswith("tests/"):
                out.add(REPO / relative, arcname=relative)
    summary["evidence"] = {
        "path": "assets/" + archive.name,
        "sha256": sha(archive),
        "bytes": archive.stat().st_size,
    }
    summary["resource_chart"] = {
        "path": "assets/" + NAME + "-resources.svg",
        "sha256": sha(ASSETS / (NAME + "-resources.svg")),
    }
    target = REPO / "docs/experiments" / (NAME + ".json")
    assert not target.exists(), target
    target.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n")
    print(
        json.dumps(
            {
                "report": str(target),
                "evidence": summary["evidence"],
                "changed_files": len(changed),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
