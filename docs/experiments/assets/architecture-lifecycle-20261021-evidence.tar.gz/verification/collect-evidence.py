"""Summarize completed architecture validation without altering source or runs."""

import hashlib
import json
import platform
import statistics
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

REPO = Path("/home/ubuntu/workspace/chase/EmbodiedForge")
TEMP = Path("/tmp/embodiedforge-architecture-20261021")
RUNS = REPO / "runs/architecture-optimization-20261021"


def load(path):
    return json.loads(path.read_text())


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024**2):
            digest.update(chunk)
    return digest.hexdigest()


def tests(path):
    root = ET.parse(path).getroot()
    cases = list(root.iter("testcase"))
    passed = sum(
        all(c.find(kind) is None for kind in ("failure", "error", "skipped"))
        for c in cases
    )
    return {
        "passed": passed,
        "cases": len(cases),
        "failures": sum(c.find("failure") is not None for c in cases),
        "errors": sum(c.find("error") is not None for c in cases),
        "skipped": sum(c.find("skipped") is not None for c in cases),
        "file": path.name,
        "sha256": sha(path),
    }


def sampling(root):
    summary = load(root / "summary.json")
    samples = [
        json.loads(line) for line in (root / "samples.jsonl").read_text().splitlines()
    ]
    after = [row for row in samples if row["seconds"] >= 300] or samples
    end = [row for row in samples if row["seconds"] >= samples[-1]["seconds"] - 300]
    resource = after[0]["resources"]
    tracked = {
        key: {
            "minimum": min(row["resources"][key] for row in after),
            "maximum": max(row["resources"][key] for row in after),
            "first_after_warmup": resource[key],
            "last": samples[-1]["resources"][key],
        }
        for key in resource
        if "peak" not in key
    }
    rss = [row["resources"]["rss_bytes"] for row in end]
    result = {
        "duration_seconds": summary["seconds"],
        "samples": len(samples),
        "resources_after_300s_warmup": tracked,
        "last_300s_rss_median_bytes": statistics.median(rss),
        "summary_sha256": sha(root / "summary.json"),
        "samples_sha256": sha(root / "samples.jsonl"),
    }
    result["recorded_run"] = load(root / "run.json")
    assert result["recorded_run"]["status"] == "complete"
    assert summary["seconds"] >= (5400 if "segments" in summary else 3600)
    if "segments" in summary:
        assert summary["all_segments_equal"] is True
        assert summary["episodes_per_mode"] == sum(row["episodes"] for row in samples)
        assert summary["transitions_per_mode"] == sum(
            row["transitions"] for row in samples
        )
        result.update(
            segments=summary["segments"],
            episodes_per_mode=summary["episodes_per_mode"],
            transitions_per_mode=summary["transitions_per_mode"],
            all_segments_equal=True,
            observed_retained_payload_peak_bytes=[
                max(row["peak_payload_bytes"][i] for row in samples) for i in range(2)
            ],
            payload_budget_bytes=16 * 1024**2,
        )
    else:
        assert summary["all_scenarios_passed"] is True
        result.update(
            cycles=summary["cycles"],
            verified_scenarios=summary["verified_scenarios"],
            all_scenarios_passed=True,
        )
    return result


def main():
    evidence = RUNS / "evidence"
    evidence.mkdir(exist_ok=True)
    baseline = TEMP / "reference/src/embodiedforge"
    current = REPO / "src/embodiedforge"
    frozen = TEMP / "final-soak/src/embodiedforge"
    modules = {
        p.relative_to(current).as_posix(): sha(p) for p in sorted(current.rglob("*.py"))
    }
    assert all(sha(frozen / name) == digest for name, digest in modules.items()), (
        "source changed after final probe freeze"
    )
    report = {
        "schema_version": 1,
        "kind": "architecture-validation",
        "validation_status": "captured_stress_interpreter_exit_failure_unresolved",
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "request": {"resumed_utc": "2026-10-21T12:49:38Z", "budget_hours": 2},
        "baseline": "Workspace snapshot before this optimization, including pre-existing uncommitted changes; not a clean Git revision",
        "scope": "Workflow lifecycle, environment layout versions, real SDK compatibility, CPU deterministic training and sustained recording integrity; zero policies do not assess walking quality",
        "changes": [
            "Shared run_lifecycle and failure classification across host workflows; terminal metadata and publication failures preserve original errors",
            "ACT process-group ownership and inherited run locks, including forced-launcher recovery",
            "Version 1 CPU environment specifications with explicit done handling and legacy compatibility",
            "Native adapter reward conversion and terminal-flag validation",
            "Native H1 model I/O included in run startup tracking",
            "Export rollback and motion SDK partial-result cleanup preserve primary failures",
        ],
        "platform": {"system": platform.platform(), "machine": platform.machine()},
        "environments": load(TEMP / "environments.json"),
        "source_modules": modules,
        "test_suites": {
            name: tests(TEMP / file)
            for name, file in {
                "main": "final-main-suite.xml",
                "act_sdk": "final-act-sdk.xml",
                "microduck_sdk": "microduck-sdk.xml",
                "native_contracts": "native-contracts.xml",
                "sdist": "sdist-validation.xml",
            }.items()
        },
        "native_startup_check": {
            "passed": 52,
            "log_sha256": sha(TEMP / "native-startup.log"),
        },
        "installed_wheel": load(TEMP / "wheel-validation/result.json"),
        "distribution_integrity": load(TEMP / "distribution-integrity.json"),
        "training_parity": load(RUNS / "training-parity/summary.json"),
        "existing_runs": load(RUNS / "existing-runs.json"),
        "legacy_datasets": load(RUNS / "legacy-datasets.json"),
        "probe_process_exit_codes": load(RUNS / "process-exit-codes.json"),
        "open_issue": {
            "probe": "process-lifecycle-captured",
            "stage": "interpreter exit after complete record and all 7088 scenarios passed",
            "exit_code": 139,
            "diagnosis": "Linux kernel confirms CPython 3.12.0 segmentation fault after workflow completion; local addr2line resolves _PyGCHead_SET_PREV at Include/internal/pycore_gc.h:74; root cause not established",
        },
        "sustained": {
            name: sampling(RUNS / "final" / name)
            for name in (
                "core-recording",
                "go1-recording",
                "h1-recording",
                "process-lifecycle",
                "process-lifecycle-captured",
            )
        },
    }
    assert all(c["match"] for c in report["training_parity"]["comparisons"])
    for suite in report["test_suites"].values():
        assert suite["failures"] == suite["errors"] == 0
    changed = []
    for name, digest in modules.items():
        old = baseline / name
        if not old.exists() or sha(old) != digest:
            changed.append(name)
    report["changed_python_modules"] = changed
    (evidence / "summary.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False) + "\n"
    )
    print(
        json.dumps(
            {
                "output": str(evidence / "summary.json"),
                "changed_modules": len(changed),
                "sustained": report["sustained"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
