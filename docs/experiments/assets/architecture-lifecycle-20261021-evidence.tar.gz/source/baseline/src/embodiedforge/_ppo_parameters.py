"""Compatibility import; shared utility now lives in learning.parameters."""

from .learning.parameters import bounded_log_std as bounded_log_std
