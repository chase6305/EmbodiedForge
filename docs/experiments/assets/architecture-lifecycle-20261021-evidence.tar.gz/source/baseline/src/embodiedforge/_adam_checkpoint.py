"""Compatibility import; shared utility now lives in learning.checkpoints."""

from .learning.checkpoints import validate_adam_checkpoint as validate_adam_checkpoint
