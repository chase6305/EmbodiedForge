"""Compatibility imports for loaded-component provenance."""

from .runtime.implementation import component as component
from .runtime.implementation import record_training_runtime as record_training_runtime
