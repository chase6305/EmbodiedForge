"""Compatibility import for bounded artifact hashing."""

from .runtime.hashing import file_sha256 as file_sha256
