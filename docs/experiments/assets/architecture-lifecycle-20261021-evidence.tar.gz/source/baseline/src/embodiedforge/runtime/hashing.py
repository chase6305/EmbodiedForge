"""File identity checks that do not retain the complete artifact in memory."""

import hashlib
import os
from pathlib import Path
from typing import BinaryIO


def file_sha256(path: str | Path) -> str:
    """Hash file bytes in bounded blocks; callers own snapshot/locking semantics."""
    with open(os.fspath(path), "rb") as stream:
        return stream_sha256(stream)


def stream_sha256(stream: BinaryIO) -> str:
    """Hash from current position to EOF; borrow the stream without closing it."""
    digest = hashlib.sha256()
    for block in iter(lambda: stream.read(1024 * 1024), b""):
        digest.update(block)
    return digest.hexdigest()
