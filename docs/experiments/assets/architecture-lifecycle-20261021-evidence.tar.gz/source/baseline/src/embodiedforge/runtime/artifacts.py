"""Atomic JSON publication shared across workflows.

Publication uses a unique sibling file and an atomic rename. It does not promise
fsync durability or serialize concurrent writers; the last completed writer wins.
"""

import json
import logging
import os
from pathlib import Path
from uuid import uuid4

LOGGER = logging.getLogger(__name__)


def write_json(path: str | Path, value) -> None:
    """Publish finite JSON without exposing partial output or reusing a temp file.

    The caller owns directory creation, schema validation and writer coordination.
    Existing output survives serialization/write/rename errors. Cleanup errors are
    logged without replacing the original failure.
    """
    # Unique path components are retained by CPython 3.12's pathlib interning.
    # Keep high-volume episode names as filesystem strings throughout this path.
    path = os.fspath(path)
    payload = json.dumps(value, indent=2, allow_nan=False) + "\n"
    parent, name = os.path.split(path)
    temporary = os.path.join(parent, f"{name}.{uuid4().hex}.tmp")
    created = False
    try:
        with open(temporary, "x", encoding="utf-8") as stream:
            created = True
            stream.write(payload)
        os.replace(temporary, path)
    except BaseException:
        if created:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass
            except OSError:
                LOGGER.warning(
                    "Could not remove partial JSON %s", temporary, exc_info=True
                )
        raise
