"""Compatibility imports for process tools now owned by runtime.process."""

from pathlib import Path

from .runtime.process import ProcessInterrupted as ProcessInterrupted
from .runtime.process import run_process as run_process
from .runtime.process import sdk_package_path as _sdk_package_path
from .runtime.process import termination_signals as termination_signals


def sdk_package_path(output):
    """Keep the historical package-location behavior for older callers."""
    return _sdk_package_path(output, package=Path(__file__).resolve().parent)
