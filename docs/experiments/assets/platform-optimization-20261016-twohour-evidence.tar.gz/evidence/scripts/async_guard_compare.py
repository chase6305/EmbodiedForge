"""Briefly pause only this run's three stress workers for paired measurements."""

import gc
import hashlib
import importlib.util
import json
import os
import signal
import statistics
import sys
import tempfile
import threading
import time
import types
from pathlib import Path

import numpy as np
import embodiedforge.data as candidate
from embodiedforge import VectorEnv
from embodiedforge.tasks import ReachTask

root=Path(__file__).resolve().parent.parent


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec)
    sys.modules[name]=result
    spec.loader.exec_module(result)
    return result


def process_identity(pid):
    return Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split()[19]


targets=[]
for directory in Path('/proc').iterdir():
    if not directory.name.isdigit():
        continue
    try:
        command=[part.decode() for part in (directory/'cmdline').read_bytes().split(b'\0') if part]
        if not command or not Path(command[0]).name.startswith('python'):
            continue
        data_worker=any(item.endswith(str(root/'scripts/endurance.py')) or item.endswith('runs/platform-optimization-20261016-twohour/scripts/endurance.py') for item in command) and '--worker' in command
        policy_worker=any(item.endswith(str(root/'scripts/executor_endurance.py')) or item.endswith('runs/platform-optimization-20261016-twohour/scripts/executor_endurance.py') for item in command)
        if data_worker or policy_worker:
            targets.append(dict(pid=int(directory.name),start_time=process_identity(int(directory.name)),command=command))
    except (FileNotFoundError,ProcessLookupError,PermissionError):
        continue
assert len(targets)==3,targets


def send(sig):
    for target in targets:
        assert process_identity(target['pid'])==target['start_time']
        os.kill(target['pid'],sig)


def interrupted(signum,frame):
    raise SystemExit(128+signum)


signal.signal(signal.SIGTERM,interrupted)


class TimeoutTask(ReachTask):
    def evaluate(self,state,actions,previous):
        count=len(state.time)
        return np.zeros(count,np.float32),np.zeros(count,bool),np.zeros(count,bool)


baseline=module('embodiedforge._quiet_baseline_data',root/'baseline/embodiedforge/data.py')
bench=module('twohour_quiet_pipeline_benchmark',Path.cwd()/'benchmarks/recording_pipeline.py')
bench.measure.__globals__['VectorEnv']=lambda config:VectorEnv(config,task=TimeoutTask())
variant=types.ModuleType('embodiedforge._guarded_recorder')
variant.__package__='embodiedforge'
sys.modules[variant.__name__]=variant
source=Path(candidate.__file__).read_text()
proposal=source.replace('or not rows\n                and ', 'or (not rows or self._executor is not None)\n                and ')
assert source!=proposal
exec(compile(proposal,'<guarded-recorder>','exec'),variant.__dict__)
(root/'guarded-recorder-prototype.py').write_text(proposal)
rows=[]
pauses=json.loads((root/'stress-pauses.json').read_text())['pauses']
previous_pauses=len(pauses)
try:
    for noise,layout,workers in [(False,'transitions',0),(False,'transitions',1),(False,'compact',2),(True,'compact',2)]:
        pause=dict(started_epoch=time.time(),targets=targets)
        timer=threading.Timer(30,lambda:send(signal.SIGCONT))
        timer.daemon=True
        timer.start()
        send(signal.SIGSTOP)
        try:
            runs={name:[] for name in ('baseline','candidate','guarded')}
            for repeat in range(13):
                order=[('baseline',baseline),('candidate',candidate),('guarded',variant)]
                order=order[repeat%3:]+order[:repeat%3]
                if repeat%2:
                    order.reverse()
                for name,implementation in order:
                    bench.measure.__globals__['EpisodeRecorder']=implementation.EpisodeRecorder
                    gc.collect()
                    with tempfile.TemporaryDirectory(prefix='ef-twohour-quiet-') as temporary:
                        result=bench.measure(Path(temporary)/'run',workers=workers,episode_format=layout,num_envs=4,steps=40,cycles=3,image_size=64,budget_mib=12,noise=noise)
                    if repeat:
                        runs[name].append(result)
            medians={name:statistics.median(row['seconds_including_close'] for row in group) for name,group in runs.items()}
            assert len({row['sha256'] for group in runs.values() for row in group})==1
            row=dict(noise=noise,layout=layout,workers=workers,runs=runs,median_seconds_including_close=medians,seconds_reduction_pct=100*(1-medians['candidate']/medians['baseline']))
            rows.append(row)
            print(json.dumps({key:row[key] for key in ('noise','layout','workers','median_seconds_including_close','seconds_reduction_pct')}),flush=True)
        finally:
            send(signal.SIGCONT)
            timer.cancel()
            pause['ended_epoch']=time.time()
            pause['seconds']=pause['ended_epoch']-pause['started_epoch']
            assert pause['seconds']<30,'Watchdog resumed workers during measurement'
            pauses.append(pause)
            (root/'stress-pauses.json').write_text(json.dumps(dict(scope='Only exact-script self-owned stress worker PIDs, PID/start-time checked before every signal; no unrelated jobs. Goal wall time includes this real benchmark work. Data parent timeout45s, each pause limited30s with resume watchdog.',pauses=pauses),indent=2)+'\n')
        time.sleep(.5)
finally:
    send(signal.SIGCONT)
(root/'async-guard-comparison.json').write_text(json.dumps(dict(source_sha256={name:hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest() for name,module in [('baseline',baseline),('candidate',candidate)]},scope='Same N4 T40 three-cycle64px 12MiB full acquisition+writer-close workload as pipeline-comparison.json; one warmup plus twelve measured baseline/current/guarded triplets. Own recording/executor stress workers briefly paused; unrelated shared-host workloads unaffected. Hashes match, both schemas and 0/1/2 writers, synthetic noise separately labelled. Measures actual whole pipeline, excludes construction/read audit; no general training speedup claim.',cases=rows,proposal_sha256=hashlib.sha256(proposal.encode()).hexdigest(),stress_pause_seconds=sum(row['seconds'] for row in pauses[previous_pauses:])),indent=2)+'\n')
