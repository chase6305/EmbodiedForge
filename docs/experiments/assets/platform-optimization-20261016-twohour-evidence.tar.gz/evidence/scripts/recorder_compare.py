import gc
import hashlib
import importlib.util
import json
import statistics
import sys
import tempfile
from pathlib import Path

from embodiedforge import VectorEnv
import embodiedforge.data as candidate
from embodiedforge.tasks import ReachTask

import numpy as np

root = Path(__file__).resolve().parent.parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


class TimeoutTask(ReachTask):
    def evaluate(self, state, actions, previous):
        count = len(state.time)
        return np.zeros(count, np.float32), np.zeros(count, bool), np.zeros(count, bool)


baseline = module("embodiedforge._twohour_baseline_data", root/"baseline/embodiedforge/data.py")
benchmark = module("twohour_recorder_benchmark", Path.cwd()/"benchmarks/recorder.py")
benchmark.measure.__globals__["VectorEnv"] = lambda config: VectorEnv(config, task=TimeoutTask())
proof = {"baseline":hashlib.sha256((root/"baseline/embodiedforge/data.py").read_bytes()).hexdigest(), "candidate":hashlib.sha256(Path(candidate.__file__).read_bytes()).hexdigest()}
cases = [("state-128",128,100,8,False,7), ("rgb-depth-32",16,50,32,True,5), ("rgb-depth-64",8,40,64,True,5)]
rows = []
for label,count,steps,size,images,pairs in cases:
    for layout in ("transitions", "compact"):
        runs = {name:[] for name in ("baseline","candidate")}
        for repeat in range(pairs+1):
            order = [("baseline",baseline),("candidate",candidate)]
            if repeat%2:
                order.reverse()
            for name,implementation in order:
                benchmark.measure.__globals__["EpisodeRecorder"] = implementation.EpisodeRecorder
                gc.collect()
                with tempfile.TemporaryDirectory(prefix="ef-twohour-recorder-") as temporary:
                    row=benchmark.measure(Path(temporary)/"run",episode_format=layout,num_envs=count,steps=steps,image_size=size,images=images,noise=False)
                if repeat:
                    runs[name].append(row)
        hashes={row['transition_sha256'] for group in runs.values() for row in group}
        assert len(hashes)==1
        medians={name:statistics.median(row['append_seconds'] for row in group) for name,group in runs.items()}
        row=dict(label=label,format=layout,arguments=dict(num_envs=count,steps=steps,image_size=size,images=images),runs=runs,median_append_seconds=medians,seconds_reduction_pct=100*(1-medians['candidate']/medians['baseline']),sha256=hashes.pop())
        rows.append(row)
        print(json.dumps({key:row[key] for key in ('label','format','median_append_seconds','seconds_reduction_pct')}),flush=True)
assert proof['candidate']==hashlib.sha256(Path(candidate.__file__).read_bytes()).hexdigest()
report=dict(scope="Alternating baseline/candidate synchronous recorder append validation, owned copies and NPZ compression; excludes physics/render/construction/close/audit from timing. Seeded NumPy point task with timeout-only termination to ensure fixed full episode lengths. Actual read_episodes payload hashes match, both schemas, repeated cached local filesystem/shared host. One warmup pair per case excluded.",source_sha256=proof,cases=rows)
(root/'recorder-path-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
