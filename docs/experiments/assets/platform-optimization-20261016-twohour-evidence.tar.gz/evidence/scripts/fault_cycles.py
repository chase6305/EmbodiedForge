"""Check recorder collection after repeated real-worker cleanup failures."""

import gc
import hashlib
import importlib.util
import json
import tempfile
import threading
import time
import weakref
from pathlib import Path

import pytest
import embodiedforge.data as data

root=Path(__file__).resolve().parent.parent
path=Path.cwd()/'tests/test_recorder_close.py'
spec=importlib.util.spec_from_file_location('recorder_fault_cases',path)
tests=importlib.util.module_from_spec(spec)
spec.loader.exec_module(tests)
original=tests.EpisodeRecorder
refs=[]
created=0


def recorder(*args,**kwargs):
    global created
    value=original(*args,**kwargs)
    refs.append(weakref.ref(value))
    created+=1
    return value


def resources():
    return dict(fd=len(list(Path('/proc/self/fd').iterdir())),threads=threading.active_count(),rss_bytes=int(next(x.split()[1] for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('VmRSS:')))*1024)


tests.EpisodeRecorder=recorder
initial=resources()
started=time.time()
samples=[]
coverage=set()
names=['test_interrupted_shutdown_still_drains_real_writes_and_releases_threads','test_close_retries_caller_interruption_while_collecting_a_finished_future','test_persistent_drain_fault_preserves_retry_state_and_blocks_append','test_shutdown_interrupt_does_not_hide_worker_failure','test_body_failure_survives_shutdown_interrupt_after_complete_drain','test_shutdown_interrupt_survives_secondary_manifest_failure','test_shutdown_interrupt_finalizes_incomplete_episode','test_interrupted_close_never_reopens_append_before_explicit_retry']
for index in range(500):
    name=names[index%len(names)]
    function=getattr(tests,name)
    with tempfile.TemporaryDirectory(prefix='ef-twohour-fault-cycle-') as temporary:
        with pytest.MonkeyPatch.context() as monkeypatch:
            available=dict(tmp_path=Path(temporary),monkeypatch=monkeypatch,error_type=(KeyboardInterrupt,SystemExit,OSError)[(index//8)%3],episode_format=('transitions','compact')[(index//48)%2],workers=(1,2)[(index//24)%2],stage=('shutdown','collection')[(index//96)%2])
            if name=='test_interrupted_close_never_reopens_append_before_explicit_retry':
                available['stage']=('collect_boundary','release_boundary')[(index//96)%2]
            arguments={key:available[key] for key in function.__code__.co_varnames[:function.__code__.co_argcount]}
            function(**arguments)
            coverage.add((name,tuple((key,str(value)) for key,value in arguments.items() if key not in ('tmp_path','monkeypatch'))))
    gc.collect()
    assert all(reference() is None for reference in refs),'Closed recorder retained after GC'
    refs.clear()
    state=resources()
    assert state['fd']==initial['fd'] and state['threads']==initial['threads'],state
    if index%25==0:
        samples.append(dict(case=index+1,resources=state))
report=dict(status='passed',started_epoch=started,ended_epoch=time.time(),cases=500,recorders_created=created,recorders_released_after_gc=created,configurations=len(coverage),initial=initial,final=resources(),samples=samples,source_sha256=hashlib.sha256(Path(data.__file__).read_bytes()).hexdigest(),test_source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),scope='500 fault-cycle invocations of eight tested cleanup scenarios, varying finite interruptions, writer counts, storage layouts and repeated-close boundaries. Actual thread-pool writers and NPZ publication; GC/weakrefs verify all recorder objects released after each case, and FD/Python threads return to baseline. Small point-state payloads only; RSS samples are not a general memory bound.')
(root/'fault-cycles.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:report[key] for key in ('status','cases','recorders_created','recorders_released_after_gc','configurations','initial','final')}),flush=True)
