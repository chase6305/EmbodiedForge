"""Briefly pause only this run's three stress workers for paired measurements."""

import gc
import hashlib
import importlib.util
import json
import os
import signal
import statistics
import sys
import tempfile
import threading
import time
from pathlib import Path

import numpy as np
import embodiedforge.data as candidate
from embodiedforge import VectorEnv
from embodiedforge.tasks import ReachTask

root=Path(__file__).resolve().parent.parent


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec)
    sys.modules[name]=result
    spec.loader.exec_module(result)
    return result


def process_identity(pid):
    return Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split()[19]


targets=[]
for directory in Path('/proc').iterdir():
    if not directory.name.isdigit():
        continue
    try:
        command=[part.decode() for part in (directory/'cmdline').read_bytes().split(b'\0') if part]
        if not command or not Path(command[0]).name.startswith('python'):
            continue
        data_worker=any(item.endswith(str(root/'scripts/endurance.py')) or item.endswith('runs/platform-optimization-20261016-twohour/scripts/endurance.py') for item in command) and '--worker' in command
        policy_worker=any(item.endswith(str(root/'scripts/executor_endurance.py')) or item.endswith('runs/platform-optimization-20261016-twohour/scripts/executor_endurance.py') for item in command)
        if data_worker or policy_worker:
            targets.append(dict(pid=int(directory.name),start_time=process_identity(int(directory.name)),command=command))
    except (FileNotFoundError,ProcessLookupError,PermissionError):
        continue
assert len(targets)==3,targets


def send(sig):
    for target in targets:
        assert process_identity(target['pid'])==target['start_time']
        os.kill(target['pid'],sig)


def interrupted(signum,frame):
    raise SystemExit(128+signum)


signal.signal(signal.SIGTERM,interrupted)


class TimeoutTask(ReachTask):
    def evaluate(self,state,actions,previous):
        count=len(state.time)
        return np.zeros(count,np.float32),np.zeros(count,bool),np.zeros(count,bool)


baseline=module('embodiedforge._quiet_baseline_data',root/'baseline/embodiedforge/data.py')
bench=module('twohour_quiet_pipeline_benchmark',Path.cwd()/'benchmarks/recorder.py')
bench.measure.__globals__['VectorEnv']=lambda config:VectorEnv(config,task=TimeoutTask())
rows=[]
pauses=json.loads((root/'stress-pauses.json').read_text())['pauses']
previous_pauses=len(pauses)
try:
    for label,count,steps,size,images,layout in [(label,n,t,size,images,layout) for label,n,t,size,images in [('state-128',128,100,8,False),('rgb-depth-32',16,50,32,True),('rgb-depth-64',8,40,64,True)] for layout in ('transitions','compact')]:
        pause=dict(started_epoch=time.time(),targets=targets)
        timer=threading.Timer(30,lambda:send(signal.SIGCONT))
        timer.daemon=True
        timer.start()
        send(signal.SIGSTOP)
        try:
            runs={name:[] for name in ('baseline','candidate')}
            for repeat in range(10):
                order=[('baseline',baseline),('candidate',candidate)]
                if repeat%2:
                    order.reverse()
                for name,implementation in order:
                    bench.measure.__globals__['EpisodeRecorder']=implementation.EpisodeRecorder
                    gc.collect()
                    with tempfile.TemporaryDirectory(prefix='ef-twohour-quiet-') as temporary:
                        result=bench.measure(Path(temporary)/'run',episode_format=layout,num_envs=count,steps=steps,image_size=size,images=images,noise=False)
                    if repeat:
                        runs[name].append(result)
            medians={name:statistics.median(row['append_seconds'] for row in group) for name,group in runs.items()}
            assert len({row['transition_sha256'] for group in runs.values() for row in group})==1
            row=dict(label=label,format=layout,arguments=dict(num_envs=count,steps=steps,image_size=size,images=images),runs=runs,median_append_seconds=medians,seconds_reduction_pct=100*(1-medians['candidate']/medians['baseline']),sha256=runs['baseline'][0]['transition_sha256'])
            rows.append(row)
            print(json.dumps({key:row[key] for key in ('label','format','median_append_seconds','seconds_reduction_pct')}),flush=True)
        finally:
            send(signal.SIGCONT)
            timer.cancel()
            pause['ended_epoch']=time.time()
            pause['seconds']=pause['ended_epoch']-pause['started_epoch']
            assert pause['seconds']<30,'Watchdog resumed workers during measurement'
            pauses.append(pause)
            (root/'stress-pauses.json').write_text(json.dumps(dict(scope='Only exact-script self-owned stress worker PIDs, PID/start-time checked before every signal; no unrelated jobs. Goal wall time includes this real benchmark work. Data parent timeout45s, each pause limited30s with resume watchdog.',pauses=pauses),indent=2)+'\n')
        time.sleep(.5)
finally:
    send(signal.SIGCONT)
(root/'quiet-recorder-comparison.json').write_text(json.dumps(dict(source_sha256={name:hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest() for name,module in [('baseline',baseline),('candidate',candidate)]},scope='Exact recorder append validation, owned copies and synchronous NPZ writing; N128T100 state, N16T50 RGBD32, N8T40 RGBD64. Excludes construction, physics/render, subsequent close and read audit. One warmup plus nine timed pairs. Own recording/executor stress workers briefly paused; unrelated shared-host workloads unaffected. Hashes match, both schemas with synchronous writers and raster payloads only. Measures actual whole pipeline, excludes construction/read audit; no general training speedup claim.',cases=rows,stress_pause_seconds=sum(row['seconds'] for row in pauses[previous_pauses:])),indent=2)+'\n')
