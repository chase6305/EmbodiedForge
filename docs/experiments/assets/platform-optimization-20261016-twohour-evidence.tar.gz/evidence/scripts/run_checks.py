import argparse
import concurrent.futures
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

root=Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser()
parser.add_argument('--label',default='')
args=parser.parse_args()
prefix=args.label+'-' if args.label else ''
env=dict(os.environ,PYTHONPATH=str(Path.cwd()/'src'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
before={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in Path('src/embodiedforge').rglob('*.py')}


def run(label,command):
    path=root/f'{prefix}{label}.log'
    started=time.time()
    with path.open('x') as stream:
        result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,env=env,timeout=600)
    report=dict(label=label,command=command,returncode=result.returncode,started_epoch=started,ended_epoch=time.time(),log=str(path),log_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),tail=path.read_text().splitlines()[-12:])
    print(json.dumps(report),flush=True)
    return report


focused=['tests/test_recorder_close.py','tests/test_recorder_duplicates.py','tests/test_async_recorder.py','tests/test_recorder_budget.py','tests/test_compact_episodes.py','tests/test_data_validation.py','tests/test_episode_identity.py','tests/test_data_policy.py','tests/test_ordered_batches.py','tests/test_dataset_reads.py']
cases=[('py310-full','/tmp/ef-ci310-20261014/bin/python',['tests']),('py312-full','/tmp/ef-ci312-20261014/bin/python',['tests']),('numpy124-focused','/tmp/ef-numpy124-20261014/bin/python',focused)]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    futures=[pool.submit(run,label,[python,'-m','pytest','-q',*paths,'--tb=short']) for label,python,paths in cases]
    results=[future.result() for future in futures]
after={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in Path('src/embodiedforge').rglob('*.py')}
assert before==after
(root/f'{prefix}checks.json').write_text(json.dumps(dict(status='passed' if all(row['returncode']==0 for row in results) else 'failed',source_hashes=before,results=results),indent=2)+'\n')
raise SystemExit(any(row['returncode']!=0 for row in results))
