"""Deliver real signals to isolated recorder controllers during thread joins."""

import argparse
import hashlib
import json
import os
import signal
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

root=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser()
p.add_argument('--worker',action='store_true')
p.add_argument('--signal',choices=('SIGINT','SIGTERM'))
p.add_argument('--repetitions',type=int,default=20)
a=p.parse_args()
if a.worker:
    import numpy as np
    import embodiedforge.data as data
    from embodiedforge import Config,VectorEnv
    from embodiedforge.data import EpisodeRecorder,read_episodes
    events={}
    initial_fd=len(list(Path('/proc/self/fd').iterdir()))
    gate,entered,waiting=threading.Event(),threading.Event(),threading.Event()
    if a.signal=='SIGTERM':
        def terminate(signum,frame):
            raise SystemExit(128+signum)
        signal.signal(signal.SIGTERM,terminate)
    with tempfile.TemporaryDirectory(prefix='ef-twohour-signal-') as temporary:
        with VectorEnv(Config(num_envs=1,max_steps=1)) as env:
            writer=EpisodeRecorder(Path(temporary)/'run',env,write_workers=1)
            write=writer._write_episode
            def blocked(*args):
                entered.set()
                assert gate.wait(5)
                return write(*args)
            writer._write_episode=blocked
            writer.append(env.observe(),env.step(np.zeros((1,2))))
            assert entered.wait(5)
            future=writer._writes[(0,0)][0]
            executor=writer._executor
            tids=[thread.native_id for thread in executor._threads]
            shutdown=executor.shutdown
            def announced(*args,**kwargs):
                events.setdefault('join_entered_epoch',time.time())
                waiting.set()
                return shutdown(*args,**kwargs)
            executor.shutdown=announced
            def inject():
                assert waiting.wait(5)
                time.sleep(.02)
                events['signal_sent_epoch']=time.time()
                os.kill(os.getpid(),getattr(signal,a.signal))
                time.sleep(.05)
                gate.set()
            sender=threading.Thread(target=inject)
            sender.start()
            caught=None
            try:
                try:
                    writer.close()
                except BaseException as error:
                    events['caught_epoch']=time.time()
                    caught=error
                if a.signal=='SIGINT':
                    assert isinstance(caught,KeyboardInterrupt)
                else:
                    assert isinstance(caught,SystemExit) and caught.code==143
                assert events['join_entered_epoch']<=events['signal_sent_epoch']<=events['caught_epoch']
                completed=writer.closed and not writer._writes and writer.buffered_bytes==0
                assert completed,'Recorder not finalized before signal propagates'
                sender.join(timeout=5)
                assert not sender.is_alive()
                assert len(list(read_episodes(writer.root)))==1
                manifest=json.loads((writer.root/'run.json').read_text())
                assert manifest['status']=='closed' and manifest['completed_episodes']==1
                until=time.monotonic()+.5
                while any(Path(f'/proc/self/task/{tid}').exists() for tid in tids) and time.monotonic()<until:
                    time.sleep(.005)
                assert all(not Path(f'/proc/self/task/{tid}').exists() for tid in tids),'Native writer thread survived completed drain'
                result=dict(status='passed',signal=a.signal,exception=type(caught).__name__,events=events,actual_join=True,native_writer_threads_gone=True,closed_before_cleanup=True,source_sha256=hashlib.sha256(Path(data.__file__).read_bytes()).hexdigest())
            finally:
                gate.set()
                sender.join(timeout=5)
                executor.shutdown=shutdown
                future.result(timeout=5)
                writer.close()
    assert len(list(Path('/proc/self/fd').iterdir()))==initial_fd
    result['fd_restored']=True
    print(json.dumps(result),flush=True)
else:
    started=time.time()
    rows=[]
    negatives=[]
    for label,path,repetitions in [('baseline',root/'baseline',1),('candidate',Path.cwd()/'src',a.repetitions)]:
        for kind in ('SIGINT','SIGTERM'):
            for repeat in range(repetitions):
                env=dict(os.environ,PYTHONPATH=str(path.resolve()),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
                command=[sys.executable,str(Path(__file__).resolve()),'--worker','--signal',kind]
                process=subprocess.run(command,env=env,capture_output=True,text=True,timeout=15)
                if label=='baseline':
                    assert process.returncode!=0 and 'Recorder not finalized before signal propagates' in process.stderr,process.stderr
                    negatives.append(dict(signal=kind,returncode=process.returncode,stderr=process.stderr))
                else:
                    assert process.returncode==0,process.stderr
                    rows.append(json.loads(process.stdout))
    report=dict(status='passed',python=sys.version,started_epoch=started,ended_epoch=time.time(),passed_cases=len(rows),baseline_negative_controls=negatives,rows=rows,scope='Real SIGINT and SIGTERM delivered to these isolated child-controller PIDs 20ms after entry into actual ThreadPoolExecutor.shutdown thread joining while an actual writer is blocked. SIGTERM uses a test handler raising SystemExit143, not production default SIGTERM behavior. Candidate drains and closes before propagating the signal; baseline negative controls fail and are finalized by the harness. Owned native thread IDs and FD recovery checked; no signals to other jobs.')
    label=f'py{sys.version_info.major}{sys.version_info.minor}'
    (root/f'real-signals-{label}.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(status='passed',python=label,passed_cases=len(rows),baseline_expected_failures=len(negatives))),flush=True)
