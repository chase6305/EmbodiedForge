import gc
import hashlib
import importlib.util
import json
import statistics
import sys
from pathlib import Path

import embodiedforge.policies as candidate
import embodiedforge.rollout as runtime
from embodiedforge import Config

root=Path(__file__).resolve().parent.parent


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec)
    sys.modules[name]=result
    spec.loader.exec_module(result)
    return result


baseline=module('embodiedforge._twohour_baseline_policy',root/'baseline/embodiedforge/policies.py')
bench=module('twohour_action_benchmark',Path.cwd()/'benchmarks/action_executor.py')
rollout=module('twohour_rollout_benchmark',Path.cwd()/'benchmarks/rollout.py')
implementations=dict(baseline=baseline.ActionExecutor,candidate=candidate.ActionExecutor)
proof=dict(baseline=hashlib.sha256(Path(baseline.__file__).read_bytes()).hexdigest(),candidate=hashlib.sha256(Path(candidate.__file__).read_bytes()).hexdigest(),benchmark=hashlib.sha256((Path.cwd()/'benchmarks/action_executor.py').read_bytes()).hexdigest())
rows=[]
for metadata in (False,True):
    for count,dim,horizon,steps in [(1,2,16,50000),(128,2,16,20000),(8192,2,16,1000),(128,32,16,10000),(128,2,1,10000)]:
        runs={name:[] for name in implementations}
        for repeat in range(10):
            order=list(implementations)
            if repeat%2:
                order.reverse()
            for name in order:
                bench.measure.__globals__['ActionExecutor']=implementations[name]
                gc.collect()
                result=bench.measure(num_envs=count,action_dim=dim,horizon=horizon,steps=steps,metadata=metadata)
                if repeat:
                    runs[name].append(result)
        assert len({row['action_sha256'] for group in runs.values() for row in group})==1
        medians={name:statistics.median(row['seconds'] for row in group) for name,group in runs.items()}
        peaks={name:statistics.median(row['single_act_peak_traced_bytes'] for row in group) for name,group in runs.items()}
        row=dict(metadata=metadata,num_envs=count,action_dim=dim,horizon=horizon,steps=steps,runs=runs,median_seconds=medians,median_act_peak_traced_bytes=peaks,seconds_reduction_pct=100*(1-medians['candidate']/medians['baseline']))
        rows.append(row)
        print(json.dumps({key:row[key] for key in ('metadata','num_envs','action_dim','horizon','median_seconds','median_act_peak_traced_bytes','seconds_reduction_pct')}),flush=True)
rollouts=[]
for label,config,steps in [('null-128',Config(num_envs=128,max_steps=100),1000),('rgb-depth-16',Config(num_envs=16,max_steps=20,image_size=32,render='raster',channels=('rgb','depth')),200)]:
    runs={name:[] for name in implementations}
    for repeat in range(8):
        order=list(implementations)
        if repeat%2:
            order.reverse()
        for name in order:
            runtime.ActionExecutor=implementations[name]
            gc.collect()
            result=rollout.measure(config,steps)
            if repeat:
                runs[name].append(result)
    assert len({row['sha256'] for group in runs.values() for row in group})==1
    assert all(row['summary']==runs['baseline'][0]['summary'] for group in runs.values() for row in group)
    medians={name:statistics.median(row['seconds'] for row in group) for name,group in runs.items()}
    row=dict(label=label,config=config.to_dict(),steps=steps,runs=runs,median_seconds=medians,seconds_reduction_pct=100*(1-medians['candidate']/medians['baseline']))
    rollouts.append(row)
    print(json.dumps({key:row[key] for key in ('label','median_seconds','seconds_reduction_pct')}),flush=True)
assert proof['candidate']==hashlib.sha256(Path(candidate.__file__).read_bytes()).hexdigest()
(root/'executor-final-comparison.json').write_text(json.dumps(dict(source_sha256=proof,scope='Alternating exact baseline/candidate ActionExecutor classes; precomputed policy chunks, optional consecutive metadata, separate allocation pass and owned-output checksums. One warmup plus nine measured pairs for executor cases. Full run_rollout cases include actual NumPy physics, task, sensor/reset work and optional raster, one warmup plus seven measured pairs; full transition hashes and summary equality verified. Excludes neural inference/training. Two recording stress workers concurrently active on shared host; traced bytes exclude construction, are not RSS, and cached IDs retain one intp[N] array per executor.',cases=rows,rollouts=rollouts),indent=2)+'\n')
