import argparse
import gc
import hashlib
import importlib.util
import json
import statistics
import sys
import types
from pathlib import Path

import embodiedforge.policies as current

root=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('executor_benchmark',Path.cwd()/'benchmarks/action_executor.py')
benchmark=importlib.util.module_from_spec(spec)
spec.loader.exec_module(benchmark)
text=Path(current.__file__).read_text()
new=text.replace('        self.cursor = np.zeros(num_envs, dtype=np.int64)','        self._env_ids = np.arange(num_envs)\n        self.cursor = np.zeros(num_envs, dtype=np.int64)').replace('observation["env_id"], np.arange(count)','observation["env_id"], self._env_ids').replace('self.chunks[np.arange(len(self.cursor)), self.cursor]','self.chunks[self._env_ids, self.cursor]')
assert text!=new
variant=types.ModuleType('embodiedforge._executor_cached')
variant.__package__='embodiedforge'
sys.modules[variant.__name__]=variant
exec(compile(new,'<cached-executor>','exec'),variant.__dict__)
(root/'executor-cache-prototype.py').write_text(new)
rows=[]
for count,dim,horizon,steps in [(1,2,16,50000),(128,2,16,20000),(8192,2,16,1000),(128,32,16,10000),(128,2,1,10000)]:
    implementations=dict(baseline=current.ActionExecutor,candidate=variant.ActionExecutor)
    runs={name:[] for name in implementations}
    for repeat in range(10):
        order=list(implementations)
        if repeat%2:
            order.reverse()
        for name in order:
            benchmark.measure.__globals__['ActionExecutor']=implementations[name]
            gc.collect()
            result=benchmark.measure(num_envs=count,action_dim=dim,horizon=horizon,steps=steps)
            if repeat:
                runs[name].append(result)
    assert len({row['action_sha256'] for group in runs.values() for row in group})==1
    medians={name:statistics.median(row['seconds'] for row in group) for name,group in runs.items()}
    row=dict(num_envs=count,action_dim=dim,horizon=horizon,steps=steps,runs=runs,median_seconds=medians,seconds_reduction_pct=100*(1-medians['candidate']/medians['baseline']))
    rows.append(row)
    print(json.dumps({key:row[key] for key in ('num_envs','action_dim','horizon','median_seconds','seconds_reduction_pct')}),flush=True)
(root/'executor-cache-comparison.json').write_text(json.dumps(dict(scope='Alternating isolated implementation classes with identical precomputed policy and environment-ID observations using the existing action_executor benchmark; one warmup pair and nine measured pairs. Includes replanning every horizon calls, owned outputs and validation, but no physics, neural inference or episode/step metadata. Two concurrent recording stress workers active on the shared host; hashes and separate allocation passes verified.',baseline_sha256=hashlib.sha256(text.encode()).hexdigest(),candidate_sha256=hashlib.sha256(new.encode()).hexdigest(),cases=rows),indent=2)+'\n')
