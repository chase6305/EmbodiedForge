import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

root=Path(__file__).resolve().parent.parent
repo=Path.cwd()
recorder=json.loads((root/'quiet-recorder-comparison.json').read_text())
executor=json.loads((root/'executor-final-comparison.json').read_text())
figure,axes=plt.subplots(1,2,figsize=(14,6),gridspec_kw={'width_ratios':[1.15,1]})
figure.patch.set_facecolor('#f6f8fb')
for axis in axes:
    axis.set_facecolor('#f6f8fb')
    axis.spines[['top','right','left']].set_visible(False)
    axis.spines['bottom'].set_color('#c6d0dc')
    axis.tick_params(axis='both',length=0,labelsize=10)
    axis.grid(axis='x',color='#dfe5ed',linewidth=.7)
    axis.set_axisbelow(True)

labels=[]
values=[]
for row in recorder['cases']:
    label={'state-128':'state N128/T100','rgb-depth-32':'RGBD32 N16/T50','rgb-depth-64':'RGBD64 N8/T40'}[row['label']]
    labels.append(f"{label} / {'legacy' if row['format']=='transitions' else 'compact'}")
    values.append(row['seconds_reduction_pct'])
axes[0].barh(np.arange(len(values)),values,color='#356db0',height=.58)
axes[0].set_yticks(np.arange(len(values)),labels)
axes[0].invert_yaxis()
axes[0].set_xlim(0,20)
axes[0].set_title('Recorder append, including synchronous NPZ compression',fontsize=12,loc='left',pad=18)
for index,value in enumerate(values):
    axes[0].text(value+.25,index,f'{value:.1f}%',va='center',fontsize=10,color='#233a56')

rows=[row for row in executor['cases'] if row['metadata']]
values=[row['seconds_reduction_pct'] for row in rows]
labels=[f"N{row['num_envs']} / A{row['action_dim']} / H{row['horizon']}" for row in rows]
axes[1].barh(np.arange(len(values)),values,color='#339184',height=.58)
axes[1].set_yticks(np.arange(len(values)),labels)
axes[1].invert_yaxis()
axes[1].set_xlim(0,8)
axes[1].set_title('Action executor with episode/step tracking',fontsize=12,loc='left',pad=18)
for index,value in enumerate(values):
    axes[1].text(value+.12,index,f'{value:.1f}%',va='center',fontsize=10,color='#233a56')
for axis in axes:
    axis.set_xlabel('Reduction in median elapsed time (%)',labelpad=12,fontsize=10)
figure.suptitle('EmbodiedForge — measured CPU paths',x=.06,ha='left',y=.97,fontsize=19,color='#18324e',weight='bold')
figure.text(.06,.075,'Alternating old/new implementations; recorder: 9 measured pairs, executor: 9 measured pairs. Output hashes match.',fontsize=9,color='#4a5d73')
figure.text(.06,.04,'Whole recording-pipeline timing varied across modes and repeat runs. These scoped results do not establish a general training-throughput or RSS gain.',fontsize=9,color='#4a5d73')
figure.subplots_adjust(left=.24,right=.97,top=.80,bottom=.24,wspace=.75)
out=repo/'docs/platform-optimization-20261016-twohour-performance.svg'
figure.savefig(out,metadata={'Date':None})
figure.savefig('/tmp/ef-twohour-performance-preview.png',dpi=130)
print(out)
