import cProfile
import io
import pstats
import tempfile
from pathlib import Path

import numpy as np

from embodiedforge import Config, VectorEnv
from embodiedforge.data import EpisodeRecorder

root = Path(__file__).resolve().parent.parent
profile = cProfile.Profile()
with tempfile.TemporaryDirectory(prefix="ef-twohour-profile-") as temporary:
    with VectorEnv(Config(num_envs=128, max_steps=100)) as env:
        env.task.target[:] = 1.2
        with EpisodeRecorder(Path(temporary)/"run", env) as writer:
            for _ in range(100):
                observation = env.observe()
                result = env.step(np.zeros((128,2)))
                profile.enable()
                writer.append(observation,result)
                profile.disable()
profile.dump_stats(root/"recorder-final.pstats")
output = io.StringIO()
pstats.Stats(profile,stream=output).sort_stats("tottime").print_stats(20)
(root/"recorder-final-profile.txt").write_text(output.getvalue())
print(output.getvalue())
