"""Write a scoped report, gated on the original two-hour deadline."""

import argparse
import hashlib
import json
import os
import subprocess
import tarfile
import time
from datetime import datetime, timezone
from pathlib import Path

root=Path(__file__).resolve().parent.parent
repo=Path.cwd()
parser=argparse.ArgumentParser()
parser.add_argument('--preview',action='store_true')
args=parser.parse_args()


def load(name):
    return json.loads((root/name).read_text())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def owned_processes():
    result=[]
    for directory in Path('/proc').iterdir():
        if not directory.name.isdigit() or int(directory.name)==os.getpid():
            continue
        try:
            argv=[part.decode() for part in (directory/'cmdline').read_bytes().split(b'\0') if part]
            if argv and Path(argv[0]).name.startswith('python') and any(str(root) in item or 'runs/platform-optimization-20261016-twohour/scripts/' in item for item in argv):
                result.append(dict(pid=int(directory.name),command=argv))
        except (FileNotFoundError,PermissionError):
            continue
    return result


state=load('state.json')
observed=time.time()
elapsed=observed-state['started_epoch']
checks=load('final2-checks.json')
assert checks['status']=='passed'
assert all(digest(repo/path)==value for path,value in checks['source_hashes'].items())
data_hash=digest(repo/'src/embodiedforge/data.py')
policy_hash=digest(repo/'src/embodiedforge/policies.py')
recorder=load('quiet-recorder-comparison.json')
executor=load('executor-final-comparison.json')
assert recorder['source_sha256']['candidate']==data_hash
assert executor['source_sha256']['candidate']==policy_hash
assert executor['source_sha256']['benchmark']==digest(repo/'benchmarks/action_executor.py')
fault_cycles=load('fault-cycles.json')
assert fault_cycles['status']=='passed'
assert fault_cycles['source_sha256']==data_hash
assert fault_cycles['test_source_sha256']==digest(repo/'tests/test_recorder_close.py')
assert load('recorder-stat-counts.json')['final_source_sha256']==data_hash
recording=load('endurance-progress.json' if args.preview else 'endurance.json')
actions=load('executor-endurance-progress.json' if args.preview else 'executor-endurance.json')
signals=[load(f'real-signals-{label}.json') for label in ('py310','py312')]
assert all(row['status']=='passed' for row in signals)
assert all(row['source_sha256']==data_hash for report in signals for row in report['rows'])
if not args.preview:
    assert elapsed>=state['required_seconds'],(elapsed,state['required_seconds'])
    assert recording['status']==actions['status']=='passed'
    assert recording['workers']['candidate']['source']['data.py']==data_hash
    assert actions['source_sha256']['candidate']==policy_hash
    assert not list(root.glob('*failure.json'))
    process_audit=owned_processes()
    assert not process_audit,process_audit


def times(row,key):
    return {name:[result[key] for result in group] for name,group in row['runs'].items()}


def memory(samples,worker=None):
    values=[row['resources'][worker] if worker else row['resources'] for row in samples]
    return dict(fd_values=sorted({row['fd'] for row in values}),thread_values=sorted({row['threads'] for row in values}),min_sampled_rss_bytes=min(row['rss_bytes'] for row in values),max_sampled_rss_bytes=max(row['rss_bytes'] for row in values),last_sample=values[-1])


def compact_stress(report,kind):
    selected={key:value for key,value in report.items() if key not in ('samples','coverage','workers','rows')}
    if 'samples' in report:
        selected['sample_count']=len(report['samples'])
        selected['resources']=({name:memory(report['samples'],name) for name in ('baseline','candidate')} if kind=='recording' else memory(report['samples']))
    if kind=='recording' and 'workers' in report:
        selected['workers']=report['workers']
    if isinstance(report.get('coverage'),list):
        selected['coverage_count']=len(report['coverage'])
    return selected


def pipeline(name):
    report=load(name)
    return dict(scope=report['scope'],source_sha256=report['source_sha256'],version='Earlier candidate before closing-state guard; diagnostic samples, not final-source end-to-end claims',cases=[dict(noise=row['noise'],layout=row['layout'],workers=row['workers'],median_seconds_including_close=row['median_seconds_including_close'],seconds=times(row,'seconds_including_close'),seconds_reduction_pct=row['seconds_reduction_pct'],sha256=row['runs']['baseline'][0]['sha256']) for row in report['cases']])


duration=dict(started_epoch=state['started_epoch'],deadline_epoch=state['deadline_epoch'],observed_epoch=observed,required_seconds=state['required_seconds'],elapsed_seconds=elapsed,requirement_met=elapsed>=state['required_seconds'],started_utc=datetime.fromtimestamp(state['started_epoch'],timezone.utc).isoformat(),observed_utc=datetime.fromtimestamp(observed,timezone.utc).isoformat(),scope='Original user-requested start to actual current UTC; parallel test durations are not added together.')
report=dict(
    schema_version=1,date='2026-10-16',kind='platform-optimization-round',status='active' if args.preview else 'complete',preview_only=args.preview,duration=duration,
    environment=load('environment.json'),
    reproduction=dict(working_directory='Repository root with source matching the final hashes; extract the evidence archive elsewhere first.',current_executor='OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONPATH=src python benchmarks/action_executor.py --metadata --output /tmp/executor-current.json',paired_recording='OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONPATH=src python <extracted>/evidence/scripts/recorder_compare.py',paired_executor='OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONPATH=src python <extracted>/evidence/scripts/executor_final_compare.py',stress='The two endurance scripts accept --until as a future Unix UTC epoch. Their absolute default records this study deadline. Quiet benchmark scripts additionally require the exact three self-owned stress workers and pause only those processes.'),
    baseline_revision=state['baseline_revision'],initial_worktree_status=state['initial_status'],initial_worktree_preserved=state['initial_untracked']+['src/embodiedforge/batching.py','tests/test_ordered_batches.py'],
    changes=[
        dict(component='Recording append',paths=['src/embodiedforge/data.py','tests/test_recorder_duplicates.py'],behavior='Only first-transition identities query an existing NPZ path; queued identities remain checked and publication rechecks its output path. The run directory is owned by one recorder; unexpected external collisions during a pending episode fail at publication. Avoid repeated filesystem calls for continuing rows.'),
        dict(component='Recorder shutdown',paths=['src/embodiedforge/data.py','tests/test_recorder_close.py'],behavior='Retry an interrupted shutdown or future-result collection once, then drain known futures even if the executor handle was released earlier. Preserve the first exception and secondary cause. Repeated failure retains retry state and disables append. Enter closing state before any cleanup; append and context reentry remain blocked after inter-operation interruption until explicit close retry completes.'),
        dict(component='Action execution',paths=['src/embodiedforge/policies.py','benchmarks/action_executor.py'],behavior='Reuse one fixed intp[N] environment-index array for row-order validation and action selection. Keep independently owned action outputs, metadata identity tracking and replanning rules. Add --metadata to the benchmark for consecutive identity tracking; retained index storage is extra persistent memory, not a whole-process memory reduction.')],
    validation=dict(full_suites=[{key:value for key,value in row.items() if key!='tail'}|{'result':row['tail'][-1]} for row in checks['results']],source_hashes=checks['source_hashes'],new_regression_cases=46,negative_controls=dict(initial_shutdown_regressions=dict(result='19 failed before the shutdown-drain fix',log='close-before.log'),inter_operation_close_regressions=dict(result='12 failed before the closing-state guard',log='boundary-before.log')),real_signals=[dict(python=entry['python'],passed_cases=entry['passed_cases'],baseline_expected_failures=len(entry['baseline_negative_controls']),scope=entry['scope']) for entry in signals],benchmark_smoke=[{key:load(name)[key] for key in ('python','numpy','action_sha256')} for name in ('executor-metadata-smoke.json','executor-metadata-smoke-py310.json','executor-metadata-smoke-numpy124.json')],style='ruff check and format --check passed for src/tests/benchmarks/examples; git diff --check passed'),
    recorder_append=dict(scope=recorder['scope'],source_sha256=recorder['source_sha256'],cases=[dict(label=row['label'],format=row['format'],arguments=row['arguments'],median_append_seconds=row['median_append_seconds'],seconds=times(row,'append_seconds'),seconds_reduction_pct=row['seconds_reduction_pct'],sha256=row['sha256']) for row in recorder['cases']],filesystem_calls=load('recorder-stat-counts.json')),
    recorder_append_with_concurrent_stress=dict(scope=load('recorder-path-comparison.json')['scope'],source_sha256=load('recorder-path-comparison.json')['source_sha256'],cases=[dict(label=row['label'],format=row['format'],median_append_seconds=row['median_append_seconds'],seconds=times(row,'append_seconds'),seconds_reduction_pct=row['seconds_reduction_pct']) for row in load('recorder-path-comparison.json')['cases']]),
    action_execution=dict(scope=executor['scope'],source_sha256=executor['source_sha256'],cases=[{key:value for key,value in row.items() if key!='runs'}|dict(seconds=times(row,'seconds'),sha256=row['runs']['baseline'][0]['action_sha256']) for row in executor['cases']],rollouts=[{key:value for key,value in row.items() if key!='runs'}|dict(seconds=times(row,'seconds'),sha256=row['runs']['baseline'][0]['sha256'],summary=row['runs']['baseline'][0]['summary']) for row in executor['rollouts']]),
    full_pipeline=pipeline('pipeline-comparison.json'),quiet_pipeline=pipeline('quiet-pipeline-comparison.json'),
    stress=dict(recording=compact_stress(recording,'recording'),executor=compact_stress(actions,'executor'),earlier_recording_stage=load('phase1/stage-summary.json'),known_pauses=load('stress-pauses.json')),
    fault_cycles=fault_cycles,
    rejected_experiment=dict(scope='Diagnostic conditional async-path prototype, not adopted. Repeat trials did not establish a stable advantage or a GIL scheduling cause.',source_sha256=load('async-guard-comparison.json').get('proposal_sha256'),cases=[dict(noise=row['noise'],layout=row['layout'],workers=row['workers'],median_seconds=row['median_seconds_including_close']) for row in load('async-guard-comparison.json')['cases']]),
    figure='platform-optimization-20261016-twohour-performance.svg',
    limits=['Append/executor improvements describe only the listed CPU workloads and scopes; no neural inference, GPU training or real-robot deployment speedup is claimed.','Full recording-pipeline timings vary across modes and repetitions, including negative cases. A uniform whole-pipeline speedup has not been established; all paired samples are retained.','FD and Python-thread equality are checked after each completed stress case; sampled RSS is not a leak proof or a hard memory budget.','Cleanup fault tests cover blocking shutdown/future-result waits and selected operation boundaries; they do not establish transactional cancellation at every bookkeeping bytecode.','SIGTERM test controllers install a handler raising SystemExit143; this does not claim cleanup under default process-killing SIGTERM behavior.','Optional dependency/asset test skips remain; full-suite counts apply to the recorded environments.'])
if not args.preview:
    report['final_process_audit']=dict(status='passed',observed_epoch=time.time(),matching_processes=process_audit,scope='Read-only exact-run Python command-path audit; excludes this reporter and unrelated jobs. Long recording controller waits/reaps both worker children before exiting; signal harness waits every isolated controller.')
    (root/'duration-gate.json').write_text(json.dumps(duration,indent=2)+'\n')
    archive=repo/'docs/assets/platform-optimization-20261016-twohour-evidence.tar.gz'
    evidence=[path for path in root.rglob('*') if path.is_file() and '__pycache__' not in path.parts and path.name!='report-preview.json' and (path.suffix in ('.py','.json','.log','.patch','.pstats','.txt','.html','.js') or path.name.startswith(('LICENSE','NOTICE')))]
    final_paths=[repo/path for path in ('src/embodiedforge/data.py','src/embodiedforge/policies.py','src/embodiedforge/batching.py','tests/test_recorder_close.py','tests/test_recorder_duplicates.py','tests/test_executor_metadata.py','benchmarks/action_executor.py','benchmarks/recorder.py','benchmarks/recording_pipeline.py','benchmarks/rollout.py','pyproject.toml')]
    with tarfile.open(archive,'w:gz') as stream:
        for path in sorted(evidence):
            stream.add(path,arcname=str(Path('evidence')/path.relative_to(root)),recursive=False)
        for path in final_paths:
            stream.add(path,arcname=str(Path('final')/path.relative_to(repo)),recursive=False)
    report['evidence_archive']=dict(path=str(archive.relative_to(repo)),sha256=digest(archive),bytes=archive.stat().st_size,scope='Exact baseline source, final source excerpts, harnesses, raw measurements and logs; temporary synthetic datasets are regenerated by the scripts. Optional external SDK assets are not bundled.')
    (root/'duration-gate.json').write_text(json.dumps(duration,indent=2)+'\n')
out=root/'report-preview.json' if args.preview else repo/'docs/platform-optimization-20261016-twohour.json'
out.write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print(json.dumps(dict(path=str(out),status=report['status'],elapsed_seconds=elapsed,requirement_met=duration['requirement_met'])))
