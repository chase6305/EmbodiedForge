"""Exact executor comparison against old source and Python-integer queues."""

import argparse
import gc
import hashlib
import importlib.util
import json
import sys
import threading
import time
import traceback
from pathlib import Path

import numpy as np
import embodiedforge.policies as current

root=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser()
p.add_argument('--until',type=float,default=1792128994)
a=p.parse_args()


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec)
    sys.modules[name]=result
    spec.loader.exec_module(result)
    return result


baseline=module('embodiedforge._endurance_baseline_policy',root/'baseline/embodiedforge/policies.py')
oracle=module('executor_integer_oracle',Path.cwd()/'tests/test_executor_metadata.py')


class BoundedPlan(oracle.PlannedActions):
    def act(self,observation):
        return np.tanh(super().act(observation))


def resources():
    return dict(fd=len(list(Path('/proc/self/fd').iterdir())),threads=threading.active_count(),rss_bytes=int(next(x.split()[1] for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('VmRSS:')))*1024)


proof={name:hashlib.sha256(Path(path).read_bytes()).hexdigest() for name,path in [('baseline',baseline.__file__),('candidate',current.__file__),('integer_oracle',oracle.__file__)]}
initial=resources()
started=time.time()
samples=[]
cases=controls=actions=0
coverage=set()
try:
    while time.time()<a.until:
        rng=np.random.default_rng(1600000+cases)
        dtype=('u8','>u8','i8','>i8','u4','>u4')[cases%6]
        count=(1,3,16,128)[(cases//6)%4]
        horizon=(1,4,8)[(cases//24)%3]
        maximum=int(np.iinfo(dtype).max)
        boundaries=sorted({0,min(2**53-1,maximum),min(2**63-2,maximum),maximum})
        episode=[boundaries[row%len(boundaries)] for row in range(count)]
        step=[max(0,boundaries[(row+1)%len(boundaries)]-2) for row in range(count)]
        old=baseline.ActionExecutor(count,1,horizon)
        new=current.ActionExecutor(count,1,horizon)
        reference=oracle.IntegerReference(count)
        policies=[BoundedPlan(count,horizon) for _ in range(3)]
        for tick in range(120):
            if tick:
                for row in range(count):
                    mode=int(rng.integers(7))
                    if mode==0:
                        continue
                    step[row]=(step[row]+(2 if mode==1 else 1))%(maximum+1)
                    if mode==2:
                        episode[row]=(episode[row]+1)%(maximum+1)
                    elif mode==3:
                        episode[row]=boundaries[int(rng.integers(len(boundaries)))]
                        step[row]=0
                if tick%9==0:
                    selected=[tick%count]
                    for executor in (old,new,reference):
                        executor.reset(selected)
            env_ids=np.repeat(np.arange(count),2)[::2] if cases%2 else np.arange(count)
            observation=dict(env_id=env_ids,episode_id=np.asarray(episode,dtype=dtype),step_id=np.asarray(step,dtype=dtype))
            expected=reference.act(observation,policies[2])
            for executor,policy in zip((old,new),policies[:2]):
                action=executor.act(observation,policy)
                np.testing.assert_array_equal(action,expected)
                np.testing.assert_array_equal(policy.calls,policies[2].calls)
                assert action.flags.owndata and action.flags.c_contiguous
                assert not np.shares_memory(action,executor.chunks)
                action[:]=-1
            if tick%17==0 and count>1:
                invalid=dict(observation,env_id=env_ids[::-1])
                for executor,policy in zip((old,new),policies[:2]):
                    cursor=executor.cursor.copy()
                    calls=policy.calls.copy()
                    try:
                        executor.act(invalid,policy)
                    except ValueError as error:
                        assert 'canonical' in str(error)
                    else:
                        raise AssertionError('Noncanonical rows accepted')
                    np.testing.assert_array_equal(executor.cursor,cursor)
                    np.testing.assert_array_equal(policy.calls,calls)
            controls+=1
            actions+=count
        cases+=1
        coverage.add((dtype,count,horizon,bool(cases%2)))
        del old,new,reference,policies,expected,action,observation
        gc.collect()
        state=resources()
        assert state['fd']==initial['fd'] and state['threads']==initial['threads']
        if not samples or time.time()-samples[-1]['epoch']>=15:
            sample=dict(epoch=time.time(),cases=cases,controls=controls,environment_actions=actions,coverage=len(coverage),resources=state)
            samples.append(sample)
            (root/'executor-endurance-progress.json').write_text(json.dumps(dict(status='running',started_epoch=started,elapsed_seconds=time.time()-started,until=a.until,**sample),indent=2)+'\n')
            print(json.dumps(sample),flush=True)
    assert proof['candidate']==hashlib.sha256(Path(current.__file__).read_bytes()).hexdigest()
    (root/'executor-endurance.json').write_text(json.dumps(dict(status='passed',started_epoch=started,ended_epoch=time.time(),elapsed_seconds=time.time()-started,source_sha256=proof,numpy=np.__version__,cases=cases,controls=controls,environment_actions=actions,coverage=sorted(coverage),initial=initial,final=resources(),samples=samples,scope='Baseline and cached-ID executor output and policy-call equivalence against independent Python-integer queue reference. Six signed/unsigned/native/non-native integer types, N1/3/16/128, H1/4/8, 0/2^53/2^63/full-range boundaries, repeated/skipped/wrapped steps, episode changes, local reset, noncontiguous canonical IDs, atomic noncanonical rejection and owned-output mutation. Fresh RNG per case; FD/threads checked each completed case, sampled RSS is not a leak proof.'),indent=2)+'\n')
except BaseException as error:
    (root/'executor-endurance-failure.json').write_text(json.dumps(dict(status='failed',epoch=time.time(),cases=cases,controls=controls,error=repr(error),traceback=traceback.format_exc()),indent=2)+'\n')
    raise
