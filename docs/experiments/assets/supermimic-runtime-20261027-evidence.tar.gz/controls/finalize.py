"""Verify closed cases and publish focused local runtime evidence."""
import datetime,difflib,hashlib,io,json,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
r=Path(__file__).parent;repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');run=repo/'runs/supermimic-runtime-20261027';asset=repo/'docs/experiments/assets/supermimic-runtime-20261027-evidence.tar.gz';report_path=repo/'docs/experiments/supermimic-runtime-20261027.json'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def test_counts(p):
 root=ET.parse(p).getroot();suites=list(root) if root.tag=='testsuites' else [root];d={k:sum(int(x.attrib.get(k,0)) for x in suites) for k in ('tests','failures','errors','skipped')};assert d['failures']==d['errors']==0;return d
source_names=['supermimic','src/embodiedforge/supermimic_run.py','src/embodiedforge/workflows/supermimic_inputs.py','benchmarks/supermimic_reproduce.py','tests/test_supermimic_run.py','MANIFEST.in','README.md','README.en.md','docs/supermimic.md','docs/experiments/README.md'];sources={n:sha(repo/n) for n in source_names};before=read(r/'before.json');history={n:h for n,h in before.items() if n.startswith(('docs/experiments/supermimic-reproduction-','docs/experiments/assets/supermimic-reproduction-'))}
for n,h in history.items():assert sha(repo/n)==h,n
cases={}
for name in ('eval','eval-all','fresh','resume'):
 launcher=read(run/name/'launcher.json');outer=read(run/(name+'-supervisor')/'result.json');worker=read(run/name/('training/result.json' if name in ('fresh','resume') else 'result.json'))
 assert launcher['status']=='complete' and launcher['worker_exit_observed'] and launcher['worker_returncode']==0
 assert outer['exit_observed'] and outer['process_returncode']==0 and outer['completed_successfully'] and not outer['timed_out']
 assert worker['status']=='complete'
 for n,h in launcher['launcher_sources'].items():assert sources[n]==h,(name,n)
 if name in ('fresh','resume'):assert worker['new_updates']>0 and worker['checkpoint_reload_action_parity'] and worker['finite_model_tensors']
 cases[name]={'launcher':launcher,'supervisor':outer,'worker':worker,'actual_original_tool_exit':0}
assert cases['eval-all']['worker']['summary']['clips']==40 and cases['eval-all']['worker']['motion_input_snapshot']['expected_manifest_verified']
assert cases['fresh']['worker']['new_updates']==16 and cases['resume']['worker']['new_updates']==16
parity=read(r/'loader-parity.json');control=read(r/'resume-source-control.json');viewer=read(r/'viewer-control.json');reject=read(r/'reject-control.json');package=read(r/'package-check.json')
assert parity['exact_action_parity'] and parity['max_abs_action_error']==0
assert control['source_restored_exactly'] and control['actual_worker_exit']==0 and control['snapshot_passed_end_validation']
assert viewer['http_status']==200 and viewer['expected_controlled_interruption'] and viewer['observed_child_exit']==130
assert reject['actual_worker_exit']==1 and reject['rejected_before_sdk_environment_and_training_configuration']
for n,h in package['runtime_source_sha256'].items():assert sources[n]==h
assert package['extracted_help_actual_exit']==0
remaining=[];prefixes=[str(run)+'/',str(run.relative_to(repo))+'/']
for d in Path('/proc').iterdir():
 if not d.name.isdigit():continue
 try:argv=(d/'cmdline').read_bytes().split(b'\0')
 except (FileNotFoundError,ProcessLookupError,PermissionError):continue
 if any(a.startswith(prefix.encode()) for a in argv for prefix in prefixes):remaining.append(int(d.name))
assert not remaining,remaining
ownership={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'remaining_run_prefix_processes':remaining,'scope':'Read-only argv namespace audit for this task; no signals to unrelated processes.'};(r/'ownership-audit.json').write_text(json.dumps(ownership,indent=2)+'\n')
counts=test_counts(r/'tests.xml');docs=test_counts(r/'documentation.xml');assert counts['tests']==224 and docs['tests']==63
changes=[]
for n in source_names:
 baseline=r/'baseline'/n;a=baseline.read_text().splitlines(keepends=True) if baseline.exists() else [];b=(repo/n).read_text().splitlines(keepends=True);assert all(line.rstrip('\r\n').rstrip(' \t')==line.rstrip('\r\n') for line in b),n
 changes.extend(difflib.unified_diff(a,b,fromfile='before/'+n,tofile='after/'+n))
(r/'source-changes.patch').write_text(''.join(changes))
files={'upstream/LICENSE':repo/'.cache/external/supermimic-reproduced/LICENSE'}
if (repo/'LICENSE').is_file():files['host/LICENSE']=repo/'LICENSE'
for n in source_names:files['final/'+n]=repo/n
for p in (r/'baseline').rglob('*'):
 if p.is_file():files['baseline/'+p.relative_to(r/'baseline').as_posix()]=p
for p in r.iterdir():
 if p.is_file() and p.suffix in ('.json','.log','.py','.xml','.patch') and p.name not in ('archive-integrity.json','final-integrity.json','publication.log'):files['controls/'+p.name]=p
for p in run.rglob('*'):
 if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts and p.suffix in ('.json','.jsonl','.py','.log'):files['runs/'+p.relative_to(run).as_posix()]=p
manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(files.items())};payload=(json.dumps(manifest,indent=2)+'\n').encode();assert not asset.exists()
with tarfile.open(asset,'w:gz',compresslevel=1) as t:
 info=tarfile.TarInfo('MANIFEST.json');info.size=len(payload);t.addfile(info,io.BytesIO(payload))
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
seen=set()
with tarfile.open(asset,'r:gz') as t:
 for m in t:
  assert m.isfile() and m.name not in seen;seen.add(m.name);data=t.extractfile(m).read()
  if m.name=='MANIFEST.json':assert data==payload
  else:assert manifest[m.name]=={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)},m.name
assert seen==set(manifest)|{'MANIFEST.json'}
archive={'path':str(asset.relative_to(repo)),'sha256':sha(asset),'verified_files':len(manifest),'all_members_decompressed_and_hashed':True,'scope':'Runtime sources, focused before/after patch, XML/logs and closed operational controls. Models, NPZ/CSV data, meshes, SDK installs, large sdist and browser output frames excluded. Current report excluded to avoid a circular hash.'};(r/'archive-integrity.json').write_text(json.dumps(archive,indent=2)+'\n')
play=read(run/'play/worker-config.json')['inputs'];all_inputs=cases['eval-all']['worker']['motion_input_snapshot'];size=lambda snap:sum((Path(snap['root'])/n).stat().st_size for n in snap['files'])
report={'status':'complete','started_at':'2026-10-27T08:41:30+00:00','finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Workspace operation and input isolation optimization of independent SuperMimic reproduction; no new policy-quality or paper-reproduction claim.','official_weights_used':False,'hardware_execution':False,'commands':{'play':'./supermimic play','eval':'./supermimic eval','train':'./supermimic train --hours 1','doctor':'./supermimic doctor'},'source_sha256':sources,'historical_artifacts_unchanged':history,'tests':{'related_suite':counts,'documentation_after_guide_update':docs,'ruff':(r/'ruff.log').read_text().strip(),'scope':'The63documentation checks are included in the224suite and were rerun after README/index changes; counts are not unique totals.'},'changes':['Resolve workspace SDK/model/data internally; no environment setup required in user commands.','Verify expected default model and motion identities; isolate all SDK imports in the child process.','Copy only the selected play clip; use private read-only snapshots for evaluation and training, verify CRC before CUDA and hashes at the end.','Load checkpoint on CPU once and transfer only policy weights to GPU.','Retain observed worker failure/interruption statuses rather than accepting partial summary files.','Include the executable workspace launcher in source distributions.'],'accepted_operational_runs':cases,'loader_fixed_input_control':parity,'shared_source_mutation_control':control,'intentional_bad_input_control':reject,'browser_entry_control':viewer,'source_distribution_control':package,'known_check_harness_failure':read(r/'package-first-attempt.json'),'play_input_copy':{'files':len(play['files']),'bytes':size(play)},'full_eval_input_copy':{'files':len(all_inputs['files']),'bytes':size(all_inputs)},'copy_scope':'File-count/byte-volume observation only, not a measured speedup.','doctor_final':read(r/'doctor-final.log'),'ownership_audit':ownership,'evidence_archive':archive,'limits':['Fresh/resumed smoke runs used8environments and one training clip; their failed tracking is recorded and is not evidence of model-quality improvement.','Default40clip evaluation used the existing58000iteration original-observation model. It is a single operational verification on training data.','The browser control verified HTTP200 and graceful owned interruption130; no full browser scene, screenshot, or prolonged interactive stability was assessed.','Read-only copies protect against ordinary shared-source replacement, not all owner/root writes, memory corruption or storage faults. The original unexplained mutation cause is not claimed fixed.','The historical anchor long-run exit1 remains failed and is not relabelled by this work.']}
report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');proof={'all_checks_passed':True,'report_sha256':sha(report_path),'archive_sha256':archive['sha256'],'verified_archive_files':len(manifest),'source_files_verified':len(sources),'historical_artifacts_verified':len(history),'expected_negative_exit1_and_interruption130_preserved':True,'owned_run_namespace_processes_remaining':0};(r/'final-integrity.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
