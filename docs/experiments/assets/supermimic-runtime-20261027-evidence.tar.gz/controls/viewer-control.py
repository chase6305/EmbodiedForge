"""Start the new browser entry point, probe its own logged URL, stop it gracefully."""
import json,os,re,signal,subprocess,sys,time,urllib.request
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;run=repo/'runs/supermimic-runtime-20261027';supervised=run/'play-supervisor';out=run/'play';command=[sys.executable,str(repo/'benchmarks/process_supervisor.py'),'--output',str(supervised),'--grace','30','--',str(repo/'supermimic'),'play','--output',str(out)]
url=None;status=None
with (r/'play-outer.log').open('x') as log:
 p=subprocess.Popen(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  deadline=time.monotonic()+180
  while time.monotonic()<deadline:
   assert p.poll() is None,'Viewer exited before HTTP readiness'
   file=out/'command.log';text=file.read_text(errors='replace') if file.exists() else '';text=re.sub(r'\x1b\[[0-9;]*m','',text)
   ports=re.findall(r'http://(?:localhost|127\.0\.0\.1|0\.0\.0\.0):(\d+)',text)
   if ports:
    url='http://127.0.0.1:'+ports[-1]
    try:
     with urllib.request.urlopen(url,timeout=2) as response:
      body=response.read(2048);status=response.status
     if status==200 and b'html' in body.lower():break
    except OSError:pass
   time.sleep(.25)
  else:raise TimeoutError('Viewer did not publish a reachable browser URL')
  p.send_signal(signal.SIGINT);code=p.wait(timeout=45)
 finally:
  if p.poll() is None:
   p.send_signal(signal.SIGTERM)
   try:p.wait(timeout=40)
   except subprocess.TimeoutExpired:p.kill();p.wait()
assert code==130,code
outer=json.loads((supervised/'result.json').read_text());launcher=json.loads((out/'launcher.json').read_text());assert outer['exit_observed'] and outer['process_returncode']==130 and not outer['forced_stop'] and not outer['timed_out'];assert launcher['status']=='interrupted'
config=json.loads((out/'worker-config.json').read_text());assert len(config['inputs']['files'])==1
proof={'status':'complete','http_status':status,'url':url,'copied_motion_files':len(config['inputs']['files']),'selected_clip':config['clip'],'observed_supervisor_exit':code,'observed_child_exit':outer['process_returncode'],'expected_controlled_interruption':True,'launcher_status':launcher['status'],'scope':'Actual Viser HTTP readiness and owned graceful interruption; no browser screenshot, subjective tracking score, or long-duration stability claim.'};(r/'viewer-control.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof),flush=True)
