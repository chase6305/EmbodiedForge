import hashlib,json,sys
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;sys.path.insert(0,str(repo/'src'))
import torch
from embodiedforge.supermimic_run import load_policy
from supermimic.eval.benchmark import load_policy_from_checkpoint
checkpoint=repo/'runs/supermimic-reproduction-20261027-fourhour/paper-resume/training/ckpt_0058000.pt';sha=hashlib.sha256(checkpoint.read_bytes()).hexdigest();torch.set_num_threads(1)
policy,cfg,iteration,updates=load_policy(checkpoint,'cpu');original,original_cfg=load_policy_from_checkpoint(checkpoint,'cpu');assert cfg==original_cfg
obs=torch.linspace(-.1,.1,3*930).reshape(3,930);goal=torch.linspace(-.2,.2,3*cfg['policy']['goal_dim']).reshape(3,-1)
with torch.no_grad():
 a=policy(obs,goal);b=original(obs,goal);assert torch.equal(a,b);error=float((a-b).abs().max())
assert hashlib.sha256(checkpoint.read_bytes()).hexdigest()==sha
proof={'actual_scope':'CPUfloat32 fixed-input comparison, trusted local model, no rollout/continuous-training equality claim','iteration':iteration,'updates':updates,'checkpoint_sha256':sha,'max_abs_action_error':error,'exact_action_parity':True,'output_shape':list(a.shape)};(r/'loader-parity.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
