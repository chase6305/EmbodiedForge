"""Read only selected regular Python files from the source archive on Python3.10."""
import hashlib,json,shutil,stat,subprocess,sys,tarfile
from pathlib import Path
r=Path(__file__).parent;repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');source=next((r/'dist').glob('*.tar.gz'));dest=r/'package-runtime';selected={};names=('supermimic','src/embodiedforge/supermimic_run.py','src/embodiedforge/workflows/supermimic_inputs.py','benchmarks/supermimic_reproduce.py')
with tarfile.open(source) as t:
 prefix=t.getmembers()[0].name.split('/')[0]
 for name in names:
  member=t.getmember(prefix+'/'+name);assert member.isfile();data=t.extractfile(member).read();assert data==(repo/name).read_bytes(),name;selected[name]=hashlib.sha256(data).hexdigest()
 assert t.getmember(prefix+'/supermimic').mode & stat.S_IXUSR
 for member in t:
  if member.name!=prefix+'/supermimic' and not(member.name.startswith(prefix+'/src/') and member.name.endswith('.py')):continue
  assert member.isfile();target=(dest/member.name).resolve();assert target.is_relative_to(dest.resolve());target.parent.mkdir(parents=True,exist_ok=True)
  with t.extractfile(member) as src,target.open('wb') as dst:shutil.copyfileobj(src,dst)
  if member.name==prefix+'/supermimic':target.chmod(0o755)
result=subprocess.run([sys.executable,str(dest/prefix/'supermimic'),'--help'],cwd='/tmp',capture_output=True,text=True,timeout=10);assert result.returncode==0,result.stderr;assert 'doctor' in result.stdout
proof={'sdist':str(source),'root_launcher_included':True,'executable_mode_preserved':True,'runtime_source_sha256':selected,'extracted_help_actual_exit':result.returncode,'tested_outside_repository_cwd':True,'scope':'Only selected regular runtime Python files extracted, no archive links followed. SDK, models and data remain external; complete distribution metadata is outside this smoke check.'};(r/'package-check.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
