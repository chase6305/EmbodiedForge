"""Mutate only this task's disposable cache after the worker freezes its input."""
import hashlib,json,sys,threading,time,zipfile
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;run=repo/'runs/supermimic-runtime-20261027';sys.path.insert(0,str(repo/'src'))
from embodiedforge.runtime.process import run_process
from embodiedforge.supermimic_run import sdk_environment
source=run/'validation-motions/walk1_subject1.npz';original=source.read_bytes();expected=hashlib.sha256(original).hexdigest();stop=threading.Event();events={};errors=[]
checkpoint=run/'fresh/training/training/ckpt_latest.pt';output=run/'resume'
command=[str(repo/'supermimic'),'train','--profile','smoke','--num-envs','8','--iterations','120','--hours','.1','--checkpoint',str(checkpoint),'--motions',str(source.parent),'--output',str(output)]
def observe():
 try:
  while not stop.wait(.05):
   result=output/'training/result.json'
   if not result.exists():continue
   d=json.loads(result.read_text())
   if d['status']!='training':continue
   private=Path(d['motion_input_snapshot']['root'])/source.name
   assert hashlib.sha256(private.read_bytes()).hexdigest()==expected
   changed=bytearray(original);changed[len(changed)//2]^=128;source.chmod(0o644);source.write_bytes(changed)
   assert hashlib.sha256(source.read_bytes()).hexdigest()!=expected
   with zipfile.ZipFile(source) as z:bad=z.testzip()
   assert bad is not None
   events.update(source_sha256_before=expected,source_sha256_during=hashlib.sha256(source.read_bytes()).hexdigest(),private_sha256_during=hashlib.sha256(private.read_bytes()).hexdigest(),bad_source_member=bad,private_path=str(private),mutation_stage=d['status'],mutation_scope='Disposable validation-motions copy only; canonical recovered data and historical runs are untouched.')
   break
 except BaseException as error:errors.append(repr(error))
watcher=threading.Thread(target=observe,daemon=True);watcher.start()
try:
 run_process(command,cwd=repo,env=sdk_environment(),log_path=r/'resume-source-control-command.log',echo=False,timeout=600)
finally:
 stop.set();watcher.join(timeout=5);source.chmod(0o644);source.write_bytes(original);source.chmod(0o444)
assert not errors and events,(errors,events)
result=json.loads((output/'training/result.json').read_text());launch=json.loads((output/'launcher.json').read_text());assert result['status']=='complete' and result['new_updates']>0 and result['finite_model_tensors'] and result['checkpoint_reload_action_parity'];assert launch['worker_returncode']==0 and launch['worker_exit_observed'];assert hashlib.sha256(Path(events['private_path']).read_bytes()).hexdigest()==expected;assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
events.update(status='complete',actual_worker_exit=launch['worker_returncode'],source_restored_exactly=True,new_updates=result['new_updates'],resume_replay_refill_steps=result['resume_replay_refill_steps'],snapshot_passed_end_validation=True,scope='Operational isolation/recovery control on a reduced one-clip smoke model; no model-quality, storage-cause, or identical-RNG claim.');(r/'resume-source-control.json').write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(events),flush=True)
