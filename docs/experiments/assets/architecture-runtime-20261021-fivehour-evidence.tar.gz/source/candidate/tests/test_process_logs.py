"""Inherited worker stdout cannot keep the launcher blocked during teardown."""

import os
import signal
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest


@pytest.mark.skipif(sys.platform != "linux", reason="Linux subreaper fixture")
@pytest.mark.parametrize("worker_code", [0, 7, "timeout"])
def test_detached_stdout_holder_does_not_block_log_cleanup(tmp_path, worker_code):
    descendant = tmp_path / "descendant.pid"
    holder = textwrap.dedent(f"""
        import os,time
        from pathlib import Path
        Path({str(descendant)!r}).write_text(str(os.getpid()))
        time.sleep(30)
    """)
    worker = textwrap.dedent(f"""
        import subprocess,sys,time
        from pathlib import Path
        subprocess.Popen([sys.executable,'-c',{holder!r}], start_new_session=True)
        while not Path({str(descendant)!r}).exists(): time.sleep(.005)
        print('worker output',flush=True)
        if {worker_code!r}=='timeout': time.sleep(30)
        raise SystemExit({worker_code!r})
    """)
    wrapper = textwrap.dedent(f"""
        import ctypes,os,signal,subprocess,sys,threading
        from pathlib import Path
        sys.path.insert(0,{str(Path(__file__).resolve().parents[1] / "src")!r})
        from embodiedforge.runtime import process
        assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
        # Shorten only the reader grace period; a stuck close still blocks.
        original = process.threading.Thread
        class Reader(original):
            def join(self,timeout=None): super().join(timeout=.2)
        process.threading.Thread=Reader
        try:
            try:
                process.run_process([sys.executable,'-c',{worker!r}],
                    cwd=Path({str(tmp_path)!r}),env=os.environ.copy(),
                    log_path=Path({str(tmp_path / "worker.log")!r}),
                    timeout=.5 if {worker_code!r}=='timeout' else 3)
            except subprocess.CalledProcessError as error:
                assert error.returncode=={worker_code!r} and {worker_code!r}!=0
            except subprocess.TimeoutExpired:
                assert {worker_code!r}=='timeout'
            else:
                assert {worker_code!r}==0
            assert threading.enumerate()==[threading.main_thread()]
            # The escaped descendant is outside the launcher's owned group.
            os.kill(int(Path({str(descendant)!r}).read_text()),0)
        finally:
            pid=int(Path({str(descendant)!r}).read_text())
            try: os.kill(pid,signal.SIGKILL)
            except ProcessLookupError: pass
            os.waitpid(pid,0)
    """)
    owner = subprocess.Popen(
        [sys.executable, "-c", wrapper],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        start_new_session=True,
    )
    stalled = False
    try:
        try:
            stdout, stderr = owner.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            stalled = True
            if descendant.exists():
                try:
                    os.kill(int(descendant.read_text()), signal.SIGKILL)
                except ProcessLookupError:
                    pass
            stdout, stderr = owner.communicate(timeout=5)
    finally:
        if owner.poll() is None:
            os.killpg(owner.pid, signal.SIGKILL)
            owner.communicate(timeout=5)
    assert not stalled, f"Log cleanup blocked on detached stdout: {stderr}"
    assert owner.returncode == 0, (stdout, stderr)
    assert (tmp_path / "worker.log").read_text().startswith("worker output\n")
    with pytest.raises(ProcessLookupError):
        os.kill(int(descendant.read_text()), 0)
