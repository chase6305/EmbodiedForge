# 公共运行记录

训练、数据采集和 SDK 工作流继续使用各自的产物格式。新运行在原有 manifest 中增加 `run_contract`，公共身份与状态查询仅依赖 Python 标准库，不加载 NumPy、核心环境或外部 SDK。`run_identity` 构造身份，`validate_run_identity` 校验并复制已声明的身份，未知版本直接拒绝。

```json
{
  "run_contract": {
    "schema_version": 1,
    "workflow": "recipes",
    "operation": "train",
    "task": "go1-joystick"
  },
  "status": "running"
}
```

`workflow` 标识执行体系，`operation` 标识该入口执行的操作，`task` 是该工作流的任务名或 `null`。它们不要求不同任务共用仿真接口。已有 `schema`、`schema_version`、`workflow`、`recipe` 等字段继续由原工作流解释；公共 schema 的版本只作用于 `run_contract`。

## 查询

```bash
python -m embodiedforge runs inspect --run /path/to/run
```

Python 中使用 `embodiedforge.runtime.records.read_run(path)`。查询返回公共身份、manifest 文件名及其 SHA256、身份来源和已记录的状态，不修改目录。

SDK 与元数据子命令放在 `embodiedforge` 后的第一个参数位置，例如 `embodiedforge h1 train ...`。核心命令的参数不会被透传到其他工作流；将它们放在 SDK 子命令前会报错，避免意外运行核心 rollout。公共 CLI 使用同一份分发目录生成命令选项并选择入口。

| 公共状态 | 含义 |
| --- | --- |
| `preparing` | 准备输入、实现快照或运行环境 |
| `running` | 运行记录标记为执行中 |
| `complete` | 工作流已报告完成 |
| `rejected` | 工作流执行完毕，但未通过显式验收 |
| `failed` | 执行或产物校验失败 |
| `interrupted` | 捕获到中断并完成状态收尾 |
| `timed_out` | 工作流超时 |

核心数据集 `core-data` 与显式元数据的原生采集 `episode-data` 将原有 `recording` / `closed` 分别映射为公共 `running` / `complete`；`recorded_status` 保留原值。关闭数据集允许丢弃未完成的 episode，不代表所有环境均有完整 episode。

`terminal` 仅描述已记录状态。机器故障可能遗留 `running`，查询不会探测进程是否仍然存在；`process_liveness` 为 `not_checked`。查询也不会读取模型或验证 checkpoint，`artifact_verification` 为 `not_checked`。恢复、评估和策略验收仍需使用对应工作流入口。

## 兼容读取

有 `run_contract` 时严格使用其版本，版本不支持则报错，不回退到猜测。旧运行仅在格式可以识别时读取：核心 PPO、核心数据集、Go1/Wuji recipes、原生 H1、IsaacLab H1、Microduck、ACT、GMR 和 SONIC；旧 RLinf/Weave 状态记录需要匹配的 `request.json` 确认身份。ACT 的记录位于 `act-run.json`；LeRobot 尚未创建目录时，可查询其父目录中的启动记录。

不根据目录名称或日期推断工作流。缺失或损坏的记录会报告错误，不初始化 SDK、不自动恢复或重写旧产物。

## 公共基础设施

| 模块 | 职责 |
| --- | --- |
| `runtime.artifacts` | 有限 JSON 的原子发布、独立临时文件与失败清理 |
| `runtime.process` | 子进程日志、进程组清理、中断转发、显式文件描述符继承、SDK 包路径 |
| `runtime.environment` | 独立 conda SDK 的基础环境配置 |
| `runtime.provenance` | 实现快照与文件身份校验 |
| `runtime.hashing` | 有界读取文件 SHA256 |
| `runtime.implementation` | 记录实际加载的实现、源码散列与依赖版本 |
| `runtime.records` | 版本化运行身份、公共生命周期与只读状态视图 |

JSON 发布使用同目录临时文件和原子替换，防止读到半个 JSON；不承诺断电后的 fsync 持久性，也不为多个写入者决定业务顺序。调用方仍需协调状态更新。

兼容入口如 `recipes.write_json`、`h1.sha256` 和 `_microduck_process.run_process` 仍可导入；新代码应直接依赖公共工具所属模块。任务专属配置、验收与 checkpoint 兼容性判断继续留在各工作流。

新工作流可通过 `runtime.records.managed_run` 发布开始、结束和异常状态。调用方独占新目录，context 不覆盖已有记录；成功时可明确标记 `rejected`，异常按失败、中断或超时记录。原生 H1 评估使用此入口，并在 `run.json` 中引用 `evaluation.json` 及其 SHA256。

已有工作流通过 `runtime.records.run_lifecycle(record, publish)` 复用同一套状态收尾，同时保留原有 manifest 路径和专属字段。核心 PPO、原生 H1 训练、IsaacLab H1、recipes、Microduck 的训练/评估/比较、ACT、RLinf、Weave 和动作 SDK 启动器已接入。它们的 checkpoint 提交、恢复校验与策略验收仍由各自工作流负责；Microduck ONNX 导出保留发布与回滚事务。

`record` 初始状态为 `running` 或 `preparing`。准备工作完成后，调用方将 `preparing` 改为 `running` 并按需发布；准备状态不能在成功退出时直接变成完成。`publish(record)` 在启动和收尾时调用，负责原子写入现有记录。可选 `finalize(record)` 在退出时收集 checkpoint 目录等终态元数据，之后仍会尝试发布最终记录。

生命周期覆盖启动写入、执行和收尾期间的终止信号；`SIGTERM` 和未被忽略的 `SIGHUP` 会进入正常异常收尾，记录 `interrupt_signal`。已有执行异常不会被终态元数据收集、最终写入或信号处理器恢复错误替换。如果执行成功而最终发布失败，会保留该发布异常，并尽力补写失败或中断状态；这次补写失败也不会替换原始异常。持续 I/O 故障、`SIGKILL` 或主机退出仍可能留下旧状态。

ACT 的训练子进程现在由 `runtime.process.run_process` 持有独立进程组，并显式继承训练锁。正常退出和可捕获的中断都会清理所持有的组；启动器被强制杀死时，仍存活的训练器继续持锁，恢复入口会拒绝并发恢复。子进程异常退出属于 `failed`，启动器收到中断属于 `interrupted`，两者不能仅根据退出信号互相推断。

在 POSIX 启动器中，静默日志直接写盘；需要回显时通过非阻塞管道和专属线程保存原始字节，并以 UTF-8 替换无效序列后显示到终端。worker 退出后，日志线程排空当时已缓冲的字节并停止，不等待持有 stdout 的其他会话关闭。脱离作业组的 SDK 服务仍由其资源所有者关闭，启动器不会越过组边界清理它们。
