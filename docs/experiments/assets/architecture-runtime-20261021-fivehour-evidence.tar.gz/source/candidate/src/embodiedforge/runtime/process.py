"""Bounded subprocess log capture with process-group interrupt forwarding."""

import codecs
import logging
import math
import os
import selectors
import signal
import subprocess
import sys
import threading
import time
from contextlib import ExitStack, contextmanager
from numbers import Real
from pathlib import Path

LOGGER = logging.getLogger(__name__)


def sdk_package_path(output, *, package=None):
    """Expose only this package to the SDK, including its spawned processes."""
    directory = Path(output) / "python"
    directory.mkdir()
    (directory / "embodiedforge").symlink_to(
        Path(package).resolve()
        if package is not None
        else Path(__file__).resolve().parents[1],
        target_is_directory=True,
    )
    return directory


class ProcessInterrupted(KeyboardInterrupt):
    def __init__(self, signum):
        super().__init__(f"Interrupted by signal {signum}")
        self.signum = signum


@contextmanager
def termination_signals():
    """Use normal cleanup for scheduler termination; respect nohup's SIGHUP ignore."""
    saved = {}
    try:
        if threading.current_thread() is threading.main_thread():

            def interrupt(signum, frame):
                raise ProcessInterrupted(signum)

            for name in ("SIGTERM", "SIGHUP"):
                sig = getattr(signal, name, None)
                if sig is None:
                    continue
                previous = signal.getsignal(sig)
                if name == "SIGHUP" and previous == signal.SIG_IGN:
                    continue
                saved[sig] = previous
                signal.signal(sig, interrupt)
        yield
    finally:
        active_error = sys.exc_info()[0] is not None
        failures = []
        for sig, previous in saved.items():
            try:
                signal.signal(sig, previous)
            except BaseException as error:
                failures.append(error)
                LOGGER.exception(
                    "Could not restore signal handler %s; preserving %s",
                    sig,
                    "the original error" if active_error else "the first cleanup error",
                )
        if failures and not active_error:
            raise failures[0]


def run_process(
    command,
    *,
    cwd,
    env,
    log_path=None,
    echo=True,
    timeout=None,
    append_log=False,
    pass_fds=(),
):
    """Run a POSIX job and stop its owned group on exit or cancellation.

    timeout is a finite nonnegative wait budget, or None. Captured logs keep raw
    bytes; terminal echo decodes UTF-8 with replacement. Teardown drains buffered
    output without waiting for stdout holders outside the owned process group.
    """
    if timeout is not None:
        try:
            valid_timeout = (
                isinstance(timeout, Real)
                and not isinstance(timeout, bool)
                and math.isfinite(timeout)
                and timeout >= 0
            )
        except OverflowError:
            valid_timeout = False
        if not valid_timeout:
            raise ValueError("timeout must be finite and nonnegative, or None")
    with ExitStack() as resources:
        resources.enter_context(termination_signals())
        log = (
            resources.enter_context(log_path.open("ab" if append_log else "xb"))
            if log_path
            else None
        )
        # Quiet workers can write bytes straight to disk; only terminal echo
        # needs a pipe, decoder, and reader thread.
        capture = log is not None and echo
        stop_reader = threading.Event() if capture else None
        process = resources.enter_context(
            subprocess.Popen(
                command,
                cwd=cwd,
                env=env,
                start_new_session=True,
                stdout=subprocess.PIPE if capture else log,
                stderr=subprocess.STDOUT if log else None,
                pass_fds=pass_fds,
            )
        )

        def send(sig):
            try:
                os.killpg(process.pid, sig)
            except ProcessLookupError:
                pass

        errors = []

        def copy_output():
            decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")
            console_open = echo

            def write_console(text):
                nonlocal console_open
                if console_open:
                    try:
                        sys.stdout.write(text)
                        sys.stdout.flush()
                    except (OSError, ValueError):
                        # A closed terminal must not discard the durable log.
                        console_open = False

            try:
                # An SDK descendant can detach from our process group while
                # retaining stdout. A blocking read would then outlive the job,
                # and closing that buffered pipe while the reader owns its lock
                # can hang Popen.__exit__ indefinitely. Read the descriptor
                # directly so teardown can stop after draining available bytes.
                descriptor = process.stdout.fileno()
                os.set_blocking(descriptor, False)
                with selectors.DefaultSelector() as readable:
                    readable.register(descriptor, selectors.EVENT_READ)
                    remaining = None
                    while True:
                        if remaining is None and stop_reader.is_set():
                            import fcntl
                            import termios
                            from array import array

                            # Bound the final drain even if an escaped process
                            # keeps producing output. The worker has exited, so
                            # all its remaining bytes are already in the pipe.
                            pending = array("i", [0])
                            fcntl.ioctl(descriptor, termios.FIONREAD, pending)
                            remaining = pending[0]
                        if remaining == 0:
                            break
                        try:
                            chunk = os.read(
                                descriptor,
                                65536 if remaining is None else min(65536, remaining),
                            )
                        except BlockingIOError:
                            if stop_reader.is_set():
                                break
                            readable.select(timeout=0.1)
                            continue
                        if not chunk:
                            break
                        if remaining is not None:
                            remaining -= len(chunk)
                        log.write(chunk)
                        log.flush()
                        write_console(decoder.decode(chunk))
                write_console(decoder.decode(b"", final=True))
            except Exception as exc:
                errors.append(exc)
                # A broken log must not leave a silent training process running.
                send(signal.SIGTERM)

        reader = None
        try:
            try:
                # Setup already owns a live child. A failed or interrupted
                # Thread.start must use the same group cleanup as execution.
                if capture:
                    reader = threading.Thread(target=copy_output, daemon=True)
                    reader.start()
                deadline = time.monotonic() + timeout if timeout is not None else None
                while True:
                    try:
                        remaining = (
                            max(0.0, deadline - time.monotonic())
                            if deadline is not None
                            else None
                        )
                        wait = remaining
                        if capture:
                            wait = (
                                min(0.25, remaining) if remaining is not None else 0.25
                            )
                        returncode = process.wait(timeout=wait)
                        break
                    except subprocess.TimeoutExpired:
                        if deadline is not None and time.monotonic() >= deadline:
                            raise subprocess.TimeoutExpired(command, timeout) from None
                        if errors:
                            send(signal.SIGKILL)
            except (KeyboardInterrupt, subprocess.TimeoutExpired):
                send(signal.SIGINT)
                try:
                    process.wait(timeout=10)
                except (subprocess.TimeoutExpired, KeyboardInterrupt):
                    pass
                finally:
                    # The wrapper may exit before descendants that ignore SIGINT
                    # and redirected stdout. They cannot be detected by the log
                    # reader, so always clean the owned group after the grace period.
                    send(signal.SIGKILL)
                    process.wait()
                raise
        finally:
            # The owned job ends with its wrapper, including a successful exit.
            # Quiet descendants do not keep the log pipe open and would otherwise
            # survive indefinitely. Unrelated jobs use different process groups.
            send(signal.SIGKILL)
            if stop_reader is not None:
                stop_reader.set()
            if reader is not None and reader.ident is not None:
                reader.join(timeout=5)
                if reader.is_alive():
                    # A child that inherited stdout may outlive the main worker.
                    send(signal.SIGKILL)
                    reader.join(timeout=5)
                if reader.is_alive() and sys.exc_info()[0] is None:
                    raise RuntimeError(f"Training log reader did not stop: {log_path}")
        if errors:
            # The last flush can fail while joining an already exited worker's
            # reader, after the earlier failure check in finally.
            send(signal.SIGKILL)
            raise RuntimeError(
                f"Failed to capture training log {log_path}: {errors[0]}"
            ) from errors[0]
        if returncode:
            raise subprocess.CalledProcessError(returncode, command)
