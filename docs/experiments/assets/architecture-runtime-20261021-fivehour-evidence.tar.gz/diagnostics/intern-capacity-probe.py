import gc,json,sys,time,tracemalloc
from pathlib import Path
startup_tracing=tracemalloc.is_tracing()
if '--core' in sys.argv:
 import embodiedforge
 for name in embodiedforge.__all__:getattr(embodiedforge,name)
tracemalloc.start(8);samples=[];original=tracemalloc.take_snapshot();began=time.monotonic()
for batch in range(5):
 for i in range(100000):str(Path('/tmp/fixed/one/two/three/file.log'))
 gc.collect();current=tracemalloc.take_snapshot();stats=current.compare_to(original,'lineno')
 samples.append({'batch':batch+1,'operations':(batch+1)*100000,'seconds':time.monotonic()-began,'net_bytes':sum(s.size_diff for s in stats),'pathlib_bytes':sum(s.size_diff for s in stats if 'pathlib.py:404' in str(s.traceback))})
print(json.dumps({'python':sys.version,'core_preloaded':'--core' in sys.argv,'startup_tracing':startup_tracing,'samples':samples}),flush=True)
