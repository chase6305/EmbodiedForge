import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
root=Path('/tmp/embodiedforge-fivehour-20261021');comparison=json.loads((root/'startup-comparison.json').read_text())
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
figure,axes=plt.subplots(2,2,figsize=(13,9),constrained_layout=True)
labels={'embodiedforge':'Package','embodiedforge.runtime.process':'Process tools','embodiedforge.runtime.records':'Run records','runs-inspect':'runs inspect','help:recipes':'recipes --help','help:microduck':'microduck --help','help:h1':'h1 --help','help:rlinf':'rlinf --help','help:gmr':'gmr --help','help:sonic':'sonic --help'}
for ax,version,title in zip(axes[0],('py310','py3120'),('CPython 3.10.0','CPython 3.12.0')):
 cases=list(comparison[version]);positions=np.arange(len(cases));height=.36
 ax.barh(positions-height/2,[comparison[version][name]['baseline_median_ms'] for name in cases],height,color='#94a3b8',label='Received worktree')
 ax.barh(positions+height/2,[comparison[version][name]['candidate_median_ms'] for name in cases],height,color='#2563eb',label='Frozen candidate')
 ax.set_yticks(positions,[labels[name] for name in cases]);ax.invert_yaxis();ax.set_xlabel('Fresh process launch to exit, median ms (30 trials / case)');ax.set_title(title,pad=30);ax.grid(axis='x',alpha=.2);ax.set_axisbelow(True);ax.legend(loc='lower left',bbox_to_anchor=(0,1.01),ncol=2,borderaxespad=0,fontsize=8)
colors=('#2563eb','#f97316','#16a34a','#9333ea')
probes=(('final-py3120-core','3.12.0 + core'),('final-py3120-stdlib','3.12.0 stdlib'),('final-py31214-core','3.12.14 + core'),('final-py3100-stdlib','3.10.0 stdlib'))
fd_ranges={};scenarios=0
for (name,label),color in zip(probes,colors):
 p=root/name/'samples.jsonl'
 if not p.is_file():continue
 samples=[json.loads(line) for line in p.read_text().splitlines() if line.strip()]
 times=np.array([x['seconds'] for x in samples]);rss=np.array([x['resources']['rss_bytes'] for x in samples]);threads=np.array([x['resources']['threads'] for x in samples]);fds=[x['resources']['fds'] for x in samples]
 baseline=np.median(rss[(times>=300)&(times<360)]) if (times>=360).any() else rss[0]
 axes[1,0].plot(times/3600,(rss-baseline)/1024**2,color=color,label=label,lw=1.2)
 axes[1,1].plot(times/3600,threads,color=color,label=label,lw=1.3,alpha=.85)
 fd_ranges[label]=[min(fds),max(fds)];scenarios+=samples[-1]['verified_scenarios']
axes[1,0].axhline(0,color='#64748b',lw=.7);axes[1,0].set_ylabel('RSS delta from 5-minute warmup, MiB');axes[1,0].set_title('Parent RSS includes benchmark sample bookkeeping')
axes[1,1].set_ylabel('Native threads');axes[1,1].set_title('Preloaded core uses NumPy; stdlib launchers do not');axes[1,1].set_yticks([1,8,16,24,32]);axes[1,1].text(.98,.5,'Sampled open FDs: '+', '.join(str(x) for x in sorted(set(tuple(v) for v in fd_ranges.values()))),ha='right',transform=axes[1,1].transAxes,fontsize=8)
for ax in axes[1]:
 ax.set_xlabel('Elapsed workload hours');ax.set_xlim(0,4);ax.grid(alpha=.2);ax.legend(fontsize=8,loc='upper left')
figure.suptitle(f'Runtime architecture validation — {scenarios:,} final-source scenarios sampled\nLinux CPU; long-probe completion and interpreter exit checked separately',fontsize=12)
figure.savefig(root/'architecture-runtime-performance.svg');figure.savefig(root/'architecture-runtime-performance.png',dpi=150);plt.close(figure)
print(json.dumps({'sampled_final_source_scenarios':scenarios,'fd_ranges':fd_ranges}))
