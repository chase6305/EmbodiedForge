"""Escaped continuous stdout holders must not make the final drain unbounded."""
import ctypes,gc,json,os,shutil,signal,subprocess,sys,threading,time
from pathlib import Path
from embodiedforge.runtime.process import run_process
root=Path('/tmp/embodiedforge-fivehour-20261021/flood-probe-v2');root.mkdir()
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
class Console:
 def write(self,value):return len(value)
 def flush(self):pass
original=sys.stdout;sys.stdout=Console()
start=time.monotonic();elapsed=[];sizes=[]
def resources():
 return {'fds':len(list(Path('/proc/self/fd').iterdir())),'threads':len(list(Path('/proc/self/task').iterdir()))}
initial=resources();settling=[]
try:
 for index in range(500):
  cycle=root/'cycle';cycle.mkdir();pidfile=cycle/'descendant.pid';log=cycle/'worker.log'
  descendant="import os,time;from pathlib import Path;Path('descendant.pid').write_text(str(os.getpid()));chunk=bytes((255,))*65536\nwhile True: os.write(1,chunk)"
  worker="import os,subprocess,sys,time;from pathlib import Path;subprocess.Popen([sys.executable,'-c',sys.argv[1]],start_new_session=True,stderr=subprocess.DEVNULL)\nwhile not Path('descendant.pid').exists():time.sleep(.001)\nos.write(1,b'WORKER-FINAL\\n')"
  began=time.monotonic()
  try:
   run_process([sys.executable,'-c',worker,descendant],cwd=cycle,env=os.environ.copy(),log_path=log,timeout=3)
   took=time.monotonic()-began;elapsed.append(took)
   assert took<2,(index,took)
   data=log.read_bytes();sizes.append(len(data));assert b'WORKER-FINAL\n' in data
   assert threading.enumerate()==[threading.main_thread()]
  finally:
   if pidfile.exists():
    pid=int(pidfile.read_text());reaped,_=os.waitpid(pid,os.WNOHANG)
    if not reaped:
     os.kill(pid,signal.SIGKILL);os.waitpid(pid,0)
  shutil.rmtree(cycle);del data;gc.collect()
  observed=resources()
  if observed!=initial:
   at=time.monotonic();details={}
   for task in Path('/proc/self/task').iterdir():
    try:details[task.name]={'comm':(task/'comm').read_text().strip(),'wchan':(task/'wchan').read_text().strip()}
    except FileNotFoundError:details[task.name]={'state':'exited while sampling'}
   while resources()!=initial and time.monotonic()-at<1:time.sleep(.001)
   settled=resources();settling.append({'iteration':index,'initial_sample':observed,'settled_sample':settled,'seconds':time.monotonic()-at,'tasks':details,'python_threads':[t.name for t in threading.enumerate()]})
   assert settled==initial,(index,settled,initial,settling[-1])
finally:
 sys.stdout=original
result={'scenarios':len(elapsed),'all_passed':len(elapsed)==500,'seconds':time.monotonic()-start,'max_job_seconds':max(elapsed),'max_log_bytes':max(sizes),'total_logged_bytes':sum(sizes),'initial_resources':initial,'native_thread_exit_settling':settling,'final_resources':resources(),'scope':'500 real jobs with detached infinite raw-byte stdout writer; final worker marker retained, reader joined, fixture descendant reaped'}
(root/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
