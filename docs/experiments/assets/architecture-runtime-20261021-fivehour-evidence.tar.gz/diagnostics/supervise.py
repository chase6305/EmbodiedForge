import argparse,datetime,json,os,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--python',required=True);p.add_argument('--source',type=Path,required=True);p.add_argument('--script',type=Path,required=True);p.add_argument('--extra-pythonpath',type=Path);p.add_argument('--preload-core',action='store_true');p.add_argument('--duration',type=float,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
command=[a.python,str(a.script.resolve()),'--duration',str(a.duration),'--output',str(a.output.resolve())]

if a.preload_core: command.append('--preload-core')
env={**os.environ,'PYTHONPATH':str(a.source.resolve()),'PYTHONFAULTHANDLER':'1'}

if a.extra_pythonpath: env['PYTHONPATH']+=os.pathsep+str(a.extra_pythonpath.resolve())
began=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with a.output.with_suffix('.log').open('xb') as stream:
 result=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=a.duration+300)
report={'command':command,'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':time.monotonic()-began,'returncode':result.returncode,'interpreter_exit_verified':result.returncode==0,'pythonpath':env['PYTHONPATH']}
for name in ('summary.json','run.json'):
 path=a.output/name
 report[name]=json.loads(path.read_text()) if path.is_file() else None
payload=json.dumps(report,indent=2)+'\n'
a.output.with_suffix('.exit.json').write_text(payload)
print(json.dumps({k:v for k,v in report.items() if k not in ('summary.json','run.json')}),flush=True)
sys.exit(0 if result.returncode==0 else 1)
