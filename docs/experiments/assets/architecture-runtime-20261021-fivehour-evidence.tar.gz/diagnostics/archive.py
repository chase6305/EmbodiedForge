"""Archive owned diagnostics and exact source bytes, excluding environments and models."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path
root=Path('/tmp/embodiedforge-fivehour-20261021');repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge')
report=json.loads((root/'report-for-archive.json').read_text());output=repo/'docs/experiments/assets/architecture-runtime-20261021-fivehour-evidence.tar.gz'
files={}
def add(path,name):
 path=Path(path)
 if path.is_file():
  if name in files:raise ValueError('Duplicate archive path '+name)
  files[name]=path.read_bytes()
for variant,source in [('baseline',root/'baseline/src'),('candidate',root/'final-source/src')]:
 for p in source.rglob('*.py'):add(p,'source/'+variant+'/src/'+str(p.relative_to(source)))
for p in (repo/'tests').glob('*.py'):add(p,'source/candidate/tests/'+p.name)
for p in (repo/'benchmarks').glob('*.py'):
 if p.name in ('import_startup.py','process_lifecycle_soak.py','architecture_parity.py'):add(p,'source/candidate/benchmarks/'+p.name)
for name in ('pyproject.toml','MANIFEST.in','LICENSE','docs/current-architecture.md','docs/run-records.md'):
 add(repo/name,'source/candidate/'+name)
for suffix in ('*.json','*.log','*.xml','*.strace','*.gdb','*.py'):
 for p in root.glob(suffix):
  if p.name in ('report-for-archive.json','summary.json','archive-result.json'):continue
  add(p,'diagnostics/'+p.name)
for label in report['probes']:
 for name in ('run.json','summary.json','samples.jsonl','benchmark.py','allocations.json','path-components.json'):
  add(root/label/name,'runs/'+label+'/'+name)
for label in ('flood-probe-v2','path-probe'):
 for name in ('summary.json','run.json','samples.jsonl','benchmark.py','path-components.json'):
  add(root/label/name,'diagnostics/'+label+'/'+name)
for p in (root/'training-parity').rglob('*'):
 if p.is_file() and p.suffix in ('.json','.log'):add(p,'training-parity/'+str(p.relative_to(root/'training-parity')))
for name in ('final-wheel-validation/result.json','wheel-stdlib-result.json','final-source/source-hashes.json','workspace-changes.diff'):
 add(root/name,'evidence/'+name)
files['evidence/summary.json']=(json.dumps(report,indent=2,ensure_ascii=False)+'\n').encode()
manifest={'schema_version':1,'scope':'Uncompressed SHA256 for every entry except this manifest; raw core files, Python environments, model checkpoints and distributions are excluded','files':{name:{'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)} for name,data in sorted(files.items())}}
files['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with output.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as archive:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
with tarfile.open(output) as archive:
 observed={member.name:hashlib.sha256(archive.extractfile(member).read()).hexdigest() for member in archive.getmembers()}
 assert len(observed)==len(files)
 for name,item in manifest['files'].items():assert observed[name]==item['sha256'],name
frozen=json.loads((root/'final-source/source-hashes.json').read_text())
for name,digest in frozen.items():
 if name.startswith('src/'):assert observed['source/candidate/'+name]==digest,name
result={'path':str(output.relative_to(repo/'docs/experiments')),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'entries':len(files),'all_entries_decoded_and_sha256_verified':True,'frozen_source_modules_verified':133}
(root/'archive-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
