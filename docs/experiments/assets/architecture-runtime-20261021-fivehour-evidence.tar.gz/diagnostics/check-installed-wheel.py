import json
import sys
from dataclasses import asdict
from pathlib import Path
from importlib.resources import files

import numpy as np
import embodiedforge
from embodiedforge import Config, VectorEnv
from embodiedforge.data import EpisodeRecorder, read_episodes
from embodiedforge.envs import validate_environment_spec
from embodiedforge.envs.evaluation import evaluate_policy
from embodiedforge.runtime.records import read_run

root=Path('/tmp/embodiedforge-fivehour-20261021/wheel-validation')
root.mkdir(exist_ok=False)
package=Path(embodiedforge.__file__).resolve()
assert package.is_relative_to(Path(sys.prefix)),(package,sys.prefix)
assert not {'torch','mujoco','mjbatch','newton'} & sys.modules.keys()
resources=files('embodiedforge')
for relative in ('viewers/web.html','viewers/web.js','locomotion/go1_scene.xml','locomotion/microduck/robot/microduck/robot_walk.xml','locomotion/microduck/robot/microduck/assets/bearing_roll.stl'):
    assert (resources/relative).is_file(),relative
with VectorEnv(Config(task='hold',num_envs=2,max_steps=4,render='raster',channels=('rgb','depth'))) as env:
    validate_environment_spec(env.spec)
    assert env.spec['schema_version']==1 and env.spec['done_handling']=='freeze'
    with EpisodeRecorder(root/'episodes',env,episode_format='compact',write_workers=1,verify_archive=True) as writer:
        evaluation=evaluate_policy(env,lambda observation:np.zeros((2,2)),steps=8,writer=writer)
assert len(list(read_episodes(root/'episodes')))==evaluation.completed_episodes==4
assert read_run(root/'episodes')['status']=='complete'
assert not {'torch','mujoco','mjbatch','newton'} & sys.modules.keys()
import torch
from embodiedforge.training import PPOConfig, train_ppo, load_training_checkpoint

torch.set_num_threads(1)
config=Config(task='hold',num_envs=4,max_steps=4)
ppo=PPOConfig(updates=1,rollout_steps=4,epochs=1,minibatch_size=8,seed=17)
train_ppo(config,ppo,root/'train')
train_ppo(config,ppo,root/'resume',resume=root/'train')
restored=load_training_checkpoint(root/'resume')
assert restored.updates==2
assert restored.bundle.env_spec['schema_version']==1
assert read_run(root/'resume')['status']=='complete'
report={'package':str(package),'python':sys.executable,'evaluation':asdict(evaluation),'resumed_updates':restored.updates,'resources_verified':True,'core_imports_without_sdks':True}
(root/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
