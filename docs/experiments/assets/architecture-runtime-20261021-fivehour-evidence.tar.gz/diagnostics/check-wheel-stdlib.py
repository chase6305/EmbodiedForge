import json,runpy,sys
from pathlib import Path
site=Path('/tmp/embodiedforge-fivehour-20261021/wheel-env/lib/python3.10/site-packages')
sys.path.insert(0,str(site))
import embodiedforge
from embodiedforge.runtime import artifacts,implementation,process,provenance,records
assert Path(embodiedforge.__file__).is_relative_to(site)
assert 'numpy' not in sys.modules
root=Path('/tmp/embodiedforge-fivehour-20261021/wheel-stdlib-query');root.mkdir()
with records.managed_run(root,records.run_identity('wheel','validate')):
 process.run_process([sys.executable,'-I','-S','-c','pass'],cwd=root,env=None)
sys.argv=['embodiedforge','runs','inspect','--run',str(root)]
runpy.run_module('embodiedforge',run_name='__main__')
assert 'numpy' not in sys.modules and 'embodiedforge.env' not in sys.modules
report={'package':embodiedforge.__file__,'standard_library_only':True,'isolation_flags':{'isolated':sys.flags.isolated,'no_site':sys.flags.no_site},'status':records.read_run(root)['status']}
Path('/tmp/embodiedforge-fivehour-20261021/wheel-stdlib-result.json').write_text(json.dumps(report,indent=2)+'\n')
