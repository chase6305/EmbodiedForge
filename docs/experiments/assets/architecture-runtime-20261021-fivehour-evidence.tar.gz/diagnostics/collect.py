import datetime,difflib,hashlib,json,re,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
root=Path('/tmp/embodiedforge-fivehour-20261021');repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge')
def read(name):
 p=root/name
 return json.loads(p.read_text()) if p.is_file() else None
progress=read('progress.json');frozen=read('final-source/source-hashes.json');assert frozen
for name,expected in frozen.items():
 if name.startswith('src/'):
  assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==expected,name
original=read('baseline-hashes.json');changes={};diff=[]
for base in ('src','tests','benchmarks','docs'):
 for p in (repo/base).rglob('*'):
  if not p.is_file() or '__pycache__' in p.parts or p.suffix not in ('.py','.md','.json','.toml'):continue
  relative=str(p.relative_to(repo))
  if relative.startswith('docs/experiments/architecture-runtime-20261021-fivehour'):continue
  digest=hashlib.sha256(p.read_bytes()).hexdigest()
  if original.get(relative)==digest:continue
  changes[relative]={'baseline_sha256':original.get(relative),'candidate_sha256':digest}
  baseline=root/'baseline'/relative
  old=baseline.read_text().splitlines(keepends=True) if baseline.is_file() else []
  diff.extend(difflib.unified_diff(old,p.read_text().splitlines(keepends=True),fromfile='baseline/'+relative,tofile='candidate/'+relative))
(root/'workspace-changes.diff').write_text(''.join(diff))
tests={}
for name in ('frozen-main-suite','frozen-native-suite','frozen-act-sdk','frozen-microduck-sdk','sdist-tests','final-sdist-tests'):
 p=root/(name+'.xml')
 if p.is_file():
  suites=ET.parse(p).getroot();children=list(suites) if suites.tag=='testsuites' else [suites]
  values={key:sum(int(s.attrib.get(key,0)) for s in children) for key in ('tests','failures','errors','skipped')};values['passed']=values['tests']-values['failures']-values['errors']-values['skipped'];values['xml']=str(p)
  console=(root/(name+'.log')).read_text()
  counts=re.findall(r'(\d+) passed',console);subtests=re.findall(r'(\d+) subtests passed',console)
  if counts:
   values['xml_testcases']=values['tests'];values['passed_including_xml_subtests']=values['passed'];values['passed']=int(counts[-1]);values['subtests_passed']=int(subtests[-1]) if subtests else 0;values['tests']-=values['subtests_passed']
  tests[name]=values
parity=read('training-parity/summary.json')
report={'schema_version':1,'stage':progress['stage'],'started_utc':progress['started_utc'],'deadline_utc':progress['deadline_utc'],'last_updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline':{'scope':'Dirty source/test/documentation worktree as received at start of this five-hour continuation; earlier edits preserved','archive':str(root/'baseline.tar.gz')},'changes':changes,'source_hashes':frozen,'tests':tests,'startup':read('startup-comparison.json'),'training_parity':{'comparisons':len(parity['comparisons']),'all_match':all(c['match'] for c in parity['comparisons']),'details':parity} if parity else None,'live_probes':read('live-status.json'),'allocation_probe':read('allocation-py31214-core/allocations.json'),'infinite_stdout_flood':read('flood-probe-v2/summary.json'),'flood_probe_initial_harness':{'status':'349th iteration saw native thread count 2 after Python join; v2 measured 3.6 ms settling and passed 500; raw failure retained'},'previous_exit_failure':{'reference':'docs/experiments/architecture-lifecycle-20261021.json','status':'unresolved unless new trace establishes a cause','observed':'SIGSEGV 139 after 7088 verified scenarios in previous one-hour captured probe; tupledealloc+56, inline _PyGCHead_SET_PREV','rapid_rechecks':{'reference_runtime_100000':0,'candidate_before_fixes_100000':0,'bare_subprocess_100000':0},'numpy_control_environments':['py31214-numpy252-environment.log','py3120-numpy241-environment.log'],'notes':'Conda CPython 3.12.0 uses fork here; standalone CPython 3.12.14 uses vfork here. Same NumPy version control confirms launch/thread behavior differs; this does not establish the SIGSEGV cause.'},'distribution':read('final-distribution-integrity.json'),'wheel_validation':read('final-wheel-validation/result.json'),'wheel_stdlib_validation':read('wheel-stdlib-result.json'),'wheel_strict_read':read('final-wheel-strict-read.log'),'limitations':['CPU/Linux validation; source parity checks numerical compatibility, not policy quality','Run completion is not interpreter-exit verification; outer supervisor or GDB inferior status must also pass','Earlier build and exploratory test attempts are retained separately; final distribution checks cover all 133 frozen production modules','Long-probe source identity is recorded per run; only final-* probes use all final 133 modules']}
(root/'summary.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'changed_paths':len(changes),'tests':{k:v['passed'] for k,v in tests.items()},'training_parity':report['training_parity']['all_match'] if parity else None,'frozen_modules_verified':133}))
