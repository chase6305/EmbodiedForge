set pagination off
set confirm off
set print thread-events off
set follow-fork-mode parent
set detach-on-fork on
handle SIGINT nostop noprint pass
handle SIGTERM nostop noprint pass
run
thread apply all bt full
info registers
quit
