import argparse,gc,json,sys,tracemalloc
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--mode',choices=['path','open','intern'],required=True);a=p.parse_args()
tracemalloc.start(8);before=tracemalloc.take_snapshot()
for i in range(100000):
 if a.mode=='path': str(Path('/tmp/fixed/one/two/three/file.log'))
 elif a.mode=='open':
  with Path('/proc/self/status').open() as stream:stream.read()
 else:sys.intern('fixed repeated component'.encode().decode())
gc.collect();after=tracemalloc.take_snapshot();changes=after.compare_to(before,'lineno')
print(json.dumps({'python':sys.version,'mode':a.mode,'net_bytes':sum(c.size_diff for c in changes),'top':[{'line':str(c.traceback),'bytes':c.size_diff,'count':c.count_diff} for c in changes[:6]]}),flush=True)
