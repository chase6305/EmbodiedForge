import datetime,json
from pathlib import Path
root=Path('/tmp/embodiedforge-fivehour-20261021')
names=('captured-py3120-gdb','captured-py3120-debug','captured-py31214','captured-py3100','control-py31214-numpy252','control-py3120-numpy241','candidate-lifecycle-py3120','candidate-lifecycle-py31214','final-py3120-core','final-py3120-stdlib','final-py31214-core','final-py3100-stdlib','allocation-py31214-core')
report={'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'probes':{}}
for name in names:
 directory=root/name
 item={}
 path=directory/'samples.jsonl'
 if path.is_file():
  with path.open('rb') as stream:
   stream.seek(0,2);size=stream.tell();stream.seek(max(0,size-16384));lines=stream.read().splitlines()
  for line in reversed(lines):
   try:sample=json.loads(line)
   except (ValueError,UnicodeError):continue
   item.update(seconds=round(sample['seconds'],1),scenarios=sample['verified_scenarios'],**sample['resources']);break
 run=directory/'run.json'
 if run.is_file():
  value=json.loads(run.read_text());item['status']=value['status']
  if 'error' in value:item['error']=value['error']
 exitfile=root/(name+'.exit.json')
 if exitfile.is_file():
  value=json.loads(exitfile.read_text());item['exitcode']=value['returncode'];item['exit_verified']=value['interpreter_exit_verified']
 gdbfile=root/(name+'.gdb-exit.json')
 if gdbfile.is_file():
  value=json.loads(gdbfile.read_text());item['exitcode']=value['inferior_exitcode'];item['exit_verified']=value['interpreter_exit_verified']
 if item:report['probes'][name]=item
(root/'live-status.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
