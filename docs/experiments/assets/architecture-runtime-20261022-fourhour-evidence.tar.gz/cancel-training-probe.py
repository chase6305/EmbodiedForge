import hashlib
import json
import os
import signal
import sys
import threading
import time
from pathlib import Path

import torch

from embodiedforge import Config
from embodiedforge.training import PPOConfig, load_training_checkpoint, train_ppo
from embodiedforge.runtime.process import ProcessInterrupted, run_process
from embodiedforge.runtime.records import managed_run, read_run, run_identity

ROOT = Path('/tmp/embodiedforge-fourhour-20261022/cancel-training-probe')
ROOT.mkdir()
torch.set_num_threads(1)


def equal(a, b):
    if isinstance(a, torch.Tensor):
        return isinstance(b, torch.Tensor) and torch.equal(a, b)
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(equal(a[key], b[key]) for key in a)
    if isinstance(a, (tuple, list)):
        return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return a == b


began = time.monotonic()
results = []
for seed in (0, 17, 1001):
    for handled in (False, True):
        case = ROOT / f'seed{seed}-outer{handled}'
        case.mkdir()
        config = Config(task='hold', num_envs=4, seed=seed, max_steps=5)
        ppo = PPOConfig(updates=1, rollout_steps=8, epochs=2, minibatch_size=16, seed=seed)
        train_ppo(config, ppo, case / 'reference')
        train_ppo(config, ppo, case / 'reference-resume', resume=case / 'reference')
        ready = case / 'ready'
        launcher = case / 'launcher'
        launcher.mkdir()
        triggered = []

        def interrupt():
            deadline = time.monotonic() + 15
            while not ready.exists():
                if time.monotonic() >= deadline:
                    return
                time.sleep(.005)
            triggered.append(True)
            os.kill(os.getpid(), signal.SIGTERM)

        trigger = threading.Thread(target=interrupt)

        def execute():
            with managed_run(launcher, run_identity('probe', 'cancel-training')):
                trigger.start()
                run_process(
                    [sys.executable, str(ROOT.parent / 'cancel-training-worker.py'), '--output', str(case / 'interrupted'), '--ready', str(ready), '--seed', str(seed)],
                    cwd=case,
                    env=os.environ.copy(),
                    log_path=case / 'worker.log',
                    timeout=20,
                )

        caught = None
        try:
            if handled:
                try:
                    raise ValueError('previous attempt already handled')
                except ValueError:
                    execute()
            else:
                execute()
        except ProcessInterrupted as error:
            caught = error
        finally:
            trigger.join(timeout=16)
        assert triggered and caught is not None and caught.signum == signal.SIGTERM
        assert read_run(launcher)['status'] == 'interrupted'
        interrupted = json.loads((case / 'interrupted/run.json').read_text())
        assert interrupted['status'] == 'interrupted' and interrupted['interrupt_signal'] == signal.SIGINT
        recovered = load_training_checkpoint(case / 'interrupted')
        reference = load_training_checkpoint(case / 'reference')
        assert recovered.updates == reference.updates == 1
        assert equal(recovered.bundle.policy.state_dict(), reference.bundle.policy.state_dict())
        assert equal(recovered.optimizer_state, reference.optimizer_state)
        train_ppo(config, ppo, case / 'resumed', resume=case / 'interrupted')
        resumed = load_training_checkpoint(case / 'resumed')
        expected = load_training_checkpoint(case / 'reference-resume')
        assert resumed.updates == expected.updates == 2
        assert equal(resumed.bundle.policy.state_dict(), expected.bundle.policy.state_dict())
        assert equal(resumed.optimizer_state, expected.optimizer_state)
        assert read_run(case / 'resumed')['status'] == 'complete'
        assert threading.enumerate() == [threading.main_thread()]
        result = {'seed': seed, 'outer_handled_error': handled, 'launcher_interrupt_signal': signal.SIGTERM, 'worker_interrupt_signal': signal.SIGINT, 'saved_updates': recovered.updates, 'resumed_updates': resumed.updates, 'checkpoint_and_optimizer_equal_to_reference': True, 'resumed_policy_and_optimizer_equal_to_two_stage_reference': True, 'checkpoint_sha256': recovered.bundle.sha256}
        results.append(result)
        print(json.dumps(result), flush=True)
report = {'scope': 'Actual CPU PPO cancelled after first committed checkpoint via the launcher; recovered state and resumed update equal a normal two-stage reference, not a continuous-training parity claim', 'seconds': time.monotonic() - began, 'cases': len(results), 'all_passed': True, 'results': results}
(ROOT / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'results'}), flush=True)
