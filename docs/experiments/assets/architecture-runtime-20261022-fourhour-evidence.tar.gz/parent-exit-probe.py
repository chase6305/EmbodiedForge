import concurrent.futures
import datetime
import itertools
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path('/tmp/embodiedforge-fourhour-20261022')
OUTPUT = ROOT / 'parent-exit-probe'
OUTPUT.mkdir()
PYTHONS = {
    'py3120': '/home/ubuntu/workspace/chase/EmbodiedForge/.cache/external/mjbatch/.venv/bin/python',
    'py31214': '/home/ubuntu/workspace/chase/EmbodiedForge/.cache/microduck-native-venv/bin/python',
}
CONFIGURATIONS = list(itertools.product(PYTHONS, ('pymalloc', 'debug'), (None, 10)))


def run(item):
    index, (version, allocator, threshold) = item
    output = OUTPUT / f'{index:03}-{version}-{allocator}-gc{threshold}'
    command = [PYTHONS[version], str(ROOT / 'final-source-v2/benchmarks/process_fault_soak.py'),
               '--duration', '10', '--preload-core', '--output', str(output)]
    if threshold is not None:
        command += ['--gc-threshold', str(threshold)]
    env = {**os.environ, 'PYTHONPATH': str(ROOT / 'final-source-v2/src'),
           'PYTHONMALLOC': allocator, 'PYTHONFAULTHANDLER': '1'}
    if version == 'py31214':
        env['PYTHONPATH'] += ':/tmp/embodiedforge-fivehour-20261021/numpy252'
    began = time.monotonic()
    with output.with_suffix('.log').open('xb') as stream:
        try:
            result = subprocess.run(command, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=40)
        except subprocess.TimeoutExpired:
            return {'index': index, 'version': version, 'allocator': allocator, 'gc_threshold': threshold, 'timed_out': True, 'exit_verified': False}
    summary_path = output / 'summary.json'
    summary = json.loads(summary_path.read_text()) if summary_path.is_file() else None
    record = {'index': index, 'version': version, 'allocator': allocator, 'gc_threshold': threshold,
              'returncode': result.returncode, 'seconds': time.monotonic() - began,
              'exit_verified': result.returncode == 0 and summary is not None and summary['all_scenarios_passed'],
              'verified_scenarios': summary['verified_scenarios'] if summary else None,
              'resources': summary['final_resources'] if summary else None}
    output.with_suffix('.exit.json').write_text(json.dumps(record, indent=2) + '\n')
    return record


began = time.monotonic()
results = []
jobs = list(enumerate(CONFIGURATIONS * 25))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
    futures = [executor.submit(run, job) for job in jobs]
    for future in concurrent.futures.as_completed(futures):
        results.append(future.result())
        status = {'completed': len(results), 'requested': len(jobs), 'failures': sum(not row['exit_verified'] for row in results), 'seconds': time.monotonic() - began}
        (OUTPUT / 'progress.json').write_text(json.dumps(status, indent=2) + '\n')
        print(json.dumps(status), flush=True)
result = {'scope': '200 independent NumPy-preloaded parent interpreters, two CPython versions x pymalloc/debug x default/10 GC thresholds, same NumPy 2.5.2 wheel, each exercising at least ten seconds of real fault scenarios',
          'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'seconds': time.monotonic() - began, 'all_exits_verified': all(row['exit_verified'] for row in results),
          'parents': len(results), 'verified_scenarios': sum(row.get('verified_scenarios') or 0 for row in results),
          'results': sorted(results, key=lambda row: row['index'])}
(OUTPUT / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'results'}), flush=True)
raise SystemExit(0 if result['all_exits_verified'] else 1)
