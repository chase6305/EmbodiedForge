import json
import shutil
from pathlib import Path

from collect import ROOT, PROJECT, PROCESS_PROBES, RECORDING_PROBES

destination = PROJECT / 'runs/architecture-runtime-20261022-fourhour'
marker = destination / 'experiment.json'
if destination.exists() and not marker.is_file():
    raise FileExistsError('Unclaimed existing experiment directory: ' + str(destination))
destination.mkdir(parents=True, exist_ok=True)
completed = []
for name in (*PROCESS_PROBES, *RECORDING_PROBES):
    exits = [ROOT / (name + suffix) for suffix in ('.exit.json', '.gdb-exit.json')]
    exit_path = next((path for path in exits if path.is_file()), None)
    if exit_path is None:
        continue
    exit_record = json.loads(exit_path.read_text())
    if not exit_record['interpreter_exit_verified']:
        continue
    target = destination / name
    target.mkdir(exist_ok=True)
    for filename in ('benchmark.py', 'run.json', 'summary.json', 'samples.jsonl'):
        source = ROOT / name / filename
        if source.is_file():
            shutil.copyfile(source, target / filename)
    shutil.copyfile(exit_path, target / 'interpreter-exit.json')
    completed.append(name)
parent = ROOT / 'parent-exit-probe/summary.json'
if parent.is_file():
    shutil.copyfile(parent, destination / 'independent-parent-exits.json')
for filename in ('tests-summary.json', 'suite-exit-status.json', 'environments.json', 'changes.json'):
    shutil.copyfile(ROOT / filename, destination / filename)
shutil.copyfile(ROOT / 'final-source-v2/source-hashes.json', destination / 'source-hashes.json')
marker.write_text(json.dumps({'started_utc': '2026-10-22T02:50:48Z', 'deadline_utc': '2026-10-22T06:50:48Z', 'scope': 'Frozen runtime fault handling and paired CPU recording validation', 'completed_probes': completed, 'original_temporary_root': str(ROOT)}, indent=2) + '\n')
print(json.dumps({'directory': str(destination), 'completed_probes_copied': len(completed)}))
