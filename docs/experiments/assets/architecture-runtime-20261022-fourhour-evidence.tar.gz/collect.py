import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path('/tmp/embodiedforge-fourhour-20261022')
PROJECT = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
FINAL = ROOT / 'final-source-v2'
PROCESS_PROBES = (
    'final-faults-py3120-debug-gdb', 'final-faults-py31214-core',
    'final-faults-py3100-stdlib', 'final-lifecycle-py3120-core',
    'final-faults-py3120-normal', 'final-faults-py31214-numpy252',
)
RECORDING_PROBES = tuple('final-recording-' + task for task in ('core', 'go1', 'h1'))


def read(path):
    return json.loads(path.read_text()) if path.is_file() else None


def probe(name):
    result = {'summary': read(ROOT / name / 'summary.json'),
              'run': read(ROOT / name / 'run.json')}
    result['exit'] = read(ROOT / (name + '.exit.json')) or read(ROOT / (name + '.gdb-exit.json'))
    if result['exit']:
        result['exit'] = {k: v for k, v in result['exit'].items() if k not in ('summary.json', 'run.json')}
    return result


def collect():
    hashes = read(FINAL / 'source-hashes.json')
    production = {k: v for k, v in hashes.items() if k.startswith('src/') and k.endswith('.py')}
    assert len(production) == 133
    assert all(hashlib.sha256((PROJECT / k).read_bytes()).hexdigest() == v for k, v in production.items())
    process = {name: probe(name) for name in PROCESS_PROBES}
    recording = {name: probe(name) for name in RECORDING_PROBES}
    all_done = all(item['summary'] is not None and item['exit'] is not None for item in (*process.values(), *recording.values()))
    all_passed = all_done and all(item['exit']['interpreter_exit_verified'] and item['run']['status'] == 'complete' for item in (*process.values(), *recording.values()))
    overhead = read(ROOT / 'launch-overhead.json')
    old = read(PROJECT / 'docs/experiments/architecture-runtime-20261021-fivehour.json')
    report = {
        'schema_version': 1,
        'summary_zh': '修复共享运行时的启动取消、日志关闭与异常收尾；六组三小时进程长测和三组两小时采集长测全部通过，历史 GC 退出异常的根因仍未确定。',
        'stage': 'complete' if all_passed else 'sustained validation running',
        'started_utc': '2026-10-22T02:50:48Z',
        'deadline_utc': '2026-10-22T06:50:48Z',
        'requested_duration_seconds': 14400,
        'last_updated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'baseline': {'scope': 'Dirty worktree at the start of the four-hour continuation; previous edits and deletions preserved', 'snapshot': 'baseline.tar.gz'},
        'changes': read(ROOT / 'changes.json'),
        'changes_summary': [
            'Keep timeout, cancellation and capture errors when buffered log close also fails with ENOSPC; independent close failures still propagate.',
            'Defer callable cancellation handlers across Popen creation and ownership registration, then forward cancellation and reap the worker; child signal masks and ignored dispositions remain inherited.',
            'Track exceptions leaving each protected runtime context explicitly; outer exceptions already being handled cannot hide current publication, metadata, signal restoration or log close failures.',
            'Add a reusable 24-case fault benchmark alternating normal calls with calls inside an outer except block.',
        ],
        'final_source': {'production_modules': len(production), 'all_current_modules_match_frozen': True, 'hashes': hashes},
        'environments': read(ROOT / 'environments.json'),
        'tests': read(ROOT / 'tests-summary.json'),
        'suite_exit_status': read(ROOT / 'suite-exit-status.json'),
        'pytest_reports': {'main': {'passed': 3263, 'skipped': 80}, 'native': {'passed': 3353, 'skipped': 59, 'passing_subtests': 25}, 'act_sdk': {'passed': 82}, 'microduck_sdk': {'passed': 158}},
        'negative_controls': {
            'old_source_regressions': {'expected_failures': 21, 'observed_failures': 21, 'candidate_passes_full_suite': True},
            'disk_full': read(ROOT / 'baseline-disk-full.json'),
            'spawn_interruption': read(ROOT / 'baseline-spawn-interruption.json'),
            'outer_handled_exception': read(ROOT / 'baseline-handled-error-finalization.json'),
        },
        'training_parity': read(ROOT / 'training-parity/summary.json'),
        'interrupted_training_recovery': read(ROOT / 'cancel-training-probe/summary.json'),
        'independent_parent_exits': read(ROOT / 'parent-exit-probe/summary.json'),
        'launch_overhead': {'scope': overhead['scope'], 'summary': overhead['summary'], 'interpretation': 'About 0.03-0.05 ms additional per job on this host. These are paired /bin/true measurements under concurrent probes, not an SDK training speed benchmark.'},
        'process_probes': process,
        'recording_probes': recording,
        'verified_process_scenarios': sum(item['summary']['verified_scenarios'] for item in process.values() if item['summary']),
        'verified_recording_transitions_per_mode': sum(item['summary']['transitions_per_mode'] for item in recording.values() if item['summary']),
        'all_final_probe_interpreters_exited_zero': all_passed,
        'historical_gc_exit': {
            'status': 'Unresolved historical SIGSEGV; no claimed root cause or fix',
            'previous_report': 'architecture-runtime-20261021-fivehour.json',
            'details': old['previous_exit_failure'],
            'current_controls': 'GDB with debug allocator and GC threshold 10; matching CPython 3.12.0 normal allocator; CPython 3.12.14 with the same NumPy 2.5.2 wheel; final parent/inferior exit checked separately.',
        },
        'distribution': read(ROOT / 'wheel-integrity.json'),
        'installed_wheel': read(ROOT / 'wheel-validation/result.json'),
        'installed_wheel_faults': read(ROOT / 'installed-wheel-faults/summary.json'),
        'stdlib_only_wheel': read(ROOT / 'wheel-stdlib-result.json'),
        'stdlib_only_wheel_faults': read(ROOT / 'wheel-stdlib-faults/summary.json'),
        'strict_dataset_read': read(ROOT / 'wheel-strict-read.json'),
        'superseded_probes': {'reason': 'First candidate replaced by explicit local exception tracking; seven preliminary probes deliberately stopped and restarted on the final snapshot.', 'stop_record': read(ROOT / 'superseded-probe-stop.json'), 'excluded_from_final_pass_counts': True},
        'harness_corrections': ['Initial new fault probe expected interrupt_signal in the public read_run projection; corrected it to read the workflow manifest. Initial ACT test command named nonexistent files; corrected the file list. Both initial outputs are retained.'],
        'limitations': [
            'Only completed fixed-budget probes and externally verified interpreter exits are counted as passed.',
            'Resource samples include native libraries and allocators. Stable observations do not establish a strict RSS bound or absence of every leak.',
            'Numerical parity covers CPU policies, optimizer state and native rollout tensors for three tasks and three seeds; it does not establish better policy quality.',
            'Actual ACT and Microduck SDK tests passed; full GPU IsaacLab, RLinf and Weave training deployments were not run in this continuation.',
            'The historical interpreter GC segmentation fault remains unresolved unless reproduced with actionable diagnostics; no GC disabling or forced os._exit is used.',
            'Process ownership tests cover responsive POSIX filesystems and console sinks; they do not prove bounded teardown for an indefinitely stalled device.',
        ],
        'reproduction': [
            'PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONPATH=$PWD/src python -m pytest -q',
            'PYTHONPATH=src python benchmarks/process_fault_soak.py --duration 10800 --preload-core --gc-threshold 10 --output /tmp/new-process-fault-run',
            'PYTHONPATH=src python benchmarks/process_lifecycle_soak.py --duration 10800 --preload-core --output /tmp/new-process-lifecycle-run',
            'PYTHONPATH=src python benchmarks/native_recording_soak.py --task go1 --duration 7200 --verify-archive --output /tmp/new-go1-recording-run',
        ],
    }
    (ROOT / 'collected.json').write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    return report


if __name__ == '__main__':
    result = collect()
    print(json.dumps({'stage': result['stage'], 'verified_process_scenarios': result['verified_process_scenarios'], 'verified_recording_transitions_per_mode': result['verified_recording_transitions_per_mode']}))
