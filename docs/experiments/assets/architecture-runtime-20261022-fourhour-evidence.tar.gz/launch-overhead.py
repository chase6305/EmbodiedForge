import importlib.util,json,os,random,statistics,sys,time
from pathlib import Path
root=Path('/tmp/embodiedforge-fourhour-20261022')
mods={}
for name,source in [('baseline',root/'baseline-source/src/embodiedforge/runtime/process.py'),('candidate',root/'final-source-v2/src/embodiedforge/runtime/process.py')]:
 spec=importlib.util.spec_from_file_location(name,source);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);mods[name]=module
samples={mode:{name:[] for name in mods} for mode in ('quiet','captured')}
for mode in samples:
 for iteration in range(500):
  order=list(mods)
  if iteration%2:order.reverse()
  for name in order:
   path=root/'launch-benchmark.log'
   at=time.perf_counter_ns()
   mods[name].run_process(['/bin/true'],cwd=root,env=os.environ.copy(),log_path=path,echo=mode=='captured')
   elapsed=(time.perf_counter_ns()-at)/1e6;path.unlink()
   if iteration>=25:samples[mode][name].append(elapsed)
summary={mode:{name:{'median_ms':statistics.median(values),'mean_ms':statistics.mean(values),'p95_ms':sorted(values)[int(.95*len(values))]} for name,values in sides.items()} for mode,sides in samples.items()}
result={'scope':'Alternating baseline/current real /bin/true launches, 25 warmups then 475 paired trials per logging mode; concurrent sustained probes active','summary':summary,'samples':samples}
(root/'launch-overhead.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(summary))
