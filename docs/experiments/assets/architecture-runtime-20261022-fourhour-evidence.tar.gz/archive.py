import hashlib
import io
import json
import tarfile
import time
from pathlib import Path

from collect import collect, ROOT, PROJECT

report = collect()
assert report['all_final_probe_interpreters_exited_zero'], 'Final sustained probes are not complete'
assert report['independent_parent_exits']['all_exits_verified']
report['charts'] = {
    'svg': 'assets/architecture-runtime-20261022-fourhour-validation.svg',
    'png': 'assets/architecture-runtime-20261022-fourhour-validation.png',
}
inner_report = ROOT / 'report-for-archive.json'
inner_report.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
selected = {}


def add(path, name=None):
    if path.is_file() and not path.is_symlink():
        relative = name or path.relative_to(ROOT).as_posix()
        assert relative not in selected, relative
        selected[relative] = path


# Root diagnostics, completed suite logs, source identities and reproduction tools.
for path in ROOT.iterdir():
    if path.suffix in ('.py', '.json', '.xml', '.log', '.gdb', '.diff') and path.name not in ('live-status.json', 'collected.json', 'archive-result.json'):
        add(path)
add(ROOT / 'baseline.tar.gz')
for directory in (ROOT / 'final-source-v2', ROOT / 'baseline-source/src', ROOT / 'training-parity', ROOT / 'wheel-validation', ROOT / 'parent-exit-probe', ROOT / 'cancel-training-probe'):
    for path in directory.rglob('*'):
        if '__pycache__' in path.parts:
            continue
        if path.suffix in ('.py', '.json', '.jsonl', '.xml', '.log') or path.name.startswith('LICENSE'):
            add(path)
for directory in ROOT.iterdir():
    if directory.is_dir() and ((directory / 'run.json').is_file() or directory.name in ('fault-smoke', 'fault-smoke-v2', 'fault-smoke-final')):
        for name in ('benchmark.py', 'run.json', 'summary.json', 'samples.jsonl', 'mismatch.json'):
            add(directory / name)
for name in ('process_fault_soak.py',):
    add(PROJECT / 'benchmarks' / name, 'worktree/benchmarks/' + name)
for name in ('test_process_startup.py', 'test_process_logs.py', 'test_run_lifecycle.py'):
    add(PROJECT / 'tests' / name, 'worktree/tests/' + name)
for name in ('current-architecture.md', 'run-records.md', 'experiments/README.md'):
    add(PROJECT / 'docs' / name, 'worktree/docs/' + name)
for extension in ('svg', 'png'):
    path = PROJECT / 'docs/experiments/assets' / ('architecture-runtime-20261022-fourhour-validation.' + extension)
    add(path, 'charts/' + path.name)
inventory = {name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for name, path in sorted(selected.items())}
for relative, expected in report['final_source']['hashes'].items():
    if relative.startswith('src/') and relative.endswith('.py'):
        assert inventory['final-source-v2/' + relative]['sha256'] == expected, relative
manifest = json.dumps({'schema_version': 1, 'entries': inventory}, indent=2).encode() + b'\n'
destination = PROJECT / 'docs/experiments/assets/architecture-runtime-20261022-fourhour-evidence.tar.gz'
with tarfile.open(destination, 'w:gz', compresslevel=9) as archive:
    info = tarfile.TarInfo('MANIFEST.json')
    info.size = len(manifest)
    info.mtime = int(time.time())
    archive.addfile(info, io.BytesIO(manifest))
    for name, path in sorted(selected.items()):
        archive.add(path, arcname=name, recursive=False)
checked = 0
with tarfile.open(destination) as archive:
    embedded = json.load(archive.extractfile('MANIFEST.json'))['entries']
    for name, expected in embedded.items():
        stream = archive.extractfile(name)
        payload = stream.read()
        assert len(payload) == expected['bytes'], name
        assert hashlib.sha256(payload).hexdigest() == expected['sha256'], name
        checked += 1
    assert set(archive.getnames()) == {'MANIFEST.json', *embedded}
result = {'path': str(destination.relative_to(PROJECT / 'docs/experiments')), 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(), 'bytes': destination.stat().st_size, 'verified_entries': checked, 'frozen_python_modules_verified': 133, 'manifest_sha256': hashlib.sha256(manifest).hexdigest(), 'all_entries_decompressed_and_sha256_verified': True, 'report_note': 'The archived report precedes addition of this archive identity to avoid recursive self-hashing.'}
(ROOT / 'archive-result.json').write_text(json.dumps(result, indent=2) + '\n')
report['evidence'] = result
(PROJECT / 'docs/experiments/architecture-runtime-20261022-fourhour.json').write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
print(json.dumps(result))
