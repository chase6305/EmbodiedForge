"""Sustained real-worker startup cancellation and full-log failure validation.

Signals are injected at Popen entry, return and context registration. The fixture
waits for a real worker and reaps it even when assertions fail. /dev/full produces
real ENOSPC errors; run records are written separately on the normal filesystem.
Use an external supervisor to verify interpreter shutdown as well as this report.
"""

import argparse
import gc
import json
import logging
import os
import platform
import shutil
import signal
import subprocess
import sys
import threading
import time
from contextlib import contextmanager
from pathlib import Path

from embodiedforge.runtime import process
from embodiedforge.runtime.artifacts import write_json
from embodiedforge.runtime.hashing import file_sha256
from embodiedforge.runtime.records import (
    managed_run,
    read_run,
    run_identity,
    run_lifecycle,
)

SIGNALS = (signal.SIGINT, signal.SIGTERM, signal.SIGHUP)
STAGES = ("before", "after", "enter")


def resources():
    root = Path("/proc/self")
    status = dict(
        line.split(":", 1) for line in (root / "status").read_text().splitlines()
    )
    return {
        "rss_bytes": int(status["VmRSS"].split()[0]) * 1024,
        "threads": int(status["Threads"]),
        "fds": len(list((root / "fd").iterdir())),
    }


@contextmanager
def preserve_popen():
    original = process.subprocess.Popen
    try:
        yield original
    finally:
        process.subprocess.Popen = original


def startup(root, signum, stage, echo):
    root.mkdir()
    marker, ready = root / "child.pid", root / "ready"
    worker = """import json,os,signal,time
from pathlib import Path
Path('child.pid').write_text(str(os.getpid()))
Path('mask.json').write_text(json.dumps(sorted(signal.pthread_sigmask(signal.SIG_BLOCK,[]))))
def stop(*args):
    Path('cleaned').touch()
    raise SystemExit(0)
signal.signal(signal.SIGINT,stop)
Path('ready').touch()
time.sleep(30)
"""
    saved = {sig: signal.getsignal(sig) for sig in SIGNALS}
    mask = set(signal.pthread_sigmask(signal.SIG_BLOCK, []))
    caught = None
    try:
        with preserve_popen() as original:

            class Inject(original):
                def __init__(self, *args, **kwargs):
                    if stage == "before":
                        os.kill(os.getpid(), signum)
                    super().__init__(*args, **kwargs)
                    deadline = time.monotonic() + 3
                    while not ready.exists():
                        if time.monotonic() >= deadline:
                            raise AssertionError("worker did not become ready")
                        time.sleep(0.001)
                    if stage == "after":
                        os.kill(os.getpid(), signum)

                def __enter__(self):
                    result = super().__enter__()
                    if stage == "enter":
                        os.kill(os.getpid(), signum)
                    return result

            process.subprocess.Popen = Inject
            try:
                with managed_run(root, run_identity("probe", "startup-cancel")):
                    process.run_process(
                        [sys.executable, "-c", worker],
                        cwd=root,
                        env=os.environ.copy(),
                        log_path=root / "worker.log",
                        echo=echo,
                    )
            except KeyboardInterrupt as error:
                caught = error
        assert caught is not None, (stage, signum, echo)
        assert getattr(caught, "signum", signal.SIGINT) == signum
        assert (root / "cleaned").is_file()
        assert set(json.loads((root / "mask.json").read_text())) == mask
        record = read_run(root)
        assert record["status"] == "interrupted"
        assert json.loads((root / "run.json").read_text())["interrupt_signal"] == signum
        pid = int(marker.read_text())
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            pass
        else:
            raise AssertionError("cancelled worker survived startup")
        assert {sig: signal.getsignal(sig) for sig in SIGNALS} == saved
        assert threading.enumerate() == [threading.main_thread()]
    finally:
        if marker.exists():
            pid = int(marker.read_text())
            try:
                os.killpg(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            try:
                os.waitpid(pid, 0)
            except ChildProcessError:
                pass


def disk_full(root, outcome):
    root.mkdir()
    original = os.killpg
    caught = None

    def cancel(pid, sig):
        original(pid, sig)
        if outcome == "interrupt" and sig == signal.SIGTERM:
            os.kill(os.getpid(), signal.SIGTERM)

    process.os.killpg = cancel
    try:
        try:
            with managed_run(root, run_identity("probe", "disk-full")):
                process.run_process(
                    [
                        sys.executable,
                        "-c",
                        "import os,signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);"
                        "os.write(1,b'worker output\\n');"
                        + (
                            "time.sleep(30)"
                            if outcome in ("timeout", "interrupt")
                            else f"raise SystemExit({7 if outcome == 'failure' else 0})"
                        ),
                    ],
                    cwd=root,
                    env=os.environ.copy(),
                    log_path=Path("/dev/full"),
                    append_log=True,
                    timeout=0.15 if outcome == "timeout" else 3,
                )
        except BaseException as error:
            caught = error
    finally:
        process.os.killpg = original
    if outcome == "timeout":
        assert isinstance(caught, subprocess.TimeoutExpired), caught
        expected = "timed_out"
    elif outcome == "interrupt":
        assert isinstance(caught, process.ProcessInterrupted), caught
        assert caught.signum == signal.SIGTERM
        expected = "interrupted"
    else:
        assert isinstance(caught, RuntimeError), caught
        assert isinstance(caught.__cause__, OSError), caught
        assert caught.__cause__.errno == 28
        expected = "failed"
    assert read_run(root)["status"] == expected
    assert threading.enumerate() == [threading.main_thread()]


def finalization_failure(root, stage):
    root.mkdir()
    failure = OSError("injected finalization failure")
    record = {
        "status": "running",
        "run_contract": run_identity("probe", "finalization"),
    }

    def publish(current):
        if stage == "publish" and current["status"] == "complete":
            raise failure
        write_json(root / "run.json", current)

    def finalize(current):
        if stage == "finalize":
            raise failure

    caught = None
    try:
        with run_lifecycle(record, publish, finalize=finalize):
            pass
    except OSError as error:
        caught = error
    assert caught is failure
    assert read_run(root)["status"] == "failed"


def run_cycle(cycle):
    for signum in SIGNALS:
        for stage in STAGES:
            for echo in (False, True):
                startup(cycle / f"{signum}-{stage}-{echo}", signum, stage, echo)
    for outcome in ("success", "failure", "timeout", "interrupt"):
        disk_full(cycle / outcome, outcome)
    for stage in ("finalize", "publish"):
        finalization_failure(cycle / stage, stage)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--duration", type=float, default=3600)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--preload-core", action="store_true")
    parser.add_argument("--gc-threshold", type=int)
    args = parser.parse_args()
    if sys.platform != "linux" or not Path("/dev/full").exists():
        parser.error("Requires Linux /proc, POSIX signals and /dev/full")
    if not 0 < args.duration < float("inf"):
        parser.error("duration must be positive and finite")
    if args.gc_threshold is not None:
        if args.gc_threshold <= 0:
            parser.error("gc-threshold must be positive")
        gc.set_threshold(args.gc_threshold, args.gc_threshold, args.gc_threshold)
    if args.preload_core:
        import embodiedforge

        for name in embodiedforge.__all__:
            getattr(embodiedforge, name)
    # Each full-log close emits an expected secondary diagnostic. Unit tests
    # verify that diagnostic; retain bounded data during the sustained probe.
    logging.getLogger(process.__name__).addHandler(logging.NullHandler())
    logging.getLogger(process.__name__).propagate = False
    args.output = args.output.resolve()
    args.output.mkdir(parents=True)
    shutil.copyfile(__file__, args.output / "benchmark.py")
    began = time.monotonic()
    cycles = scenarios = 0
    samples = []
    with managed_run(
        args.output,
        run_identity("benchmark", "validate", "process-faults"),
        metadata={
            "python": sys.executable,
            "python_version": platform.python_version(),
            "benchmark_sha256": file_sha256(Path(__file__)),
            "process_sha256": file_sha256(Path(process.__file__)),
            "gc_threshold": gc.get_threshold(),
            "core_preloaded": args.preload_core,
        },
    ) as record:
        with (args.output / "samples.jsonl").open("x") as stream:
            initial = resources()
            while time.monotonic() - began < args.duration:
                cycle = args.output / "cycle"
                cycle.mkdir()
                if cycles % 2:
                    try:
                        raise ValueError("previous attempt already handled")
                    except ValueError:
                        run_cycle(cycle)
                else:
                    run_cycle(cycle)
                scenarios += len(SIGNALS) * len(STAGES) * 2 + 4 + 2
                shutil.rmtree(cycle)
                cycles += 1
                gc.collect()
                sample = {
                    "seconds": time.monotonic() - began,
                    "cycles": cycles,
                    "verified_scenarios": scenarios,
                    "resources": resources(),
                }
                stream.write(json.dumps(sample) + "\n")
                stream.flush()
                if not samples or sample["seconds"] - samples[-1]["seconds"] >= 30:
                    samples.append(sample)
                    print(json.dumps(sample), flush=True)
            final = resources()
        result = {
            "all_scenarios_passed": True,
            "cycles": cycles,
            "verified_scenarios": scenarios,
            "seconds": time.monotonic() - began,
            "initial_resources": initial,
            "final_resources": final,
            "samples": samples,
        }
        write_json(args.output / "summary.json", result)
        record.update(cycles=cycles, verified_scenarios=scenarios)
        print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
