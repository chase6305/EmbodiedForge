import datetime,json
from pathlib import Path
root=Path('/tmp/embodiedforge-fourhour-20261022')
names=('final-faults-py3120-debug-gdb', 'final-faults-py31214-core', 'final-faults-py3100-stdlib', 'final-lifecycle-py3120-core', 'final-faults-py3120-normal', 'final-faults-py31214-numpy252', 'final-recording-core', 'final-recording-go1', 'final-recording-h1')
report={'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'probes':{}}
for name in names:
 directory=root/name;item={};path=directory/'samples.jsonl'
 if path.is_file():
  with path.open('rb') as stream:
   stream.seek(0,2);size=stream.tell();stream.seek(max(0,size-16384));lines=stream.read().splitlines()
  for line in reversed(lines):
   try:sample=json.loads(line)
   except (ValueError,UnicodeError):continue
   item.update(seconds=round(sample['seconds'],1),scenarios=sample.get('verified_scenarios'),segment=sample.get('segment'),**sample.get('resources',{}));break
 path=directory/'run.json'
 if path.is_file():
  value=json.loads(path.read_text());item['status']=value['status']
  if 'error' in value:item['error']=value['error']
 for suffix in ('.exit.json','.gdb-exit.json'):
  path=root/(name+suffix)
  if path.is_file():
   value=json.loads(path.read_text());item['exitcode']=value.get('returncode',value.get('inferior_exitcode'));item['exit_verified']=value['interpreter_exit_verified']
 if item:report['probes'][name]=item
(root/'live-status.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
