import argparse
import time
from pathlib import Path

import torch

from embodiedforge import Config
from embodiedforge import training

parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--ready', type=Path, required=True)
parser.add_argument('--seed', type=int, required=True)
args = parser.parse_args()
torch.set_num_threads(1)
publish = training.publish_checkpoint


def pause_after_commit(root, checkpoint, optimizer, metadata):
    publish(root, checkpoint, optimizer, metadata)
    if checkpoint['updates'] == 1:
        args.ready.touch()
        while True:
            time.sleep(.1)


training.publish_checkpoint = pause_after_commit
training.train_ppo(
    Config(task='hold', num_envs=4, seed=args.seed, max_steps=5),
    training.PPOConfig(updates=30, rollout_steps=8, epochs=2, minibatch_size=16, seed=args.seed),
    args.output,
)
