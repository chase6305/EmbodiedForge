import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path('/tmp/embodiedforge-fourhour-20261022')
TARGET = Path('/home/ubuntu/workspace/chase/EmbodiedForge/docs/experiments/assets')
NAMES = (
    ('final-faults-py3120-debug-gdb', '3.12.0 debug / GC 10'),
    ('final-faults-py3120-normal', '3.12.0 / GC 10'),
    ('final-faults-py31214-core', '3.12.14 / NumPy 2.4.1'),
    ('final-faults-py31214-numpy252', '3.12.14 / NumPy 2.5.2 / GC 10'),
    ('final-faults-py3100-stdlib', '3.10.0 stdlib'),
    ('final-lifecycle-py3120-core', '3.12.0 lifecycle control'),
)


def samples(name):
    path = ROOT / name / 'samples.jsonl'
    values = [json.loads(line) for line in path.read_text().splitlines()]
    stride = max(1, len(values) // 600)
    return values[::stride] + ([values[-1]] if (len(values) - 1) % stride else [])


plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'svg.fonttype': 'none'})
fig, axes = plt.subplots(2, 3, figsize=(15, 8), constrained_layout=True)
colors = plt.get_cmap('tab10').colors
for index, (name, label) in enumerate(NAMES):
    data = samples(name)
    x = [row['seconds'] / 3600 for row in data]
    initial = data[0]['resources']['rss_bytes']
    axes[0, 0].plot(x, [(row['resources']['rss_bytes'] - initial) / 2**20 for row in data], label=label, color=colors[index], linewidth=1.4)
    axes[0, 1].plot(x, [row['resources']['fds'] for row in data], color=colors[index], linewidth=1.3)
    axes[0, 2].plot(x, [row['resources']['threads'] for row in data], color=colors[index], linewidth=1.3)
    axes[1, 1].plot(x, [row['verified_scenarios'] / 1000 for row in data], color=colors[index], linewidth=1.3)
axes[0, 0].set(title='Process probes: RSS change after first cycle', ylabel='MiB change')
axes[0, 0].legend(fontsize=7, loc='best')
axes[0, 1].set(title='Process probes: open file descriptors', ylabel='Descriptors', ylim=(0, 8))
axes[0, 2].set(title='Process probes: native OS threads', ylabel='Threads', ylim=(0, 36))
axes[1, 1].set(title='Verified process failure / lifecycle scenarios', ylabel='Scenarios (thousands)')
for task, color in zip(('core', 'go1', 'h1'), ('#2563eb', '#16a34a', '#dc2626')):
    data = samples('final-recording-' + task)
    initial = data[0]['resources']['rss_bytes']
    axes[1, 0].plot([row['seconds'] / 3600 for row in data], [(row['resources']['rss_bytes'] - initial) / 2**20 for row in data], label=task, color=color, linewidth=1.4)
axes[1, 0].set(title='Paired recording: RSS change after first segment', ylabel='MiB change')
axes[1, 0].legend(fontsize=8)
for ax in (axes[0, 0], axes[0, 1], axes[0, 2], axes[1, 0], axes[1, 1]):
    ax.set_xlabel('Elapsed hours')
    ax.grid(alpha=.18)
overhead = json.loads((ROOT / 'launch-overhead.json').read_text())['summary']
x = np.arange(2)
for offset, side, color in ((-.18, 'baseline', '#94a3b8'), (.18, 'candidate', '#2563eb')):
    values = [overhead[mode][side]['median_ms'] for mode in ('quiet', 'captured')]
    bars = axes[1, 2].bar(x + offset, values, width=.35, label=side, color=color)
    axes[1, 2].bar_label(bars, fmt='%.3f', fontsize=8, padding=3)
axes[1, 2].set(title='Job launch median: /bin/true, paired trials', ylabel='Milliseconds', xticks=x, xticklabels=['Direct log', 'Captured log'], ylim=(0, 1.95))
axes[1, 2].legend(fontsize=8)
fig.suptitle('EmbodiedForge runtime continuation: fault handling and sustained validation', fontsize=15, fontweight='bold')
fig.supxlabel('Same frozen production source. RSS includes allocators; samples do not establish strict memory bounds. Launch timings measured under concurrent probe load.', fontsize=8)
TARGET.mkdir(parents=True, exist_ok=True)
stem = TARGET / 'architecture-runtime-20261022-fourhour-validation'
fig.savefig(stem.with_suffix('.svg'))
fig.savefig(stem.with_suffix('.png'), dpi=150)
print(json.dumps({'svg': str(stem.with_suffix('.svg')), 'png': str(stem.with_suffix('.png'))}))
