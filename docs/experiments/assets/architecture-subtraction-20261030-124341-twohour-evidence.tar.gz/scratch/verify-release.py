"""Inspect source/wheel contents and exercise installed host-safe entry points."""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import zipfile
from pathlib import Path

root = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
work = Path('/tmp/embodiedforge-subtraction-20261030-124341-twohour')
artifacts = {}
for path in (work / 'distribution').iterdir():
    if path.suffix not in {'.whl', '.gz'}:
        continue
    artifacts[path.name] = {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
wheel = work / 'distribution/embodiedforge-0.1.0-py3-none-any.whl'
archive = work / 'distribution/embodiedforge-0.1.0.tar.gz'
modules = {p.relative_to(root / 'src').as_posix(): p for p in (root / 'src/embodiedforge').rglob('*.py')}
resources = {p.relative_to(root / 'src').as_posix(): p for p in (root / 'src/embodiedforge').rglob('*')
             if p.is_file() and p.suffix not in {'.py', '.pyc'} and '__pycache__' not in p.parts}
with zipfile.ZipFile(wheel) as bundle:
    assert {n for n in bundle.namelist() if n.startswith('embodiedforge/') and n.endswith('.py')} == modules.keys()
    for name, path in {**modules, **resources}.items():
        assert bundle.read(name) == path.read_bytes(), name
release = work / 'source-release'
release.mkdir()
with tarfile.open(archive) as bundle:
    assert not any('/docs/experiments/' in item.name and item.name.endswith('.tar.gz') for item in bundle)
    bundle.extractall(release)
source = release / 'embodiedforge-0.1.0'
for name, path in {**modules, **resources}.items():
    assert (source / 'src' / name).read_bytes() == path.read_bytes(), name
installed = work / 'installed-wheel'
with (work / 'wheel-install.log').open('wb') as log:
    subprocess.run([shutil.which('uv'), 'pip', 'install', '--target', str(installed), '--no-deps', str(wheel)],
                   stdout=log, stderr=subprocess.STDOUT, timeout=120, check=True)
probe = """import sys
sys.path.insert(0, sys.argv[1])
import embodiedforge
from embodiedforge import microduck
from embodiedforge.workflows import supermimic_contacts
assert str(embodiedforge.__file__).startswith(sys.argv[1])
assert not {'torch', 'numpy', 'mujoco', 'mjlab'} & sys.modules.keys()
"""
subprocess.run([sys.executable, '-I', '-S', '-c', probe, str(installed)], cwd=work, timeout=30, check=True)
with (work / 'source-release-targets.log').open('wb') as log:
    subprocess.run(['/home/ubuntu/miniconda3/envs/xvla2/bin/python', '-m', 'pytest', '-q',
                    'tests/test_dataset_reads.py', 'tests/test_rollout.py', 'tests/test_archive_integrity.py', 'tests/test_documentation.py',
                    '--tb=short', '--junitxml=' + str(work / 'source-release-targets.xml')],
                   cwd=source, env={**os.environ, 'PYTHONPATH': 'src', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1'},
                   stdout=log, stderr=subprocess.STDOUT, timeout=90, check=True)
result = {'status': 'passed', 'artifacts': artifacts, 'exact_python_modules': len(modules),
          'exact_resources': len(resources), 'historical_evidence_tar_members': 0,
          'installed_host_imports_without_site_packages': True,
          'source_release_root': str(source), 'installed_root': str(installed),
          'target_tests': str(work / 'source-release-targets.xml')}
(work / 'release-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
