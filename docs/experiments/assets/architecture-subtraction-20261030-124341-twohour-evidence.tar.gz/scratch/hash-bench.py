"""Initial-observation hashing only: identical bytes, timing and allocation."""
import argparse
import ast
import hashlib
import json
import statistics
import time
import tracemalloc
from pathlib import Path

import numpy as np

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
tree = ast.parse(args.source.read_text())
function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'run_episode_batch')
start = next(i for i, n in enumerate(function.body) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'digest' for t in n.targets))
body = function.body[start:start + 2] + [ast.Return(value=ast.Call(func=ast.Attribute(value=ast.Name(id='digest', ctx=ast.Load()), attr='hexdigest', ctx=ast.Load()), args=[], keywords=[]))]
probe = ast.FunctionDef(name='hash_initial', args=ast.arguments(posonlyargs=[], args=[ast.arg(arg='observation')], kwonlyargs=[], kw_defaults=[], defaults=[]), body=body, decorator_list=[])
namespace = {'np': np, 'hashlib': hashlib}
exec(compile(ast.fix_missing_locations(ast.Module(body=[probe], type_ignores=[])), str(args.source), 'exec'), namespace)
hash_initial = namespace['hash_initial']
image = np.full((16, 4, 512, 512, 3), 37, dtype=np.uint8)
image.flags.writeable = False
observation = {'env_id': np.arange(16), 'rgb': image}
expected = hashlib.sha256()
for name, value in sorted(observation.items()):
    expected.update(f'{name}:{value.dtype}:{value.shape}:'.encode())
    expected.update(value.tobytes())
reference = expected.hexdigest()
assert hash_initial(observation) == reference
times = []
for _ in range(11):
    started = time.perf_counter()
    assert hash_initial(observation) == reference
    times.append(time.perf_counter() - started)
tracemalloc.start()
assert hash_initial(observation) == reference
current, peak = tracemalloc.get_traced_memory()
tracemalloc.stop()
result = {'status': 'measured', 'scope': __doc__, 'source': str(args.source),
          'source_sha256': hashlib.sha256(args.source.read_bytes()).hexdigest(), 'numpy': np.__version__,
          'image_bytes': image.nbytes, 'seconds': times, 'median_seconds': statistics.median(times),
          'peak_traced_bytes': peak, 'sha256': reference,
          'limits': 'Extracted hash statements over an immutable 48 MiB contiguous image batch. Excludes rendering, inference and training; traced peak is not RSS.'}
args.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
