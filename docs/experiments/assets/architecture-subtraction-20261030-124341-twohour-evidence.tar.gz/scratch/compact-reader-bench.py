"""Real compact-NPZ decode/validation/owned-copy cost; fixture construction excluded."""
import argparse
import gc
import hashlib
import json
import statistics
import time
import tracemalloc
from pathlib import Path

import numpy as np

from embodiedforge import Config, VectorEnv
from embodiedforge.data import EpisodeReadOptions, EpisodeRecorder, read_episodes
from embodiedforge.tasks import ReachTask

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--dataset', type=Path, required=True)
parser.add_argument('--prepare', action='store_true')
parser.add_argument('--output', type=Path)
parser.add_argument('--repeats', type=int, default=5)
args = parser.parse_args()


class TimeoutTask(ReachTask):
    def evaluate(self, state, actions, previous):
        count = len(actions)
        return np.ones(count, dtype=np.float32), np.zeros(count, bool), np.zeros(count, bool)


if args.prepare:
    with VectorEnv(Config(num_envs=1, max_steps=64, seed=391), task=TimeoutTask()) as env:
        with EpisodeRecorder(args.dataset, env, episode_format='compact', verify_archive=True) as writer:
            observation = env.observe()
            for field in range(4):
                observation['camera_' + str(field)] = np.full((1, 256, 256, 3), field, dtype=np.uint8)
            for step in range(64):
                result = env.step(np.zeros((1, 2), dtype=np.float32))
                for field in range(4):
                    result.observation['camera_' + str(field)] = np.full((1, 256, 256, 3), (step + field + 1) % 256, dtype=np.uint8)
                writer.append(observation, result)
                observation = result.observation
    print(json.dumps({'dataset': str(args.dataset), 'steps': 64, 'camera_fields': 4, 'shape': [256, 256, 3], 'format': 'compact'}))
    raise SystemExit


def read(verify=False):
    episode, = read_episodes(args.dataset, options=EpisodeReadOptions(verify_archive=verify))
    return episode


def fingerprint(episode):
    digest = hashlib.sha256()
    for name, value in episode.items():
        digest.update(f'{name}:{value.shape}:{value.dtype}:'.encode())
        digest.update(value.data)
    return digest.hexdigest()


samples = []
for verify in [False, True]:
    warm = read(verify)
    expected = fingerprint(warm)
    payload_bytes = sum(value.nbytes for value in warm.values())
    assert all(value.flags.owndata and value.flags.c_contiguous for value in warm.values())
    for name in [name[4:] for name in warm if name.startswith('obs/')]:
        assert not np.shares_memory(warm['obs/' + name], warm['next/' + name])
    del warm
    times = []
    for _ in range(args.repeats):
        gc.collect()
        began = time.perf_counter()
        episode = read(verify)
        times.append(time.perf_counter() - began)
        assert fingerprint(episode) == expected
        del episode
    gc.collect()
    tracemalloc.start()
    episode = read(verify)
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    assert fingerprint(episode) == expected
    del episode
    samples.append({'verify_archive': verify, 'seconds': times, 'median_seconds': statistics.median(times),
                    'retained_traced_bytes': current, 'peak_traced_bytes': peak,
                    'output_array_bytes': payload_bytes, 'sha256': expected})
result = {'status': 'measured', 'scope': __doc__, 'numpy': np.__version__, 'samples': samples,
          'fixture': {'steps': 64, 'camera_fields': 4, 'camera_shape': [256, 256, 3]},
          'limits': 'Traced Python/NumPy allocation peak, not process RSS or training memory. Timing and tracing run separately.'}
args.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
