"""Publish compact source/test/evidence snapshots without weights or mesh copies."""
import hashlib
import io
import json
import tarfile
from pathlib import Path

root = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
work = Path('/tmp/embodiedforge-subtraction-20261030-124341-twohour')
stem = 'architecture-subtraction-20261030-124341-twohour'
state = json.loads((work / 'state.json').read_text())
assert state['status'] == 'complete' and state['elapsed_seconds'] >= 7200
target = root / 'docs/experiments/assets' / (stem + '-evidence.tar.gz')
assert not target.exists()
files = {}


def include(path, name):
    assert path.is_file() and not path.is_symlink(), str(path)
    assert name not in files and not name.startswith('/') and '..' not in Path(name).parts
    files[name] = path


for path in work.iterdir():
    if path.is_file() and path.suffix in {'.py', '.json', '.jsonl', '.xml', '.log', '.patch'}:
        include(path, 'scratch/' + path.name)
for path in (work / 'baseline').rglob('*'):
    if path.is_file() and not {'__pycache__', '.pytest_cache'} & set(path.parts) and path.suffix.lower() != '.stl':
        include(path, 'baseline/' + path.relative_to(work / 'baseline').as_posix())
for name in state['changed_files_this_round']:
    include(root / name, 'final/' + name)
for directory in work.iterdir():
    if directory.is_dir() and directory.name.startswith('workflow'):
        for path in directory.iterdir():
            if path.is_file() and path.suffix in {'.json', '.jsonl', '.log'}:
                include(path, 'scratch/' + path.relative_to(work).as_posix())
manifest = {'scope': 'Baseline source/tests, four final changed files, scripts, assertions, unit logs and allocation measurements and two supervised 90-minute recording/reading/evaluation comparisons.',
            'excluded': ['Model/checkpoint weights and reference datasets; recorded SHA256 retained',
                         'Unchanged STL meshes; baseline file identities retained',
                         'Distribution binaries/install/staging trees; exact content checks and SHA256 retained',
                         'Previous historical evidence archives, pytest caches and Python bytecode'], 'files': {}}
with tarfile.open(target, 'w:gz', compresslevel=6) as bundle:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        manifest['files'][name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        item = tarfile.TarInfo(name)
        item.size, item.mode = len(data), 0o644
        bundle.addfile(item, io.BytesIO(data))
    data = (json.dumps(manifest, indent=2) + '\n').encode()
    item = tarfile.TarInfo('manifest.json')
    item.size, item.mode = len(data), 0o644
    bundle.addfile(item, io.BytesIO(data))
with tarfile.open(target) as bundle:
    actual_manifest = json.load(bundle.extractfile('manifest.json'))
    assert actual_manifest == manifest
    assert set(bundle.getnames()) == set(manifest['files']) | {'manifest.json'}
    for name, expected in manifest['files'].items():
        data = bundle.extractfile(name).read()
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256'], name
state['evidence_bundle'] = {'path': target.relative_to(root).as_posix(), 'bytes': target.stat().st_size,
                            'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
                            'verified_members': len(manifest['files']) + 1,
                            'report_snapshot': 'scratch/state.json',
                            'snapshot_note': 'Frozen before inserting the bundle checksum, to avoid self-reference.'}
for path in [work / 'state.json', root / 'runs' / stem / 'optimization.json', root / 'docs/experiments' / (stem + '.json')]:
    path.write_text(json.dumps(state, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
print(json.dumps(state['evidence_bundle'], indent=2))
