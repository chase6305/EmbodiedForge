"""Verify recorder coverage against actual simulator time, including bad clocks."""

import numpy as np
import pytest

from embodiedforge.workflows.supermimic_contacts import validate_substep_clock


def test_device_float32_clock_accumulation_is_accepted():
    # The actual device accumulates this clock, rather than multiplying a step ID.
    time = np.float32(0)
    times = []
    for _ in range(2280):
        time += np.float32(0.005)
        times.append(time)
    actual = validate_substep_clock(times, 0.005)
    assert actual["actual_clock_verified"]
    assert actual["actual_last_time_s"] == float(time)
    assert actual["actual_max_step_error_s"] < 1e-6


@pytest.mark.parametrize(
    "times", [[0.005, 0.005], [0.005, 0.015], [0.005, 0.0], [0.005, float("nan")], []]
)
def test_duplicate_skipped_reversed_or_nonfinite_physics_clock_fails(times):
    with pytest.raises(ValueError, match="clock|timestamps"):
        validate_substep_clock(times, 0.005)
