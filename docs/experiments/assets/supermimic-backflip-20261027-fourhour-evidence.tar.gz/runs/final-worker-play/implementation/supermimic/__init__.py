"""Pinned independent SuperMimic with mjlab physics adapter."""
