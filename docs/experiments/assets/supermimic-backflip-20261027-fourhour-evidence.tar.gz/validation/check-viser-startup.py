"""Bounded local viewer server and real-policy physics; no browser-render claim."""
import json,socket,sys,urllib.request
from pathlib import Path
from types import SimpleNamespace
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');sys.path.insert(0,str(repo/'src'));sys.path.insert(0,str(repo/'runs/supermimic-backflip-20261027-fourhour/public-evaluation-control/implementation'))
import torch,viser
from mjlab.viewer import ViserPlayViewer
from supermimic.env import TrackingSim,make_sim
from embodiedforge.workflows.supermimic_reference_evaluate import components
from embodiedforge.workflows.supermimic_reference_mjlab import launch_simulation
from embodiedforge.workflows.supermimic_reference_play import build_viewer_policy
torch.set_num_threads(1);checkpoint=repo/'runs/supermimic-backflip-20261027-fourhour/reference-main/logs/ckpt_006000.pt';saved,args,motion,mdp,policy=components({'checkpoint':str(checkpoint)},repo/'runs/supermimic/tasks/backflip/data/backflip.csv');cfg=make_sim('cuda:0',SimpleNamespace(seed=0))
with socket.socket() as selected:selected.bind(('127.0.0.1',0));port=selected.getsockname()[1]
with launch_simulation(cfg,args):
 backend=TrackingSim(cfg,1,motion,mdp,eval_mode=True);wrapped,act=build_viewer_policy(backend,policy,args);server=viser.ViserServer(host='127.0.0.1',port=port,label='Bounded SuperMimic validation')
 try:
  actual_port=server.get_port()
  with urllib.request.urlopen('http://127.0.0.1:'+str(actual_port),timeout=10) as response:status=response.status;content=response.read()
  assert status==200 and b'<html' in content.lower()
  viewer=ViserPlayViewer(wrapped,act,viser_server=server);viewer.run(num_steps=20,catch_sigint=False);assert viewer._last_error is None,viewer._last_error;assert viewer._step_count>=20
 finally:server.stop()
proof={'status':'complete','http_status':status,'served_html_bytes':len(content),'actual_policy_control_steps':viewer._step_count,'viewer_error':viewer._last_error,'owned_server_stopped':True,'scope':'LocalHTTPstartup and standardViser20step real-policy loop; browser-sideWebGLrender/interaction was not tested.'};r=Path(__file__).parent;(r/'viser-startup-control.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
