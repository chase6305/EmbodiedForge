import json,sys
from pathlib import Path
from types import SimpleNamespace
import torch
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');sys.path.insert(0,str(repo/'src'));sys.path.insert(0,str(repo/'runs/supermimic-backflip-20261027-fourhour/probe-retry/implementation'))
from supermimic.rotations import so3_exp,mat_to_quat
from embodiedforge.workflows.supermimic_reference_mjlab import read_state,write_state,step_physics
torch.manual_seed(4);n=7;origins=torch.randn(n,3);p=torch.randn(n,3);R=so3_exp(torch.randn(n,3));v=torch.randn(n,3);w=torch.randn(n,3);q=torch.randn(n,29);qd=torch.randn(n,29);warm=torch.ones(n,35);before=torch.cat((p+origins,mat_to_quat(R),q),-1);vel=torch.cat((v,(R.transpose(-1,-2)@w.unsqueeze(-1)).squeeze(-1),qd),-1)
class Sim:
 def __init__(self):self.data=SimpleNamespace(qpos=before.clone(),qvel=vel.clone(),qacc_warmstart=warm);self.forward_calls=0
 def forward(self):self.forward_calls+=1
class Reset:
 def reset(self,*args,**kwargs):pass
class Raw:
 def __init__(self):self.action_manager=Reset();self.actions=None
 def step(self,actions):self.actions=actions.clone()
owner=SimpleNamespace(sim=Sim(),origins=origins,robot=Reset(),raw=Raw());actual=read_state(owner)
for a,b in zip(actual,(p,R,v,w,q,qd),strict=True):assert torch.allclose(a,b,atol=1e-5)
ids=torch.tensor([1,3,5]);newp=p[ids]+.4;newR=so3_exp(torch.randn(3,3));newv=v[ids]-.3;neww=w[ids]+.7
write_state(owner,ids,newp,newR,newv,neww,q[ids],qd[ids]);after=read_state(owner)
for a,b in zip((x[ids] for x in after),(newp,newR,newv,neww,q[ids],qd[ids]),strict=True):assert torch.allclose(a,b,atol=1e-5)
assert torch.equal(owner.sim.data.qpos[[0,2,4,6]],before[[0,2,4,6]]) and torch.count_nonzero(warm[ids])==0
owner.default_q=torch.randn(29);owner.xi=torch.randn(n,33)*.01;owner.alpha=torch.ones(29)*.3;owner.actual_scale=torch.ones(n,29)*.3;actions=torch.randn(n,29);step_physics(owner,actions);assert torch.allclose(owner.raw.actions*.3+owner.default_q,owner.default_q+owner.xi[:,1:30]+owner.alpha*actions)
proof={'status':'complete','cpu_only':True,'world_to_body_angular_velocity_roundtrip':True,'environment_origin_roundtrip':True,'selected_reset_leaves_other_states_unchanged':True,'warmstart_reset':True,'upstream_actuator_bias_and_action_scaling':True,'cases':7};r=Path(__file__).parent;(r/'state-bridge-control.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
