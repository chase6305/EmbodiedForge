"""Offline actual-airborne geometry, using fixed primary-source thresholds."""
import argparse,json,sys
from pathlib import Path
import mujoco,numpy as np
from scipy.spatial.transform import Rotation
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge')
p=argparse.ArgumentParser();p.add_argument('--evaluation',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--model',type=Path);args=p.parse_args()
from mjlab.asset_zoo.robots.unitree_g1.g1_constants import G1_XML
with np.load(args.evaluation/'backflip-rollout.npz',allow_pickle=False) as d:state=d['state'].astype(np.float64);times=d['time_s'].copy()
with np.load(repo/'runs/supermimic/tasks/backflip/data/eval/backflip.npz',allow_pickle=False) as d:qref=d['joint_pos'].astype(np.float64);body_names=list(map(str,d['body_names']));ref_feet=d['body_pos_w'][:,[body_names.index('left_ankle_roll_link'),body_names.index('right_ankle_roll_link')]].astype(np.float64)
assert state.shape[1]==71 and np.isfinite(state).all() and np.allclose(times,np.arange(len(state))/50)
if args.model is not None:
 model=mujoco.MjModel.from_binary_path(str(args.model))
else:
 spec=mujoco.MjSpec.from_file(str(G1_XML));spec.worldbody.add_geom(name='ef_geometry_floor',type=mujoco.mjtGeom.mjGEOM_PLANE,size=[20,20,.1]);model=spec.compile()
assert model.nq==36 and model.nv==35
planes=np.flatnonzero(model.geom_type==mujoco.mjtGeom.mjGEOM_PLANE);assert len(planes)==1;floor=int(planes[0]);data=mujoco.MjData(model)
def body_id(name):
 ids=[i for i in range(model.nbody) if model.body(i).name.endswith(name)];assert len(ids)==1;return ids[0]
feet=[set(np.flatnonzero(model.geom_bodyid==body_id(name)).tolist()) for name in ('left_ankle_roll_link','right_ankle_roll_link')];ankle_ids=[int(model.geom_bodyid[next(iter(group))]) for group in feet];allfeet=feet[0]|feet[1];air=[];bad=[];ankles=[];gaps=[]

for row in state:
 data.qpos[:]=row[:36];data.qvel[:]=row[36:];mujoco.mj_forward(model,data);gap=[min(mujoco.mj_geomDistance(model,data,g,floor,10,None) for g in group) for group in feet];contact=any(c.dist<0 and ((int(c.geom[0])==floor and int(c.geom[1]) not in allfeet) or (int(c.geom[1])==floor and int(c.geom[0]) not in allfeet)) for c in data.contact);gaps.append(gap);air.append(min(gap)>.03);bad.append(contact);ankles.append(float(np.linalg.norm(data.xpos[ankle_ids[0]]-data.xpos[ankle_ids[1]])))
m=Rotation.from_quat(state[:,[4,5,6,3]]).as_matrix();phase=np.unwrap(np.arctan2(-(m[:,:,0]@m[0,:,2]),m[:,:,0]@m[0,:,0]));up=m[:,2,2];n=min(321,len(state));fullair=np.array(air[:n])&~np.array(bad[:n]);edge=np.diff(np.r_[False,fullair,False].astype(int));starts=np.flatnonzero(edge==1);ends=np.flatnonzero(edge==-1)
result={'status':'complete','source':'Saved actual policy states only; CPU FK/geometry without new physical integration or retiming','scope':'50Hzgeometry and dynamic-airborne-window thresholds ported from fixed reference; no200Hzforce data in this offline analysis; not strictV14equivalence','actual_states':len(state),'reference_motion_states':321,'nonfoot_floor_geometry_frames':int(sum(bad)),'hold_nonfoot_geometry_frames':int(sum(bad[321:])),'whole_reference_sagittal_rotation_deg':float(np.degrees(phase[n-1]-phase[0])),'fully_airborne_seconds':float(fullair.sum()/50),'has_airborne_segment':bool(len(starts)),'longest_airborne_window':None,'aerial_rotation_deg':None,'aerial_axis_min_alignment':None,'aerial_hip_knee_rmse_deg':None,'aerial_max_ankle_separation_m':None,'same_window_reference_max_ankle_separation_m':None}
if len(starts):
 longest=int(np.argmax(ends-starts));a,z=int(starts[longest]),int(ends[longest]);idx=[0,1,2,3,6,7,8,9];rmse=float(np.degrees(np.sqrt(np.mean((state[a:z,7:36][:,idx]-qref[a:z,idx])**2))));sep=max(ankles[a:z]);refsep=float(np.max(np.linalg.norm(ref_feet[a:z,0]-ref_feet[a:z,1],axis=1)));alignment=float((m[a:z,:,1]@m[0,:,1]).min());rot=float(np.degrees(phase[z-1]-phase[a]));result.update(longest_airborne_window=[a,z],aerial_rotation_deg=rot,aerial_axis_min_alignment=alignment,aerial_hip_knee_rmse_deg=rmse,aerial_max_ankle_separation_m=sep,same_window_reference_max_ankle_separation_m=refsep)
result.update(model_source=str(args.model) if args.model is not None else 'Bare pinned G1 geometry plus a plane',minimum_up_reference_window=float(up[:n].min()),minimum_up_airborne=float(up[:n][fullair].min()) if fullair.any() else None,initial_root_speed=float(np.linalg.norm(state[0,36:39])),initial_joint_speed=float(np.linalg.norm(state[0,42:])),relative_pitch_rotation_rad=float((Rotation.from_quat(state[:-1,[4,5,6,3]]).inv()*Rotation.from_quat(state[1:,[4,5,6,3]])).as_rotvec()[:320,1].sum()),last25_min_root_height_m=float(state[-25:,2].min()),last25_min_up=float(up[-25:].min()))
result['geometry_quality_checks']={'full_backward_turn':bool(-370<=result['whole_reference_sagittal_rotation_deg']<=-350 and len(state)>=321),'airborne_rotation':bool(result['aerial_rotation_deg'] is not None and result['aerial_rotation_deg']<=-250 and result['aerial_axis_min_alignment']>.8),'dynamic_leg_posture':bool(result['aerial_hip_knee_rmse_deg'] is not None and result['aerial_hip_knee_rmse_deg']<25 and result['aerial_max_ankle_separation_m']<=result['same_window_reference_max_ankle_separation_m']+.15),'no_nonfoot_geometry':not any(bad)};result['all_geometry_checks_passed']=all(result['geometry_quality_checks'].values());args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
