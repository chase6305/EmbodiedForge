import datetime,hashlib,json,subprocess
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;job=repo/'runs/supermimic-backflip-20261027-fourhour/reference-seed138';launch=json.loads((job/'launcher.json').read_text())
for name,digest in launch['launcher_sources'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
worker=json.loads((job/'result.json').read_text()) if (job/'result.json').is_file() else {}
if 'motion_input_snapshot' in worker:assert hashlib.sha256((job/'inputs/backflip.csv').read_bytes()).hexdigest()==worker['motion_input_snapshot']['private_csv_sha256']
lines=(job/'command.log').read_text(errors='replace').splitlines() if (job/'command.log').exists() else [];progress=next((line for line in reversed(lines) if line.startswith('it ')),None);cuda=subprocess.run(['nvidia-smi','--query-gpu=memory.used,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10)
row={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':worker.get('status','preparing'),'progress':progress,'last_log_line':lines[-1][:300] if lines else None,'source_files_verified':len(launch['launcher_sources']),'private_csv_verified':'motion_input_snapshot' in worker,'gpu_used_free_MiB_util_percent':cuda.stdout.strip() if cuda.returncode==0 else None,'policy_budget_started':any('POLICY_BUDGET_START' in line for line in lines)}
with (r/'reference-seed138-health.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
(r/'latest-health.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row))
