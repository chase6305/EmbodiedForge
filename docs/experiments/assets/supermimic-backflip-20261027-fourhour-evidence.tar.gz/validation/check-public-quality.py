import json,sys
from pathlib import Path
import numpy as np
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');sys.path.insert(0,str(repo/'src'));r=Path(__file__).parent;folder=repo/'runs/supermimic-backflip-20261027-fourhour/intermediate-6000-force';record=json.loads((folder/'result.json').read_text())
from embodiedforge.workflows.supermimic_backflip_quality import airborne_geometry,combine_quality
with np.load(folder/'backflip-rollout.npz',allow_pickle=False) as d:state=d['state'].copy()
geometry=airborne_geometry(state,repo/'runs/supermimic/tasks/backflip/data/eval/backflip.npz',folder/'physics-model.mjb');independent=json.loads((r/'intermediate-6000-force-geometry.json').read_text())
for name in ('whole_reference_sagittal_rotation_deg','aerial_rotation_deg','aerial_axis_min_alignment','aerial_hip_knee_rmse_deg','aerial_max_ankle_separation_m','same_window_reference_max_ankle_separation_m','fully_airborne_seconds','relative_pitch_rotation_rad'):assert abs(geometry[name]-independent[name])<1e-9,(name,geometry[name],independent[name])
quality=combine_quality(complete=record['complete'],initial_velocity=record['initial_velocity_max_abs'],native_return=record['native320step_zero_padded_return'],control_steps=record['executed_control_steps'],state_samples=record['actual_states'],diagnostics=record['diagnostics'],geometry=geometry,forces=record['contact_force_audit']);assert quality['ported_quality_passed'] is True
proof={'status':'complete','public_geometry_matches_independent_analysis':True,'geometry':geometry,'quality':quality,'scope':'Offline reanalysis of the actual6000step force-audited policy rollout; intermediate only, not final checkpoint selection.'};(r/'public-quality-control.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'status':'complete','public_geometry_matches_independent_analysis':True,'ported_quality_passed':quality['ported_quality_passed'],'initial_pose_max_error':geometry['initial_pose_max_abs_error']}))
