"""Actual570step policy rollout plus2280GPU-solved force samples; no resets."""
import argparse,hashlib,json,sys
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');sys.path.insert(0,str(repo/'src'))
p=argparse.ArgumentParser();p.add_argument('--recipe',choices=['reference','cuboi'],required=True);p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args();out=args.output.resolve();out.mkdir(exist_ok=False);checkpoint=args.checkpoint.resolve();sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest();checkpoint_sha=sha(checkpoint)
from embodiedforge.workflows import supermimic_backflip as backflip
from embodiedforge.workflows.supermimic_contacts import ContactRecorder
from embodiedforge.runtime.provenance import snapshot_implementation,validate_snapshot
from embodiedforge.workflows.supermimic_catalog import REFERENCES
from embodiedforge.supermimic import source_identity
from embodiedforge.runtime.hashing import snapshot_file_hashes
paths=['src/embodiedforge/workflows/supermimic_backflip.py','src/embodiedforge/workflows/supermimic_contacts.py','src/embodiedforge/workflows/supermimic_reference.py','src/embodiedforge/workflows/supermimic_reference_mjlab.py','src/embodiedforge/workflows/supermimic_reference_worker.py'];guards={name:sha(repo/name) for name in paths};guards[str(Path(__file__).resolve())]=sha(__file__)
data=backflip.task_directory(repo)/'data';provenance=backflip.prepared(data)
if args.recipe=='reference':
 from embodiedforge.workflows.supermimic_reference import freeze_reference
 implementation=freeze_reference(repo,out);manifest=implementation['adapted_manifest']
else:
 root=repo/'.cache/external/supermimic-reproduced';ref=REFERENCES['cuboi-reproduced'];source=source_identity(root,ref['revision'],ref['source_files']+[str(f.relative_to(root)) for f in (root/'src/supermimic').rglob('*.py') if '__pycache__' not in f.parts]);manifest=snapshot_implementation(root/'src/supermimic',out/'implementation/supermimic');implementation={'source':source,'adapted_manifest':manifest}
sys.path.insert(0,str(out/'implementation'))
import numpy as np,torch
from embodiedforge.workflows.supermimic_reference_worker import save_actual_state
states=[];rewards=[];actions=[];torch.set_num_threads(1);torch.manual_seed(0);failed=False;finished=False
if args.recipe=='reference':
 from supermimic.env import TrackingSim,make_sim
 from supermimic.kinematics import G1Kinematics
 from supermimic.motion import MotionLib
 from supermimic.mdp import MDP,OBS_DIM
 from supermimic.robot import default_joint_pos_list
 from supermimic.networks import Policy
 import supermimic.networks as networks
 from embodiedforge.workflows.supermimic_reference_mjlab import launch_simulation
 from types import SimpleNamespace
 saved=torch.load(checkpoint,map_location='cpu',weights_only=False);cfg=saved['args'];networks.AMP_DTYPE=torch.bfloat16 if cfg.get('amp','none')=='bf16' else None;kin=G1Kinematics('cuda:0');canonical=(data/'backflip.csv').read_bytes();csv=out/'backflip.csv';csv.write_bytes(canonical+canonical.splitlines(keepends=True)[-1]*250);csv.chmod(0o444);csv_sha=sha(csv);motion=MotionLib([str(csv)],kin,'cuda:0',src_fps=50);assert motion.num_frames==571;mdp=MDP(kin,motion,torch.tensor(default_joint_pos_list(),device='cuda:0'));policy=Policy(OBS_DIM,73*cfg['goal_frames'],hist=cfg['hist']).to('cuda:0');policy.load_state_dict(saved['pi']);policy.eval();sim_cfg=make_sim('cuda:0',SimpleNamespace(seed=0));hist=torch.zeros(1,cfg['hist'],OBS_DIM,device='cuda:0')
 with launch_simulation(sim_cfg,cfg):
  env=TrackingSim(sim_cfg,1,motion,mdp,eval_mode=True);ids=torch.zeros(1,dtype=torch.long,device='cuda:0');env.reset(ids,ids);recorder=ContactRecorder(env);states.append(save_actual_state(env)[0].cpu().numpy())
  try:
   with torch.no_grad():
    for step in range(570):
     observation=mdp.obs(env.state(),env.a_prev,env.xi,env.f);hist=observation[:,None].expand_as(hist).clone() if step==0 else torch.cat((hist[:,1:],observation[:,None]),1);act=policy(hist,motion.goal(env.f,cfg['goal_frames']));tr=env.step(act);states.append(save_actual_state(env)[0].cpu().numpy());rewards.append(float(tr['r'][0]));actions.append(act[0].cpu().numpy());failed=bool(tr['term'][0]);finished=bool(tr['done'][0]);
     if failed or finished:break
   force=recorder.save(out)
  finally:recorder.close()
 assert sha(csv)==csv_sha
 iteration=int(saved['iteration'])
else:
 from embodiedforge.supermimic_run import load_policy
 from supermimic.envs import SuperMimicEnvCfgArgs,make_env
 from supermimic.envs.state_io import StateIO
 policy,cfg,iteration,updates=load_policy(checkpoint,'cuda:0');env=make_env(SuperMimicEnvCfgArgs(npz_files=[str(data/'eval/backflip.npz')],num_envs=1,future_frames=cfg['env']['future_frames'],episode_length_s=1e5,action_noise_std=0.,obs_noise=False,reset_noise=False,domain_randomization=False,sampling_mode='start',record_transitions=False,seed=0,anchor_obs=cfg['env'].get('anchor_obs',False)),device='cuda:0')
 try:
  command=env.command_manager.get_term('motion');command.forced_frame[:]=command.library.clip_start[0];obs,_=env.reset();state_io=StateIO(env);recorder=ContactRecorder(env);states.append(state_io.read()[0].cpu().numpy())
  try:
   with torch.no_grad():
    for step in range(570):
     act=policy(obs['policy'],obs['goal']);obs,rew,term,tout,_=env.step(act);rewards.append(float(rew[0]));actions.append(act[0].cpu().numpy());failed=bool(term[0]);finished=bool(tout[0])
     if failed or finished:break # Never append an auto-reset pose.
     states.append(state_io.read()[0].cpu().numpy())
   force=recorder.save(out)
  finally:recorder.close()
 finally:env.close()
state=np.stack(states);assert force['samples']==4*len(rewards);complete=not failed and len(state)==571;np.savez_compressed(out/'backflip-rollout.npz',state=state,time_s=np.arange(len(state))/50,rewards=np.array(rewards),actions=np.array(actions));diagnostics=backflip.diagnose_rollout(state,data/'eval/backflip.npz',out,complete);result={'status':'complete','recipe':args.recipe,'checkpoint':str(checkpoint),'checkpoint_sha256':checkpoint_sha,'iteration':iteration,'actual_states':len(state),'executed_control_steps':len(rewards),'force_samples':force['samples'],'complete':complete,'terminated':failed,'initial_velocity_max_abs':float(np.abs(state[0,36:]).max()),'native320step_zero_padded_return':float(np.sum(rewards[:320])/(.1*320)),'mean_executed_step_return':float(np.mean(rewards)/.1),'source_guards':guards,'implementation':implementation,'diagnostics':diagnostics,'contact_force_audit':force,'scope':'Actual policy controls and GPU physics.570actions cover571timestamps from0to11.4s; first320step return is native to each recipe and not interchangeable across reward implementations. Force sample qpos is post-integration, while solved contact constraints belong to that integration interval.'}
assert sha(checkpoint)==checkpoint_sha
for name,expected in guards.items():assert sha(repo/name)==expected,name
validate_snapshot(out/'implementation/supermimic',manifest)
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'recipe':args.recipe,'iteration':iteration,'complete':complete,'rotation':diagnostics['actual_lateral_rotation_deg'],'force_balance_verified':force['force_balance_verified'],'force_nonfoot_substeps':force['nonfoot_force_substeps'],'force_capacity_overflows':force['capacity_overflow_substeps']}))
