import json,sys
from pathlib import Path
from types import SimpleNamespace
import torch
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');sys.path.insert(0,str(repo/'src'));sys.path.insert(0,str(repo/'runs/supermimic-backflip-20261027-fourhour/probe-retry/implementation'))
from supermimic.env import TrackingSim,make_sim
from supermimic.kinematics import G1Kinematics
from supermimic.motion import MotionLib
from supermimic.mdp import MDP,OBS_DIM
from supermimic.robot import default_joint_pos_list
from supermimic.networks import Policy
import supermimic.networks as networks
from embodiedforge.workflows.supermimic_reference_mjlab import launch_simulation
from embodiedforge.workflows.supermimic_reference_play import build_viewer_policy
torch.set_num_threads(1);torch.manual_seed(0);ck=torch.load(repo/'runs/supermimic-backflip-20261027-fourhour/reference-main/logs/ckpt_002000.pt',map_location='cpu',weights_only=False);args=ck['args'];networks.AMP_DTYPE=torch.bfloat16;kin=G1Kinematics('cuda:0');motion=MotionLib([str(repo/'runs/supermimic/tasks/backflip/data/backflip.csv')],kin,'cuda:0',src_fps=50);mdp=MDP(kin,motion,torch.tensor(default_joint_pos_list(),device='cuda:0'));policy=Policy(OBS_DIM,730,hist=args['hist']).to('cuda:0');policy.load_state_dict(ck['pi']);policy.eval();cfg=make_sim('cuda:0',SimpleNamespace(seed=0))
with launch_simulation(cfg,args):
 backend=TrackingSim(cfg,1,motion,mdp,eval_mode=True);wrapped,act=build_viewer_policy(backend,policy,args);assert int(backend.f[0])==0
 for _ in range(20):wrapped.step(act(wrapped.get_observations()))
 assert int(backend.f[0])==20
 a=act(wrapped.get_observations());history=wrapped.unwrapped.history.clone();b=act(wrapped.get_observations());assert torch.equal(a,b) and torch.equal(history,wrapped.unwrapped.history)
 wrapped.unwrapped.reset(env_ids=torch.zeros(1,dtype=torch.long,device='cuda:0'));assert int(backend.f[0])==0 and wrapped.unwrapped.history is None
 backend.f[0]=319;backend.ep_step[0]=319;wrapped.step(act(wrapped.get_observations()));assert int(backend.f[0])==0 and wrapped.unwrapped.history is None and not bool(backend.done_eval[0])
 proof={'status':'complete','actual_physics_control_steps':21,'rsl_viewer_wrapper_constructed':True,'gui_reset_resets_motion_phase_and_history':True,'repeated_render_callback_does_not_duplicate_policy_history':True,'clip_end_loops_to_frame_zero':True,'scope':'Headless real-physics viewer adapter test, including an explicit last-frame reset control; not a complete backflip performance result or a browser-render test.'}
r=Path(__file__).parent;(r/'play-adapter-control.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
