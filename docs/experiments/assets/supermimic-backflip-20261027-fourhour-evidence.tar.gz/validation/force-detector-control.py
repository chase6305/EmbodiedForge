"""Known physical nonfoot contact must fail the detector; this is not a policy result."""
import json,sys
from pathlib import Path
from types import SimpleNamespace
import mujoco,mujoco_warp as mjw,warp as wp
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');sys.path.insert(0,str(repo/'src'))
from embodiedforge.workflows.supermimic_contacts import ContactRecorder
xml='''<mujoco><option timestep=".005" integrator="implicitfast" cone="pyramidal"/><worldbody><geom name="floor" type="plane" size="2 2 .1"/><body name="torso" pos="0 0 .05"><freejoint/><geom name="torso_box" type="box" size=".1 .1 .1" mass="1"/></body><body name="left_ankle_roll_link" pos="-1 0 2"><geom name="left_visual" type="sphere" size=".02" contype="0" conaffinity="0"/></body><body name="right_ankle_roll_link" pos="1 0 2"><geom name="right_visual" type="sphere" size=".02" contype="0" conaffinity="0"/></body></worldbody></mujoco>'''
m=mujoco.MjModel.from_xml_string(xml);d=mujoco.MjData(m);wm=mjw.put_model(m);wd=mjw.put_data(m,d,nworld=1,nconmax=32,njmax=64)
class Sim:
 mj_model=m;wp_model=wm;wp_data=wd;use_cuda_graph=False
 def step(self):mjw.step(self.wp_model,self.wp_data)
sim=Sim();env=SimpleNamespace(sim=sim,physics_dt=.005);out=repo/'runs/supermimic-backflip-20261027-fourhour/force-detector-control';out.mkdir(exist_ok=False);recorder=ContactRecorder(env)
try:
 for _ in range(4):sim.step()
 result=recorder.save(out);assert result['samples']==4 and result['nonfoot_force_substeps']>0 and result['max_nonfoot_force_N']>1 and result['force_balance_verified']
finally:recorder.close()
proof={'status':'complete','source':'Known penetrating torso box with a real4stepMuJoCo-Warp solve; detector control only, not a SuperMimic skill evaluation','nonfoot_force_substeps':result['nonfoot_force_substeps'],'max_nonfoot_force_N':result['max_nonfoot_force_N'],'force_balance_verified':result['force_balance_verified']};r=Path(__file__).parent;(r/'force-detector-control.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
