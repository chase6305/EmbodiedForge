"""Publish the bounded experiment only after real closure and the four-hour window."""
import datetime,hashlib,io,json,os,shutil,subprocess,sys,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;run=repo/'runs/supermimic-backflip-20261027-fourhour';report_path=repo/'docs/experiments/supermimic-backflip-20261027-fourhour.json';assets=repo/'docs/experiments/assets'
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(path,data):Path(path).write_text(json.dumps(data,indent=2)+'\n')
control=read(r/'control.json');now=datetime.datetime.now(datetime.timezone.utc);deadline=datetime.datetime.fromisoformat(control['deadline']);assert now<deadline, 'This is an explicitly early prepublication audit, not final completion'
plan=read(r/'final-plan.json');names=['reference-main',plan['second_run']];checks=read(r/'final-check-exits.json');assert checks and all(code==0 for code in checks.values());old=read(r/'history-hashes.json')
for path,expected in old.items():assert sha(repo/path)==expected,path
train_source=read(r/'main-source-hashes.json');final_source=read(r/'final-source-hashes.json')
for path,expected in train_source.items():assert sha(r/'phase-main'/path)==expected,path
for path,expected in final_source.items():assert sha(repo/path)==sha(r/'phase-final'/path)==expected,path
for path,row in read(r/'recovered-smoke-sources.json').items():assert row['expected']==row['recovered']==sha(r/'phase-smoke'/path),path
training={};evaluations={};physical={}
for name in names:
 actual=read(r/('actual-'+name+'-exit.json'));worker=read(run/name/'result.json');outer=read(run/(name+'-supervisor/result.json'));launcher=read(run/name/'launcher.json');config=read(run/name/'worker-config.json');assert actual['actual_tool_exit']==0 and worker['status']=='complete' and launcher['worker_exit_observed'] and launcher['worker_returncode']==0 and outer['exit_observed'] and outer['process_returncode']==0 and not outer['timed_out'];assert worker['finite_model_tensors'] and worker['checkpoint_reload_action_parity'] and worker['policy_updates']>0 and worker['policy_budget_seconds']>=5400
 for path,expected in launcher['launcher_sources'].items():assert sha(r/'phase-main'/path)==expected,(name,path)
 checkpoint=run/name/'logs/last.pt';assert sha(checkpoint)==worker['checkpoint_sha256'];training[name]={'actual_original_tool_exit':actual,'worker':worker,'supervisor':outer,'options':config,'selection':'Actual last completed model, never chosen by checkpoint score'}
 driver=read(r/(name+'-evaluations-original-exit.json'));assert driver['actual_tool_exit']==0
 group=read(r/(name+'-final-evaluations.json'));assert len(group)==3
 for row in group:
  assert row['observed']['driver_wait_returncode']==0 and row['worker']['status']=='complete' and row['worker']['iteration']==worker['iteration'] and row['worker']['checkpoint_sha256']==worker['checkpoint_sha256'];assert row['supervisor']['exit_observed'] and row['supervisor']['process_returncode']==0 and not row['supervisor']['timed_out']
  for artifact_name,digest in row['worker'].get('rollout_artifact_sha256',{}).items():assert sha(run/row['label']/artifact_name)==digest,(row['label'],artifact_name)
  reference_snapshot=row['worker'].get('diagnostic_reference_snapshot')
  if reference_snapshot:assert sha(Path(reference_snapshot['private_path']))==reference_snapshot['sha256']
  runtime=read(run/row['label']/'launcher.json')['launcher_sources'];expected_phase=r/('phase-main' if runtime==train_source else 'phase-final')
  for path,digest in runtime.items():assert sha(expected_phase/path)==digest,(row['label'],path)
 evaluations[name]=group
 measured=[row['worker']['physical_quality'] for row in group if 'physical_quality' in row['worker']]
 audit=run/plan['force_audits'][name]['directory'];assert (audit/'physical-quality.json').exists();proof=read(audit/'physical-quality.json');force=read(audit/'contact-force-audit.json');geometry=read(audit/'airborne-geometry.json');assert sha(audit/'physics-model.mjb')==force['compiled_cpu_geometry_model_sha256']==geometry['model_sha256'];assert read(audit/'result.json')['checkpoint_sha256']==worker['checkpoint_sha256']
 if not measured:
  exit_record=read(r/plan['force_audits'][name]['original_exit_record']);assert exit_record.get('actual_tool_exit')==0 or (exit_record.get('actual_tool_exit') is None and exit_record.get('supervisor_exit_observed') is True and exit_record.get('actual_supervisor_child_wait_returncode')==0);measured=[proof]
 physical[name]={'evaluated_quality_records':measured,'all_assessed_records_passed':all(value['ported_quality_passed'] is True for value in measured),'selected_first_force_audit':{'directory':str(audit.relative_to(repo)),'quality':proof,'forces':force,'geometry':geometry}}
current=names[-1];registry=read(repo/'runs/supermimic/tasks/backflip/reference/current.json');assert registry['checkpoint_sha256']==training[current]['worker']['checkpoint_sha256'];current_quality=all(row['worker'].get('physical_quality',{}).get('ported_quality_passed') is True for row in evaluations[current]);assert not plan.get('promote_reference') or current_quality
# All original jobs must be gone; exclude only this publishing process and its ancestors.
allowed={os.getpid()};pid=os.getppid()
while pid>0 and pid not in allowed:
 allowed.add(pid)
 try:stat=(Path('/proc')/str(pid)/'stat').read_text();tail=stat[stat.rfind(')')+2:].split();pid=int(tail[1])
 except OSError:break
live=[]
for entry in Path('/proc').iterdir():
 if not entry.name.isdigit() or int(entry.name) in allowed:continue
 try:
  cmd=(entry/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
  if str(run) in cmd or str(run.relative_to(repo)) in cmd or str(r) in cmd:live.append({'pid':int(entry.name),'command':cmd})
 except OSError:pass
assert not live,live
identity_checks=[]
for file in ['main-identities.json','seed138-identities.json']:
 for record in read(r/file):
  path=Path('/proc')/str(record['pid'])/'stat'
  try:
   stat=path.read_text();actual_start=int(stat[stat.rfind(')')+2:].split()[19]);same=actual_start==record['start_ticks']
  except OSError:same=False;actual_start=None
  identity_checks.append({'pid':record['pid'],'expected_start_ticks':record['start_ticks'],'current_start_ticks':actual_start,'same_owned_process_alive':same});assert not same,record
query=subprocess.run(['nvidia-smi','--query-compute-apps=pid,used_memory','--format=csv,noheader'],capture_output=True,text=True,timeout=15)
process_audit={'at':now.isoformat(),'scope':'Only this experiment run/private-script prefixes; publishing process/ancestors excluded','matching_live_processes':live,'owned_pid_start_identity_checks':identity_checks,'gpu_compute_process_query':{'actual_wait_returncode':query.returncode,'stdout':query.stdout,'stderr':query.stderr},'signals_sent':0};write(r/'prepublish-process-audit.json',process_audit)
def count_tests(file):
 root=ET.parse(r/file).getroot();suites=list(root.iter('testsuite'));totals={key:sum(int(suite.get(key,0)) for suite in suites) for key in ['tests','failures','errors','skipped']};assert totals['failures']==totals['errors']==0;return totals

print(json.dumps({'status':'prepublication_checks_passed','final_publication':False,'at':now.isoformat(),'deadline':control['deadline'],'current_quality':current_quality,'related_tests':count_tests('final-tests.xml'),'documentation':count_tests('final-documentation.xml'),'all_history_files_unchanged':len(old)}))
