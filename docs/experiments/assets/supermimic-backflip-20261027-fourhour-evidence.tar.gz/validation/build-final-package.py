"""Build final wheel in isolation and verify exact new-module/license inclusion."""
import hashlib,json,shutil,subprocess,sys,zipfile
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;stage=r/'package-final-stage';stage.mkdir(exist_ok=False);shutil.copytree(repo/'src',stage/'src',ignore=shutil.ignore_patterns('__pycache__','*.egg-info'))
for name in ['pyproject.toml','README.en.md']:shutil.copyfile(repo/name,stage/name)
wheelhouse=r/'package-final-wheels';wheelhouse.mkdir(exist_ok=False)
with (r/'package-final-build.log').open('x') as log:result=subprocess.run([sys.executable,'-m','pip','wheel','--no-deps','--no-build-isolation','--no-cache-dir','--wheel-dir',str(wheelhouse),str(stage)],cwd=stage,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0,result.returncode
wheels=list(wheelhouse.glob('*.whl'));assert len(wheels)==1;wheel=wheels[0];members=['embodiedforge/supermimic_run.py']+[str(path.relative_to(repo/'src')) for path in sorted((repo/'src/embodiedforge/workflows').glob('supermimic*.py'))]+['embodiedforge/workflows/LICENSE.supermimic-backflip']
with zipfile.ZipFile(wheel) as opened:
 assert opened.testzip() is None
 for name in members:assert opened.read(name)==(repo/'src'/name).read_bytes(),name
assert (repo/'src/embodiedforge/workflows/LICENSE.supermimic-backflip').read_bytes()==(repo/'.cache/external/supermimic-backflip-5090/LICENSE').read_bytes()
script='''import importlib,json,sys
sys.path.insert(0,sys.argv[1])
names=json.loads(sys.argv[2])
for name in names:importlib.import_module(name)
assert not {'torch','mujoco','mjlab','warp'} & set(sys.modules)
print(json.dumps({'modules':len(names),'heavy_simulation_modules_loaded':False}))
''';modules=[name.removesuffix('.py').replace('/','.') for name in members if name.endswith('.py')];probe=subprocess.run([sys.executable,'-I','-c',script,str(wheel),json.dumps(modules)],cwd=stage,text=True,capture_output=True,timeout=30);assert probe.returncode==0,(probe.stdout,probe.stderr);proof={'status':'complete','actual_build_wait_returncode':result.returncode,'actual_import_wait_returncode':probe.returncode,'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'wheel_bytes':wheel.stat().st_size,'verified_members':members,'exact_current_source_bytes_verified':True,'license_exactly_matches_pinned_reference':True,'isolated_import':json.loads(probe.stdout),'scope':'Wheel creation/inclusion and metadata-only imports verified in a separate source copy. Dedicated SDK training/evaluation is validated separately in the workspace, not installed into this host.'};(r/'package-final-validation.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
