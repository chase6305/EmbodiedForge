"""Read-only production-quality reanalysis of a completed actual force audit."""
import argparse,hashlib,json,sys
from pathlib import Path
import numpy as np
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');sys.path.insert(0,str(repo/'src'))
from embodiedforge.workflows.supermimic_backflip_quality import airborne_geometry,combine_quality
p=argparse.ArgumentParser();p.add_argument('--evaluation',type=Path,required=True);args=p.parse_args();out=args.evaluation;record=json.loads((out/'result.json').read_text());original={name:hashlib.sha256((out/name).read_bytes()).hexdigest() for name in ['result.json','backflip-rollout.npz','contact-forces-200hz.npz','physics-model.mjb']}
with np.load(out/'backflip-rollout.npz',allow_pickle=False) as data:state=data['state'].copy()
geometry=airborne_geometry(state,repo/'runs/supermimic/tasks/backflip/data/eval/backflip.npz',out/'physics-model.mjb');quality=combine_quality(complete=record['complete'],initial_velocity=record['initial_velocity_max_abs'],native_return=record['native320step_zero_padded_return'],control_steps=record['executed_control_steps'],state_samples=record['actual_states'],diagnostics=record['diagnostics'],geometry=geometry,forces=record['contact_force_audit'])
(out/'airborne-geometry.json').write_text(json.dumps(geometry,indent=2)+'\n');(out/'physical-quality.json').write_text(json.dumps(quality,indent=2)+'\n')
for name,expected in original.items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==expected
proof={'status':'complete','original_files_unchanged':original,'checkpoint_sha256':record['checkpoint_sha256'],'quality':quality};(out/'quality-reanalysis.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'status':'complete','ported_quality_passed':quality['ported_quality_passed'],'failed_checks':quality['failed_checks'],'unassessed_checks':quality['unassessed_checks']}))
