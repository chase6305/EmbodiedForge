"""Inspect real final optimizer buffers on CPU; never mutate model/registry files."""
import hashlib,json
from pathlib import Path
import torch
r=Path(__file__).parent;repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');torch.set_num_threads(1);rows=[]
for run in ['reference-main','reference-seed138']:
 path=repo/'runs/supermimic-backflip-20261027-fourhour'/run/'logs/last.pt';before=hashlib.sha256(path.read_bytes()).hexdigest();saved=torch.load(path,map_location='cpu',weights_only=False);optimizers={}
 for key in ['opt_wm','opt_pi','opt_v']:
  state=saved[key]['state'];tensor_count=0;elements=0;steps=[]
  for parameter in state.values():
   for name,value in parameter.items():
    if isinstance(value,torch.Tensor):
     assert value.device.type=='cpu' and torch.isfinite(value).all(),(run,key,name);tensor_count+=1;elements+=value.numel()
     if name=='exp_avg_sq':assert (value>=0).all(),(run,key,'negative second moment')
     if name=='step':steps.append(float(value))
  assert tensor_count>0 and steps and min(steps)>0,(run,key)
  optimizers[key]={'tensor_count':tensor_count,'elements':elements,'all_finite':True,'second_moments_nonnegative':True,'min_parameter_updates':min(steps),'max_parameter_updates':max(steps)}
 assert hashlib.sha256(path.read_bytes()).hexdigest()==before;rows.append({'run':run,'checkpoint_sha256':before,'iteration':saved['iteration'],'checkpoint_training_seed':saved['args']['seed'],'optimizers':optimizers});del saved
proof={'status':'complete','device':'cpu','physical_robot_execution':False,'actual_final_checkpoints':rows,'scope':'Finite/valid Adam buffers in both actual final full checkpoints. CPU inspection only; no further training, policy selection or registry mutation.'};(r/'final-optimizer-audit.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
