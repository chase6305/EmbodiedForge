"""Prepare reviewable late integration without changing the active training source."""
import ast,hashlib,json
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;stage=r/'late-integration';stage.mkdir(exist_ok=True)
def replace(text,old,new):
 assert text.count(old)==1,(old,text.count(old));return text.replace(old,new)
def save(name,text):
 ast.parse(text);p=stage/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
name='src/embodiedforge/workflows/supermimic_reference.py';s=(repo/name).read_text()
s=replace(s,'record.get("recipe") != "reference"','record.get("task") != "backflip"\n        or record.get("recipe") != "reference"')
s=replace(s,'    if options["action"] == "play":\n        raise ValueError(\n            "Reference recipe currently supports train/eval; use the saved actual rollout/video for inspection"\n        )\n','')
s=replace(s,'    elif options["action"] == "eval":','    elif options["action"] in {"eval", "play"}:')
s=replace(s,'        "benchmarks/supermimic_reference.py",\n    )','        "benchmarks/supermimic_reference.py",\n        "src/embodiedforge/workflows/supermimic_contacts.py",\n        "src/embodiedforge/workflows/supermimic_backflip_quality.py",\n        "src/embodiedforge/workflows/supermimic_reference_play.py",\n        "src/embodiedforge/workflows/supermimic_reference_evaluate.py",\n    )')
s=replace(s,'str((output / "logs/last.pt").relative_to(workspace))','checkpoint_registry_path(output / "logs/last.pt", workspace)')
s=replace(s,'    # Resume restores weights and optimizers, but the upstream replay is not saved.','    source = replace_once(source, "    if start_it == 0:\\n        log_f.write(", "    if log_f.tell() == 0:\\n        log_f.write(")\n    # Resume restores weights and optimizers, but the upstream replay is not saved.')
s+='''\n\ndef checkpoint_registry_path(checkpoint, workspace):
    """Keep external output directories usable by the same local registry."""
    checkpoint, workspace = Path(checkpoint).resolve(), Path(workspace).resolve()
    return str(checkpoint.relative_to(workspace) if checkpoint.is_relative_to(workspace) else checkpoint)


def preferred_recipe(workspace):
    """Select the explicitly activated algorithm family; registries remain separate."""
    marker = backflip.task_directory(workspace) / "reference/preferred.json"
    if not marker.exists():
        return "cuboi"
    record = load_options(marker)
    if record.get("task") != "backflip" or record.get("recipe") != "reference":
        raise ValueError("Invalid preferred backflip recipe")
    return "reference"


def activate_preference(workspace, *, basis_report, checkpoint_sha256):
    """Activate the recipe after a caller has evaluated its actual current model."""
    current = latest_checkpoint(workspace)
    if current is None or current["checkpoint_sha256"] != checkpoint_sha256:
        raise ValueError("Preferred-recipe activation requires the current checkpoint identity")
    target = backflip.task_directory(workspace) / "reference/preferred.json"
    write_json(target, {"task":"backflip", "recipe":"reference",
                       "basis_report":basis_report, "evaluated_checkpoint_sha256":checkpoint_sha256,
                       "activated_at":datetime.now(timezone.utc).isoformat(),
                       "scope":"Prefer this algorithm family; subsequent train commands resume its latest completed model. This marker does not certify later models."})
'''
save(name,s)
name='src/embodiedforge/supermimic_run.py';s=(repo/name).read_text();s=replace(s,'        default="cuboi",','        default=None,');s=replace(s,'    expected_checkpoint = None','    from embodiedforge.workflows import supermimic_reference\n\n    recipe = args.recipe or (\n        supermimic_reference.preferred_recipe(workspace)\n        if args.task == "backflip" else "cuboi"\n    )\n    if recipe == "reference" and args.anchor_obs:\n        raise ValueError("The reference recipe requires --task backflip and its own99dimensional observation protocol")\n    expected_checkpoint = None');s=replace(s,'                if args.recipe == "reference"','                if recipe == "reference"');s=replace(s,'        "recipe": args.recipe,','        "recipe": recipe,');s=replace(s,'            "train": 512,','            "train": 1024 if recipe == "reference" else 512,');save(name,s)
name='src/embodiedforge/workflows/supermimic_reference_worker.py';s=(repo/name).read_text();start=s.index('\ndef save_actual_state');end=s.index('\ndef main(config):');s=s[:start]+s[end:]
s=replace(s,'        import torch\n        from mjlab.asset_zoo','        import supermimic\n        import torch\n        from embodiedforge.workflows.supermimic_reference_evaluate import validate_checkpoint\n        from mjlab.asset_zoo')
s=replace(s,'        torch.set_num_threads(1)','        if Path(supermimic.__file__).resolve().parent != (output / "implementation/supermimic").resolve():\n            raise ValueError("SuperMimic import did not resolve to the frozen implementation")\n        if options["checkpoint"] is not None:\n            if snapshot_file_hashes(options["checkpoint"])[0] != options["checkpoint_sha256"]:\n                raise ValueError("Checkpoint changed before CPU validation")\n            saved = torch.load(options["checkpoint"], map_location="cpu", weights_only=False)\n            validate_checkpoint(saved, training=options["action"] == "train", iterations=options["iterations"])\n            del saved\n        torch.set_num_threads(1)')
s=replace(s,'        else:\n            record.update(\n                evaluate(options, output, csv),','        else:\n            from embodiedforge.workflows.supermimic_reference_evaluate import evaluate, play\n\n            execute = evaluate if options["action"] == "eval" else play\n            record.update(\n                execute(options, output, csv),')
s=replace(s,'                    "recipe": "reference",\n                }','                    "recipe": "reference",\n                    **({"skill_success": record["skill_success"], "physical_quality": record["physical_quality"]} if "physical_quality" in record else {}),\n                }');save(name,s)
print(json.dumps({'prepared_files':3,'active_source_unchanged':True}))
