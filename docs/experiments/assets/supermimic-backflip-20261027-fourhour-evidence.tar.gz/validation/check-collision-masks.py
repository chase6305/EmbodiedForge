"""Confirm nonfoot-ground contacts were not disabled to pass a force test."""
import hashlib,json
from pathlib import Path
import mujoco,numpy as np
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');folder=repo/'runs/supermimic-backflip-20261027-fourhour/intermediate-6000-force';path=folder/'physics-model.mjb';source=hashlib.sha256(path.read_bytes()).hexdigest();expected=json.loads((folder/'contact-force-audit.json').read_text())['compiled_cpu_geometry_model_sha256'];assert source==expected;model=mujoco.MjModel.from_binary_path(str(path));floors=np.flatnonzero(model.geom_type==mujoco.mjtGeom.mjGEOM_PLANE).tolist();assert len(floors)==1;floor=floors[0];feet={i for i in range(model.nbody) if any(model.body(i).name.endswith(name) for name in ('left_ankle_roll_link','right_ankle_roll_link'))};records=[]
for geom in range(model.ngeom):
 name=model.geom(geom).name or '';body=int(model.geom_bodyid[geom])
 if not name.endswith('_collision') or body in feet:continue
 collision=bool((model.geom_contype[geom]&model.geom_conaffinity[floor]) or (model.geom_contype[floor]&model.geom_conaffinity[geom]));assert collision,(name,model.geom_contype[geom],model.geom_conaffinity[geom]);signature=(min(body,int(model.geom_bodyid[floor]))<<16)+max(body,int(model.geom_bodyid[floor]));assert signature not in model.exclude_signature
 records.append({'geom':name,'body':model.body(body).name,'contype':int(model.geom_contype[geom]),'conaffinity':int(model.geom_conaffinity[geom]),'ground_pair_enabled':collision})
assert len(records)>10
proof={'status':'complete','model_sha256':source,'ground_geom':model.geom(floor).name,'nonfoot_ground_collision_geoms_checked':len(records),'all_nonfoot_ground_pairs_enabled':True,'self_collisions_disabled':True,'records':records};Path(__file__).with_name('collision-mask-control.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items() if k!='records'}))
