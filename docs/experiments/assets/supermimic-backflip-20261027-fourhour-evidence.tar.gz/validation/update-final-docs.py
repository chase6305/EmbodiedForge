"""Write final guide text from completed evaluations, preserving historical reports."""
import json,shutil
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;plan=json.loads((r/'final-plan.json').read_text());names=['reference-main',plan['second_run']];rows=[]
def display_range(values, digits, unit):
 return f'{min(values):.{digits}f}–{max(values):.{digits}f} {unit}' if all(value is not None for value in values) else '未覆盖完整姿态窗口'
def display_flight(geometry):
 angle=geometry['aerial_rotation_deg']
 return f"{geometry['fully_airborne_seconds']:.2f} s / {abs(angle):.1f}°" if angle is not None else '未形成有效腾空段'
for name in names:
 data=json.loads((r/(name+'-final-evaluations.json')).read_text());assert len(data)==3;training=json.loads((repo/'runs/supermimic-backflip-20261027-fourhour'/name/'result.json').read_text())
 leg=[v['diagnostics']['fixed_window_pose']['hip_knee_rmse_deg'] for v in data];span=[v['diagnostics']['fixed_window_pose']['max_ankle_separation_m'] for v in data];physical=[v['worker']['physical_quality']['ported_quality_passed'] for v in data if 'physical_quality' in v['worker']];force=repo/'runs/supermimic-backflip-20261027-fourhour'/plan['force_audits'][name]['directory'];audit=json.loads((force/'physical-quality.json').read_text());geometry=json.loads((force/'airborne-geometry.json').read_text());quality=(str(sum(value is True for value in physical))+'/3 完整物理评测通过') if physical else ('3/3 姿态评测通过；另做 1 次完整物理评测'+('通过' if audit['ported_quality_passed'] else '未通过'));rows.append(f'| {137 if name=="reference-main" else 138} | {training["iteration"]} / {training["policy_updates"]} | {display_range(leg,2,"°")} | {display_range(span,3,"m")} | {display_flight(geometry)} | {quality} |')
command_recipe='' if plan.get('promote_reference') else ' --recipe reference'
text='''本轮四小时优化已将完整 vibed SuperMimic 算法适配到现有 mjlab：保留 99 维观测、730 维目标、10 帧历史、骨盆奖励锚点、next-frame 解析奖励与终止、H=32 想象更新，以及 500 次世界模型单独预热。没有使用官方权重、外部控制器或强制动作对称补丁。两个独立随机种子各从零训练 90 分钟策略预算；这四小时还包含适配、预热、诊断与评测，并非四小时 GPU 策略训练。

| 训练种子 | 最后迭代 / 策略更新 | 固定窗口髋膝误差范围 | 最大脚踝间距范围 | 首次力审计的腾空时长 / 腾空后翻角度 | 实际最后模型评测 |
| --- | --- | --- | --- | --- | --- |
'''+ '\n'.join(rows)+'''

评测保留原始时间，不在失败后重置。初始状态加 570 次真实控制覆盖 571 个状态，并记录 2,280 个 200 Hz 物理子步的实际约束力，分别检查腾空、姿态、非脚部力、负接触距离、容量溢出和额外 5 秒保持。几何分析使用该次实际编译模型；接触力来自设备求解结果。两个种子分别报告，不能把同一模型的进程复测当成训练种子统计或泛化证明。

'''
if plan.get('promote_reference'):text+='当前工作区已将后空翻短指令切换至验证后的 reference 算法族，无需设置环境变量：\n\n'
else:text+='使用完整 reference 算法的运行指令，无需设置环境变量：\n\n'
text+='```bash\n'+ '\n'.join('./supermimic '+action+' --task backflip'+command_recipe for action in ['play','eval','train'])+'\n```\n\n'
text+='首次训练从零开始，后续继续这一实现最近一次正常完成的最后检查点；`--fresh` 开始独立训练，`--hours` 设置策略更新预算（默认 1.5 小时），`--iterations` 是全局迭代目标。训练与评测自动选择本地专用 SDK。`play` 使用真实策略驱动物理仿真并在片段结束后循环，`eval` 连续执行一次完整物理验收。Viser 服务及真实策略循环已验证，浏览器侧 WebGL 交互未实测。\n\n'
text+='reference 使用独立登记 `runs/supermimic/tasks/backflip/reference/current.json`；`--recipe cuboi` 可访问原实现，两套网络不能混载。登记只代表训练正常完成，后续新模型需要重新评测。物理资产、求解器和批大小仍与 IsaacLab3 参考工程不同，这是当前 mjlab 上的完整算法复现，不宣称精确 V14 等价或实机成功。两种实现的控制计数和奖励定义不同，平均回报不作跨实现比较。[实际最后模型对比图](experiments/assets/supermimic-backflip-20261027-fourhour-comparison.svg)与[完整训练、失败和物理评测记录](experiments/supermimic-backflip-20261027-fourhour.json)。\n'
p=repo/'docs/supermimic.md';s=p.read_text();start=s.index('四小时优化正在验证另一条完整算法适配：');end=s.index('\n## ',start);p.write_text(s[:start]+text+s[end:]);assets=repo/'docs/experiments/assets';shutil.copyfile(r/'fourhour-comparison.svg',assets/'supermimic-backflip-20261027-fourhour-comparison.svg')
p=repo/'docs/experiments/README.md';s=p.read_text();s=s.replace('本轮进行中的记录','本轮完整记录');s=s.replace('正在将完整 vibed 训练逻辑适配到现有 mjlab，分别保留新旧模型、实际退出和共享姿态诊断；最终状态以报告为准。','将完整 vibed 算法适配到现有 mjlab，保留两个独立训练种子的实际最后模型、进程复测、200 Hz 物理检查和原有失败。结果及适用范围以结构化报告为准。');s=s.replace('SuperMimic 后空翻四小时优化（进行中）','SuperMimic 后空翻四小时优化');p.write_text(s)
print(json.dumps({'status':'complete','seeds':2,'preferred_reference_planned':plan.get('promote_reference',False)}))
