"""Plot actual original-time trajectories and measured pose/contact quality."""
import json,sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9,'axes.titlesize':10,'axes.labelsize':9})
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;sys.path.insert(0,str(repo/'src'));run=repo/'runs/supermimic-backflip-20261027-fourhour';plan=json.loads((r/'final-plan.json').read_text())
from embodiedforge.workflows.supermimic_backflip import lateral_rotation_degrees
with np.load(repo/'runs/supermimic/tasks/backflip/data/eval/backflip.npz',allow_pickle=False) as d:ref_quat=d['body_quat_w'][:,0].copy()
def curve(q):return np.array([lateral_rotation_degrees(q[:end+1]) for end in range(len(q))])
rows=[{'label':'Prior Cuboi baseline','evaluation':repo/'runs/supermimic-backflip-20261027/main-eval-r1','force':run/'baseline-force','color':'#d47c31'}]
for index,name in enumerate(['reference-main',plan['second_run']]):
 groups=json.loads((r/(name+'-final-evaluations.json')).read_text());force=run/plan['force_audits'][name]['directory'];rows.append({'label':name,'evaluation':run/groups[0]['label'],'force':force,'color':['#2c69b3','#27805b'][index]})
fig,axes=plt.subplots(2,2,figsize=(11,7),layout='constrained');fig.suptitle('SuperMimic backflip on mjlab: actual final checkpoints',fontsize=11)
ref_t=np.arange(len(ref_quat))/50;axes[0,0].plot(ref_t,curve(ref_quat),'--',color='#555',label='Reference target')
labels=[];leg=[];spans=[];colors=[];table=[]
for row in rows:
 folder=row['evaluation'];diag=json.loads((folder/'backflip-diagnostics.json').read_text())
 with np.load(folder/'backflip-rollout.npz',allow_pickle=False) as d:state=d['state'].copy();t=d['time_s'].copy()
 axes[0,0].plot(t,curve(state[:,3:7]),label=row['label'],color=row['color']);labels.append(row['label']);leg.append(diag['fixed_window_pose']['hip_knee_rmse_deg']);spans.append(diag['fixed_window_pose']['max_ankle_separation_m']);colors.append(row['color'])
 with np.load(row['force']/'contact-forces-200hz.npz',allow_pickle=False) as f:time=f['time_s'];reaction=f['total_ground_force_N'][:,2]/float(f['mass'])/9.81
 axes[1,1].plot(time,reaction,label=row['label'],color=row['color'],alpha=.85,linewidth=.8)
 table.append({'model':row['label'],'fixed_window_hip_knee_rmse_deg':leg[-1],'fixed_window_max_ankle_separation_m':spans[-1],'rotation_deg':diag['actual_lateral_rotation_deg'],'completed_reference_and_hold':diag['completed_extended_reference'],'basic_checks':diag['basic_checks_passed'],'fixed_window_pose_pass':diag['fixed_window_pose']['pose_quality_passed']})
axes[0,0].axvspan(6.4,11.4,color='#999',alpha=.1);axes[0,0].set(xlabel='Original simulation time (s)',ylabel='Accumulated lateral rotation (deg)',xlim=(0,11.4),title='Rotation and additional 5 s hold');axes[0,0].legend(fontsize=7)
positions=np.arange(len(labels));axes[0,1].bar(positions,[np.nan if value is None else value for value in leg],color=colors);axes[0,1].axhline(25,linestyle='--',color='#b33',label='25 degree limit');axes[0,1].set_xticks(positions,labels,rotation=13,fontsize=7);axes[0,1].set(ylabel='Hip/knee RMSE (degrees)',title='Fixed window: hip/knee tracking');axes[0,1].legend(fontsize=8)
axes[1,0].bar(positions,[np.nan if value is None else value for value in spans],color=colors);axes[1,0].axhline(.3948038073726456+.15,linestyle='--',color='#b33',label='Reference max + 0.15 m');axes[1,0].set_xticks(positions,labels,rotation=13,fontsize=7);axes[1,0].set(ylabel='Maximum ankle separation (m)',title='Fixed window: ankle spacing');axes[1,0].legend(fontsize=8)
axes[1,1].set(xlabel='Original simulation time (s)',ylabel='Ground reaction / body weight',xlim=(0,3.2),title='Measured ground reaction (200 Hz)');axes[1,1].legend(fontsize=7)
for axis in axes.flat:axis.grid(axis='y',alpha=.2)
for extension in ('svg','png'):fig.savefig(r/('fourhour-comparison.'+extension),dpi=140)
plt.close(fig);(r/'plot-source-scalars.json').write_text(json.dumps({'selection':'States/pose: first declared final-evaluation repeat per model. Forces: first declared full200Hzaudit of the same actual last checkpoint, a separate process for baseline/seed137. All repeats remain in the report. Different training recipes/assets settings are not a single-change ablation.','rows':table},indent=2)+'\n');print(json.dumps({'status':'complete','rows':len(rows),'source':'Actual saved states and actual solved forces; no reference state substitution or time alignment'}))
