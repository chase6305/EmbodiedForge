import json,sys
from pathlib import Path
import numpy as np
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');sys.path.insert(0,str(repo/'src'));r=Path(__file__).parent;out=repo/'runs/supermimic-backflip-20261027-fourhour/shared-diagnostics-control';out.mkdir(exist_ok=False)
from embodiedforge.workflows.supermimic_backflip import diagnose_rollout
old=repo/'runs/supermimic-backflip-20261027/main-eval-r1';reference=repo/'runs/supermimic/tasks/backflip/data/eval/backflip.npz'
with np.load(old/'backflip-rollout.npz',allow_pickle=False) as source:state=source['state'].copy()
expected=json.loads((old/'backflip-diagnostics.json').read_text());(out/'unchanged').mkdir();actual=diagnose_rollout(state,reference,out/'unchanged',True);assert actual==expected
negative=state.copy();negative[:,2]-=1.;(out/'penetration-control').mkdir();control=diagnose_rollout(negative,reference,out/'penetration-control',True);assert control['nonfoot_floor_penetration_frames']>0 and control['basic_checks_passed'] is False
record={'status':'complete','baseline_diagnostics_exactly_unchanged':True,'baseline_actual_rotation_deg':actual['actual_lateral_rotation_deg'],'synthetic_lowered_root_control':{'source':'Copy of saved states with root z reduced1m ONLY as a detector negative control; not a real rollout or performance result','nonfoot_penetration_frames':control['nonfoot_floor_penetration_frames'],'basic_checks_passed':control['basic_checks_passed']}};(r/'shared-diagnostics-control.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
