"""Bound the final play worker to20real controls on an owned local Viser server."""
import hashlib,json,socket,sys,urllib.request
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;sys.path.insert(0,str(repo/'src'))
import viser
from mjlab import viewer as viewer_module
from embodiedforge import supermimic_run as runner
from embodiedforge.workflows.supermimic_reference_worker import main
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();sources=read(r/'final-source-hashes.json');plan=read(r/'final-plan.json');current=plan['second_run'];cp=repo/'runs/supermimic-backflip-20261027-fourhour'/current/'logs/last.pt';digest=sha(cp);output=repo/'runs/supermimic-backflip-20261027-fourhour/final-worker-play';output.mkdir(exist_ok=False);observed=[];Original=viewer_module.ViserPlayViewer
class BoundedViser(Original):
 def __init__(self,env,policy):
  with socket.socket() as selection:selection.bind(('127.0.0.1',0));port=selection.getsockname()[1]
  self.owned_server=viser.ViserServer(host='127.0.0.1',port=port,label='SuperMimic final-model bounded validation')
  super().__init__(env,policy,viser_server=self.owned_server)
 def run(self):
  try:
   with urllib.request.urlopen('http://127.0.0.1:'+str(self.owned_server.get_port()),timeout=10) as response:status=response.status;html=response.read()
   assert status==200 and b'<html' in html.lower()
   super().run(num_steps=20,catch_sigint=False);assert self._step_count>=20 and self._last_error is None
   observed.append({'http_status':status,'html_bytes':len(html),'actual_policy_controls':self._step_count,'viewer_error':self._last_error})
  finally:self.owned_server.stop()
viewer_module.ViserPlayViewer=BoundedViser
options=runner.resolve_options(runner.parser().parse_args(['play','--task','backflip','--recipe','reference','--checkpoint',str(cp),'--output',str(output)]));options['checkpoint_sha256']=digest;config=output/'worker-config.json';config.write_text(json.dumps(options,indent=2)+'\n')
for name,expected in sources.items():assert sha(repo/name)==expected,name
assert main(config)==0 and observed
for name,expected in sources.items():assert sha(repo/name)==expected,name
assert sha(cp)==digest;worker=read(output/'result.json');assert worker['status']=='complete' and worker['checkpoint_sha256']==digest
proof={'status':'complete','worker':worker,'observed_viewer':observed,'server_stopped':True,'source_files_verified':len(sources),'scope':'Final owned checkpoint through the integrated play worker and actual standardViser20control loop. Private wrapper bounds run duration/localhost port only. No browser-side WebGLrender or skill acceptance claim from this short play control.'};(r/'final-worker-play-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'status':'complete','actual_controls':observed[0]['actual_policy_controls'],'checkpoint_sha256':digest}))
