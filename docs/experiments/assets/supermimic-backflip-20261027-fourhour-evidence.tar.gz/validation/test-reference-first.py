"""Keep the new complete recipe isolated from the older checkpoint protocol."""

import hashlib
import json

import pytest

from embodiedforge import supermimic_run as runner
from embodiedforge.workflows import supermimic_backflip as backflip
from embodiedforge.workflows import supermimic_reference as reference


def registry(workspace, recipe):
    checkpoint = workspace / (recipe + ".pt")
    checkpoint.write_bytes(recipe.encode())
    directory = backflip.task_directory(workspace)
    if recipe == "reference":
        directory /= "reference"
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "current.json").write_text(
        json.dumps(
            {
                "task": "backflip",
                "recipe": recipe,
                "training_status": "complete",
                "checkpoint": checkpoint.name,
                "checkpoint_sha256": hashlib.sha256(
                    checkpoint.read_bytes()
                ).hexdigest(),
            }
        )
    )
    return checkpoint


def test_reference_recipe_never_resumes_the_older_cuboi_policy(tmp_path):
    registry(tmp_path, "cuboi")
    args = runner.parser().parse_args(
        ["train", "--task", "backflip", "--recipe", "reference"]
    )
    plan = runner.resolve_options(args, tmp_path)
    assert plan["fresh"] is True and plan["checkpoint"] is None
    assert plan["recipe"] == "reference"
    assert plan["motions"].endswith("backflip/data/train")


def test_reference_registry_is_separate_and_hash_checked(tmp_path):
    older = registry(tmp_path, "cuboi")
    newer = registry(tmp_path, "reference")
    args = runner.parser().parse_args(
        ["eval", "--task", "backflip", "--recipe", "reference"]
    )
    assert runner.resolve_options(args, tmp_path)["checkpoint"] == str(newer)
    args = runner.parser().parse_args(["eval", "--task", "backflip"])
    assert runner.resolve_options(args, tmp_path)["checkpoint"] == str(older)
    newer.write_bytes(b"changed")
    with pytest.raises(ValueError, match="checkpoint changed"):
        reference.latest_checkpoint(tmp_path)
    assert backflip.latest_checkpoint(tmp_path)["checkpoint"] == str(older)


@pytest.mark.parametrize("extra", [[], ["--task", "backflip", "--anchor-obs"]])
def test_reference_protocol_rejects_incompatible_options_before_sdk_load(extra, capsys):
    assert runner.main(["train", "--recipe", "reference", *extra]) == 2
    assert "requires --task backflip" in capsys.readouterr().err


def test_reference_target_must_leave_policy_updates_after_warmup(tmp_path):
    args = runner.parser().parse_args(
        ["train", "--task", "backflip", "--recipe", "reference", "--iterations", "500"]
    )
    plan = runner.resolve_options(args, tmp_path)
    with pytest.raises(ValueError, match="policy updates"):
        reference.launch(plan, {})
    assert not (tmp_path / "runs").exists()


@pytest.mark.parametrize("source", ["no matching target", "target target"])
def test_pinned_adapter_refuses_missing_or_ambiguous_patch_targets(source):
    with pytest.raises(ValueError, match="match once"):
        reference.replace_once(source, "target", "replacement")
