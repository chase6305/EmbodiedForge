import json,sys
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');sys.path.insert(0,str(repo/'src'));out=repo/'runs/supermimic-backflip-20261027-fourhour/probe';out.mkdir(exist_ok=False)
from embodiedforge.workflows.supermimic_reference import freeze_reference
record=freeze_reference(repo,out);sys.path.insert(0,str(out/'implementation'))
import torch,numpy as np,mujoco
from supermimic.kinematics import G1Kinematics
from supermimic.motion import MotionLib
from supermimic.mdp import MDP,OBS_DIM
from supermimic.robot import default_joint_pos_list,MJCF_PATH
from supermimic.env import TrackingSim,make_sim
from supermimic.rotations import quat_to_mat,mat_to_quat
from embodiedforge.workflows.supermimic_reference_mjlab import launch_simulation
from types import SimpleNamespace
torch.set_num_threads(1);torch.manual_seed(137)
kin=G1Kinematics('cpu');motion=MotionLib([str(repo/'runs/supermimic/tasks/backflip/data/backflip.csv')],kin,'cpu',src_fps=50);assert motion.num_frames==321
model=mujoco.MjModel.from_xml_path(MJCF_PATH);data=mujoco.MjData(model);worst=0.
for idx in (0,80,100,120,320):
 q=np.concatenate((motion.root_p[idx].numpy(),mat_to_quat(motion.root_R[idx]).numpy(),motion.q[idx].numpy()));data.qpos[:]=q;mujoco.mj_forward(model,data)
 for j,name in enumerate(['pelvis','left_hip_roll_link','left_knee_link','left_ankle_roll_link','right_hip_roll_link','right_knee_link','right_ankle_roll_link','torso_link','left_shoulder_roll_link','left_elbow_link','left_wrist_yaw_link','right_shoulder_roll_link','right_elbow_link','right_wrist_yaw_link']):worst=max(worst,float(np.max(np.abs(data.body(name).xpos-motion.body_p[idx,j].numpy()))))
assert worst<1e-5,worst
kin=G1Kinematics('cuda:0');motion=MotionLib([str(repo/'runs/supermimic/tasks/backflip/data/backflip.csv')],kin,'cuda:0',src_fps=50);mdp=MDP(kin,motion,torch.tensor(default_joint_pos_list(),device='cuda:0'));args=SimpleNamespace(seed=137);cfg=make_sim('cuda:0',args)
with launch_simulation(cfg,args):
 env=TrackingSim(cfg,8,motion,mdp,eval_mode=True);env.reset(torch.arange(8,device='cuda:0'),frames=torch.arange(8,device='cuda:0'));S=env.state();f=env.f.clone();assert torch.allclose(S[0],motion.root_p[f],atol=1e-6);assert torch.allclose(S[4],motion.q[f],atol=1e-6);assert mdp.obs(S,env.a_prev,env.xi,f).shape==(8,99);assert motion.goal(f,10).shape==(8,730)
 for _ in range(10):
  tr=env.step(torch.zeros(8,29,device='cuda:0'));assert torch.isfinite(tr['s1']).all();assert torch.isfinite(tr['r']).all()
 assert not any(name.startswith(('isaaclab','newton')) for name in sys.modules)
 proof={'status':'complete','frames':motion.num_frames,'cpu_fk_max_position_error_m':worst,'gpu_physics_steps':10,'num_envs':8,'obs_dim':OBS_DIM,'goal_dim':730,'isaaclab_imported':False,'finite_states_rewards':True,'physics_dt':env.raw.physics_dt,'control_dt':env.raw.step_dt,'self_collisions':False,'context_friction':env.xi[:,0].tolist()}
(out/'result.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
