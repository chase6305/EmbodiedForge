import json,sys
from pathlib import Path
import numpy as np,mujoco
from mjlab.asset_zoo.robots.unitree_g1.g1_constants import G1_XML
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');out={};spec=mujoco.MjSpec.from_file(str(G1_XML));spec.worldbody.add_geom(name='ef_floor',type=mujoco.mjtGeom.mjGEOM_PLANE,size=[20,20,.1]);m=spec.compile();d=mujoco.MjData(m);floor=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_GEOM,'ef_floor');feet={mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,n) for n in ['left_ankle_roll_link','right_ankle_roll_link']}
for label in ('intermediate-2000','intermediate-2000-force'):
 with np.load(repo/'runs/supermimic-backflip-20261027-fourhour'/label/'backflip-rollout.npz',allow_pickle=False) as f:states=f['state'].copy()
 rows=[]
 for i,row in enumerate(states):
  d.qpos[:]=row[:36];d.qvel[:]=row[36:];mujoco.mj_forward(m,d)
  for c in d.contact:
   a,b=map(int,c.geom)
   if floor in (a,b) and c.dist<0:
    g=b if a==floor else a;body=int(m.geom_bodyid[g])
    if body not in feet:rows.append({'state_frame':i,'time_s':i/50,'geom':m.geom(g).name,'body':m.body(body).name,'penetration_m':float(-c.dist),'base_contype':int(m.geom_contype[g]),'base_conaffinity':int(m.geom_conaffinity[g])})
 out[label]=rows
print(json.dumps(out,indent=2));Path(__file__).with_name('intermediate-2000-penetration-details.json').write_text(json.dumps(out,indent=2)+'\n')
