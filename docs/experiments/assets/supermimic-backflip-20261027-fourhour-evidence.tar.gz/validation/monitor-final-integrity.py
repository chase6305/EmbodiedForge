"""Monitor the accepted result while the authorized work window closes."""
import datetime,hashlib,json
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources=read(r/'final-source-hashes.json');history=read(r/'history-hashes.json')
for name,digest in sources.items():assert sha(repo/name)==sha(r/'phase-final'/name)==digest,name
for name,digest in history.items():assert sha(repo/name)==digest,name
models={}
for name in ['reference-main','reference-seed138']:
 job=repo/'runs/supermimic-backflip-20261027-fourhour'/name;worker=read(job/'result.json');cp=job/'logs/last.pt';assert sha(cp)==worker['checkpoint_sha256'];models[name]=worker['checkpoint_sha256']
registry=read(repo/'runs/supermimic/tasks/backflip/reference/current.json');assert registry['checkpoint_sha256']==models['reference-seed138'];marker=read(repo/'runs/supermimic/tasks/backflip/reference/preferred.json');assert marker['recipe']=='reference' and marker['evaluated_checkpoint_sha256']==registry['checkpoint_sha256']
for row in read(r/'reference-seed138-final-evaluations.json'):
 worker=row['worker'];assert worker['physical_quality']['ported_quality_passed'] is True
 for name,digest in worker['rollout_artifact_sha256'].items():assert sha(repo/'runs/supermimic-backflip-20261027-fourhour'/row['label']/name)==digest
 snapshot=worker['diagnostic_reference_snapshot'];assert sha(snapshot['private_path'])==snapshot['sha256']
video=repo/'runs/supermimic-backflip-20261027-fourhour/reference-seed138-final-video';assert sha(video/'policy.mp4')==read(video/'result.json')['video_sha256'];assert sha(r/'fourhour-comparison.svg')==sha(repo/'docs/experiments/assets/supermimic-backflip-20261027-fourhour-comparison.svg')
row={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'final_source_files_verified':len(sources),'historical_reports_assets_verified':len(history),'actual_last_checkpoints_verified':len(models),'current_full_physical_evaluations_passed':3,'trajectory_contact_model_reference_video_hashes_verified':True,'default_recipe':'reference','runtime_source_frozen':True}
with (r/'final-integrity-health.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
print(json.dumps(row))
