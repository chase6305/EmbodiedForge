"""Apply reviewed evaluation/viewer integration only after actual training closure."""
import ast,hashlib,json,shutil
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name in ['reference-main','reference-seed138']:
 assert read(r/('actual-'+name+'-exit.json'))['actual_tool_exit']==0,name
 assert read(repo/'runs/supermimic-backflip-20261027-fourhour'/name/'launcher.json')['status']=='complete',name
for name,digest in read(r/'main-source-hashes.json').items():assert sha(repo/name)==digest,name
for name,digest in read(r/'pre-late-tests-hashes.json').items():assert sha(repo/name)==digest,name
changes=[]
for source in sorted((r/'late-integration').rglob('*.py')):
 ast.parse(source.read_text());relative=source.relative_to(r/'late-integration');target=repo/relative;changes.append({'path':str(relative),'before_sha256':sha(target),'after_sha256':sha(source)});shutil.copyfile(source,target)
(r/'late-integration-applied.json').write_text(json.dumps({'status':'complete','changes':changes,'scope':'Evaluation/viewer/resume metadata/default-family routing only; the two completed formal training runs retain their original source snapshots and weights.'},indent=2)+'\n');print(json.dumps({'status':'complete','files':len(changes)}))
