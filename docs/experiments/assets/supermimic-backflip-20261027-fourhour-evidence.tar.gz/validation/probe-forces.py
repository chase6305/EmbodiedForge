import json,sys
from pathlib import Path
from types import SimpleNamespace
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');sys.path.insert(0,str(repo/'src'));sys.path.insert(0,str(repo/'runs/supermimic-backflip-20261027-fourhour/probe-retry/implementation'))
import torch
from supermimic.kinematics import G1Kinematics
from supermimic.motion import MotionLib
from supermimic.mdp import MDP
from supermimic.robot import default_joint_pos_list
from supermimic.env import TrackingSim,make_sim
from embodiedforge.workflows.supermimic_reference_mjlab import launch_simulation
from embodiedforge.workflows.supermimic_contacts import ContactRecorder
torch.set_num_threads(1);args=SimpleNamespace(seed=0);cfg=make_sim('cuda:0',args);kin=G1Kinematics('cuda:0');motion=MotionLib([str(repo/'runs/supermimic/tasks/backflip/data/backflip.csv')],kin,'cuda:0',src_fps=50);mdp=MDP(kin,motion,torch.tensor(default_joint_pos_list(),device='cuda:0'));out=repo/'runs/supermimic-backflip-20261027-fourhour/force-probe';out.mkdir(exist_ok=False)
with launch_simulation(cfg,args):
 env=TrackingSim(cfg,1,motion,mdp,eval_mode=True);ids=torch.zeros(1,dtype=torch.long,device='cuda:0');env.reset(ids,ids);recorder=ContactRecorder(env)
 try:
  for _ in range(20):env.step(torch.zeros(1,29,device='cuda:0'))
  result=recorder.save(out);assert result['samples']==80 and result['force_balance_verified'] and result['capacity_overflow_substeps']==0
 finally:recorder.close()
print(json.dumps(result))
