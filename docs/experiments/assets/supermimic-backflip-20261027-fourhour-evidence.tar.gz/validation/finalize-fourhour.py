"""Publish the bounded experiment only after real closure and the four-hour window."""
import datetime,hashlib,io,json,os,shutil,subprocess,sys,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;run=repo/'runs/supermimic-backflip-20261027-fourhour';report_path=repo/'docs/experiments/supermimic-backflip-20261027-fourhour.json';assets=repo/'docs/experiments/assets'
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(path,data):Path(path).write_text(json.dumps(data,indent=2)+'\n')
control=read(r/'control.json');now=datetime.datetime.now(datetime.timezone.utc);deadline=datetime.datetime.fromisoformat(control['deadline']);assert now>=deadline,'Do not declare the4hourworkwindow complete early'
plan=read(r/'final-plan.json');names=['reference-main',plan['second_run']];checks=read(r/'final-check-exits.json');assert checks and all(code==0 for code in checks.values());old=read(r/'history-hashes.json')
for path,expected in old.items():assert sha(repo/path)==expected,path
train_source=read(r/'main-source-hashes.json');final_source=read(r/'final-source-hashes.json')
for path,expected in train_source.items():assert sha(r/'phase-main'/path)==expected,path
for path,expected in final_source.items():assert sha(repo/path)==sha(r/'phase-final'/path)==expected,path
for path,row in read(r/'recovered-smoke-sources.json').items():assert row['expected']==row['recovered']==sha(r/'phase-smoke'/path),path
training={};evaluations={};physical={}
for name in names:
 actual=read(r/('actual-'+name+'-exit.json'));worker=read(run/name/'result.json');outer=read(run/(name+'-supervisor/result.json'));launcher=read(run/name/'launcher.json');config=read(run/name/'worker-config.json');assert actual['actual_tool_exit']==0 and worker['status']=='complete' and launcher['worker_exit_observed'] and launcher['worker_returncode']==0 and outer['exit_observed'] and outer['process_returncode']==0 and not outer['timed_out'];assert worker['finite_model_tensors'] and worker['checkpoint_reload_action_parity'] and worker['policy_updates']>0 and worker['policy_budget_seconds']>=5400
 for path,expected in launcher['launcher_sources'].items():assert sha(r/'phase-main'/path)==expected,(name,path)
 checkpoint=run/name/'logs/last.pt';assert sha(checkpoint)==worker['checkpoint_sha256'];training[name]={'actual_original_tool_exit':actual,'worker':worker,'supervisor':outer,'options':config,'selection':'Actual last completed model, never chosen by checkpoint score'}
 driver=read(r/(name+'-evaluations-original-exit.json'));assert driver['actual_tool_exit']==0
 group=read(r/(name+'-final-evaluations.json'));assert len(group)==3
 for row in group:
  assert row['observed']['driver_wait_returncode']==0 and row['worker']['status']=='complete' and row['worker']['iteration']==worker['iteration'] and row['worker']['checkpoint_sha256']==worker['checkpoint_sha256'];assert row['supervisor']['exit_observed'] and row['supervisor']['process_returncode']==0 and not row['supervisor']['timed_out']
  for artifact_name,digest in row['worker'].get('rollout_artifact_sha256',{}).items():assert sha(run/row['label']/artifact_name)==digest,(row['label'],artifact_name)
  reference_snapshot=row['worker'].get('diagnostic_reference_snapshot')
  if reference_snapshot:assert sha(Path(reference_snapshot['private_path']))==reference_snapshot['sha256']
  runtime=read(run/row['label']/'launcher.json')['launcher_sources'];expected_phase=r/('phase-main' if runtime==train_source else 'phase-final')
  for path,digest in runtime.items():assert sha(expected_phase/path)==digest,(row['label'],path)
 evaluations[name]=group
 measured=[row['worker']['physical_quality'] for row in group if 'physical_quality' in row['worker']]
 audit=run/plan['force_audits'][name]['directory'];assert (audit/'physical-quality.json').exists();proof=read(audit/'physical-quality.json');force=read(audit/'contact-force-audit.json');geometry=read(audit/'airborne-geometry.json');assert sha(audit/'physics-model.mjb')==force['compiled_cpu_geometry_model_sha256']==geometry['model_sha256'];assert read(audit/'result.json')['checkpoint_sha256']==worker['checkpoint_sha256']
 if not measured:
  exit_record=read(r/plan['force_audits'][name]['original_exit_record']);assert exit_record.get('actual_tool_exit')==0 or (exit_record.get('actual_tool_exit') is None and exit_record.get('supervisor_exit_observed') is True and exit_record.get('actual_supervisor_child_wait_returncode')==0);measured=[proof]
 physical[name]={'evaluated_quality_records':measured,'all_assessed_records_passed':all(value['ported_quality_passed'] is True for value in measured),'selected_first_force_audit':{'directory':str(audit.relative_to(repo)),'quality':proof,'forces':force,'geometry':geometry}}
current=names[-1];registry=read(repo/'runs/supermimic/tasks/backflip/reference/current.json');assert registry['checkpoint_sha256']==training[current]['worker']['checkpoint_sha256'];current_quality=all(row['worker'].get('physical_quality',{}).get('ported_quality_passed') is True for row in evaluations[current]);assert not plan.get('promote_reference') or current_quality
# All original jobs must be gone; exclude only this publishing process and its ancestors.
allowed={os.getpid()};pid=os.getppid()
while pid>0 and pid not in allowed:
 allowed.add(pid)
 try:stat=(Path('/proc')/str(pid)/'stat').read_text();tail=stat[stat.rfind(')')+2:].split();pid=int(tail[1])
 except OSError:break
live=[]
for entry in Path('/proc').iterdir():
 if not entry.name.isdigit() or int(entry.name) in allowed:continue
 try:
  cmd=(entry/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
  if str(run) in cmd or str(run.relative_to(repo)) in cmd or str(r) in cmd:live.append({'pid':int(entry.name),'command':cmd})
 except OSError:pass
assert not live,live
identity_checks=[]
for file in ['main-identities.json','seed138-identities.json']:
 for record in read(r/file):
  path=Path('/proc')/str(record['pid'])/'stat'
  try:
   stat=path.read_text();actual_start=int(stat[stat.rfind(')')+2:].split()[19]);same=actual_start==record['start_ticks']
  except OSError:same=False;actual_start=None
  identity_checks.append({'pid':record['pid'],'expected_start_ticks':record['start_ticks'],'current_start_ticks':actual_start,'same_owned_process_alive':same});assert not same,record
query=subprocess.run(['nvidia-smi','--query-compute-apps=pid,used_memory','--format=csv,noheader'],capture_output=True,text=True,timeout=15)
process_audit={'at':now.isoformat(),'scope':'Only this experiment run/private-script prefixes; publishing process/ancestors excluded','matching_live_processes':live,'owned_pid_start_identity_checks':identity_checks,'gpu_compute_process_query':{'actual_wait_returncode':query.returncode,'stdout':query.stdout,'stderr':query.stderr},'signals_sent':0};write(r/'final-process-audit.json',process_audit)
def count_tests(file):
 root=ET.parse(r/file).getroot();suites=list(root.iter('testsuite'));totals={key:sum(int(suite.get(key,0)) for suite in suites) for key in ['tests','failures','errors','skipped']};assert totals['failures']==totals['errors']==0;return totals
report=read(report_path);observed=read(r/'observed-exits.json');report.update(status='complete',completed_at=now.isoformat(),work_window={'requested_hours':4,'started_at':control['started_at'],'deadline':control['deadline'],'actual_elapsed_seconds':(now-datetime.datetime.fromisoformat(control['started_at'])).total_seconds(),'scope':'Four hours of implementation, bounded training and validation work; not four hours of GPU policy training'},training_runs=training,final_evaluations=evaluations,physical_assessments=physical,final_plan=plan,skill_success=current_quality,strict_acceptance='ported_physics_checks_passed' if current_quality else 'ported_physics_checks_failed_or_incomplete',strict_v14_equivalence=False,physical_robot_execution=False,observed_exits=observed,known_failures=[row for row in observed if row.get('actual_tool_exit') not in (None,0)],final_checks={'actual_exits':checks,'related_tests':count_tests('final-tests.xml'),'documentation_tests':count_tests('final-documentation.xml'),'wheel':read(r/'package-final-validation.json')},source_phases={'training':train_source,'final_evaluation':final_source,'note':'Two training runs retain the recorded training source. Later evaluation/viewer/metadata integration does not alter saved policy weights.'},history_preservation={'verified_files':len(old),'all_unchanged':True},final_process_audit=process_audit)
def measured_range(values):
 return [min(values),max(values)] if values and all(value is not None for value in values) else None
summary_rows=[]
for name in names:
 group=evaluations[name];leg=[row['diagnostics']['fixed_window_pose']['hip_knee_rmse_deg'] for row in group];span=[row['diagnostics']['fixed_window_pose']['max_ankle_separation_m'] for row in group];summary_rows.append({'run':name,'training_seed':training[name]['options']['seed'],'last_iteration':training[name]['worker']['iteration'],'policy_updates':training[name]['worker']['policy_updates'],'policy_budget_seconds':training[name]['worker']['policy_budget_seconds'],'process_repeats':len(group),'fixed_window_hip_knee_rmse_deg_range':measured_range(leg),'max_ankle_separation_m_range':measured_range(span),'completed_physical_audits':len(physical[name]['evaluated_quality_records']),'all_completed_physical_audits_passed':physical[name]['all_assessed_records_passed']})
report['final_optimizer_audit']=read(r/'final-optimizer-audit.json')
report['readable_summary']={'current_run':current,'prior_pose_rmse_deg':report['baseline']['diagnostics']['fixed_window_pose']['hip_knee_rmse_deg'],'prior_max_ankle_separation_m':report['baseline']['diagnostics']['fixed_window_pose']['max_ankle_separation_m'],'independent_training_runs':summary_rows,'same_model_process_repeats_are_not_independent_training_seeds':True,'hardware_tested':False}
report.pop('active_training',None);report.pop('latest_health',None);report['updated_at']=now.isoformat();report.pop('remaining_work',None);report['progress_plot']='assets/supermimic-backflip-20261027-fourhour-comparison.svg';report['local_final_video']=str((run/(current+'-final-video/policy.mp4')).relative_to(repo));report['limitations']=['The two runs use equal90minute policy wall budgets, not equal update counts. Compilation/cache/runtime timing changes the realized iteration count; this is not a matched-update seed-only ablation.','Current mjlabG1assets, solver, reduced batches and evaluation timestamp count differ from the referenced IsaacLab3experiment; this is not official weights or exactV14reproduction.','Independent training seeds are reported separately; fixed-seed process repeats do not supply confidence intervals or broad motion generalization.','Native rewards differ across recipes and extra static hold changes means. Compare the physical pose/airborne/contact gates, not cross-recipe mean returns.','Compiled CPU model is used for geometry only; solved forces come from actual device constraints, including device-side material values. No hardware execution.','Intermediate6000passed but final selection always uses actual last completed checkpoints; all observed failures and repeat variation remain retained.']
if plan.get('promote_reference'):
 sys.path.insert(0,str(repo/'src'))
 from embodiedforge.workflows.supermimic_reference import activate_preference
 activate_preference(repo,basis_report=str(report_path.relative_to(repo)),checkpoint_sha256=registry['checkpoint_sha256'])
 activation=[]
 for label,command in [('doctor',['doctor','--task','backflip']),('play-dry-run',['--task','backflip','--dry-run']),('legacy-doctor',['doctor','--task','backflip','--recipe','cuboi'])]:
  child=subprocess.run([str(repo/'supermimic'),*command],cwd=repo,text=True,capture_output=True,timeout=30);assert child.returncode==0,(label,child.stdout,child.stderr);data=json.loads(child.stdout);activation.append({'label':label,'actual_wait_returncode':child.returncode,'result':data});write(r/('activation-'+label+'.json'),activation[-1])
 assert activation[1]['result']['recipe']=='reference' and activation[1]['result']['checkpoint']==str(run/current/'logs/last.pt');report['default_recipe_activation']=activation
else:report['default_recipe_activation']='Not activated because the actual current last model lacks complete positive acceptance'
# Stage a checksum-free scalar summary inside the archive; canonical report records archive digest afterward.
write(r/'final-scalar-summary.json',{key:report[key] for key in ['status','completed_at','work_window','skill_success','strict_acceptance','strict_v14_equivalence','final_checks','physical_assessments']})
assets.mkdir(exist_ok=True);shutil.copyfile(r/'fourhour-comparison.svg',assets/'supermimic-backflip-20261027-fourhour-comparison.svg');archive=assets/'supermimic-backflip-20261027-fourhour-evidence.tar.gz';members={}
def add(path,name):
 path=Path(path);assert path.is_file() and path.suffix.lower() not in {'.pt','.npz','.mjb','.mp4','.stl','.whl','.png'};assert path.stat().st_size<50_000_000;members[name]=path.read_bytes()
for path in sorted(run.rglob('*')):
 if path.is_file() and path.suffix in {'.json','.jsonl','.log','.py','.yaml','.yml'} and '__pycache__' not in path.parts:add(path,'runs/'+str(path.relative_to(run)))
for path in sorted(r.iterdir()):
 if path.is_file() and path.suffix in {'.py','.json','.jsonl','.log','.xml'}:add(path,'validation/'+path.name)
for phase in ['baseline','phase-smoke','phase-main','phase-force-v1','phase-evaluation-prototype','phase-staged','phase-final']:
 for path in sorted((r/phase).rglob('*')):
  if path.is_file() and '__pycache__' not in path.parts:add(path,'sources/'+phase+'/'+str(path.relative_to(r/phase)))
for pattern in ['src/embodiedforge/workflows/supermimic*.py','src/embodiedforge/runtime/*.py','tests/test_supermimic*.py']:
 for path in sorted(repo.glob(pattern)):add(path,'sources/final/'+str(path.relative_to(repo)))
for name in ['supermimic','src/embodiedforge/__init__.py','src/embodiedforge/supermimic.py','src/embodiedforge/supermimic_run.py','tests/test_architecture.py','tests/test_hashing.py','tests/test_import_boundaries.py','tests/test_runtime_provenance.py','tests/test_sdk_boundaries.py','benchmarks/supermimic_reference.py','benchmarks/process_supervisor.py','pyproject.toml','docs/supermimic.md','docs/experiments/README.md','README.md'] :add(repo/name,'sources/final/'+name)
for path in sorted((repo/'.cache/external/supermimic-vibed/supermimic').glob('*.py')):add(path,'upstream/vibed/'+path.name)
for path,name in [(repo/'.cache/external/supermimic-vibed/LICENSE','vibed-MIT'),(repo/'.cache/external/supermimic-backflip-5090/LICENSE','backflip-reference-MIT'),(repo/'.cache/external/mjbatch/LICENSE','mjbatch-Apache-2.0'),(repo/'.cache/external/supermimic-reproduced/LICENSE','Cuboi-MIT')]:add(path,'licenses/'+name)
for name in ['current.json','reference/current.json','reference/preferred.json','data/provenance.json']:
 path=repo/'runs/supermimic/tasks/backflip'/name
 if path.is_file():add(path,'registries/backflip/'+name)
add(repo/'src/embodiedforge/workflows/LICENSE.supermimic-backflip','sources/final/src/embodiedforge/workflows/LICENSE.supermimic-backflip');add(r/'fourhour-comparison.svg','derived/fourhour-comparison.svg')
for name in names:
 for path in (run/name/'logs').glob('*.csv'):add(path,'derived/'+name+'-'+path.name)
members['README.txt']=b'Actual bounded SuperMimic/mjlab backflip optimization. Native rewards across recipes are not interchangeable. All source phases, original failures and actual process exits are retained. Checkpoints, raw motion arrays/CSVs, compiled robot models, SDK, meshes and video are excluded. Derived training CSVs contain scalar diagnostics only. Fixed-window, airborne and200Hzforce gates are a conservative mjlab port, not exactV14or hardware acceptance.\n';manifest={name:hashlib.sha256(data).hexdigest() for name,data in sorted(members.items())};members['SHA256SUMS.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with tarfile.open(archive,'w:gz') as target:
 for name,data in sorted(members.items()):
  entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.mtime=0;target.addfile(entry,io.BytesIO(data))
with tarfile.open(archive) as opened:
 assert len(opened.getmembers())==len(members) and all(member.isfile() for member in opened.getmembers())
 for name,data in members.items():assert hashlib.sha256(opened.extractfile(name).read()).hexdigest()==hashlib.sha256(data).hexdigest(),name
 assert json.loads(opened.extractfile('SHA256SUMS.json').read())==manifest
report['evidence']={'path':str(archive.relative_to(repo/'docs/experiments')),'sha256':sha(archive),'members':len(members),'every_member_verified':True,'excluded':['weights','raw motion CSV/NPZ','compiled MJB robot models','SDK','meshes','videos/frames','private agent state notes']};write(report_path,report);print(json.dumps({'status':'complete','work_elapsed_seconds':report['work_window']['actual_elapsed_seconds'],'current_run':current,'skill_success':report['skill_success'],'exact_v14':False,'archive_members':len(members),'archive_sha256':report['evidence']['sha256']}))
