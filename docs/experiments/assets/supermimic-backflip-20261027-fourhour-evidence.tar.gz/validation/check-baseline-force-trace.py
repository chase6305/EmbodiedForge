from pathlib import Path
import json,numpy as np
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent
with np.load(repo/'runs/supermimic-backflip-20261027/main-eval-r1/backflip-rollout.npz',allow_pickle=False) as d:old=d['state'].astype(np.float64)
with np.load(repo/'runs/supermimic-backflip-20261027-fourhour/baseline-force/backflip-rollout.npz',allow_pickle=False) as d:new=d['state'].astype(np.float64)
assert old.shape==new.shape==(571,71);delta=np.abs(old-new);result={'status':'complete','source_states':571,'audit_states':571,'same_original50Hztimestamps':True,'max_qpos_difference':float(delta[:,:36].max()),'max_qvel_difference':float(delta[:,36:].max()),'notes':'Actual new force-audited rollout vs the previous normal CUDA-graph rollout; no posthoc state alignment or time shift. Precision differences are reported, not silently projected away.'};(r/'baseline-force-trace-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
