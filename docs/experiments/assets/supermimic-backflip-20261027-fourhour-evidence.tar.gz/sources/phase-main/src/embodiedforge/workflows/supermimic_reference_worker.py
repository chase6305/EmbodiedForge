"""Run the complete independent SuperMimic recipe in the dedicated SDK."""

import importlib.metadata
import json
import runpy
import sys
from pathlib import Path

from embodiedforge.runtime.artifacts import write_json
from embodiedforge.runtime.hashing import snapshot_file_hashes
from embodiedforge.runtime.provenance import validate_snapshot
from embodiedforge.supermimic import matches_version
from embodiedforge.workflows import supermimic_backflip as backflip
from embodiedforge.workflows.supermimic_catalog import REFERENCES
from embodiedforge.workflows.supermimic_reference import freeze_reference


def save_actual_state(env):
    import torch

    row = torch.cat((env.sim.data.qpos[:], env.sim.data.qvel[:]), -1).clone()
    row[:, :3] -= env.origins
    return row


def evaluate(options, output, motion_csv):
    import numpy as np
    import supermimic.networks as networks
    import torch
    from supermimic.env import TrackingSim, make_sim
    from supermimic.kinematics import G1Kinematics
    from supermimic.mdp import MDP, OBS_DIM
    from supermimic.motion import MotionLib
    from supermimic.networks import Policy
    from supermimic.robot import default_joint_pos_list

    from embodiedforge.workflows.supermimic_reference_mjlab import launch_simulation

    saved = torch.load(options["checkpoint"], map_location="cpu", weights_only=False)
    args = saved["args"]
    if not {"pi", "wm", "iteration", "args"}.issubset(saved) or "config" in saved:
        raise ValueError(
            "Expected an owned reference-recipe checkpoint, not a Cuboi model"
        )
    networks.AMP_DTYPE = torch.bfloat16 if args.get("amp", "none") == "bf16" else None
    torch.manual_seed(0)
    kin = G1Kinematics("cuda:0")
    motion = MotionLib([str(motion_csv)], kin, "cuda:0", src_fps=50)
    mdp = MDP(kin, motion, torch.tensor(default_joint_pos_list(), device="cuda:0"))
    policy = Policy(OBS_DIM, 73 * args["goal_frames"], hist=args["hist"]).to("cuda:0")
    policy.load_state_dict(saved["pi"])
    policy.eval()
    from types import SimpleNamespace

    config = make_sim("cuda:0", SimpleNamespace(seed=0))
    history = torch.zeros(1, args["hist"], OBS_DIM, device="cuda:0")
    states, rewards = [], []
    failed, finished = False, False
    with launch_simulation(config, args):
        env = TrackingSim(config, 1, motion, mdp, eval_mode=True)
        env.reset(
            torch.zeros(1, dtype=torch.long, device="cuda:0"),
            frames=torch.zeros(1, dtype=torch.long, device="cuda:0"),
        )
        states.append(save_actual_state(env)[0].cpu().numpy())
        with torch.no_grad():
            for step in range(motion.num_frames - 1):
                observation = mdp.obs(env.state(), env.a_prev, env.xi, env.f)
                history = (
                    observation[:, None].expand_as(history).clone()
                    if step == 0
                    else torch.cat((history[:, 1:], observation[:, None]), 1)
                )
                result = env.step(
                    policy(history, motion.goal(env.f, args["goal_frames"]))
                )
                states.append(save_actual_state(env)[0].cpu().numpy())
                rewards.append(float(result["r"][0]))
                failed, finished = bool(result["term"][0]), bool(result["done"][0])
                if failed or finished:
                    break
    state = np.stack(states)
    np.savez(
        output / "backflip-rollout.npz", state=state, time_s=np.arange(len(state)) / 50
    )
    reference = backflip.task_directory(options["workspace"]) / "data/eval/backflip.npz"
    diagnostics = backflip.diagnose_rollout(
        state,
        reference,
        output,
        not failed and finished and len(state) == motion.num_frames,
    )
    result = {
        "iteration": saved["iteration"],
        "goal_dim": 73 * args["goal_frames"],
        "obs_dim": OBS_DIM,
        "summary": {
            "mean_norm_return": sum(rewards) / (0.1 * len(rewards)),
            "full_clip_zero_padded_return": sum(rewards)
            / (0.1 * (motion.num_frames - 1)),
            "failed": int(failed or not finished),
            "executed_control_steps": len(rewards),
            "actual_state_samples": len(state),
        },
        "backflip_diagnostics": diagnostics,
        "skill_success": diagnostics["skill_success"],
        "strict_backflip_acceptance": "not_assessed",
        "evaluation_protocol": "Initial state plus actual post-step states at50Hz;570actions cover571reference timestamps from0to11.4s. No auto-reset or motion retiming. Analytic next-frame rewards differ from the Cuboi simulator reward protocol; compare saved-state quality metrics, not return across recipes.",
    }
    return result


def main(config):
    options = json.loads(Path(config).read_text())
    output, workspace = Path(options["output"]), Path(options["workspace"])
    record = {
        "status": "preparing",
        "recipe": "reference",
        "method": "SuperMimic",
        "backend": "mjlab",
        "official_weights_used": False,
    }
    write_json(output / "result.json", record)
    try:
        reference = REFERENCES["cuboi-reproduced"]
        versions = {
            name: importlib.metadata.version(name) for name in reference["dependencies"]
        }
        if sys.version_info[:2] != (3, 12) or any(
            not matches_version(versions[name], constraint)
            for name, constraint in reference["dependencies"].items()
        ):
            raise ValueError(
                "Reference/mjlab bridge requires the existing pinned SuperMimic SDK"
            )
        origin = json.loads(
            importlib.metadata.distribution("mjlab").read_text("direct_url.json")
        )
        if origin["vcs_info"]["commit_id"] != reference["framework"]["revision"]:
            raise ValueError("mjlab framework revision changed")
        data = backflip.task_directory(workspace) / "data"
        provenance = backflip.prepared(data)
        canonical = (data / "backflip.csv").read_bytes()
        if snapshot_file_hashes(data / "backflip.csv")[0] != backflip.CSV_SHA256:
            raise ValueError("Canonical backflip CSV changed")
        extended = options["action"] == "eval"
        lines = canonical.splitlines(keepends=True)
        if len(lines) != 321 or not canonical.endswith(b"\n"):
            raise ValueError("Expected321canonical50Hzframes")
        inputs = output / "inputs"
        inputs.mkdir()
        csv = inputs / "backflip.csv"
        csv.write_bytes(canonical + (lines[-1] * 250 if extended else b""))
        csv.chmod(0o444)
        csv_sha = snapshot_file_hashes(csv)[0]
        manifest = freeze_reference(workspace, output)
        sys.path.insert(0, str(output / "implementation"))
        import torch
        from mjlab.asset_zoo.robots.unitree_g1.g1_constants import G1_XML

        torch.set_num_threads(1)
        if not torch.cuda.is_available():
            raise ValueError("Reference recipe requires CUDA")
        assets = {
            str(p.relative_to(G1_XML.parent.parent)): snapshot_file_hashes(p)[0]
            for p in sorted(G1_XML.parent.parent.rglob("*"))
            if p.is_file() and "__pycache__" not in p.parts
        }
        record.update(
            environment={
                "python": sys.version,
                "packages": versions,
                "mjlab_origin": origin,
                "gpu": torch.cuda.get_device_name(0),
            },
            g1_assets=assets,
            motion_input_snapshot={
                "canonical_sha256": backflip.CSV_SHA256,
                "source_sha256": provenance["source_sha256"],
                "private_csv_sha256": csv_sha,
                "frames": 571 if extended else 321,
                "fps": 50,
                "read_only": True,
            },
            reference_adapter=manifest,
        )
        if (
            options["checkpoint"] is not None
            and snapshot_file_hashes(options["checkpoint"])[0]
            != options["checkpoint_sha256"]
        ):
            raise ValueError("Checkpoint changed before SDK execution")
        write_json(output / "result.json", record)
        if options["action"] == "train":
            smoke = options["profile"] == "smoke"
            script = output / "implementation/supermimic/train.py"
            if smoke:
                source = script.read_text().replace(
                    "torch.compile(", "(lambda function: function)("
                )
                script.write_text(source)
                manifest["adapted_manifest"]["files"]["train.py"] = (
                    snapshot_file_hashes(script)[0]
                )
                write_json(output / "reference-adapter.json", manifest)
            argv = [
                str(script),
                "--num_envs",
                str(options["num_envs"]),
                "--iterations",
                str(options["iterations"]),
                "--motion_dir",
                str(inputs),
                "--log_dir",
                str(output / "logs"),
                "--seed",
                str(options["seed"]),
                "--max_policy_minutes",
                str(options["hours"] * 60),
                "--wm_batch",
                str(32 if smoke else min(options["num_envs"], 1024)),
                "--pi_batch",
                str(8 if smoke else min(options["num_envs"], 1024)),
                "--warmup_steps",
                "20" if smoke else "64",
                "--wm_only_iters",
                "4" if smoke else "500",
                "--wm_batches",
                "2" if smoke else "10",
                "--wm_window",
                "2" if smoke else "8",
                "--horizon",
                "4" if smoke else "32",
                "--ckpt_every",
                "1000",
                "--log_every",
                "1" if smoke else "50",
            ]
            if options["checkpoint"]:
                argv += ["--resume", options["checkpoint"]]
            record.update(status="training", training_command=argv, smoke_only=smoke)
            write_json(output / "result.json", record)
            sys.argv = argv
            runpy.run_path(str(script), run_name="__main__")
            integrity = json.loads(
                (output / "logs/training-integrity.json").read_text()
            )
            if integrity["policy_updates"] <= 0:
                raise ValueError("No actual SuperMimic policy updates executed")
            record.update(
                integrity,
                checkpoint_sha256=snapshot_file_hashes(output / "logs/last.pt")[0],
            )
        else:
            record.update(
                evaluate(options, output, csv),
                checkpoint_sha256=options["checkpoint_sha256"],
            )
        validate_snapshot(
            output / "implementation/supermimic", manifest["adapted_manifest"]
        )
        if snapshot_file_hashes(csv)[0] != csv_sha:
            raise ValueError("Private backflip input changed during execution")
        if (
            options["checkpoint"] is not None
            and snapshot_file_hashes(options["checkpoint"])[0]
            != options["checkpoint_sha256"]
        ):
            raise ValueError("Resume/evaluation checkpoint changed during execution")
        for name, expected in assets.items():
            if snapshot_file_hashes(G1_XML.parent.parent / name)[0] != expected:
                raise ValueError(f"G1 asset changed during execution: {name}")
        record["status"] = "complete"
        print(
            json.dumps(
                {
                    "status": "complete",
                    "iteration": record["iteration"],
                    "recipe": "reference",
                }
            ),
            flush=True,
        )
        return 0
    except BaseException as error:
        record.update(status="failed", error=f"{type(error).__name__}: {error}")
        raise
    finally:
        write_json(output / "result.json", record)
