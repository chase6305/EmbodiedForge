"""Fresh seeded IEEE bit patterns, unusual strides and strict FP modes."""
import gc,itertools,json,os,time,warnings
import numpy as np
from common import CLASSES,ROOT,StateSnapshot,atomic,fingerprint,guard,pin,sha
pin(4);guard();start=time.time();cases=0;fail={};seen_warnings=set();seen_errors=set()
layouts=('C','F','reverse_rows','reverse_columns','reverse_both','broadcast','unaligned')
def field(rng,count,layout,profile):
 if profile=='finite':value=rng.normal(size=(count,2))
 elif profile=='raw':value=rng.integers(0,2**64,size=(count,2),dtype=np.uint64).view(np.float64)
 else:
  bits=np.array([0,2**63,0x7ff0000000000000,0xfff0000000000000,0x7ff8000000000081,0x7ff0000000000081,1,0x8000000000000001,0x7fefffffffffffff,0xffefffffffffffff,0x380fffffe0000000,0x3810000010000000],np.uint64)
  value=np.resize(rng.permutation(bits),(count,2)).view(np.float64)
 if layout=='F':value=np.asfortranarray(value)
 elif layout=='reverse_rows':value=value[::-1]
 elif layout=='reverse_columns':value=value[:,::-1]
 elif layout=='reverse_both':value=value[::-1,::-1]
 elif layout=='broadcast':value=np.broadcast_to(value[:1] if count else np.zeros((1,2)),(count,2))
 elif layout=='unaligned':
  other=np.ndarray(value.shape,dtype=np.float64,buffer=bytearray(value.nbytes+1),offset=1);other[:]=value;value=other
 value.flags.writeable=False;return value
try:
 for repeat,(taskname,count,layout,profile,mode) in itertools.product(range(4),itertools.product(('reach','hold'),(0,1,1023,1024,4097),layouts,('finite','raw','targeted'),('ignore','warn','raise'))):
  seed=82100000+cases;rng=np.random.default_rng(seed);position,velocity,target=[field(rng,count,layout,profile) for _ in range(3)];inputs=dict(position=position,velocity=velocity,target=target);before=fingerprint(inputs);results={}
  fail=dict(seed=seed,repeat=repeat,task=taskname,count=count,layout=layout,profile=profile,mode=mode)
  for version in ('initial','current'):
   task=CLASSES[version][taskname]();task.build(count);task.target=target;state=StateSnapshot(position,velocity,np.zeros(count),np.zeros(count,np.int64))
   with warnings.catch_warnings(record=True) as records,np.errstate(all=mode):
    warnings.simplefilter('always')
    try:
     out=task.observe(state)['proprio'];result=dict(status='passed',dtype=out.dtype.str,shape=out.shape,data=out.tobytes(),kind=type(out).__name__,owned=bool(out.flags.owndata),order=(bool(out.flags.c_contiguous),bool(out.flags.f_contiguous)))
     assert all(not np.shares_memory(out,v) for v in inputs.values());out[:]=99;del out
    except FloatingPointError as e:result=dict(status='floating_point_error',message=str(e));seen_errors.add(str(e))
    result['warnings']=[(x.category.__name__,str(x.message)) for x in records];seen_warnings.update(str(x.message) for x in records)
   assert fingerprint(inputs)==before,(version,'input bytes changed');results[version]=result
  assert results['initial']==results['current'],(fail,{k:{n:v for n,v in d.items() if n!='data'} for k,d in results.items()})
  cases+=1
  if cases%630==0:guard();gc.collect()
 guard();d=dict(status='passed',cases=cases,started_epoch=start,elapsed_seconds=time.time()-start,python=__import__('platform').python_version(),numpy=np.__version__,script_sha256=sha(__import__('pathlib').Path(__file__)),common_sha256=sha(ROOT/'scripts/common.py'),runtime_source_sha256=__import__('common').source_map(),fresh_seed_per_case=True,layouts=layouts,profiles=['finite','raw uint64 interpreted as float64','targeted signed zero, subnormal, infinity, quiet/signaling NaN payloads, extreme and midpoint values'],fp_modes=['ignore','warn','raise'],observed_warning_messages=sorted(seen_warnings),observed_floating_errors=sorted(seen_errors))
 atomic(ROOT/('adversarial-py'+d['python']+'-numpy'+d['numpy']+'.json'),d);print(json.dumps({k:v for k,v in d.items() if k!='runtime_source_sha256'}))
except BaseException as e:
 np.savez(ROOT/'adversarial-failure-input.npz',**inputs);atomic(ROOT/'adversarial-failure.json',dict(status='failed',case=fail,cases=cases,error=repr(e)));raise
