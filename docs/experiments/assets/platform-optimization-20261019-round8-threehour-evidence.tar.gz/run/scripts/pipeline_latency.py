"""Independent warm steady-state full-step timing to investigate noisy regressions."""
import json,os,platform,statistics,time
from pathlib import Path
import numpy as np
from common import ROOT,environment,equal,fingerprint,guard,pin,sha,source_map
pin(5);guard();started=time.time();rows=[];pairs=63;loops=128
for task in ('reach','hold'):
 for count in (1024,8192):
  objects={v:environment(v,task,count) for v in ('initial','current')};action=np.zeros((count,2));action.flags.writeable=False;samples={v:[] for v in objects};last={}
  try:
   for env in objects.values():
    for _ in range(16):env.step(action)
   for pair in range(pairs):
    for version in (('initial','current') if pair%2==0 else ('current','initial')):
     env=objects[version];tick=time.perf_counter()
     for _ in range(loops):
      result=env.step(action);values={**result.observation,'reward':result.reward,'terminated':result.terminated,'truncated':result.truncated};del values
     samples[version].append((time.perf_counter()-tick)/loops);last[version]={**result.observation,'reward':result.reward,'terminated':result.terminated,'truncated':result.truncated}
    equal(last['initial'],last['current'])
   med={v:statistics.median(x) for v,x in samples.items()};row=dict(task=task,num_envs=count,seconds=samples,median_seconds=med,elapsed_reduction_percent=100*(1-med['current']/med['initial']),output_sha256=fingerprint(last['current']));rows.append(row);print(task,count,round(row['elapsed_reduction_percent'],2),flush=True)
  finally:
   for env in objects.values():env.close()
  guard()
d=dict(status='passed',started_epoch=started,finished_epoch=time.time(),python=platform.python_version(),numpy=np.__version__,cpu_affinity=sorted(os.sched_getaffinity(0)),pairs=pairs,steps_per_sample=loops,warmup_steps_per_environment=16,runtime_source_sha256=source_map(),initial_source_sha256=sha(ROOT/'initial/src/embodiedforge/tasks.py'),script_sha256={'scripts/pipeline_latency.py':sha(Path(__file__)),'scripts/common.py':sha(ROOT/'scripts/common.py')},cases=rows,scope='Independent confirmation with reused warm initial/current environments, pinned CPU 5 on the same shared host. Time includes complete camera-free step and result packaging, excludes construction, warmup and output byte comparisons; no tracing. All signed samples retained. This follow-up does not replace the original 44-case reports or erase their negative samples.')
p=ROOT/('pipeline-latency-confirmation-py'+d['python']+'-numpy'+d['numpy']+'.json');p.write_text(json.dumps(d,indent=2)+'\n');print(p.name,flush=True)
