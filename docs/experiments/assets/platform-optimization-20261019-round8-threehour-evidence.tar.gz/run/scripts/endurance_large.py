"""Additional 8192-row camera-free full-step differential endurance."""
import argparse,errno,itertools,json,os,sys,threading,time,traceback,weakref
from pathlib import Path
import numpy as np
from embodiedforge.core import StateSnapshot
from common import ROOT,CLASSES,arrays,environment,equal,fingerprint,source_map,guard,read,sha,atomic,pin
parser=argparse.ArgumentParser();parser.add_argument('--name',required=True);parser.add_argument('--scope',choices=('task','environment'),required=True);parser.add_argument('--cpu',type=int,required=True);parser.add_argument('--smoke',type=int,default=0);parser.add_argument('--inject-failure',action='store_true');parser.add_argument('--inject-write-failure',action='store_true');args=parser.parse_args()
assert not (args.inject_failure or args.inject_write_failure) or args.smoke>0
RAM_ROOT=Path('/dev/shm')/ROOT.name;RAM_ROOT.mkdir(exist_ok=True);persistence_events=[]
def stderr(message):
 try:print(message,file=sys.stderr,flush=True)
 except OSError:pass
def persist(path,data):
 mirror=RAM_ROOT/path.relative_to(ROOT);mirror.parent.mkdir(parents=True,exist_ok=True);atomic(mirror,data)
 try:
  if args.inject_write_failure:raise OSError(errno.ENOSPC,'Injected root filesystem write failure')
  atomic(path,data)
 except OSError as error:
  if error.errno not in (errno.ENOSPC,errno.EDQUOT,errno.EIO):raise
  event=dict(epoch=time.time(),path=str(path),errno=error.errno,error=str(error));persistence_events.append(event);atomic(mirror,data);stderr(json.dumps(dict(artifact_write_interruption=event,ram_mirror=str(mirror))))
own_script_sha=sha(Path(__file__))
pin(args.cpu);started=time.time();stop=read(ROOT/'state.json')['probe_stop_epoch'];cases=0;covered=set();resources=[];last_progress=last_guard=0;failure_context={}
class Numeric(np.ndarray):pass
class OpaqueSize(Numeric):
 @property
 def size(self):raise RuntimeError('Subclass size must not be inspected')

def task_case(index,config):
 count,task_name,kind,layout,mode=config;rng=np.random.default_rng(810000+index)
 dtype={'subclass':'float64','mixed':'float64','opaque_size':'float64'}.get(kind,kind)
 fields=arrays(count,'C',dtype,810000+index)
 if kind=='mixed':
  fields=[np.full((count,2),2**63+2**39+1,np.uint64),rng.integers(-10,10,(count,2),dtype=np.int64),np.full((count,2),2**63+2**39+1,np.uint64)]
 elif mode=='special' and np.dtype(dtype).kind=='f':
  for i,v in enumerate(fields):
   values=np.array([0.,-0.,np.inf,-np.inf,np.nan,np.finfo(v.dtype).max,np.finfo(v.dtype).tiny],dtype=v.dtype)
   fields[i]=np.resize(values,(count,2))
 for i,v in enumerate(fields):
  if layout=='F':v=np.asfortranarray(v)
  elif layout=='strided':v=np.repeat(v,2,axis=0)[::2]
  if kind=='subclass':v=v.view(Numeric)
  elif kind=='opaque_size':v=v.view(OpaqueSize)
  v.flags.writeable=False;fields[i]=v
 if mode=='alias':fields[2]=fields[0]
 position,velocity,target=fields;state=StateSnapshot(position,velocity,np.zeros(count),np.zeros(count,np.int64))
 inputs=dict(position=position,velocity=velocity,target=target,time=state.time,version=state.version);before=fingerprint(inputs)
 global failure_context
 failure_context={**{'before/'+k:v.copy() for k,v in inputs.items()},'case':np.array(index),'configuration':np.array(json.dumps(config))}
 pair=[CLASSES[v][task_name]() for v in ('initial','current')]
 for task in pair:task.target=target
 with np.errstate(all='ignore'):
  expected=pair[0].observe(state);assert fingerprint(inputs)==before,'Initial task changed input bytes'
  actual=pair[1].observe(state);assert fingerprint(inputs)==before,'Current task changed input bytes'
  failure_context.update({'initial/'+k:v for k,v in expected.items()});failure_context.update({'current/'+k:v for k,v in actual.items()})
  failure_context.update({'after/'+k:v for k,v in inputs.items()})
  if args.inject_failure:actual['proprio'][0,0]+=1
  equal(expected,actual)
  a,b=expected['proprio'],actual['proprio'];assert a.flags.owndata==b.flags.owndata and a.strides==b.strides
  for value in (a,b):
   for input_value in inputs.values():assert not np.shares_memory(value,input_value)
  expected_bytes=a.tobytes();a[:]=99;b[:]=99
  assert pair[0].observe(state)['proprio'].tobytes()==expected_bytes
  assert pair[1].observe(state)['proprio'].tobytes()==expected_bytes
 assert fingerprint(inputs)==before and all(not v.flags.writeable for v in fields)
 refs=[weakref.ref(v) for v in (*pair,state,*inputs.values(),a,b)];failure_context={};return refs

def result_fields(r):return {**{'obs/'+k:v for k,v in r.observation.items()},'reward':r.reward,'terminated':r.terminated,'truncated':r.truncated,**{'info/'+k:v for k,v in r.info.items()}}
def environment_case(index,config):
 task_name,count,substeps,channels=config;pair=[environment(v,task_name,count,substeps,channels,820000+index) for v in ('initial','current')];rng=np.random.default_rng(830000+index)
 global failure_context
 for step in range(12):
  action=rng.uniform(-.1,.1,(count,2));action.flags.writeable=False;before=action.tobytes()
  if step%3==0:
   for env in pair:env.terminated[::4]=True;env.truncated[2::4]=True
  failure_context={'action':action,'case':np.array(index),'step':np.array(step),'configuration':np.array(json.dumps(config))}
  for label,env in zip(('initial','current'),pair,strict=True):
   failure_context.update({'before_'+label+'/'+k:v.copy() for k,v in vars(env.physics.snapshot()).items()});failure_context['before_'+label+'/target']=env.task.target.copy()
  results=[env.step(action) for env in pair];initial,current=map(result_fields,results)
  failure_context.update(initial);failure_context.update({'current/'+k:v for k,v in current.items()});equal(initial,current);assert action.tobytes()==before
  for r in results:
   for v in result_fields(r).values():assert v.flags.owndata
  if step in (3,7):
   ids=np.arange(1,count,3)[::-1];obs=[env.reset(ids) for env in pair];equal(obs[0],obs[1])
  equal(pair[0].observe(),pair[1].observe())
 refs=[weakref.ref(env) for env in pair]+[weakref.ref(v) for r in results for v in result_fields(r).values()]
 for env in pair:env.close()
 failure_context={};return refs

if args.scope=='task':configs=list(itertools.product((0,1,8191,8192,8193,16384),('reach','hold'),('float64','float32','float16','>f8','int64','mixed','subclass','longdouble','opaque_size'),('C','F','strided'),('normal','special','alias')))
else:configs=list(itertools.product(('reach','hold'),(8192,),(1,4,16),((),)))
np.random.default_rng(819).shuffle(configs)
report=dict(status='running',name=args.name,scope=args.scope,pid=os.getpid(),started_epoch=started,python=__import__('platform').python_version(),numpy=np.__version__,cpu_affinity=sorted(os.sched_getaffinity(0)),base_configurations_expected=len(configs),runtime_source_sha256=source_map(),script_sha256={f'scripts/{n}':sha(ROOT/'scripts'/n) for n in ('endurance_large.py','common.py')},resources=resources,ram_evidence_directory=str(RAM_ROOT),persistence_events=persistence_events)
def resource():return dict(fds=len(list(Path('/proc/self/fd').iterdir())),python_threads=threading.active_count(),os_threads=len(list(Path('/proc/self/task').iterdir())))
def progress(status='running'):
 global last_progress
 assert sha(Path(__file__))==own_script_sha,'Large-cohort harness drift'
 now=time.time();resources.append(dict(epoch=now,**resource()))
 for key in ('fds','python_threads','os_threads'):assert len({r[key] for r in resources})==1,key
 report.update(status=status,updated_epoch=now,elapsed_seconds=now-started,cases=cases,configuration_count=len(covered));persist(ROOT/(args.name+'-progress.json'),report);last_progress=now
try:
 guard();progress()
 while (cases<args.smoke if args.smoke else time.time()<stop):
  config=(8192,'reach','float64','C','normal') if args.inject_failure else configs[cases%len(configs)]
  refs=(task_case if args.scope=='task' else environment_case)(cases,config);assert all(ref() is None for ref in refs),'Completed case retained objects or buffers'
  covered.add(cases%len(configs));cases+=1;now=time.time()
  if now-last_guard>60:guard();last_guard=now
  if now-last_progress>20:progress()
 guard();progress('passed');report['finished_epoch']=time.time();persist(ROOT/(args.name+'.json'),report)
except BaseException:
 original=traceback.format_exc();stderr(original)
 if failure_context:
  path=RAM_ROOT/(args.name+'-failure-input.npz');path.parent.mkdir(parents=True,exist_ok=True);np.savez_compressed(path,**failure_context)
  try:(ROOT/(args.name+'-failure-input.npz')).write_bytes(path.read_bytes())
  except OSError as error:stderr(json.dumps(dict(failure_capture_copy_error=str(error),ram_capture=str(path))))
 report.update(status='failed',cases=cases,configuration_count=len(covered),finished_epoch=time.time(),traceback=original);persist(ROOT/(args.name+'-failure.json'),report);raise
