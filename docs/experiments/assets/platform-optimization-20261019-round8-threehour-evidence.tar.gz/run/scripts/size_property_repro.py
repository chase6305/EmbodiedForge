"""Reproduce the candidate's unintended ndarray-subclass size inspection."""
import hashlib,importlib.util,json
import numpy as np
from pathlib import Path
from embodiedforge.core import StateSnapshot
from embodiedforge.tasks import ReachTask,HoldTask
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'initial/src/embodiedforge/tasks.py';spec=importlib.util.spec_from_file_location('embodiedforge._r8_size_property_reference',p);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
class Borrowed(np.ndarray):
 @property
 def size(self):raise RuntimeError('size property must not be inspected')
state=StateSnapshot(np.zeros((8192,2)).view(Borrowed),np.zeros((8192,2)),np.zeros(8192),np.zeros(8192,np.int64));results={}
for baseline,current in ((old.ReachTask,ReachTask),(old.HoldTask,HoldTask)):
 results[current.__name__]={}
 for label,cls in (('initial',baseline),('current',current)):
  task=cls();task.build(8192)
  try:
   output=task.observe(state)['proprio'];result=dict(status='passed',shape=list(output.shape),dtype=str(output.dtype),sha256=hashlib.sha256(output.tobytes()).hexdigest())
  except Exception as error:result=dict(status='failed',error_type=type(error).__name__,message=str(error))
  results[current.__name__][label]=result
report=dict(results=results,runtime_source_sha256=hashlib.sha256(Path('src/embodiedforge/tasks.py').read_bytes()).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(ROOT/'size-property-repro.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
