"""Check observed cast diagnostics against a preserved candidate without FP guards."""
import hashlib,importlib.util,json,time,warnings
from pathlib import Path
import numpy as np
from common import CLASSES,ROOT,StateSnapshot,guard,sha,source_map
p=ROOT/'candidate-before-fp-guard/candidate/src/embodiedforge/tasks.py';spec=importlib.util.spec_from_file_location('embodiedforge._r8_no_fp_guard',p);candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate);guard();rows=[]
for taskname in ('reach','hold'):
 for mode in ('repeated_overflow_warnings','strict_error_priority'):
  position=np.full((8192,2),np.finfo(float).max if mode=='repeated_overflow_warnings' else np.nextafter(0.,1.));velocity=np.full((8192,2),np.finfo(float).max);state=StateSnapshot(position,velocity,np.zeros(8192),np.zeros(8192,np.int64));results={}
  classes={'initial':CLASSES['initial'][taskname],'unguarded_candidate':getattr(candidate,'ReachTask' if taskname=='reach' else 'HoldTask'),'current':CLASSES['current'][taskname]}
  for version,cls in classes.items():
   task=cls();task.build(8192);settings=dict(all='raise') if mode=='strict_error_priority' else dict(all='warn',under='ignore')
   with warnings.catch_warnings(record=True) as records,np.errstate(**settings):
    warnings.simplefilter('always')
    try:
     output=task.observe(state)['proprio'];result=dict(status='passed',dtype=output.dtype.str,shape=list(output.shape),output_sha256=hashlib.sha256(output.tobytes()).hexdigest())
    except FloatingPointError as e:result=dict(status='floating_point_error',message=str(e))
    result['warnings']=[dict(category=w.category.__name__,message=str(w.message)) for w in records]
   results[version]=result
  assert results['current']==results['initial'] and results['unguarded_candidate']!=results['initial'],(taskname,mode,results)
  rows.append(dict(task=taskname,mode=mode,results=results))
d=dict(status='passed',epoch=time.time(),cases=rows,script_sha256=sha(Path(__file__)),runtime_source_sha256=source_map(),unguarded_candidate_path=str(p.relative_to(ROOT)),unguarded_candidate_sha256=sha(p),interpretation='Two diagnostic modes across Reach/Hold prove the guards matter: the preserved unguarded candidate differs from baseline, while final source matches exact warnings and exception messages. Original candidate source is loaded into a separate module; workspace runtime source is unchanged.')
(ROOT/'fp-guard-control.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2))
