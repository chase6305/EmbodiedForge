"""Re-read the real archive and verify source, tests, measurements and timing links."""
import hashlib,io,json,tarfile,time
import numpy as np
from report import ROOT,WORKSPACE,REPORT,ARCHIVE,FIGURE,CORE,PROBES,START,DURATION,read,sha,verify_archive
report=read(REPORT);assert report['actual_elapsed_seconds']>=DURATION and report['duration_gate']['actual_elapsed_seconds']>=DURATION
payload=ARCHIVE.read_bytes();assert len(payload)==report['evidence_archive']['bytes'] and hashlib.sha256(payload).hexdigest()==report['evidence_archive']['sha256']
count=verify_archive(payload);assert count==report['evidence_archive']['regular_members']
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tar:
 def data(n):return tar.extractfile(n).read()
 def digest(n):return hashlib.sha256(data(n)).hexdigest()
 initial=json.loads(data('run/initial-hashes.json'));initial_runtime=0
 for p,h in initial.items():
  if p.startswith('src/') and p.endswith('.py'):assert digest('run/initial/'+p)==h;initial_runtime+=1
 assert initial_runtime==105
 for p,h in report['review_files_sha256'].items():assert sha(WORKSPACE/p)==digest('final/'+p)==h
 fig='final/'+str(FIGURE.relative_to(WORKSPACE));assert digest(fig)==sha(FIGURE)==report['figure']['figure_sha256'] and b'<text' in data(fig)
 assert digest('run/scripts/plot.py')==report['figure']['script_sha256'] and report['figure']['latency_claim'] is False
 root_rel=ROOT.relative_to(WORKSPACE)
 for p,h in report['validation']['sha256'].items():
  assert sha(WORKSPACE/p)==h
  location='run/'+str((WORKSPACE/p).relative_to(ROOT)) if p.startswith(str(root_rel)+'/') else 'final/'+p if p in CORE else 'run/initial/'+p
  assert digest(location)==h,location
 frozen=json.loads(data('run/frozen-runtime.json'))['sha256'];assert frozen=={str(p.relative_to(WORKSPACE)):sha(p) for p in (WORKSPACE/'src').rglob('*.py')}
 for n in PROBES:
  p='run/'+n+'.json';d=json.loads(data(p));assert digest(p)==report['probe_results'][n]['raw_report_sha256']
  assert d['status']=='passed' and d['runtime_source_sha256']==frozen and d['cases']==report['probe_results'][n]['cases'] and d['configuration_count']==d['base_configurations_expected']
  for p,h in d['script_sha256'].items():assert digest('run/'+p)==h
  assert data('run/'+n+'.json')==data('run/ram-mirror/'+n+'.json')
 for n,d in report['performance'].items():
  assert digest('run/'+n)==d['sha256'];raw=json.loads(data('run/'+n));assert len(raw['cases'])==44 and raw['status']=='passed' and raw['runtime_source_sha256']==frozen
  for p,h in raw['script_sha256'].items():assert digest('run/'+p)==h
 gate=json.loads(data('run/duration-gate.json'));assert gate==report['duration_gate'];early=gate['early_control']
 assert early['real_clock_used'] and not early['clock_simulated'] and early['actual_elapsed_seconds']<DURATION and early['actual_rejection_exit']==1 and not early['final_outputs_created']
 assert digest('run/scripts/report.py')==sha(ROOT/'scripts/report.py')==early['reporter_sha256']
 completed=json.loads(data('run/session-completions.json'));assert set(completed)==set(PROBES)
 for n,d in completed.items():assert d['exit_code']==0 and d['reaped'] is True
 capture=report['capture_control'];p='run/controls/capture-control-failure-input.npz';assert digest(p)==capture['capture_sha256']
 assert digest('run/scripts/endurance.py')==capture['harness_sha256'] and digest('run/controls/capture-control-failure.json')==capture['failed_report_sha256']
 with np.load(io.BytesIO(data(p)),allow_pickle=False) as f:
  assert f['initial/proprio'].tobytes()!=f['current/proprio'].tobytes()
  for k in ('position','velocity','target','time','version'):assert f['before/'+k].tobytes()==f['after/'+k].tobytes()
 assert json.loads(data('run/controls/capture-control-failure.json'))['status']=='failed'
 persistence=report['persistence_control'];assert digest('run/controls/root-write-failure-ram.json')==persistence['ram_report_sha256'] and digest('run/scripts/endurance.py')==persistence['harness_sha256']
 control=json.loads(data('run/controls/root-write-failure-ram.json'));assert control['status']=='passed' and control['cases']==20 and all(e['errno']==28 for e in control['persistence_events'])
 for p,h in report['inherited_diagnostics']['files_sha256'].items():assert digest('run/'+p)==h
 assert json.loads(data('run/inherited-diagnostics/motion/subclasses-py312-failure.json'))['status']=='failed'
 assert json.loads(data('run/inherited-diagnostics/round7/diagnostic.json'))['status']=='unclassified_persistence_interruption'
 interrupted=report['process_interruption'];assert digest('run/interrupted-numpy124-sigterm/diagnostic.json')==interrupted['diagnostic_sha256']
 for p,h in interrupted['data']['sha256'].items():assert digest('run/interrupted-numpy124-sigterm/'+p)==h
 assert interrupted['data']['actual_tool_result']['exit_code']==143 and interrupted['data']['actual_tool_result']['reaped'] is True
report['artifact_verification']=dict(status='passed',epoch=time.time(),actual_elapsed_seconds=time.time()-START,regular_archive_members=count,gzip_crc_and_all_manifest_hashes_verified=True,source_tests_logs_performance_and_harness_links_verified=True,real_early_rejection_and_final_duration_verified=True,output_difference_and_unchanged_input_control_verified=True,mirrored_persistence_control_verified=True,inherited_unclassified_records_preserved=True,allocation_and_latency_claims_scoped=True)
report['status']='complete_with_unclassified_diagnostics'
tmp=REPORT.with_suffix('.json.tmp');tmp.write_text(json.dumps(report,indent=2)+'\n');tmp.replace(REPORT)
print(json.dumps(report['artifact_verification'],indent=2))
