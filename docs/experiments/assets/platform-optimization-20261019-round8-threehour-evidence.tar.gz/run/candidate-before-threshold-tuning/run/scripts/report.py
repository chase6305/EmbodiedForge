"""Export evidence only after three real elapsed hours and successful reaping."""
import argparse,gzip,hashlib,io,json,tarfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];WORKSPACE=ROOT.parents[1]
START=1792410782;DEADLINE=1792421582;DURATION=10800
STEM='platform-optimization-20261019-round8-threehour'
REPORT=WORKSPACE/'docs'/(STEM+'.json');ARCHIVE=WORKSPACE/'docs/assets'/(STEM+'-evidence.tar.gz');FIGURE=WORKSPACE/'docs'/(STEM+'-allocations.svg')
CORE=('src/embodiedforge/tasks.py','tests/test_task_observation_buffers.py','benchmarks/task_observations.py','docs/interfaces.md')
PROBES=('task-py312','task-numpy124','environment-py312')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def preservation():
 initial=read(ROOT/'initial-hashes.json');changed=[]
 for p,h in initial.items():
  assert sha(ROOT/'initial'/p)==h,('Initial snapshot drift',p)
  if sha(WORKSPACE/p)!=h:changed.append(p)
 assert set(changed)=={'src/embodiedforge/tasks.py','docs/interfaces.md'},changed
 current={str(p.relative_to(WORKSPACE)):sha(p) for p in sorted((WORKSPACE/'src').rglob('*.py'))}
 assert current==read(ROOT/'frozen-runtime.json')['sha256']
 return dict(initial_files_verified=len(initial),runtime_sources_verified=len(current),changed_initial_files=changed,prior_changes_preserved=True)
def members():
 data={}
 for p in sorted(ROOT.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(ROOT)
  if '__pycache__' in rel.parts or p.suffix=='.pyc' or p.suffix=='.tmp' or p.name in ('preview-report.json','archive-preflight.json'):continue
  if rel.parts[0]=='initial' and p.suffix not in ('.py','.md','.json','.toml','.txt','.xml','.svg','.html','.js') and not p.name.startswith(('LICENSE','NOTICE')):continue
  data['run/'+str(rel)]=p.read_bytes()
 for p in CORE:data['final/'+p]=(WORKSPACE/p).read_bytes()
 data['final/'+str(FIGURE.relative_to(WORKSPACE))]=FIGURE.read_bytes()
 manifest={n:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for n,v in data.items()}
 data['manifest.json']=(json.dumps(dict(status='passed',manifest_excludes_itself=True,members=manifest),indent=2)+'\n').encode()
 return data

def pack(data):
 target=io.BytesIO()
 with tarfile.open(fileobj=target,mode='w:gz') as tar:
  for name,value in data.items():
   p=Path(name);assert not p.is_absolute() and '..' not in p.parts
   item=tarfile.TarInfo(name);item.mode=0o644;item.mtime=START;item.size=len(value);tar.addfile(item,io.BytesIO(value))
 return target.getvalue()
def verify_archive(payload):
 gzip.decompress(payload)
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tar:
  items=tar.getmembers();names={p.name for p in items};assert len(names)==len(items)
  manifest=json.load(tar.extractfile('manifest.json'))['members'];assert names==set(manifest)|{'manifest.json'}
  for p in items:
   path=Path(p.name);assert p.isfile() and not path.is_absolute() and '..' not in path.parts
   value=tar.extractfile(p).read()
   if p.name!='manifest.json':assert len(value)==manifest[p.name]['bytes'] and hashlib.sha256(value).hexdigest()==manifest[p.name]['sha256'],p.name
 return len(items)

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--preview',action='store_true');args=parser.parse_args()
 now=time.time();state=read(ROOT/'state.json');assert state['start_epoch']==START and state['deadline_epoch']==DEADLINE and state['required_elapsed_seconds']==DURATION==DEADLINE-START
 if not args.preview:
  assert now-START>=DURATION,'Three-hour elapsed-time gate: actual elapsed time must reach 10800 seconds'
  assert not REPORT.exists() and not ARCHIVE.exists()
 preserved=preservation();validation=read(ROOT/'validation.json');assert validation['status']=='passed'
 for p,h in validation['sha256'].items():assert sha(WORKSPACE/p)==h,p
 frozen=read(ROOT/'frozen-runtime.json')['sha256'];performance={}
 for p in sorted(ROOT.glob('performance-*.json')):
  d=read(p);assert d['status']=='passed' and len(d['cases'])==44 and d['pairs']==21
  assert d['runtime_source_sha256']==frozen and d['initial_source_sha256']==sha(ROOT/'initial'/CORE[0])
  for n,h in d['script_sha256'].items():assert sha(ROOT/n)==h,n
  selected=[c for c in d['cases'] if c['num_envs']==8192 and c['layout']=='C']
  controls=[dict(task=c['task'],num_envs=c['num_envs'],layout=c['layout'],scope=c['scope'],elapsed_reduction_percent=c['elapsed_reduction_percent'],peak_reduction_percent=c['peak_reduction_percent']) for c in d['cases'] if c['num_envs']<1024]
  performance[p.name]=dict(sha256=sha(p),python=d['python'],numpy=d['numpy'],cpu_affinity=d['cpu_affinity'],cases=len(d['cases']),pairs=d['pairs'],selected_8192_env_C=selected,small_batch_controls=controls)
 assert len(performance)==3
 figure=read(ROOT/'figure-provenance.json');assert figure['status']=='passed' and sha(FIGURE)==figure['figure_sha256'] and sha(ROOT/'scripts/plot.py')==figure['script_sha256']
 for p,h in figure['reports_sha256'].items():assert sha(ROOT/p)==h
 capture=read(ROOT/'capture-control.json');assert capture['status']=='passed' and capture['injected_output_difference_verified'] and capture['before_after_inputs_verified']
 assert capture['capture_sha256']==sha(ROOT/'controls/capture-control-failure-input.npz')
 assert capture['harness_sha256']==sha(ROOT/'scripts/endurance.py') and capture['common_sha256']==sha(ROOT/'scripts/common.py')
 assert capture['failed_report_sha256']==sha(ROOT/'controls/capture-control-failure.json')
 persistence=read(ROOT/'persistence-control.json');assert persistence['status']=='passed' and persistence['actual_process_exit']==0 and persistence['simulated_errno']==28
 assert persistence['harness_sha256']==sha(ROOT/'scripts/endurance.py') and persistence['ram_report_sha256']==sha(ROOT/'controls/root-write-failure-ram.json')
 probes={}
 for n in PROBES:
  p=ROOT/(n+('-progress' if args.preview else '')+'.json');d=read(p)
  assert d['runtime_source_sha256']==frozen
  for f,h in d['script_sha256'].items():assert sha(ROOT/f)==h
  if not args.preview:assert d['status']=='passed' and d['configuration_count']==d['base_configurations_expected']
  probes[n]={k:d[k] for k in ('status','scope','started_epoch','elapsed_seconds','cases','configuration_count','base_configurations_expected')};probes[n]['raw_report_sha256']=sha(p);probes[n]['persistence_events']=d['persistence_events']
  for k in ('fds','python_threads','os_threads'):
   values=sorted({v[k] for v in d['resources']});assert len(values)==1;probes[n]['observed_'+k]=values
 assert not list(ROOT.glob('*-failure.json'))
 motion=ROOT/'inherited-diagnostics/motion/subclasses-py312-failure.json';prior=ROOT/'inherited-diagnostics/round7/diagnostic.json'
 assert read(motion)['status']=='failed' and sha(motion)=='de44b89feaf11365036e4fafb15bc4e0163a39d247c4693c9b1ea68123b265de'
 assert read(prior)['status']=='unclassified_persistence_interruption'
 inherited={str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'inherited-diagnostics').rglob('*')) if p.is_file()}
 report=dict(status='active_preview' if args.preview else 'closing_after_elapsed_gate',objective='持续优化 EmbodiedForge 三个实际小时，保留既有工作，完成测量、回归、持续验证及可审查证据。',start_epoch=START,deadline_epoch=DEADLINE,required_elapsed_seconds=DURATION,actual_elapsed_seconds=now-START,parallel_durations_added=False,preservation=preserved,review_files_sha256={p:sha(WORKSPACE/p) for p in CORE},changes=['Large plain native float64 Reach/Hold fields concatenate directly into the final owned float32 output when finite values fit float32 and underflow diagnostics are ignored, avoiding a full float64 concatenation result and subsequent cast allocation. Range reductions add overhead; allocation savings do not imply a time gain.','Position arrays with fewer than 2048 elements, mixed types, nonnative byte order, ndarray subclasses and diagnostic-sensitive float values retain the original concatenate-then-cast promotion, dispatch and FP diagnostics. Relative target subtraction remains unchanged.','144 regression cases cover threshold boundaries, empty inputs, layouts, independent owned output, input bytes, dtype promotion, subclass dispatch, special floating-point bits and FP diagnostic sequences. A reproducible task/complete-step benchmark is included.'],scope='Synthetic CPU Reach/Hold task observations and complete camera-free VectorEnv.step. No GPU, MuJoCo, RSS limit or training-throughput inference.',performance=performance,performance_claims=dict(primary='Separately traced transient allocation reduction in large native-float64 direct task.observe cases.',latency='Raw signed timings retained as shared-host observations; complete-step time gains are small and are not presented as a general speedup.',pipeline_memory='Complete-step savings are separately shown and much smaller than direct task feature assembly; no propagation of the direct percentages to overall memory.'),performance_caveats=['Three Python/NumPy environments; 44 scenarios each, 21 alternating pairs, one pinned CPU on a shared host. All signed small-batch controls and layout variants retained.','Construction, warmup, tracing and byte comparisons excluded from timing. Later measurements may overlap separately pinned differential cohorts. Three independent tracemalloc peak samples; prebuilt inputs and runtime caches are outside tracing.'],validation=validation,figure=figure,probe_results=probes,capture_control=capture,persistence_control=persistence,inherited_diagnostics=dict(status='unclassified',files_sha256=inherited,interpretation='The prior MotionClips fingerprint event and previous round exit-120 persistence interruption remain unclassified. Their original records are retained. This round changes separate task feature assembly and does not classify or erase those events. The new isolated ENOSPC control verifies mirrored evidence behavior, not their historical cause.'),round_scope='Three actual wall-clock hours include analysis, implementation, measurements, final-source regression and sustained differential validation, diagnostics and export. Per-cohort starts/durations are separate; parallel durations are not added.',ram_evidence_scope='Final cohorts mirror progress and failure bytes to /dev/shm before root writes and report exceptions directly through tool stderr. Mirrors are copied to the evidence archive after actual reaping.',evidence_selection='Raw measurements, source/harness snapshots, logs, input/output capture control, inherited diagnostic records, initial text files and final review files/figure retained. Initial binary assets and earlier compressed archives excluded; all their original hashes remain recorded.')
 interrupted=read(ROOT/'interrupted-numpy124-sigterm/diagnostic.json')
 assert interrupted['status']=='unclassified_process_termination' and interrupted['actual_tool_result']['exit_code']==143 and interrupted['actual_tool_result']['reaped'] is True
 for p,h in interrupted['sha256'].items():assert sha(ROOT/'interrupted-numpy124-sigterm'/p)==h
 report['process_interruption']=dict(status=interrupted['status'],diagnostic_sha256=sha(ROOT/'interrupted-numpy124-sigterm/diagnostic.json'),data=interrupted,interpretation='One NumPy 1.24 cohort exited with observed code 143 without an application failure report. This round did not request termination; sender/cause remain unknown. The incomplete prefix is preserved separately and is not counted as a passed final cohort. The other two cohorts continued; the replacement cohort reports its own start and duration.')
 phase_root=ROOT/'candidate-before-subclass-guard';phase=read(phase_root/'preservation.json')
 assert phase['status']=='superseded_due_to_reproduced_compatibility_regression'
 for p,h in phase['sha256'].items():assert sha(phase_root/p)==h,p
 for d in phase['controlled_stop_results'].values():assert d['reaped'] is True and d['tool_result']['exit_code']==143
 fixed=read(ROOT/'size-property-repro.json');assert fixed['runtime_source_sha256']==frozen[CORE[0]] and fixed['script_sha256']==sha(ROOT/'scripts/size_property_repro.py')
 for name,d in fixed['results'].items():
  assert d['initial']==d['current'] and d['current']['status']=='passed'
  old=phase['reproduction']['results'][name];assert old['initial']['status']=='passed' and old['current']['status']=='failed' and old['current']['error_type']=='RuntimeError'
 report['resolved_candidate_regression']=dict(status='fixed_and_revalidated',preservation_sha256=sha(phase_root/'preservation.json'),preserved=phase,fixed_reproduction_sha256=sha(ROOT/'size-property-repro.json'),fixed_reproduction=fixed,interpretation='The first candidate inspected an ndarray subclass size property before confirming plain ndarray type. A reproducer showed the baseline passed and candidate raised. All three then-running cohorts were deliberately stopped and reaped, and their source/tests/measurements/logs were preserved separately. Type inspection now precedes size inspection. Final-source 144-case regressions, complete suites, measurements and cohorts were rerun; superseded results are not final-source evidence.')
 fp_phase_root=ROOT/'candidate-before-fp-guard';fp_phase=read(fp_phase_root/'preservation.json')
 assert fp_phase['status']=='superseded_due_to_fp_diagnostic_difference'
 for p,h in fp_phase['sha256'].items():assert sha(fp_phase_root/p)==h,p
 stopped=read(ROOT/'fp-candidate-stop-results.json')
 for d in stopped.values():assert d['reaped'] is True and d['tool_result']['exit_code']==143
 adversarial={}
 for p in sorted(ROOT.glob('adversarial-py*.json')):
  d=read(p);assert d['status']=='passed' and d['cases']==2520 and not d['behavior_differences'] and d['runtime_source_sha256']==frozen
  assert d['script_sha256']==sha(ROOT/'scripts/adversarial_cast.py') and d['common_sha256']==sha(ROOT/'scripts/common.py')
  adversarial[p.name]=dict(sha256=sha(p),python=d['python'],numpy=d['numpy'],cases=d['cases'],behavior_differences=0)
 assert len(adversarial)==3 and validation['new_regression_cases']==144
 report['resolved_fp_diagnostics']=dict(status='fixed_and_revalidated',preservation_sha256=sha(fp_phase_root/'preservation.json'),preserved=fp_phase,controlled_stops=stopped,stop_results_sha256=sha(ROOT/'fp-candidate-stop-results.json'),final_adversarial=adversarial,interpretation='Adversarial IEEE patterns exposed repeated cast warnings and differing strict FloatingPointError priority in the second candidate. Finite-range reductions now gate fused casts, and nonignored underflow diagnostics use the original path. All three final NumPy environments show exact returned bytes, warning sequences and FP exceptions across 2520 fresh-seeded cases each, including reversed/broadcast/unaligned layouts and signaling NaN payloads. Both superseded phases retain separate raw evidence; final source is measured and tested again.')
 report['signal_diagnostic_followup']=dict(parent_tracing='The final NumPy 1.24 cohort runs as a child of strace restricted to SIGTERM events. Existing-process attachment was denied; no kernel permissions were changed. The final trace is preserved in ram-mirror after reaping.',historical_cause='The earlier exit 143 remains unclassified; later successful runs or absence of a new signal do not identify the earlier sender.')
 if args.preview:
  (ROOT/'preview-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],actual_elapsed_seconds=now-START)));return
 early=read(ROOT/'duration-gate-control.json');assert early['status']=='passed' and early['real_clock_used'] and not early['clock_simulated'] and early['actual_elapsed_seconds']<DURATION and early['reporter_sha256']==sha(Path(__file__))
 completed=read(ROOT/'session-completions.json')
 for n in PROBES:assert completed[n]['exit_code']==0 and completed[n]['reaped'] is True and not (Path('/proc')/str(completed[n]['pid'])).exists()
 assert not read(ROOT/'operator-state.json')['active_sessions'] and read(ROOT/'closing-preflight.json')['status']=='passed'
 gate=dict(status='passed',real_clock_used=True,actual_elapsed_seconds=now-START,required_elapsed_seconds=DURATION,parallel_durations_added=False,early_control=early)
 (ROOT/'duration-gate.json').write_text(json.dumps(gate,indent=2)+'\n');report['duration_gate']=gate
 payload=pack(members());count=verify_archive(payload)
 with ARCHIVE.open('xb') as f:f.write(payload)
 report['evidence_archive']=dict(path=str(ARCHIVE.relative_to(WORKSPACE)),sha256=hashlib.sha256(payload).hexdigest(),bytes=len(payload),regular_members=count)
 with REPORT.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
 print(json.dumps(dict(status=report['status'],actual_elapsed_seconds=now-START,archive_members=count,archive_bytes=len(payload))))
if __name__=='__main__':main()
