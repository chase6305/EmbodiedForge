"""In-memory archive verification before formal export is permitted."""
import json,time
from report import ROOT,REPORT,ARCHIVE,START,members,pack,preservation,verify_archive
assert not REPORT.exists() and not ARCHIVE.exists()
preserved=preservation();payload=pack(members());count=verify_archive(payload)
d=dict(status='passed',epoch=time.time(),actual_elapsed_seconds=time.time()-START,regular_members=count,compressed_bytes=len(payload),all_manifest_hashes_and_gzip_crc_verified=True,preservation=preserved,formal_outputs_created=False,scope='Preflight snapshot only; formal export still requires the three-hour gate and reaped final cohorts.')
(ROOT/'archive-preflight.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
