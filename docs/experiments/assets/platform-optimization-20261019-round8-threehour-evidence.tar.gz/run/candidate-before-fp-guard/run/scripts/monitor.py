"""Observe immutable sources, fresh mirrored progress and bounded resource counts."""
import json,os,time
from pathlib import Path
from common import ROOT,WORKSPACE,read,sha,atomic,guard
RAM_ROOT=Path('/dev/shm')/ROOT.name
state=read(ROOT/'state.json');assert state['start_epoch']==1792410782 and state['deadline_epoch']==1792421582 and state['required_elapsed_seconds']==10800
assert not list(ROOT.glob('*-failure.json')) and not list(RAM_ROOT.glob('*-failure.json')),'A new probe has failed'
guard();initial=read(ROOT/'initial-hashes.json')
for p,h in initial.items():assert sha(ROOT/'initial'/p)==h,p
for p,h in read(ROOT/'validation.json')['sha256'].items():assert sha(WORKSPACE/p)==h,p
now=time.time();rows={}
for name,s in read(ROOT/'operator-state.json')['active_sessions'].items():
 candidates=[read(p) for p in (ROOT/(name+'-progress.json'),RAM_ROOT/(name+'-progress.json')) if p.exists()];d=max(candidates,key=lambda v:v['updated_epoch'])
 assert d['pid']==s['pid'] and d['status'] in ('running','passed')
 if d['status']=='running':
  assert now-d['updated_epoch']<90,(name,'Stale progress');args=(Path('/proc')/str(s['pid'])/'cmdline').read_bytes().split(b'\0');assert name.encode() in args and any(a.endswith(b'/endurance.py') for a in args)
 assert d['runtime_source_sha256']==read(ROOT/'frozen-runtime.json')['sha256']
 for p,h in d['script_sha256'].items():assert sha(ROOT/p)==h,p
 for k in ('fds','python_threads','os_threads'):assert len({v[k] for v in d['resources']})==1,(name,k)
 rows[name]={k:d[k] for k in ('status','cases','configuration_count','base_configurations_expected')};rows[name]['persistence_events']=len(d['persistence_events'])
st=os.statvfs(ROOT);free=st.f_bavail*st.f_frsize
event=dict(status='passed',epoch=now,elapsed_seconds=now-state['start_epoch'],remaining_seconds=max(0,state['deadline_epoch']-now),disk_free_bytes=free,storage_pressure=free<256*1024*1024,initial_files_verified=len(initial),runtime_files_verified=105,probes=rows)
with (RAM_ROOT/'monitor-audit.jsonl').open('a') as f:f.write(json.dumps(event,separators=(',',':'))+'\n')
atomic(RAM_ROOT/'monitor-latest.json',event)
try:
 with (ROOT/'monitor-audit.jsonl').open('a') as f:f.write(json.dumps(event,separators=(',',':'))+'\n')
 atomic(ROOT/'monitor-latest.json',event)
except OSError as e:event['observer_write_error']=str(e)
print(json.dumps(event))
