"""Alternating paired task/full-step timing and separately traced allocations."""
import itertools,json,os,platform,statistics,time,tracemalloc
from pathlib import Path
import numpy as np
from common import ROOT,CLASSES,task_fixture,environment,equal,fingerprint,sha,source_map,pin
pin();PAIRS=21

def measure(version,task,count,layout,pipeline,trace=False):
 if pipeline:
  obj=environment(version,task,count);action=np.zeros((count,2))
  def call():
   result=obj.step(action)
   return {**result.observation,'reward':result.reward,'terminated':result.terminated,'truncated':result.truncated}
  close=obj.close
 else:
  obj,state=task_fixture(version,task,count,layout)
  def call():return obj.observe(state)
  def close():pass
 try:
  for _ in range(4):call()
  loops=1 if trace else (8 if pipeline else 16 if count>=65536 else 64)
  if trace:tracemalloc.start()
  start=time.perf_counter()
  for _ in range(loops):values=call();del values
  elapsed=(time.perf_counter()-start)/loops
  peak=tracemalloc.get_traced_memory()[1] if trace else None
  if trace:tracemalloc.stop()
  values=call()
  return elapsed,peak,values
 finally:
  if tracemalloc.is_tracing():tracemalloc.stop()
  close()
started=time.time();rows=[]
cases=[(*c,False) for c in itertools.product(('reach','hold'),(1,16,128,1024,8192,65536),('C','F','strided'))]
cases += [(task,count,'C',True) for task,count in itertools.product(('reach','hold'),(16,128,1024,8192))]
for task,count,layout,pipeline in cases:
 samples={'initial':[],'current':[]}
 for pair in range(PAIRS):
  last={}
  for version in (('initial','current') if pair%2==0 else ('current','initial')):
   t,_,values=measure(version,task,count,layout,pipeline);samples[version].append(t);last[version]=values
  equal(last['initial'],last['current'])
 peaks={v:[measure(v,task,count,layout,pipeline,True)[1] for _ in range(3)] for v in ('initial','current')}
 medians={v:statistics.median(s) for v,s in samples.items()}
 row=dict(task=task,num_envs=count,layout=layout,scope='environment_step' if pipeline else 'task_observe',seconds=samples,median_seconds=medians,traced_peak_bytes=peaks,elapsed_reduction_percent=100*(1-medians['current']/medians['initial']),peak_reduction_percent=100*(1-statistics.median(peaks['current'])/statistics.median(peaks['initial'])),output_sha256=fingerprint(last['current']))
 rows.append(row);print(task,count,layout,pipeline,round(row['elapsed_reduction_percent'],2),round(row['peak_reduction_percent'],2),flush=True)
name=f'performance-py{platform.python_version()}-numpy{np.__version__}'
report=dict(status='passed',started_epoch=started,finished_epoch=time.time(),python=platform.python_version(),numpy=np.__version__,cpu_affinity=sorted(os.sched_getaffinity(0)),pairs=PAIRS,runtime_source_sha256=source_map(),initial_source_sha256=sha(ROOT/'initial/src/embodiedforge/tasks.py'),script_sha256={f'scripts/{n}':sha(ROOT/'scripts'/n) for n in ('performance.py','common.py')},scope='Synthetic CPU Reach/Hold task.observe or complete camera-free VectorEnv.step including result packaging. Setup, warmup, tracing and byte comparison excluded from timing. Shared host, pinned CPU; all signed samples retained. Three independent transient tracemalloc peak samples, not RSS. No GPU or training throughput inference.',cases=rows)
(ROOT/(name+'.json')).write_text(json.dumps(report,indent=2)+'\n');print(name,flush=True)
