import json,time,tracemalloc,statistics
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
def old(parts):return np.concatenate(parts,axis=1).astype(np.float32)
def direct(parts):return np.concatenate(parts,axis=1,dtype=np.float32,casting='unsafe')
def guarded(parts):
 if parts[0].size>=2048 and all(type(v) is np.ndarray and v.dtype==np.float64 for v in parts):return direct(parts)
 return old(parts)
rows=[]
for count in (1,16,128,512,1024,8192,65536):
 for k in (2,3):
  rng=np.random.default_rng(8);parts=tuple(rng.normal(size=(count,2)) for _ in range(k));times={f.__name__:[] for f in (old,direct,guarded)};peaks={}
  for _ in range(9):
   for f in (old,direct,guarded):
    start=time.perf_counter()
    for i in range(100):f(parts)
    times[f.__name__].append((time.perf_counter()-start)/100)
  for f in (old,direct,guarded):
   tracemalloc.start();r=f(parts);peaks[f.__name__]=tracemalloc.get_traced_memory()[1];tracemalloc.stop();assert np.array_equal(r,old(parts))
  row=dict(count=count,parts=k,seconds=times,medians={n:statistics.median(v) for n,v in times.items()},peak_bytes=peaks);rows.append(row)
  print(count,k,{n:round(v*1e6,2) for n,v in row['medians'].items()},peaks,flush=True)
(ROOT/'explore.json').write_text(json.dumps(rows,indent=2)+'\n')
