"""Exercise the real early-export rejection without simulating clock values."""
import subprocess,sys,time,json
from report import ROOT,REPORT,ARCHIVE,START,DURATION,sha
assert time.time()-START<DURATION and not REPORT.exists() and not ARCHIVE.exists()
p=ROOT/'scripts/report.py';result=subprocess.run([sys.executable,str(p)],capture_output=True,text=True)
assert result.returncode==1 and 'Three-hour elapsed-time gate: actual elapsed time must reach 10800 seconds' in result.stderr
assert not REPORT.exists() and not ARCHIVE.exists()
report=dict(status='passed',epoch=time.time(),actual_elapsed_seconds=time.time()-START,real_clock_used=True,clock_simulated=False,reporter_sha256=sha(p),actual_rejection_exit=result.returncode,final_outputs_created=False,stderr=result.stderr)
(ROOT/'duration-gate-control.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ('status','actual_elapsed_seconds','final_outputs_created')}))
