"""Show direct observation allocation savings alongside complete-step limits."""
import hashlib,json,statistics
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parents[1];WORKSPACE=ROOT.parents[1]
paths=sorted(ROOT.glob('performance-*.json'));assert len(paths)==3
plt.rcParams.update({'svg.fonttype':'none','font.size':10})
fig,axes=plt.subplots(3,2,figsize=(11,10))
for row,path in enumerate(paths):
 d=json.loads(path.read_text())
 for col,scope in enumerate(('task_observe','environment_step')):
  ax=axes[row,col];cases=[next(c for c in d['cases'] if c['task']==t and c['num_envs']==8192 and c['layout']=='C' and c['scope']==scope) for t in ('reach','hold')];x=np.arange(2);width=.34
  for offset,version,label,color in ((-.5,'initial','Initial','#7e8b97'),(.5,'current','Current','#18877f')):
   values=[statistics.median(c['traced_peak_bytes'][version])/2**20 for c in cases]
   bars=ax.bar(x+offset*width,values,width,label=label,color=color);ax.bar_label(bars,labels=[f'{v:.3f}' for v in values],padding=3,fontsize=9)
  ax.set_xticks(x,['Reach','Hold']);ax.set_ylabel('Peak traced allocation (MiB)');ax.set_title(f"Python {d['python']} / NumPy {d['numpy']}",fontsize=11);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True);ax.set_ylim(0,ax.get_ylim()[1]*1.18)
  if row==0 and col==0:ax.legend(loc='upper right',fontsize=9)
fig.suptitle('Task feature buffers: observed transient allocation peaks',fontsize=15,y=.98)
fig.text(.29,.935,'Direct task.observe',ha='center',fontsize=12);fig.text(.77,.935,'Complete step without cameras',ha='center',fontsize=12)
fig.subplots_adjust(top=.89,bottom=.17,left=.09,right=.98,hspace=.42,wspace=.25)
fig.text(.09,.055,'8192 environments, native float64 inputs, C layout. Medians of three independent tracemalloc peaks.\nInputs, decoded state and existing runtime buffers are prepared before tracing; peaks are not process RSS.\nDirect feature savings are not overall memory or training-throughput savings. Raw latency samples and\nall 44 scenarios per version are retained; complete-step time gains remain inconclusive.',fontsize=10)
figure=WORKSPACE/'docs/platform-optimization-20261019-round8-threehour-allocations.svg';fig.savefig(figure);fig.savefig('/tmp/ef-round8-allocations.png',dpi=120)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
provenance=dict(status='passed',figure_sha256=sha(figure),script_sha256=sha(Path(__file__)),reports_sha256={p.name:sha(p) for p in paths},latency_claim=False,scope='Separate direct task.observe and full-step allocation peaks at 8192 environments; no RSS or throughput claim.')
(ROOT/'figure-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n');print(json.dumps(provenance))
