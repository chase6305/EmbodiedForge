"""Finalize only actually reaped successful cohorts and verify no owned workers."""
import json,os,time,shutil
from pathlib import Path
from report import ROOT,PROBES,REPORT,ARCHIVE,read,sha,preservation,START
state=read(ROOT/'state.json');assert time.time()>=state['probe_stop_epoch']
assert not REPORT.exists() and not ARCHIVE.exists()
operator=read(ROOT/'operator-state.json');results=read(ROOT/'tool-session-results.json')
assert set(results)==set(operator['active_sessions'])==set(PROBES)
ram=Path('/dev/shm')/ROOT.name
assert ram.exists()
shutil.copytree(ram,ROOT/'ram-mirror')
for n in PROBES:
 p=ram/(n+'.json');assert read(p)['status']=='passed';(ROOT/(n+'.json')).write_bytes(p.read_bytes())
completed={}
for n in PROBES:
 s=operator['active_sessions'][n];r=results[n];d=read(ROOT/(n+'.json'))
 assert r['session_id']==s['session_id'] and r['tool_result']['exit_code']==0 and r['reaped'] is True
 assert d['pid']==s['pid'] and d['status']=='passed' and d['configuration_count']==d['base_configurations_expected']
 assert not (Path('/proc')/str(s['pid'])).exists()
 completed[n]={**s,'status':'passed','exit_code':0,'reaped':True,'cases':d['cases'],'elapsed_seconds':d['elapsed_seconds']}
assert not (ROOT/'session-completions.json').exists()
(ROOT/'session-completions.json').write_text(json.dumps(completed,indent=2)+'\n')
operator.update(status='closing',active_sessions={},completed_sessions=completed,updated_epoch=time.time());state.update(status='closing',updated_epoch=time.time())
for n,d in (('operator-state.json',operator),('state.json',state)):(ROOT/n).write_text(json.dumps(d,indent=2)+'\n')
for n,h in read(ROOT/'validation.json')['sha256'].items():assert sha(ROOT.parents[1]/n)==h,n
assert not list(ROOT.glob('*-failure.json'))
live=[]
for p in Path('/proc').iterdir():
 if not p.name.isdecimal() or int(p.name)==os.getpid():continue
 try:argv=(p/'cmdline').read_bytes().split(b'\0')
 except (FileNotFoundError,ProcessLookupError,PermissionError):continue
 if argv and Path(os.fsdecode(argv[0])).name.startswith('python') and any(ROOT.name.encode() in a for a in argv[1:]):live.append(int(p.name))
assert not live,live
report=dict(status='passed',epoch=time.time(),actual_elapsed_seconds=time.time()-START,preservation=preservation(),owned_python_processes_remaining=live,all_final_sessions_actually_reaped=True,formal_outputs_created=False)
(ROOT/'closing-preflight.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
