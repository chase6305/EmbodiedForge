"""Frozen initial/current task implementations and exact numeric evidence."""
import hashlib,importlib.util,json,os
from pathlib import Path
import numpy as np
from embodiedforge import Config,VectorEnv
from embodiedforge.core import StateSnapshot
from embodiedforge.tasks import ReachTask,HoldTask
ROOT=Path(__file__).resolve().parents[1];WORKSPACE=ROOT.parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def atomic(p,data):
 tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n');tmp.replace(p)
spec=importlib.util.spec_from_file_location('embodiedforge._round8_initial_tasks',ROOT/'initial/src/embodiedforge/tasks.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
CLASSES={'initial':{'reach':old.ReachTask,'hold':old.HoldTask},'current':{'reach':ReachTask,'hold':HoldTask}}
def source_map():return {str(p.relative_to(WORKSPACE)):sha(p) for p in sorted((WORKSPACE/'src').rglob('*.py'))}
def guard():
 assert source_map()==read(ROOT/'frozen-runtime.json')['sha256'],'Runtime source drift'
 for p,h in read(ROOT/'frozen-harness.json')['sha256'].items():assert sha(ROOT/p)==h,p
def pin(cpu=0):assert cpu in os.sched_getaffinity(0);os.sched_setaffinity(0,{cpu})
def fingerprint(values):
 h=hashlib.sha256()
 for key,value in sorted(values.items()):
  h.update(key.encode());h.update(str((value.shape,value.dtype.str)).encode());h.update(value.tobytes())
 return h.hexdigest()
def equal(left,right):
 assert left.keys()==right.keys()
 for key in left:
  a,b=left[key],right[key];assert type(a) is type(b),(key,'type')
  assert a.shape==b.shape and a.dtype==b.dtype,(key,'shape/dtype')
  assert a.tobytes()==b.tobytes(),(key,'bytes')
def environment(version,task_name,count,substeps=4,channels=(),seed=81):
 task=CLASSES[version][task_name]();env=VectorEnv(Config(task=task_name,num_envs=count,physics_hz=50*substeps,max_steps=1000000,render='raster' if channels else 'null',channels=channels,image_size=32,seed=seed),task)
 env.physics.position[:]=.5;env.physics.velocity[:]=0
 if task_name=='reach':task.target[:]=1
 return env

def arrays(count,layout='C',dtype='float64',seed=81):
 rng=np.random.default_rng(seed);fields=[]
 for _ in range(3):
  value=rng.normal(size=(count,2)).astype(dtype)
  if layout=='F':value=np.asfortranarray(value)
  elif layout=='strided':value=np.repeat(value,2,axis=0)[::2]
  fields.append(value)
 return fields

def task_fixture(version,task_name,count,layout='C'):
 task=CLASSES[version][task_name]();task.build(count);position,velocity,task.target=arrays(count,layout)
 for v in (position,velocity,task.target):v.flags.writeable=False
 state=StateSnapshot(position,velocity,np.zeros(count),np.zeros(count,np.int64))
 return task,state
