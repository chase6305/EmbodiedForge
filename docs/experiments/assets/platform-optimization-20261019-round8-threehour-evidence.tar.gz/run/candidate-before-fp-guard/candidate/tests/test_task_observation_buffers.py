"""Task features retain conversion, dispatch and ownership across layouts."""

import numpy as np
import pytest

from embodiedforge.core import StateSnapshot
from embodiedforge.tasks import HoldTask, ReachTask


class LegacyConcatenate(np.ndarray):
    def __array_function__(self, func, types, args, kwargs):
        if func is np.concatenate:
            assert "dtype" not in kwargs and "casting" not in kwargs
        return super().__array_function__(func, types, args, kwargs)


class NoSizeInspection(LegacyConcatenate):
    @property
    def size(self):
        raise RuntimeError("Feature assembly must not inspect subclass size")


@pytest.mark.parametrize("task_class", [ReachTask, HoldTask])
def test_task_observation_does_not_inspect_subclass_size(task_class):
    position = np.zeros((1024, 2)).view(NoSizeInspection)
    velocity = np.zeros((1024, 2))
    task = task_class()
    task.build(1024)
    state = StateSnapshot(position, velocity, np.zeros(1024), np.zeros(1024, np.int64))
    parts = (position, velocity)
    if task_class is ReachTask:
        parts += (task.target - position,)
    expected = np.concatenate(parts, axis=1).astype(np.float32)
    assert task.observe(state)["proprio"].tobytes() == expected.tobytes()


@pytest.mark.parametrize("task_class", [ReachTask, HoldTask])
@pytest.mark.parametrize("count", [0, 1, 1023, 1024, 4097])
@pytest.mark.parametrize("layout", ["C", "F", "strided"])
@pytest.mark.parametrize("kind", ["float64", "float32", ">f8", "subclass"])
def test_task_observation_conversion_and_owned_storage(task_class, count, layout, kind):
    rng = np.random.default_rng(812)
    values = []
    for _ in range(3):
        value = rng.normal(size=(count, 2)).astype(
            np.float64 if kind == "subclass" else kind
        )
        if layout == "F":
            value = np.asfortranarray(value)
        elif layout == "strided":
            value = np.repeat(value, 2, axis=0)[::2]
        if kind == "subclass":
            value = value.view(LegacyConcatenate)
        value.flags.writeable = False
        values.append(value)
    position, velocity, target = values
    before = [value.tobytes() for value in values]
    state = StateSnapshot(
        position, velocity, np.zeros(count), np.zeros(count, np.int64)
    )
    task = task_class()
    task.build(count)
    task.target = target
    parts = (position, velocity)
    if task_class is ReachTask:
        parts += (target - position,)
    expected = np.concatenate(parts, axis=1).astype(np.float32)
    actual = task.observe(state)["proprio"]
    assert type(actual) is type(expected)
    assert actual.dtype == expected.dtype == np.float32
    assert actual.shape == expected.shape
    assert actual.tobytes() == expected.tobytes()
    assert actual.flags.owndata
    assert actual.flags.c_contiguous == expected.flags.c_contiguous
    assert actual.flags.f_contiguous == expected.flags.f_contiguous
    for value in values:
        assert not np.shares_memory(actual, value)
    actual[:] = 99
    assert task.observe(state)["proprio"].tobytes() == expected.tobytes()
    assert before == [value.tobytes() for value in values]


@pytest.mark.parametrize("task_class", [ReachTask, HoldTask])
def test_mixed_integer_promotion_is_preserved(task_class):
    count = 1024
    # The integer lies just above a float32 midpoint. Promoting it to float64
    # before the final cast can round differently from a direct integer cast.
    midpoint = 2**63 + 2**39 + 1
    position = np.full((count, 2), midpoint, np.uint64)
    velocity = np.zeros((count, 2), np.int64)
    task = task_class()
    task.build(count)
    task.target = position.copy()
    state = StateSnapshot(
        position, velocity, np.zeros(count), np.zeros(count, np.int64)
    )
    parts = (position, velocity)
    if task_class is ReachTask:
        parts += (task.target - position,)
    expected = np.concatenate(parts, axis=1).astype(np.float32)
    assert position.astype(np.float32).tobytes() != expected[:, :2].tobytes()
    assert task.observe(state)["proprio"].tobytes() == expected.tobytes()


@pytest.mark.parametrize("task_class", [ReachTask, HoldTask])
def test_float64_cast_preserves_special_value_bits(task_class):
    values = np.array([0.0, -0.0, np.inf, -np.inf, np.nan, np.finfo(float).tiny])
    position = np.resize(values, (1024, 2))
    velocity = np.resize(values[::-1], (1024, 2))
    task = task_class()
    task.build(1024)
    state = StateSnapshot(position, velocity, np.zeros(1024), np.zeros(1024, np.int64))
    with np.errstate(all="ignore"):
        parts = (position, velocity)
        if task_class is ReachTask:
            parts += (task.target - position,)
        expected = np.concatenate(parts, axis=1).astype(np.float32)
        assert task.observe(state)["proprio"].tobytes() == expected.tobytes()
