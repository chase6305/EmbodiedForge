"""Compare whole baseline/current packages with isolated pipeline workers."""
import argparse,gc,hashlib,importlib.util,json,os,statistics,subprocess,sys,tempfile
from pathlib import Path
root=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--worker',action='store_true');p.add_argument('--case');a=p.parse_args()
if a.worker:
 import numpy as np
 import embodiedforge
 from embodiedforge import VectorEnv
 from embodiedforge.tasks import ReachTask
 class TimeoutTask(ReachTask):
  def evaluate(self,state,actions,previous):
   n=len(state.time);return np.zeros(n,np.float32),np.zeros(n,bool),np.zeros(n,bool)
 spec=importlib.util.spec_from_file_location('r3_pipeline_bench',Path.cwd()/'benchmarks/recording_pipeline.py');bench=importlib.util.module_from_spec(spec);spec.loader.exec_module(bench)
 bench.measure.__globals__['VectorEnv']=lambda config:VectorEnv(config,task=TimeoutTask())
 gc.collect()
 with tempfile.TemporaryDirectory(prefix='ef-r3-pipeline-') as tmp:r=bench.measure(Path(tmp)/'run',**json.loads(a.case))
 package=Path(embodiedforge.__file__).parent;r['source_sha256']={name:hashlib.sha256((package/name).read_bytes()).hexdigest() for name in ('data.py','backends/render.py','env.py','sensors.py')};print(json.dumps(r),flush=True)
else:
 cases=[dict(workers=w,episode_format=layout,num_envs=4,steps=40,cycles=3,image_size=64,budget_mib=12,noise=noise) for noise in (False,True) for layout in ('transitions','compact') for w in (0,1,2)]
 cases.extend(dict(workers=w,episode_format='compact',num_envs=16,steps=10,cycles=3,image_size=128,budget_mib=64,noise=False) for w in (0,2))
 cases.extend(dict(workers=w,episode_format='compact',num_envs=n,steps=3,cycles=2,image_size=size,budget_mib=512,noise=False) for n,size in [(16,540),(8,1024)] for w in (0,2))
 rows=[]
 for case in cases:
  runs={name:[] for name in ('baseline','candidate')}
  for pair in range(6):
   order=[('baseline',root/'baseline'),('candidate',Path.cwd()/'src')]
   if pair%2:order.reverse()
   for label,path in order:
    env=dict(os.environ,PYTHONPATH=str(path.resolve()),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    r=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker','--case',json.dumps(case)],env=env,capture_output=True,text=True,timeout=60);assert r.returncode==0,r.stdout+r.stderr
    if pair:runs[label].append(json.loads(r.stdout))
  assert len({r['sha256'] for v in runs.values() for r in v})==1
  for label,group in runs.items():assert all(r['source_sha256']==group[0]['source_sha256'] for r in group)
  med={name:statistics.median(r['seconds_including_close'] for r in v) for name,v in runs.items()}
  row=dict(arguments=case,runs=runs,median_seconds=med,reduction_pct=100*(1-med['candidate']/med['baseline']));rows.append(row);print(json.dumps({k:v for k,v in row.items() if k!='runs'}),flush=True)
 report=dict(scope='Whole isolated baseline/current packages: NumPy physics+raster RGB/depth+recorder append/NPZ+final close, excluding construction and subsequent full decoded audit; all decoded hashes match. Timeout-only task, fixed seed/cycles; synthetic noise labelled. One warmup and five alternating measured pairs. No task-owned sustained probes during this benchmark, shared unpinned host; no neural inference or training throughput claim.',cases=rows)
 (root/'full-pipeline-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
