"""Audit live stress progress, source identity and the one retained budget control."""
import hashlib,json,time
from pathlib import Path
root=Path(__file__).resolve().parent.parent;now=time.time();summary={};proof=json.loads((root/'final-checks.json').read_text())['source_hashes']
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in proof.items())
assert [str(p.relative_to(root)) for p in root.rglob('*failure.json')]==['phase3/large-recording-budget-control/endurance-failure.json']
for stem in ['sensor-py312','sensor-numpy124','endurance','large-recording/endurance']:
 final=root/(stem+'.json');progress=root/(stem+'-progress.json');data=json.loads((final if final.exists() else progress).read_text());row={k:data[k] for k in ['status','cases','coverage','selected_pixels','transitions','unique_configurations'] if k in data}
 if final.exists():assert data['status']=='passed'
 else:row['progress_age_seconds']=round(now-data['epoch'],2);assert row['progress_age_seconds']<60,(stem,row)
 summary[stem]=row
report=dict(epoch=now,elapsed_minutes=round((now-1792138162)/60,2),source_unchanged=True,stress=summary)
audit=root/'monitor-audit.json';history=json.loads(audit.read_text()) if audit.exists() else [];history.append(report);audit.write_text(json.dumps(history,indent=2)+'\n');print(json.dumps(report),flush=True)
