import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent.parent
py312='/tmp/ef-ci312-20261014/bin/python';py124='/tmp/ef-numpy124-20261014/bin/python'
cases=[('validation-py312',[py312,str(root/'scripts/compare_validation.py'),'--output','validation-final-py312.json']),('validation-numpy124',[py124,str(root/'scripts/compare_validation.py'),'--output','validation-final-numpy124.json']),('environment',[py312,str(root/'scripts/compare_environment.py')]),('pipeline',[py312,str(root/'scripts/full_pipeline_compare.py')])]
proof=hashlib.sha256(Path('src/embodiedforge/sensors.py').read_bytes()).hexdigest();rows=[];env=dict(os.environ,PYTHONPATH=str(Path.cwd()/'src'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
for label,command in cases:
 started=time.time();log=root/f'performance-{label}.log'
 (root/'performance-progress.json').write_text(json.dumps(dict(status='running',stage=label,started_epoch=started,finished=rows),indent=2)+'\n');print(json.dumps(dict(stage=label,status='running',epoch=started)),flush=True)
 with log.open('x') as stream:r=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=1800)
 row=dict(stage=label,command=command,returncode=r.returncode,started_epoch=started,ended_epoch=time.time(),log=str(log),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest());rows.append(row);print(json.dumps(row),flush=True)
 assert r.returncode==0,log.read_text()[-5000:]
 assert proof==hashlib.sha256(Path('src/embodiedforge/sensors.py').read_bytes()).hexdigest()
(root/'performance-runs.json').write_text(json.dumps(dict(status='passed',source_sha256=proof,stages=rows,scope='Task-owned benchmark stages executed sequentially, with no task-owned long stress process active. Shared unpinned host; unrelated host activity unknown.'),indent=2)+'\n')
