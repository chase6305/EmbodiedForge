"""Validate sensor predicates, cache atomicity and ownership against baseline and NumPy."""
import argparse,gc,hashlib,importlib.util,json,threading,time,traceback,weakref
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import embodiedforge.sensors as current
from embodiedforge.core import Config,RenderBatch,SceneUpdate,StateSnapshot
root=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--until',type=float,default=1792145182);p.add_argument('--label',required=True);p.add_argument('--seconds',type=float);a=p.parse_args()
if a.seconds is not None:a.until=time.time()+a.seconds
s=importlib.util.spec_from_file_location('embodiedforge._r3_endurance_old_sensors',root/'baseline/embodiedforge/sensors.py');old=importlib.util.module_from_spec(s);s.loader.exec_module(old)
proof={label:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for label,m in [('baseline',old),('candidate',current)]};harness_hash=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
def resources():
 return dict(fd=len(list(Path('/proc/self/fd').iterdir())),threads=threading.active_count(),rss_bytes=int(next(x.split()[1] for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('VmRSS:')))*1024)
initial=resources();started=time.time();cases=pixels=large=0;coverage=set();samples=[];refs=[]
layouts=['C','F','reversed','mixed','strided'];faults=['none','negative','nan','pinf','ninf','snan','validity','both','time','version','shape','dtype'];sizes=[1,7,32,64,127,257,540,1024,2049]
try:
 while time.time()<a.until:
  index=(cases*104729)%(len(layouts)*len(faults)*len(sizes)*3);size=sizes[index%9];layout=layouts[(index//9)%5];fault=faults[(index//45)%12];n=(1,3,16)[(index//540)%3];n=min(n,2) if size>=1024 else n
  rng=np.random.default_rng(8700000+cases);selected=max(1,n-(cases%max(1,n)));ids=rng.choice(n,selected,replace=False)
  if (cases+cases//1620)%2:ids=np.repeat(ids,2)[::2]
  state=StateSnapshot(np.zeros((n,2)),np.zeros((n,2)),np.arange(n,dtype=np.float64)+cases/100,np.arange(n,dtype=np.int64)+cases);update=SceneUpdate(state,{})
  depth=rng.random((selected,1,size,size),dtype=np.float32);depth[...,::3,::5]=0;depth.flat[0]=np.finfo(np.float32).max;depth.flat[-1]=np.finfo(np.float32).smallest_subnormal
  if layout=='F':depth=np.asfortranarray(depth)
  elif layout=='reversed':depth=depth[...,::-1,::-1]
  elif layout=='strided':depth=np.repeat(depth,2,axis=-1)[...,::2]
  valid=depth>0
  if layout=='mixed':valid=np.asfortranarray(valid)
  valid_time=state.time[ids];valid_version=state.version[ids]
  good=RenderBatch(dict(depth=depth,depth_valid=valid),valid_time,valid_version,dict(camera={'case':cases,'size':size}))
  pipelines=[]
  for module in (old,current):
   renderer=SimpleNamespace(sync=lambda _:None,render=lambda _:good);pipe=module.SensorPipeline(Config(num_envs=n,image_size=size,channels=('depth',)),renderer);pipe.sample(ids,update);pipelines.append(pipe);refs.append(weakref.ref(pipe))
  expected_depth=np.zeros((n,1,size,size),np.float32);expected_valid=np.zeros((n,1,size,size),bool);expected_depth[ids]=depth;expected_valid[ids]=valid
  expected_time=np.zeros(n);expected_version=np.zeros(n,np.int64);expected_time[ids]=valid_time;expected_version[ids]=valid_version
  position=[0,262143,262144,depth.size-1][(cases+cases//1620)%4]%depth.size
  if fault in ['negative','nan','pinf','ninf','both']:depth.flat[position]={'negative':-np.finfo(np.float32).smallest_subnormal,'nan':np.nan,'pinf':np.inf,'ninf':-np.inf,'both':np.nan}[fault]
  if fault=='snan':depth.view(np.uint32).flat[position]=0x7f800001
  if fault in ['validity','both']:valid.flat[position]=not valid.flat[position]
  batch_time=valid_time.copy();batch_version=valid_version.copy();images=dict(depth=depth,depth_valid=valid)
  if fault=='time':batch_time[-1]+=1
  if fault=='version':batch_version[-1]+=1
  if fault=='shape':images['depth_valid']=valid[...,0]
  if fault=='dtype':images['depth_valid']=valid.astype(np.uint8)
  batch=RenderBatch(images,batch_time,batch_version,dict(camera={'case':cases+1,'size':size}))
  if (cases+cases//1620)%2:depth.setflags(write=False);valid.setflags(write=False)
  input_hash=hashlib.sha256(depth.tobytes()+valid.tobytes()).hexdigest()
  with np.errstate(all='raise'):
   oracle_finite=bool(np.isfinite(depth).all() and not (depth<0).any());oracle_mask=np.array_equal(depth>0,valid)
   for module in (old,current):assert module._valid_depth(depth)==oracle_finite;assert module._matching_depth_validity(depth,valid)==oracle_mask
  expected_error=None
  if fault in ['negative','nan','pinf','ninf','snan','both']:expected_error='Depth must be finite and nonnegative'
  elif fault=='validity':expected_error='Depth validity must match positive depth pixels'
  elif fault in ['time','version']:expected_error='Renderer returned a stale or mismatched state version/time'
  elif fault in ['shape','dtype']:expected_error='Invalid renderer layout/dtype for depth_valid'
  for pipe in pipelines:
   pipe.renderer.render=lambda _:batch
   try:pipe.sample(ids,update)
   except ValueError as error:assert str(error)==expected_error,(fault,str(error),expected_error)
   else:assert expected_error is None,fault
   np.testing.assert_array_equal(pipe.images['depth'],expected_depth);np.testing.assert_array_equal(pipe.images['depth_valid'],expected_valid);np.testing.assert_array_equal(pipe.frame_time,expected_time);np.testing.assert_array_equal(pipe.frame_version,expected_version)
   assert pipe.calibration==dict(camera={'case':cases if expected_error else cases+1,'size':size})
   observed=pipe.observe(state.time,env_ids=ids)
   for name in ['depth','depth_valid','frame_time','frame_version','frame_age']:
    assert observed[name].flags.owndata
    observed[name][...]=0
   np.testing.assert_array_equal(pipe.images['depth'],expected_depth);np.testing.assert_array_equal(pipe.images['depth_valid'],expected_valid)
  assert hashlib.sha256(depth.tobytes()+valid.tobytes()).hexdigest()==input_hash
  cases+=1;pixels+=depth.size;large+=depth.size>4*1024*1024;coverage.add((size,layout,fault,n))
  del pipe,pipelines,observed,good,batch,renderer
  if cases%25==0:gc.collect();assert all(ref() is None for ref in refs);refs.clear()
  r=resources();assert r['fd']==initial['fd'] and r['threads']==initial['threads']
  if not samples or time.time()-samples[-1]['epoch']>=15:
   sample=dict(epoch=time.time(),cases=cases,selected_pixels=pixels,large_cases=large,coverage=len(coverage),resources=r);samples.append(sample);(root/f'sensor-{a.label}-progress.json').write_text(json.dumps(dict(status='running',started_epoch=started,until=a.until,**sample),indent=2)+'\n');print(json.dumps(sample),flush=True)
 gc.collect();assert all(ref() is None for ref in refs)
 assert proof['candidate']==hashlib.sha256(Path(current.__file__).read_bytes()).hexdigest();assert harness_hash==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 report=dict(status='passed',python=__import__('platform').python_version(),numpy=np.__version__,started_epoch=started,ended_epoch=time.time(),cases=cases,selected_pixels=pixels,large_cases=large,coverage=len(coverage),source_sha256=proof,harness_sha256=harness_hash,initial=initial,final=resources(),samples=samples,scope='Baseline/current sensor helper predicates against independent NumPy finite/nonnegative/mask reference; real SensorPipeline.sample/observe, successful partial caches then 12 valid/fault classes with error-message parity and unchanged previous images/time/version/calibration on rejection. Nine sizes, five layouts including independent mixed strides, read-only inputs, strided random selections, negative subnormal/NaN/+inf/-inf/signaling NaN/mismatch/stale stamps/shape/dtype. Returned observation mutation cannot alter caches or renderer inputs. FD and Python threads stable after every case; weakref release every 25 cases. RSS samples are not a leak proof.')
 (root/f'sensor-{a.label}.json').write_text(json.dumps(report,indent=2)+'\n')
except BaseException as error:
 (root/f'sensor-{a.label}-failure.json').write_text(json.dumps(dict(status='failed',epoch=time.time(),cases=cases,error=repr(error),traceback=traceback.format_exc()),indent=2)+'\n');raise
