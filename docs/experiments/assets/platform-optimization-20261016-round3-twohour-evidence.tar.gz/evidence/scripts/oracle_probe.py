import argparse,hashlib,importlib.util,json,sys,time
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--output',default='oracle-final.json');args=p.parse_args()
s=importlib.util.spec_from_file_location('embodiedforge._r3_oracle_candidate',root/'scripts/sensors_prototype.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
rng=np.random.default_rng(9961);started=time.time();cases=0;values=0
class Images(np.ndarray):pass
for size in [0,1,1024,8191,8192,8193,262143,262144,262145,4*1024*1024,4*1024*1024+1]:
 for dtype in [np.dtype('float32'),np.dtype('>f4'),np.dtype('float64')]:
  a=rng.uniform(0,100,size).astype(dtype);a[::7]=0
  for layout in ['C','reversed','strided','subclass']:
   if layout=='C':depth=a.copy()
   elif layout=='reversed':depth=a[::-1]
   elif layout=='strided':depth=np.repeat(a,2)[::2]
   else:depth=a.view(Images)
   for fault in [None,0x00000001,0x80000001,0x7f7fffff,0x7f800000,0xff800000,0x7f800001,0x7fc00000,0xff800001,0x80000000]:
    saved=depth[-1].copy() if size else None
    if size and fault is not None:depth[-1]=np.array([fault],np.uint32).view(np.float32)[0]
    with np.errstate(all='ignore'):
     expected=bool(np.isfinite(depth).all() and not (depth<0).any());actual=m._valid_depth(depth)
    assert actual==expected,(size,str(dtype),layout,fault,actual,expected)
    valid=depth>0
    for mismatch in [False,True]:
     if size and mismatch:valid[-1]=not valid[-1]
     before_depth=depth.tobytes();before_mask=valid.tobytes()
     assert m._matching_depth_validity(depth,valid)==np.array_equal(depth>0,valid),(size,str(dtype),layout,fault,mismatch)
     assert depth.tobytes()==before_depth and valid.tobytes()==before_mask
     cases+=1;values+=size
    if size:depth[-1]=saved
print(json.dumps(dict(status='passed',cases=cases,logical_values=values,seconds=time.time()-started)),flush=True)
(root/args.output).write_text(json.dumps(dict(status='passed',cases=cases,logical_values=values,seconds=time.time()-started,source_sha256=hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()),indent=2)+'\n')
