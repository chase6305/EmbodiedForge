"""Verify the gated final report, archive CRC/members, and source/stress identities."""
import gzip,hashlib,json,os,tarfile,time
from pathlib import Path,PurePosixPath
root=Path(__file__).resolve().parent.parent;repo=Path.cwd()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
report=json.loads((repo/'docs/platform-optimization-20261016-round3-twohour.json').read_text());state=json.loads((root/'progress-state.json').read_text());checks=json.loads((root/'final-checks.json').read_text());duration=report['duration']
assert report['status']=='complete' and not report['preview_only'] and duration['requirement_met'] and duration['elapsed_seconds']>=7200
assert duration['started_epoch']==1792138162 and duration['deadline_epoch']==1792145362
archive=repo/report['evidence_archive']['path'];assert sha(archive)==report['evidence_archive']['sha256'] and archive.stat().st_size==report['evidence_archive']['bytes']
with gzip.open(archive,'rb') as stream:
 while stream.read(1024*1024):pass
with tarfile.open(archive,'r:gz') as stream:
 members=stream.getmembers();names=[m.name for m in members];assert len(names)==len(set(names));payloads={}
 for member in members:
  path=PurePosixPath(member.name);assert not path.is_absolute() and '..' not in path.parts and member.isfile()
  with stream.extractfile(member) as content:data=content.read()
  assert len(data)==member.size;payloads[member.name]=data
 assert json.loads(payloads['evidence/duration-gate.json'])==duration
 for f,h in state['initial_runtime_sha256'].items():assert hashlib.sha256(payloads['evidence/baseline/'+str(Path(f).relative_to('src'))]).hexdigest()==h
 for f in ['src/embodiedforge/sensors.py','tests/test_sensor_validation.py','benchmarks/sensor_validation.py','docs/platform-optimization-20261016-round3-twohour-performance.svg']:
  assert hashlib.sha256(payloads['final/'+f]).hexdigest()==sha(repo/f)
 for name in ['endurance.json','sensor-py312.json','sensor-numpy124.json','large-recording/endurance.json']:
  assert json.loads(payloads['evidence/'+name])['status']=='passed'
 for f,h in json.loads(payloads['evidence/stress-script-hashes.json'])['sha256'].items():assert hashlib.sha256(payloads['evidence/'+f]).hexdigest()==h
control=json.loads(payloads['evidence/duration-gate-negative-control.json'])
assert hashlib.sha256(payloads['evidence/scripts/report.py']).hexdigest()==control['reporter_sha256'] and control['status']=='passed'
assert all(sha(repo/f)==h for f,h in checks['source_hashes'].items())
assert sha(repo/'tests/test_sensor_validation.py')==state['final_test_sha256']
verification=dict(status='passed',observed_epoch=time.time(),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,archive_members=len(members),gzip_crc='passed',all_tar_members_readable=True,no_duplicate_or_unsafe_member_paths=True,initial_runtime_sources_verified=len(state['initial_runtime_sha256']),final_runtime_sources_unchanged_since_tests=True,final_changed_source_test_benchmark_figure_verified=True,duration_gate_matches_report=True,final_stress_reports_passed=True)
(root/'artifact-verification.json').write_text(json.dumps(verification,indent=2)+'\n');report['artifact_verification']=verification;(repo/'docs/platform-optimization-20261016-round3-twohour.json').write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n');print(json.dumps(verification),flush=True)
