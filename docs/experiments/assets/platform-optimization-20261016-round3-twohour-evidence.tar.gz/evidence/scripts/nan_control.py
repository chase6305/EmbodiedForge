import hashlib,importlib.util,json,time
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parent.parent
paths={'baseline':root/'baseline/embodiedforge/sensors.py','initial_candidate':root/'phase1/sensors-before-f32-zero.py','final_candidate':Path.cwd()/'src/embodiedforge/sensors.py'}
rows=[]
for label,path in paths.items():
 s=importlib.util.spec_from_file_location('embodiedforge._nan_'+label,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
 for size in [8192,4194305]:
  for bits in [0x7f800001,0xff800001]:
   depth=np.ones(size,np.float32);depth.view(np.uint32)[-1]=bits;error=None;result=None
   try:
    with np.errstate(all='raise'):result=m._valid_depth(depth)
   except FloatingPointError as e:error=str(e)
   expected_failure=label=='initial_candidate' and size==4194305
   assert (error is not None)==expected_failure
   if not expected_failure:assert result is False
   assert depth.view(np.uint32)[-1]==bits
   rows.append(dict(source=label,size=size,bits=hex(bits),result=result,error=error,expected_failure=expected_failure,source_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
report=dict(status='passed',numpy=np.__version__,rows=rows,scope='Two signaling-NaN payload signs, direct and one-element final buffered chunk, under np.errstate(all=raise). Exact pre-fix source reproduces two NumPy1.24 scalar-promotion failures, baseline and final sources reject without mutation or floating exceptions.')
(root/'nan-control.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
