import hashlib,json,os,subprocess,tempfile,time
import numpy as np
from pathlib import Path
root=Path(__file__).resolve().parent.parent;bench=Path.cwd()/'benchmarks/sensor_validation.py'
env=dict(os.environ,PYTHONPATH=str(Path.cwd()/'src'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');rows=[]
with tempfile.TemporaryDirectory(prefix='ef-r3-bench-') as tmp:
 for label,exe in [('py310','/tmp/ef-ci310-20261014/bin/python'),('py312','/tmp/ef-ci312-20261014/bin/python'),('numpy124','/tmp/ef-numpy124-20261014/bin/python')]:
  hashes=[]
  for layout in ['contiguous','fortran','reversed','mixed','strided']:
   output=Path(tmp)/f'{label}-{layout}.json';cmd=[exe,str(bench),'--num-envs','3','--image-size','7','--calls','2','--layout',layout,'--output',str(output)]
   r=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=30);assert r.returncode==0,r.stdout+r.stderr;report=json.loads(output.read_text());assert report==json.loads(r.stdout);assert report['seconds']>0 and report['peak_traced_bytes']>0;hashes.append(report['sha256']);rows.append(dict(label=label,layout=layout,status='passed',sha256=report['sha256']))
  assert len({v for layout,v in zip(['contiguous','fortran','reversed','mixed','strided'],hashes) if layout!='reversed'})==1
  depth=np.random.default_rng(42).random((3,1,7,7),dtype=np.float32);depth[depth<.2]=0;depth=depth[...,::-1,::-1];valid=depth>0;digest=hashlib.sha256()
  for values in (depth,valid):digest.update(str((values.shape,values.dtype.str)).encode());digest.update(np.ascontiguousarray(values).data)
  assert hashes[2]==digest.hexdigest()
  for option,value in [('--num-envs','0'),('--image-size','-1'),('--calls','0'),('--layout','unknown')]:
   output=Path(tmp)/f'{label}-bad-{option}.json';cmd=[exe,str(bench),option,value,'--output',str(output)];r=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=30);assert r.returncode==2 and not output.exists(),r.stdout+r.stderr;rows.append(dict(label=label,option=option,value=value,returncode=r.returncode,status='passed'))
report=dict(status='passed',benchmark_sha256=hashlib.sha256(bench.read_bytes()).hexdigest(),source_sha256=hashlib.sha256(Path('src/embodiedforge/sensors.py').read_bytes()).hexdigest(),valid_cases=15,invalid_cases=12,rows=rows)
(root/'benchmark-smoke.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
