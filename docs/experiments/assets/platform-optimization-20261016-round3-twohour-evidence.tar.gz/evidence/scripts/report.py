"""Third two-hour report; final writes require the original actual wall-clock deadline."""
import argparse,hashlib,json,os,tarfile,time
from datetime import datetime,timezone
from pathlib import Path
root=Path(__file__).resolve().parent.parent;repo=Path.cwd()
p=argparse.ArgumentParser();p.add_argument('--preview',action='store_true');a=p.parse_args()
def load(name):return json.loads((root/name).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def compact_pairs(report,time_key='seconds'):
 rows=[]
 for row in report['cases']:
  r={k:v for k,v in row.items() if k!='runs'};r['seconds']={name:[x[time_key] for x in group] for name,group in row['runs'].items()};r['sha256']=row['runs']['baseline'][0]['sha256'];rows.append(r)
 return {k:v for k,v in report.items() if k!='cases'}|dict(cases=rows)
def compact_stress(report):
 r={k:v for k,v in report.items() if k!='samples'}
 if 'samples' in report:r['sample_count']=len(report['samples'])
 return r
def owned_processes():
 result=[]
 for directory in Path('/proc').iterdir():
  if not directory.name.isdigit() or int(directory.name)==os.getpid():continue
  try:
   argv=[v.decode() for v in (directory/'cmdline').read_bytes().split(b'\0') if v]
   if argv and Path(argv[0]).name.startswith('python') and any(str(root) in v or 'runs/platform-optimization-20261016-round3-twohour/' in v for v in argv):result.append(dict(pid=int(directory.name),command=argv))
  except (FileNotFoundError,PermissionError):continue
 return result
state=load('progress-state.json');observed=time.time();elapsed=observed-state['start_epoch'];checks=load('final-checks.json');source_hash=sha(repo/'src/embodiedforge/sensors.py')
if not a.preview:assert elapsed>=7200,(elapsed,7200)
assert state['start_epoch']==1792138162 and state['deadline_epoch']==1792145362
assert checks['status']=='passed' and all(sha(repo/f)==h for f,h in checks['source_hashes'].items())
assert all(sha(root/'baseline'/Path(f).relative_to('src'))==h for f,h in state['initial_runtime_sha256'].items())
assert all(sha(repo/f)==h for f,h in state['final_runtime_sha256'].items())
assert load('runtime-diff-summary.json')['changed_runtime_files']==['src/embodiedforge/sensors.py']
validation=[load('validation-final-py312.json'),load('validation-final-numpy124.json')];environment=load('environment-comparison.json');pipeline=load('full-pipeline-comparison.json')
assert all(r['status']=='passed' for r in validation+[environment])
for r in validation:
 assert r['source_sha256']['candidate']==source_hash and r['source_sha256']['benchmark']==sha(repo/'benchmarks/sensor_validation.py')
for r in [environment,pipeline]:
 for case in r['cases']:
  for sample in case['runs']['candidate']:assert sample['source_sha256']['sensors.py']==source_hash
assert load('performance-runs.json')['status']=='passed'
nan=load('nan-control.json');smoke=load('benchmark-smoke.json');oracles=[load('oracle-final-py312.json'),load('oracle-final-numpy124.json')]
assert nan['status']==smoke['status']=='passed'
assert smoke['source_sha256']==source_hash and smoke['benchmark_sha256']==sha(repo/'benchmarks/sensor_validation.py')
assert all(r['status']=='passed' and r['source_sha256']==source_hash for r in oracles)
assert all(row['source_sha256']==source_hash for row in nan['rows'] if row['source']=='final_candidate')
assert load('style-checks.json')['status']=='passed'
recording=load('endurance-progress.json' if a.preview else 'endurance.json')
sensors=[load(f'sensor-{label}-progress.json' if a.preview else f'sensor-{label}.json') for label in ['py312','numpy124']]
large_recording=load('large-recording/endurance.json' if (root/'large-recording/endurance.json').exists() else 'large-recording/endurance-progress.json')
if not a.preview:
 assert elapsed>=7200,(elapsed,7200)
 assert recording['status']=='passed' and all(r['status']=='passed' for r in sensors)
 assert recording['workers']['candidate']['source']['sensors.py']==source_hash
 assert all(r['source_sha256']['candidate']==source_hash for r in sensors)
 assert all(sha(root/f)==h for f,h in load('stress-script-hashes.json')['sha256'].items())
 assert [str(p.relative_to(root)) for p in root.rglob('*failure.json')]==['phase3/large-recording-budget-control/endurance-failure.json']
 assert load('large-recording-budget-control.json')['status']=='passed'
 assert large_recording['status']=='passed' and large_recording['cases']==128 and large_recording['unique_configurations']==128
 assert large_recording['workers']['candidate']['source']['sensors.py']==source_hash
 processes=owned_processes();assert not processes,processes
 assert all(r['cases']>0 for r in sensors) and recording['cases']>0

duration=dict(started_epoch=state['start_epoch'],deadline_epoch=state['deadline_epoch'],observed_epoch=observed,elapsed_seconds=elapsed,required_seconds=7200,requirement_met=elapsed>=7200,started_utc=datetime.fromtimestamp(state['start_epoch'],timezone.utc).isoformat(),observed_utc=datetime.fromtimestamp(observed,timezone.utc).isoformat(),scope='Actual wall clock from this round start; parallel benchmark, test and stress durations are not summed.')
report=dict(schema_version=1,date='2026-10-16',round='third-two-hour-round',status='active' if a.preview else 'complete',preview_only=a.preview,duration=duration,baseline_revision=state['head'],initial_worktree_status=(root/'initial-status.txt').read_text(),environment=load('environment.json'),runtime_diff=load('runtime-diff-summary.json'),changes=[dict(component='CPU sensor depth validation',paths=['src/embodiedforge/sensors.py','tests/test_sensor_validation.py'],behavior='Use min/max reductions for exact native float32 contiguous arrays at 8192..4194304 elements, retaining NumPy dispatch and existing small/strided fallback. Large arrays use 262144-element nditer chunks. Compare to a float32 zero so NumPy1.24 signaling-NaN scalar promotion cannot raise at a one-element tail. Reuse owned comparison scratch in-place, release it before allocating the next block, and chunk moderate equally ordered contiguous depth/validity arrays while avoiding iterator copy buffers for moderate strided arrays. Renderer inputs remain read-only; finite/nonnegative and positive-depth mask checks still precede all cache updates.'),dict(component='Validation benchmark coverage',paths=['benchmarks/sensor_validation.py'],behavior='Add interval-strided depth layout alongside C/F/reversed/mixed layouts, with input generation and hashing outside measured validation time.')],validation=dict(full_suites=[{k:v for k,v in row.items() if k!='tail'}|dict(result=row['tail'][-1]) for row in checks['results']],source_hashes=checks['source_hashes'],new_test_cases=62,new_test_breakdown=dict(readonly_extreme_thresholds=24,nan_negative_subnormal_payloads=12,readonly_mask_layouts=15,scalar_predicates=5,noncamera_dtype_and_mask_fallback=2,small_public_cache_atomicity=4),nan_negative_control=nan,predicate_oracles=oracles,benchmark_cli=smoke,style=load('style-checks.json')),performance=dict(serial_execution=load('performance-runs.json'),depth_validation=[compact_pairs(r) for r in validation],environment=compact_pairs(environment),recording=compact_pairs(pipeline,'seconds_including_close')),stress=dict(sensor_validation=[compact_stress(r) for r in sensors],recording=compact_stress(recording)),intermediate_experiments=[dict(path='phase1/',scope='Prototype reductions and comparisons; exact initial candidate failed two signaling-NaN tail tests on NumPy1.24. Baseline and final pass those controls; initial two full modern-NumPy suites passed, but this stage was not adopted.'),dict(path='phase2/',scope='Signaling-NaN fix with earlier 4096-element reduction cutoff. NumPy1.24 64px single-frame traced peak rose about4KB; final8192 cutoff avoids it. Earlier complete benchmarks and source retained as diagnostics.'),dict(path='validation-bounded-prototype-py312.json',scope='Early comparison blocking improved contiguous peak but increased moderate reversed-layout peak through iterator buffers; final only blocks matched contiguous layouts in this size range.')],figure='platform-optimization-20261016-round3-twohour-performance.svg')
for r in validation+[environment,pipeline]:
 for case in r['cases']:
  assert len({sample['sha256'] for group in case['runs'].values() for sample in group})==1
for r in validation:assert r['source_sha256']['baseline']==sha(root/'baseline/embodiedforge/sensors.py')
assert len(environment['cases'])==9 and len(pipeline['cases'])==18
selected=[case for r in validation for case in r['cases'] if case['num_envs']>1 and case['layout']=='contiguous']
report['key_findings']=dict(scope='Within-version baseline/final comparisons only; complete depth validation, contiguous float32 batches N32S128/N16S540/N8S1024',seconds_reduction_pct_range=[min(r['reduction_pct'] for r in selected),max(r['reduction_pct'] for r in selected)],traced_peak_reduction_pct_range=[min(r['peak_reduction_pct'] for r in selected),max(r['peak_reduction_pct'] for r in selected)],environment_seconds_reduction_pct_range=[min(r['reduction_pct'] for r in environment['cases']),max(r['reduction_pct'] for r in environment['cases'])],recording_seconds_reduction_pct_range=[min(r['reduction_pct'] for r in pipeline['cases']),max(r['reduction_pct'] for r in pipeline['cases'])],uniform_end_to_end_gain_established=False)
report['stress']['large_image_recording']=compact_stress(large_recording)
report['validation']['large_recording_budget_control']=load('large-recording-budget-control.json')
report['validation']['duration_gate_negative_control']=load('duration-gate-negative-control.json')
storage=[json.loads(p.read_text()) for p in sorted(root.glob('storage-oracle-*.json'))]
assert len(storage)==3 and all(r['status']=='passed' and r['source_sha256']['candidate']==source_hash for r in storage)
report['validation']['unusual_storage_oracles']=storage
report['reproduction']=dict(cwd='Repository checkout matching final source hashes. Extract evidence elsewhere; harness root/baseline is self-relative, current source/benchmark paths use repository cwd. CPU NumPy only for portable paths; optional integration suites use recorded environments.',current='OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONPATH=src python benchmarks/sensor_validation.py --num-envs 16 --image-size 540 --calls 100 --layout contiguous --output /tmp/depth-validation-r3.json',comparison='Run evidence/scripts/compare_validation.py with --output new-name.json from repository cwd using Python/NumPy as recorded. Candidate prototype whole-file hash matches final sensors.py. compare_environment.py and full_pipeline_compare.py compare isolated whole packages.',stress='sensor_endurance.py --label new-label --until FUTURE_UNIX_EPOCH; endurance.py --until FUTURE_UNIX_EPOCH. Defaults record this original round stop; use a future epoch to reproduce a new run.')
report['reproduction']['large_recording_baseline_alias']='Specialized large-image harnesses expect baseline aliases: evidence/large-recording/baseline -> ../baseline, and evidence/phase3/large-recording-budget-control/baseline -> ../../baseline. Recreate these directory symlinks after extraction, or copy the baseline package there; external robot binary assets remain supplied by the checkout.'
report['performance']['depth_validation_timing_inputs']='Valid finite nonnegative float32 RNG depth with20percent zeros and exactly matching boolean masks. Error rejection behavior is validated separately; rejection latency is not benchmarked.'
report['limits']=['All timings use CPU reference workloads on a shared unpinned host, with no neural inference, GPU training, real robot or web delivery. Compare initial/final within each Python/NumPy row; cross-version results also differ in Python and measurement time.','SensorPipeline validation inputs are allocated before tracing; their SHA256 is an input-content checksum. Environment checksums cover public observations/rewards/termination/reset outputs; recording checksums cover decoded episodes. Timing, traced allocation and checksum passes are separate.','Layout, size and NumPy affect gains. Small/strided/mixed cases can be effectively flat; all raw positive and negative measurements are retained.','Complete environment and recording experiments show positive and negative timing changes. No uniform end-to-end acquisition or training throughput improvement is established. Complete environment traced peaks remain essentially flat as images and owned observation copies dominate.','Traced temporary allocation peaks are not process RSS, GPU memory or hard process-memory budgets. Iterator copy buffers still depend on strides and dtype, particularly NumPy1.24.','The sustained sensor probe validates accepted/rejected batches and previous cache preservation; it does not promise rollback on arbitrary interpreter cancellation or allocation failure during cache writes.','FD/Python-thread equality and weakref release apply to tested cases; sampled RSS is not a general leak proof. Optional integration test skips and warnings remain recorded.']
if not a.preview:
 report['final_process_audit']=dict(status='passed',observed_epoch=time.time(),matching_processes=processes,scope='Exact run Python command-path scan excluding reporter; recording controller waits and reaps its workers.')
 (root/'duration-gate.json').write_text(json.dumps(duration,indent=2)+'\n')
 archive=repo/'docs/assets/platform-optimization-20261016-round3-twohour-evidence.tar.gz'
 files=[f for f in root.rglob('*') if f.is_file() and '__pycache__' not in f.parts and f.name!='report-preview.json' and (f.suffix in ('.py','.json','.log','.patch','.pstats','.txt','.html','.js','.xml') or f.name.startswith(('LICENSE','NOTICE')))]
 final=['src/embodiedforge/sensors.py','tests/test_sensor_validation.py','benchmarks/sensor_validation.py','benchmarks/reference_step.py','benchmarks/recording_pipeline.py','pyproject.toml','docs/interfaces.md','docs/platform-optimization-20261016-round3-twohour-performance.svg']
 final += [name for name in ('LICENSE','LICENSE.md','NOTICE','NOTICE.md') if (repo/name).is_file()]
 with tarfile.open(archive,'w:gz') as stream:
  for f in sorted(files):stream.add(f,arcname=str(Path('evidence')/f.relative_to(root)),recursive=False)
  for f in final:stream.add(repo/f,arcname=str(Path('final')/f),recursive=False)
 report['evidence_archive']=dict(path=str(archive.relative_to(repo)),sha256=sha(archive),bytes=archive.stat().st_size,scope='Exact initial Python package snapshot; final changed source/test/benchmark and documentation; raw paired measurements, scripts, test logs, phase1/phase2 diagnostics, duration gate and long stress samples. Synthetic inputs regenerate from scripts; installed packages and external binary SDK/robot assets excluded.')
out=root/'report-preview.json' if a.preview else repo/'docs/platform-optimization-20261016-round3-twohour.json'
out.write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n');print(json.dumps(dict(path=str(out),status=report['status'],elapsed_seconds=elapsed,requirement_met=duration['requirement_met'])))
