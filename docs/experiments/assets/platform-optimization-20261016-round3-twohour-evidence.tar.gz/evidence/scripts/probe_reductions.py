import gc,importlib.util,json,statistics,time,tracemalloc
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('embodiedforge._r3_baseline_sensors',root/'baseline/embodiedforge/sensors.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
def scalar(a):return bool(a.min(initial=0)>=0 and a.max(initial=0)<np.inf)
def chunked(a):
 with np.nditer(a,flags=['external_loop','buffered','zerosize_ok'],op_flags=['readonly'],buffersize=256*1024) as chunks:
  return all(scalar(chunk) for chunk in chunks)
def selected(a):
 if a.size<4096:return old._valid_depth(a)
 if a.size<=4*1024*1024 and (a.flags.c_contiguous or a.flags.f_contiguous):return scalar(a)
 return chunked(a)
rows=[]
for size in [1024,4096,16384,65536,524288,4665600,8388608]:
 for layout in ['C','F','reversed','strided']:
  rng=np.random.default_rng(71);a=rng.random((size//1024,1,32,32),dtype=np.float32)
  if layout=='F':a=np.asfortranarray(a)
  elif layout=='reversed':a=a[...,::-1,::-1]
  elif layout=='strided':a=np.repeat(a,2,axis=-1)[...,::2]
  funcs={'baseline':old._valid_depth,'scalar':scalar,'chunked':chunked,'selected':selected};runs={name:[] for name in funcs};peaks={name:[] for name in runs};calls=max(10,int(5e6/a.size))
  for pair in range(8):
   order=list(runs)
   if pair%2:order.reverse()
   for name in order:
    fn=funcs[name];gc.collect();assert fn(a)
    started=time.perf_counter()
    for _ in range(calls):assert fn(a)
    elapsed=time.perf_counter()-started
    if pair:runs[name].append(elapsed)
    tracemalloc.start();assert fn(a);_,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
    if pair:peaks[name].append(peak)
  med={k:statistics.median(v) for k,v in runs.items()}
  row=dict(shape=a.shape,layout=layout,calls=calls,runs=runs,peaks=peaks,median_seconds=med,reduction_pct={k:100*(1-v/med['baseline']) for k,v in med.items()})
  rows.append(row);print(json.dumps({k:v for k,v in row.items() if k not in ['runs','peaks']}),flush=True)
(root/'reductions-prototype.json').write_text(json.dumps(dict(cases=rows),indent=2)+'\n')
