import gc,importlib.util,json,statistics,time,tracemalloc
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parent.parent
s=importlib.util.spec_from_file_location('embodiedforge._r3_old_masks',root/'baseline/embodiedforge/sensors.py');old=importlib.util.module_from_spec(s);s.loader.exec_module(old)
def vector(depth,valid):
 mask=depth>0;np.not_equal(mask,valid,out=mask);return not mask.any()
def chunked(depth,valid):
 with np.nditer([depth,valid],flags=['external_loop','buffered','zerosize_ok'],op_flags=[['readonly'],['readonly']],buffersize=256*1024) as chunks:
  return all(vector(values,mask) for values,mask in chunks)
rows=[]
for n,size in [(1,32),(1,64),(32,128),(16,540),(8,1024)]:
 for layout in ['C','F','reversed','mixed','strided']:
  rng=np.random.default_rng(71);a=rng.random((n,1,size,size),dtype=np.float32)
  if layout=='F':a=np.asfortranarray(a)
  elif layout=='reversed':a=a[...,::-1,::-1]
  elif layout=='strided':a=np.repeat(a,2,axis=-1)[...,::2]
  valid=a>0
  if layout=='mixed':valid=np.asfortranarray(valid)
  funcs={'baseline':old._matching_depth_validity,'vector':vector,'chunked':chunked};runs={name:[] for name in funcs};peaks={name:[] for name in runs};calls=max(20,min(5000,int(5e7/a.size)))
  for pair in range(8):
   order=list(runs)
   if pair%2:order.reverse()
   for name in order:
    fn=funcs[name];gc.collect();assert fn(a,valid)
    started=time.perf_counter()
    for _ in range(calls):assert fn(a,valid)
    elapsed=time.perf_counter()-started
    if pair:runs[name].append(elapsed)
    tracemalloc.start();assert fn(a,valid);_,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
    if pair:peaks[name].append(peak)
  med={k:statistics.median(v) for k,v in runs.items()};pm={k:statistics.median(v) for k,v in peaks.items()}
  row=dict(num_envs=n,image_size=size,layout=layout,calls=calls,runs=runs,peaks=peaks,median_seconds=med,median_peaks=pm,reduction_pct={k:100*(1-v/med['baseline']) for k,v in med.items()});rows.append(row);print(json.dumps({k:v for k,v in row.items() if k not in ['runs','peaks']}),flush=True)
(root/'masks-prototype.json').write_text(json.dumps(dict(cases=rows),indent=2)+'\n')
