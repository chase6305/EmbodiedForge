"""Whole-package environment stepping, separate timing/tracing/checksum passes."""
import argparse,gc,hashlib,importlib.util,json,os,statistics,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
root=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--worker',action='store_true');p.add_argument('--case');a=p.parse_args()
if a.worker:
 import embodiedforge
 from embodiedforge.core import Config
 spec=importlib.util.spec_from_file_location('r3_env_benchmark',Path.cwd()/'benchmarks/reference_step.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
 case=json.loads(a.case);channels=tuple(case.pop('channels'));b.measure.__globals__['Config']=lambda **kwargs:Config(**(kwargs|dict(channels=channels)))
 args=SimpleNamespace(scope='environment',active_fraction=1.0,**case);gc.collect();seconds,_,_=b.measure(args);_,peak,_=b.measure(args,trace=True);_,_,digest=b.measure(args,checksum=True)
 package=Path(embodiedforge.__file__).parent;proof={str(f.relative_to(package)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(package.rglob('*.py'))}
 print(json.dumps(dict(seconds=seconds,peak_traced_bytes=peak,sha256=digest,source_sha256=proof)),flush=True)
else:
 cases=[dict(num_envs=128,image_size=64,steps=300,render='null',channels=[])]
 cases += [dict(num_envs=n,image_size=size,steps=steps,render='raster',channels=channels) for n,size,steps in [(1,64,200),(32,128,100),(16,540,20),(8,1024,12)] for channels in [('depth',),('rgb','depth')]]
 rows=[]
 for case in cases:
  runs={name:[] for name in ('baseline','candidate')}
  for pair in range(8):
   order=list(runs)
   if pair%2:order.reverse()
   for label in order:
    path=root/'baseline' if label=='baseline' else Path.cwd()/'src';env=dict(os.environ,PYTHONPATH=str(path.resolve()),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    r=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker','--case',json.dumps(case)],env=env,capture_output=True,text=True,timeout=180);assert r.returncode==0,r.stdout+r.stderr
    if pair:runs[label].append(json.loads(r.stdout))
  assert len({r['sha256'] for v in runs.values() for r in v})==1
  for group in runs.values():assert all(r['source_sha256']==group[0]['source_sha256'] for r in group)
  med={name:statistics.median(r['seconds'] for r in v) for name,v in runs.items()};peaks={name:statistics.median(r['peak_traced_bytes'] for r in v) for name,v in runs.items()}
  row=dict(arguments=case,runs=runs,median_seconds=med,median_peak_traced_bytes=peaks,reduction_pct=100*(1-med['candidate']/med['baseline']),peak_reduction_pct=100*(1-peaks['candidate']/peaks['baseline']));rows.append(row);print(json.dumps({k:v for k,v in row.items() if k!='runs'}),flush=True)
  (root/'environment-comparison.json').write_text(json.dumps(dict(status='running',cases=rows),indent=2)+'\n')
 (root/'environment-comparison.json').write_text(json.dumps(dict(status='passed',scope='Isolated whole baseline/current packages; NumPy VectorEnv.step with optional depth/RGB raster, SensorPipeline validation/copies, observation ownership and immediate reset of completed rows. One warmup plus seven alternating measured pairs; construction excluded; timing, traced allocation and complete output checksums are separate passes. Traced peak is not RSS; no policy inference, NPZ recording, GPU or training throughput. Shared unpinned host; concurrency recorded separately.',cases=rows),indent=2)+'\n')
