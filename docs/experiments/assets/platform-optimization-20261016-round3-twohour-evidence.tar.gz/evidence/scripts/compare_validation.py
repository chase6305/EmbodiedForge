import argparse,gc,hashlib,importlib.util,json,platform,statistics,sys,time
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--output',default='validation-comparison.json');p.add_argument('--replicates',type=int,default=9);p.add_argument('--candidate',default='scripts/sensors_prototype.py');a=p.parse_args()
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
old=module('embodiedforge._r3_baseline_sensors',root/'baseline/embodiedforge/sensors.py');new=module('embodiedforge._r3_candidate_sensors',root/a.candidate);bench=module('r3_validation_bench',Path.cwd()/'benchmarks/sensor_validation.py')
proof={name:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for name,m in [('baseline',old),('candidate',new),('benchmark',bench)]}
cases=[(n,s,layout) for n,s in [(1,32),(1,64),(32,128),(16,540),(8,1024)] for layout in ('contiguous','fortran','reversed','mixed','strided')]
rows=[]
for n,size,layout in cases:
 calls=max(20,min(10000,int(1e8/(n*size*size))));runs={label:[] for label in ('baseline','candidate')}
 for pair in range(a.replicates+1):
  order=list(runs)
  if pair%2:order.reverse()
  for label in order:
   bench.measure.__globals__['SensorPipeline']=(old if label=='baseline' else new).SensorPipeline;gc.collect();r=bench.measure(n,size,calls,layout)
   if pair:runs[label].append(r)
 assert len({r['sha256'] for group in runs.values() for r in group})==1
 med={label:statistics.median(r['seconds'] for r in group) for label,group in runs.items()};peaks={label:statistics.median(r['peak_traced_bytes'] for r in group) for label,group in runs.items()}
 row=dict(num_envs=n,image_size=size,layout=layout,calls=calls,runs=runs,median_seconds=med,median_peak_traced_bytes=peaks,reduction_pct=100*(1-med['candidate']/med['baseline']),peak_reduction_pct=100*(1-peaks['candidate']/peaks['baseline']));rows.append(row)
 (root/a.output).write_text(json.dumps(dict(status='running',source_sha256=proof,python=platform.python_version(),numpy=np.__version__,cases=rows),indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k!='runs'}),flush=True)
assert proof['candidate']==hashlib.sha256(Path(new.__file__).read_bytes()).hexdigest()
if a.candidate=='scripts/sensors_prototype.py':assert proof['candidate']==hashlib.sha256((Path.cwd()/'src/embodiedforge/sensors.py').read_bytes()).hexdigest()
(root/a.output).write_text(json.dumps(dict(status='passed',source_sha256=proof,python=platform.python_version(),numpy=np.__version__,scope='SensorPipeline complete depth-batch validation only; one warmup plus alternating measured pairs; separate traced allocation pass, input allocation and hashing excluded; traced peak is not RSS; shared unpinned host.',cases=rows),indent=2)+'\n')
