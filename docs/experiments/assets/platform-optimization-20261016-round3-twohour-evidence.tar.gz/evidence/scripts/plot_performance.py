"""Publication-style figure of complete depth validation, separate timing/allocation."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parent.parent
reports=[json.loads((root/name).read_text()) for name in ['validation-final-py312.json','validation-final-numpy124.json']]
cases=[(1,64),(32,128),(16,540),(8,1024)];labels=['N=1, 64 px','N=32, 128 px','N=16, 540 px','N=8, 1024 px'];colors={'baseline':'#939ca8','candidate':'#167f9d'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
fig,axes=plt.subplots(2,2,figsize=(13,9),gridspec_kw={'hspace':.45,'wspace':.25});x=np.arange(len(cases));width=.34
for row,report in enumerate(reports):
 selected=[next(r for r in report['cases'] if (r['num_envs'],r['image_size'])==case and r['layout']=='contiguous') for case in cases]
 for name,offset in [('baseline',-.5*width),('candidate',.5*width)]:
  measured=[[run['seconds']/r['calls']*1e6 for run in r['runs'][name]] for r in selected];median=np.array([np.median(v) for v in measured]);low=np.array([np.quantile(v,.25) for v in measured]);high=np.array([np.quantile(v,.75) for v in measured]);memory=np.array([r['median_peak_traced_bytes'][name]/1024 for r in selected])
  for col,values in [(0,median),(1,memory)]:
   ax=axes[row,col];ax.bar(x+offset,values,width,color=colors[name],label='Initial baseline' if name=='baseline' else 'Final source',zorder=3)
   if col==0:ax.errorbar(x+offset,values,yerr=[median-low,high-median],fmt='none',ecolor='#333333',capsize=3,lw=1,zorder=4)
   for xpos,value in zip(x+offset,values):ax.text(xpos,value*1.10,f'{value:.0f}',ha='center',va='bottom',fontsize=8)
 for col in range(2):
  ax=axes[row,col];ax.set_xticks(x,labels);ax.set_yscale('log');ax.grid(axis='y',alpha=.18,zorder=0);ax.set_axisbelow(True)
  ax.set_title(f"Python {report['python']} / NumPy {report['numpy']} — "+('validation time' if col==0 else 'traced allocation peak'),fontsize=11,pad=13)
  ax.set_ylabel('Microseconds per call (log scale)' if col==0 else 'KiB (log scale)');ax.set_ylim((3,20000) if col==0 else (2,2500));ax.legend(frameon=False,loc='upper left' if col==0 else 'upper right',fontsize=9)
fig.suptitle('CPU depth batch validation: timing and temporary allocation',fontsize=16,y=.98)
fig.text(.5,.925,'Contiguous float32 depth + bool validity; complete SensorPipeline._validate, including capture stamps and layouts.',ha='center',fontsize=10)
fig.text(.5,.035,'One warmup + nine alternating measured pairs; bars show medians, timing whiskers show IQR. Shared unpinned CPU, one BLAS/OMP thread.\nTiming excludes tracing and hashing. Allocation excludes inputs and is not RSS. Rendering, cache copies, recording and training are outside this figure.',ha='center',va='bottom',fontsize=9,color='#444444',linespacing=1.7)
fig.subplots_adjust(top=.86,bottom=.15)
out=Path('docs/platform-optimization-20261016-round3-twohour-performance.svg');fig.savefig(out,bbox_inches='tight');fig.savefig('/tmp/ef-round3-performance.png',dpi=140,bbox_inches='tight');print(out)
