import gc,importlib.util,json,statistics,sys,time,tracemalloc
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('embodiedforge._r3_baseline_sensors',root/'baseline/embodiedforge/sensors.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
def candidate(depth):
 if type(depth) is not np.ndarray or depth.dtype != np.float32:
  return old._valid_depth(depth)
 return bool(depth.min(initial=0) >= 0 and np.isfinite(depth.max(initial=0)))
rows=[]
for shape in [(1,1,32,32),(32,1,128,128),(16,1,540,540),(8,1,1024,1024)]:
 for layout in ['C','F','reversed','strided']:
  rng=np.random.default_rng(71);a=rng.random(shape,dtype=np.float32)
  if layout=='F':a=np.asfortranarray(a)
  elif layout=='reversed':a=a[...,::-1,::-1]
  elif layout=='strided':a=np.repeat(a,2,axis=-1)[...,::2]
  runs={name:[] for name in ['baseline','candidate']};peaks={name:[] for name in runs};calls=max(10,int(1e7/a.size))
  for pair in range(8):
   order=list(runs)
   if pair%2:order.reverse()
   for name in order:
    fn=old._valid_depth if name=='baseline' else candidate
    gc.collect();assert fn(a)
    started=time.perf_counter()
    for _ in range(calls):assert fn(a)
    elapsed=time.perf_counter()-started
    if pair:runs[name].append(elapsed)
    tracemalloc.start();assert fn(a);_,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
    if pair:peaks[name].append(peak)
  med={k:statistics.median(v) for k,v in runs.items()}
  row=dict(shape=shape,layout=layout,calls=calls,runs=runs,peaks=peaks,median_seconds=med,reduction_pct=100*(1-med['candidate']/med['baseline']))
  rows.append(row);print(json.dumps({k:v for k,v in row.items() if k not in ['runs','peaks']}),flush=True)
(root/'depth-prototype.json').write_text(json.dumps(dict(cases=rows),indent=2)+'\n')
