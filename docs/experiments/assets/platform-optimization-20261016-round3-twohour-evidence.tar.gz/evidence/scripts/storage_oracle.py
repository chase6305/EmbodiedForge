"""Unaligned, broadcast and permuted storage predicate validation."""
import hashlib,importlib.util,json,platform,time
from pathlib import Path
import numpy as np
import embodiedforge.sensors as new
root=Path(__file__).resolve().parent.parent
s=importlib.util.spec_from_file_location('embodiedforge._r3_storage_old',root/'baseline/embodiedforge/sensors.py');old=importlib.util.module_from_spec(s);s.loader.exec_module(old)
started=time.time();rows=[];pixels=0
for shape in [(1,1,64,64),(2,1,128,128),(2,1,513,513),(1,1,2049,2049)]:
 for layout in ['unaligned1','unaligned3','broadcast','transpose','outer_reverse','mask_broadcast']:
  for fault in [None,0x80000001,0x7f800000,0xff800000,0x7f800001,0xff800001,0x7fc00000,0x7f7fffff,0x80000000]:
   rng=np.random.default_rng(7781);values=rng.random(shape,dtype=np.float32);values[...,::3,::5]=0
   if layout.startswith('unaligned'):
    offset=int(layout[-1]);storage=np.empty(values.nbytes+offset,np.uint8);depth=np.ndarray(shape,np.float32,buffer=storage,offset=offset);depth[:]=values;target=depth
   elif layout=='broadcast':
    target=values[:1,:,:1].copy();depth=np.broadcast_to(target,shape)
   elif layout=='transpose':target=values;depth=values.swapaxes(-1,-2)
   elif layout=='outer_reverse':target=values;depth=values[::-1]
   else:target=values;depth=values;depth[:]=1
   if fault is not None:target.view(np.uint32).flat[-1]=fault
   valid=depth>0
   if layout=='mask_broadcast':valid=np.broadcast_to(np.array(True),shape)
   elif len(rows)%2:valid=np.asfortranarray(valid)
   depth.setflags(write=False);valid.setflags(write=False)
   before=(hashlib.sha256(depth.tobytes()).hexdigest(),hashlib.sha256(valid.tobytes()).hexdigest())
   with np.errstate(all='ignore'):
    finite=bool(np.isfinite(depth).all() and not (depth<0).any());matching=np.array_equal(depth>0,valid)
   for module in (old,new):
    with np.errstate(all='raise'):assert module._valid_depth(depth)==finite
    with np.errstate(all='ignore'):assert module._matching_depth_validity(depth,valid)==matching
   assert before==(hashlib.sha256(depth.tobytes()).hexdigest(),hashlib.sha256(valid.tobytes()).hexdigest())
   if finite:
    wrong=np.logical_not(valid);wrong.setflags(write=False)
    for module in (old,new):assert module._matching_depth_validity(depth,wrong)==np.array_equal(depth>0,wrong)
   pixels+=depth.size;rows.append(dict(shape=shape,layout=layout,bits=None if fault is None else hex(fault),finite=finite,matching=bool(matching),aligned=depth.flags.aligned))
report=dict(status='passed',python=platform.python_version(),numpy=np.__version__,seconds=time.time()-started,cases=len(rows),logical_values=pixels,source_sha256={'baseline':hashlib.sha256(Path(old.__file__).read_bytes()).hexdigest(),'candidate':hashlib.sha256(Path(new.__file__).read_bytes()).hexdigest()},rows=rows,scope='Exact predicates against baseline and independent NumPy; read-only misaligned float32 byte offsets1/3, broadcast zero strides, transposed and outer-reversed storage, broadcast validity masks, finite extrema/signaling NaN/negative subnormal/infinities. _valid_depth runs with all floating exceptions enabled; matching helper uses NumPy baseline warning policy for invalid depths rejected before it by the public validator. Input bit hashes unchanged.')
out=root/f'storage-oracle-{platform.python_version()}-numpy{np.__version__}.json';out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='rows'}),flush=True)
