"""Real-time bounded live-source raster probes with source and resource guards."""

import argparse
import hashlib
import json
import os
import sys
import threading
import time
import traceback
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def atomic(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def resources():
    return dict(epoch=time.time(), fds=len(os.listdir('/proc/self/fd')), python_threads=threading.active_count(), os_threads=len(os.listdir('/proc/self/task')))


class Run:
    def __init__(self):
        parser = argparse.ArgumentParser()
        parser.add_argument('--name', required=True)
        parser.add_argument('--cases', type=int)
        self.args = parser.parse_args()
        self.state = json.loads((ROOT / 'state.json').read_text())
        self.source = json.loads((ROOT / 'frozen-runtime.json').read_text())['sha256']
        paths = [Path(__file__), Path(sys.argv[0]).resolve()]
        self.scripts = {str(p.relative_to(ROOT)): sha(p) for p in paths}
        self.report = dict(name=self.args.name, status='running', pid=os.getpid(), argv=sys.argv, started_epoch=time.time(), python=sys.version, numpy=np.__version__, runtime_source_sha256=self.source, script_sha256=self.scripts, cases=0, configurations={}, resources=[resources()], scope='Live final-source public raster vs captured initial raster and independent dense geometry. Cases include expected empty requests; resource snapshots do not establish an RSS limit or general leak proof.')
        self.last = self.last_source = 0
        self.checkpoint(force=True)

    def active(self):
        return time.time() < self.state['probe_stop_epoch'] and (self.args.cases is None or self.report['cases'] < self.args.cases)

    def record(self, config):
        self.report['cases'] += 1
        key = json.dumps(config, sort_keys=True)
        self.report['configurations'][key] = self.report['configurations'].get(key, 0) + 1
        self.checkpoint()

    def checkpoint(self, force=False):
        now = time.time()
        if force or now - self.last >= 20:
            if force or now - self.last_source >= 60:
                actual = {str(p.relative_to(WORKSPACE)): sha(p) for p in sorted((WORKSPACE/'src').rglob('*.py'))}
                assert actual == self.source, 'Live runtime changed during probe'
                for name, digest in self.scripts.items():
                    assert sha(ROOT/name) == digest, name
                self.last_source = now
            current = resources()
            for key in ('fds', 'python_threads', 'os_threads'):
                assert current[key] == self.report['resources'][0][key], (key, current)
            self.report['resources'].append(current)
            self.report.update(updated_epoch=now, elapsed_seconds=now-self.report['started_epoch'], configuration_count=len(self.report['configurations']))
            atomic(ROOT/(self.args.name+'-progress.json'), self.report)
            self.last = now

    def finish(self):
        self.report.update(status='passed', finished_epoch=time.time())
        self.checkpoint(force=True)
        atomic(ROOT/(self.args.name+'.json'), self.report)
        print(json.dumps({k:self.report[k] for k in ('name','status','cases','elapsed_seconds','configuration_count')}), flush=True)

    def failed(self):
        self.report.update(status='failed', finished_epoch=time.time(), traceback=traceback.format_exc())
        atomic(ROOT/(self.args.name+'-failure.json'), self.report)
        atomic(ROOT/(self.args.name+'-progress.json'), self.report)
