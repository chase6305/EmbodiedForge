"""Plot deterministic allocation observations, without a timing speedup claim."""

import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
WORKSPACE=ROOT.parents[1]
STEM='platform-optimization-20261018-round6-sevenhour'
paths=sorted(ROOT.glob('raster-performance-*.json'),key=lambda p:json.loads(p.read_text())['numpy'],reverse=True)
assert len(paths)==3
plt.rcParams.update({'svg.fonttype':'none','font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(3,2,figsize=(11,10),layout='constrained')
fig.suptitle('Selective raster buffers: transient allocation peaks',fontsize=18,fontweight='bold',y=.99)
for row,path in enumerate(paths):
    data=json.loads(path.read_text())
    for column,pipeline in enumerate((False,True)):
        ax=axes[row,column]
        selected=[item for item in data['cases'] if item['size']==512 and item['count']==32 and item['pipeline']==pipeline]
        labels=['Depth','RGB','All channels']+([] if pipeline else ['Instance ID'])
        assert len(selected)==len(labels)
        x=np.arange(len(labels));width=.35
        for index,(key,color,label) in enumerate((('initial','#65788f','Captured initial source'),('current','#008f95','Selective buffers'))):
            values=[item[key]['peak_traced_bytes']/1024**2 for item in selected]
            bars=ax.bar(x+(index-.5)*width,values,width,color=color,label=label)
            ax.bar_label(bars,fmt='%.1f',padding=3,fontsize=8)
        ax.set_xticks(x,labels)
        ax.set_ylabel('Peak traced allocation (MiB)')
        ax.set_title(('Complete VectorEnv.step' if pipeline else 'Public RasterRenderer.render')+f"\nPython {data['python']} / NumPy {data['numpy']}",loc='left',fontsize=10)
        ax.set_ylim(0,190)
        ax.grid(axis='y',alpha=.18)
        ax.set_axisbelow(True)
        if row==0 and column==0:ax.legend(fontsize=8,loc='upper left')
fig.get_layout_engine().set(rect=(0,.09,1,.84))
fig.text(.03,.065,'32 environments, 512 x 512 pixels. The depth and RGB fast paths preserve public pixels, dtypes and ownership.',fontsize=9)
fig.text(.03,.045,'Tracemalloc peak of a call; prebuilt inputs/cache excluded. These are allocation observations, not process RSS.',fontsize=9)
fig.text(.03,.025,'CPU times are inconclusive because unchanged controls varied; all signed raw timings are retained. No GPU/training claim.',fontsize=9)
output=WORKSPACE/'docs'/f'{STEM}-allocations.svg'
fig.savefig(output,metadata={'Creator':'Matplotlib','Date':None})
fig.savefig('/tmp/ef-round6-allocations.png',dpi=130)
provenance=dict(status='passed',figure=str(output.relative_to(WORKSPACE)),figure_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),reports_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},timing_speedup_claim=False)
(ROOT/'figure-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps(provenance))
