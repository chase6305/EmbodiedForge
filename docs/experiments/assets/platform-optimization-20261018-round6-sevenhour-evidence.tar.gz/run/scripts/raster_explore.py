"""Exploratory public-renderer measurements; not final performance evidence."""

import hashlib
import importlib.util
import json
import platform
import statistics
import time
import tracemalloc
from pathlib import Path

import numpy as np
from embodiedforge.core import Config, SceneSpec, SceneUpdate, StateSnapshot

ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


paths = [ROOT / "initial/src/embodiedforge/backends/render.py", ROOT / "candidate-render.py"]
classes = [load("raster_" + str(i), p).RasterRenderer for i, p in enumerate(paths)]
rows = []
for size, count in ((64, 1), (128, 32), (256, 32), (512, 32)):
    rng = np.random.default_rng(1819)
    position, target = rng.uniform(-2, 2, (2, count, 2))
    state = StateSnapshot(position, np.zeros_like(position), np.arange(count, dtype=float), np.arange(count))
    update = SceneUpdate(state, dict(agent=position, target=target))
    ids = np.arange(count - 1, -1, -1)
    for channels in (("depth",), ("rgb",), ("rgb", "depth", "instance_id", "semantic_id")):
        renderers = [cls() for cls in classes]
        for renderer in renderers:
            renderer.build(SceneSpec(), Config(num_envs=count, image_size=size, channels=channels))
            renderer.sync(update)
        outputs = [x.render(ids) for x in renderers]
        for key in outputs[0].images:
            a, b = outputs[0].images[key], outputs[1].images[key]
            assert a.dtype == b.dtype and a.shape == b.shape
            assert a.tobytes() == b.tobytes() and b.flags.owndata
        times = [[], []]
        for pair in range(7):
            for index in ((0, 1) if pair % 2 == 0 else (1, 0)):
                started = time.perf_counter()
                for _ in range(3):
                    renderers[index].render(ids)
                times[index].append((time.perf_counter() - started) / 3)
        peaks = []
        for renderer in renderers:
            tracemalloc.start()
            output = renderer.render(ids)
            peaks.append(tracemalloc.get_traced_memory()[1])
            tracemalloc.stop()
            del output
        row = dict(size=size, count=count, channels=channels, seconds=times, peak_bytes=peaks, time_reduction_percent=100 * (1 - statistics.median(times[1]) / statistics.median(times[0])), peak_reduction_percent=100 * (1 - peaks[1] / peaks[0]))
        rows.append(row)
        print(json.dumps(row), flush=True)
report = dict(scope=__doc__, python=platform.python_version(), numpy=np.__version__, source_sha256={str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}, cases=rows)
(ROOT / "raster-explore.json").write_text(json.dumps(report, indent=2) + "\n")
