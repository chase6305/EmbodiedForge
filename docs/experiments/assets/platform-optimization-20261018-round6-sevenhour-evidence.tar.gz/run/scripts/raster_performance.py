"""Paired CPU raster and complete VectorEnv.step comparisons on frozen inputs."""

import gc
import hashlib
import importlib.util
import json
import platform
import time
import tracemalloc
from pathlib import Path

import numpy as np
from embodiedforge import Config, VectorEnv
from embodiedforge.backends import render as render_module
from embodiedforge.core import SceneSpec, SceneUpdate, StateSnapshot

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parents[1]
PATHS = [ROOT / "initial/src/embodiedforge/backends/render.py", WORKSPACE / "src/embodiedforge/backends/render.py"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(index):
    spec = importlib.util.spec_from_file_location("paired_raster_" + str(index), PATHS[index])
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.RasterRenderer


CLASSES = [load(index) for index in (0, 1)]


def arrays(output, pipeline):
    return output.observation if pipeline else {**output.images, "frame_time": output.time, "frame_version": output.version}


def compare(first, second, pipeline):
    a, b = arrays(first, pipeline), arrays(second, pipeline)
    assert list(a) == list(b)
    digest = hashlib.sha256()
    for name in a:
        assert a[name].dtype == b[name].dtype and a[name].shape == b[name].shape
        assert a[name].tobytes() == b[name].tobytes(), name
        assert b[name].flags.owndata
        digest.update(name.encode())
        digest.update(a[name].tobytes())
    if pipeline:
        for name in ("reward", "terminated", "truncated"):
            assert np.array_equal(getattr(first, name), getattr(second, name))
        assert not second.terminated.any() and not second.truncated.any()
    else:
        assert first.calibration == second.calibration
    return digest.hexdigest()


def case(size, count, channels, pipeline):
    config = Config(num_envs=count, image_size=size, channels=channels, render="raster", seed=19, max_steps=1000000)
    instances = []
    if pipeline:
        original = render_module.RasterRenderer
        try:
            for cls in CLASSES:
                render_module.RasterRenderer = cls
                instances.append(VectorEnv(config))
        finally:
            render_module.RasterRenderer = original
        action = np.zeros((count, 2))
        action.flags.writeable = False
        functions = [lambda env=env: env.step(action) for env in instances]
    else:
        rng = np.random.default_rng(1819)
        position, target = rng.uniform(-2, 2, (2, count, 2))
        position.flags.writeable = target.flags.writeable = False
        state = StateSnapshot(position, np.zeros_like(position), np.arange(count, dtype=float), np.arange(count))
        update = SceneUpdate(state, dict(agent=position, target=target))
        ids = np.arange(count - 1, -1, -1)
        ids.flags.writeable = False
        for cls in CLASSES:
            renderer = cls()
            renderer.build(SceneSpec(), config)
            renderer.sync(update)
            instances.append(renderer)
        functions = [lambda renderer=renderer: renderer.render(ids) for renderer in instances]
    for function in functions:
        for _ in range(4):
            function()
    calls = 3 if size <= 128 else 1
    times = [[], []]
    for pair in range(21):
        for index in ((0, 1) if pair % 2 == 0 else (1, 0)):
            gc.collect()
            started = time.perf_counter()
            for _ in range(calls):
                functions[index]()
            times[index].append((time.perf_counter() - started) / calls)
    peaks = []
    for function in functions:
        gc.collect()
        tracemalloc.start()
        output = function()
        peaks.append(tracemalloc.get_traced_memory()[1])
        tracemalloc.stop()
        del output
    first, second = [function() for function in functions]
    digest = compare(first, second, pipeline)
    results = []
    for index in (0, 1):
        results.append(dict(seconds=times[index], median_seconds=float(np.median(times[index])), q25_seconds=float(np.quantile(times[index], .25)), q75_seconds=float(np.quantile(times[index], .75)), peak_traced_bytes=peaks[index]))
    for instance in instances:
        instance.close()
    return dict(size=size, count=count, channels=channels, pipeline=pipeline, pairs=21, calls_per_sample=calls, output_sha256=digest, initial=results[0], current=results[1], elapsed_reduction_percent=100 * (1-results[1]["median_seconds"]/results[0]["median_seconds"]), peak_reduction_percent=100 * (1-peaks[1]/peaks[0]))


started = time.time()
sources = {"initial": sha(PATHS[0]), "current": sha(PATHS[1])}
rows = []
for pipeline, configurations in ((False, ((32, 1), (64, 16), (128, 32), (256, 32), (512, 32))), (True, ((64, 16), (256, 32), (512, 32)))):
    channel_sets = (("depth",), ("rgb",), ("rgb", "depth", "instance_id", "semantic_id"))
    if not pipeline:
        channel_sets += (("instance_id",),)
    for size, count in configurations:
        for channels in channel_sets:
            row = case(size, count, channels, pipeline)
            rows.append(row)
            print(json.dumps({k: row[k] for k in ("size", "count", "channels", "pipeline", "elapsed_reduction_percent", "peak_reduction_percent")}), flush=True)
assert sources == {"initial": sha(PATHS[0]), "current": sha(PATHS[1])}
report = dict(status="passed", scope="Shared, unpinned CPU host. Two frozen historical probes remained active during this final-source measurement; CPU timings are observational and no timing speedup is claimed. Public raster.render and complete NumPy VectorEnv.step (physics/task/raster/sensor validation/cache/owned observation) measured separately. Construction, warmup, audit and tracing excluded from paired timing. Traced peaks are transient allocations, not RSS. Synthetic point-reach scene; no robot training, GPU or photorealistic renderer claim.", started_epoch=started, finished_epoch=time.time(), python=platform.python_version(), numpy=np.__version__, source_sha256=sources, script_sha256=sha(Path(__file__)), cases=rows)
path = ROOT / f"raster-performance-py{platform.python_version()}-numpy{np.__version__}.json"
with path.open("x") as stream:
    json.dump(report, stream, indent=2)
    stream.write("\n")
print(json.dumps({"status": report["status"], "path": str(path), "cases": len(rows)}), flush=True)
