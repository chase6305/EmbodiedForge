"""Inject an isolated failure and verify the historical input recorder."""

import hashlib
import json
import sys
import textwrap
from pathlib import Path
from types import SimpleNamespace

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
script = ROOT/'scripts/subclass_endurance.py'
block = script.read_text().split('except BaseException:\n',1)[1].split('    if run.report',1)[0]
directory = ROOT/'controls/raw-capture'
directory.mkdir(parents=True,exist_ok=False)
namespace = dict(np=np,json=json,sys=sys,ROOT=directory,run=SimpleNamespace(name='injected'))
exec('def case():\n    arrays={"field":np.arange(12,dtype=np.float32).reshape(4,3), "masked":np.ma.array([1.,2.],mask=[False,True])}\n    metadata={"control":"injected"}\n    index=115660\n    before="controlled-before"\n    raise AssertionError("controlled recorder exercise")\n',namespace)
try:
    namespace['case']()
except AssertionError:
    exec(textwrap.dedent(block),namespace)
path=directory/'injected-failure-input.npz'
with np.load(path,allow_pickle=False) as data:
    assert np.array_equal(data['field'],np.arange(12,dtype=np.float32).reshape(4,3))
    assert np.array_equal(data['masked__mask'],[False,True])
    assert data['diagnostic_index'].item()==115660
    assert data['diagnostic_before_fingerprint'].item()=='controlled-before'
    assert json.loads(str(data['diagnostic_metadata']))==dict(control='injected')
report=dict(status='passed',scope='Injected recorder exercise only; does not classify the earlier real failure.',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),harness_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),capture_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
(ROOT/'capture-control.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
