"""Check preservation and absence of owned probe processes before final export."""

import json
import os
import time
from pathlib import Path

from report import ARCHIVE, PROBES, REPORT, ROOT, START, WORKSPACE, preservation, read, sha

assert not REPORT.exists() and not ARCHIVE.exists()
assert not read(ROOT/'operator-state.json')['active_sessions']
preserved=preservation()
validation=read(ROOT/'validation.json')
for name,digest in validation['sha256'].items():assert sha(WORKSPACE/name)==digest
completed=read(ROOT/'session-completions.json')
for name in PROBES:
    row=completed[name];assert row['exit_code']==0 and row['reaped'] is True
    assert not (Path('/proc')/str(row['pid'])).exists()
    assert read(ROOT/(name+'.json'))['status']=='passed'
assert not list(ROOT.glob('*-failure.json'))
live=[]
for path in Path('/proc').iterdir():
    if not path.name.isdecimal() or int(path.name)==os.getpid():continue
    try:arguments=(path/'cmdline').read_bytes().split(b'\0')
    except (FileNotFoundError,ProcessLookupError,PermissionError):continue
    if arguments and Path(os.fsdecode(arguments[0])).name.startswith('python') and any(ROOT.name.encode() in argument for argument in arguments[1:]):live.append(int(path.name))
assert not live,live
data=dict(status='passed',epoch=time.time(),actual_elapsed_seconds=time.time()-START,preservation=preserved,owned_python_processes_remaining=live,all_final_cohort_sessions_reaped=True,formal_outputs_created=False)
(ROOT/'closing-preflight.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data))
