"""Re-read the real exported archive and cross-check report/source evidence."""

import hashlib
import io
import json
import tarfile
import time

from report import ARCHIVE, CORE, DURATION, FIGURE, PROBES, REPORT, ROOT, START, WORKSPACE, read, sha, verify_archive

report=read(REPORT)
assert report['actual_elapsed_seconds']>=DURATION
assert report['duration_gate']['actual_elapsed_seconds']>=DURATION
assert report['parallel_durations_added'] is False
payload=ARCHIVE.read_bytes()
assert len(payload)==report['evidence_archive']['bytes']
assert hashlib.sha256(payload).hexdigest()==report['evidence_archive']['sha256']
count=verify_archive(payload)
assert count==report['evidence_archive']['regular_members']
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as archive:
    def archived(name):return archive.extractfile(name).read()
    initial=json.loads(archived('run/initial-hashes.json'))
    initial_sources=0
    for name,digest in initial.items():
        if name.startswith('src/') and name.endswith('.py'):
            assert hashlib.sha256(archived('run/initial/'+name)).hexdigest()==digest
            initial_sources+=1
    assert initial_sources==105
    for name in CORE:
        expected=report['review_files_sha256'][name]
        assert sha(WORKSPACE/name)==expected
        assert hashlib.sha256(archived('final/'+name)).hexdigest()==expected
    figure_name=str(FIGURE.relative_to(WORKSPACE))
    figure_data=archived('final/'+figure_name)
    assert hashlib.sha256(figure_data).hexdigest()==report['figure']['figure_sha256']==sha(FIGURE)
    assert b'<text' in figure_data
    assert hashlib.sha256(archived('run/scripts/plot.py')).hexdigest()==report['figure']['script_sha256']
    root_relative=ROOT.relative_to(WORKSPACE)
    for name,digest in report['validation']['sha256'].items():
        assert sha(WORKSPACE/name)==digest,name
        if name.startswith(str(root_relative)+'/'):
            location='run/'+str((WORKSPACE/name).relative_to(ROOT))
        else:
            location='final/'+name if name in CORE else 'run/initial/'+name
        assert hashlib.sha256(archived(location)).hexdigest()==digest,location
    frozen=json.loads(archived('run/frozen-runtime.json'))['sha256']
    assert frozen=={str(p.relative_to(WORKSPACE)):sha(p) for p in sorted((WORKSPACE/'src').rglob('*.py'))}
    old_frozen={name:hashlib.sha256(archived('run/initial/'+name)).hexdigest() for name in frozen}
    for name in PROBES:
        data=archived('run/'+name+'.json')
        probe=json.loads(data)
        assert probe['status']=='passed'
        assert probe['cases']==report['probe_results'][name]['cases']
        assert hashlib.sha256(data).hexdigest()==report['probe_results'][name]['raw_report_sha256']
        assert probe['configuration_count']==probe['base_configurations_expected']
        assert probe['runtime_source_sha256']==(old_frozen if name.startswith('historical') else frozen)
        for path,digest in probe['script_sha256'].items():assert hashlib.sha256(archived('run/'+path)).hexdigest()==digest,path
    for name,entry in report['performance'].items():
        data=archived('run/'+name)
        assert hashlib.sha256(data).hexdigest()==entry['sha256']
        assert json.loads(data)==entry['data']
        assert hashlib.sha256(archived('run/scripts/raster_performance.py')).hexdigest()==entry['data']['script_sha256']
    prior=archived('run/prior-diagnostic/subclasses-py312-failure.json')
    assert json.loads(prior)['status']=='failed'
    assert hashlib.sha256(prior).hexdigest()==report['historical_anomaly']['prior_failure_sha256']
    assert report['historical_anomaly']['status']=='unclassified'
    capture=report['capture_control']
    assert hashlib.sha256(archived('run/controls/raw-capture/injected-failure-input.npz')).hexdigest()==capture['capture_sha256']
    assert hashlib.sha256(archived('run/scripts/capture_control.py')).hexdigest()==capture['script_sha256']
    gate=json.loads(archived('run/duration-gate.json'))
    assert gate==report['duration_gate']
    control=gate['early_control']
    assert control['real_clock_used'] is True and control['clock_simulated'] is False
    assert control['actual_elapsed_seconds']<DURATION and control['final_outputs_created'] is False
    assert hashlib.sha256(archived('run/scripts/report.py')).hexdigest()==control['reporter_sha256']==sha(ROOT/'scripts/report.py')
    completions=json.loads(archived('run/session-completions.json'))
    for name in PROBES:assert completions[name]['exit_code']==0 and completions[name]['reaped'] is True
report['artifact_verification']=dict(status='passed',epoch=time.time(),actual_elapsed_seconds=time.time()-START,regular_archive_members=count,initial_runtime_sources=initial_sources,final_source_test_log_and_harness_links_verified=True,gzip_crc_and_all_manifest_hashes_verified=True,duration_and_real_early_rejection_verified=True,historical_failed_record_preserved=True,historical_and_live_scopes_separated=True,timing_speedup_claim_withheld=True)
report['status']='complete_with_prior_unclassified_anomaly'
temporary=REPORT.with_suffix('.json.tmp');temporary.write_text(json.dumps(report,indent=2)+'\n');temporary.replace(REPORT)
print(json.dumps(report['artifact_verification'],indent=2))
