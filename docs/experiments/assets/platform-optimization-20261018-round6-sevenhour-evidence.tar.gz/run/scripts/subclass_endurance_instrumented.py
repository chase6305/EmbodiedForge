"""Subclass endurance with retained bytes and separate constructor checkpoints."""

import hashlib
import json
import time
from pathlib import Path

import numpy as np

from endurance_support import Run
from fixture import ROOT

SCRIPT = ROOT / "scripts/subclass_endurance.py"
namespace = {"__file__": str(SCRIPT), "__name__": "subclass_instrumented"}
exec(compile(SCRIPT.read_text().split("run = Run(__doc__)")[0], str(SCRIPT), "exec"), namespace)
base_fingerprint = namespace["fingerprint"]
base_invoke = namespace["invoke"]
snapshot = {}


def contents(arrays, metadata):
    result = {"metadata": json.dumps(metadata, sort_keys=True).encode()}
    for key, value in sorted(arrays.items()):
        result[key + ":description"] = str((value.shape, value.dtype.str)).encode()
        if isinstance(value, np.ma.MaskedArray):
            result[key + ":data"] = value.data.tobytes()
            result[key + ":mask"] = np.ma.getmaskarray(value).tobytes()
        else:
            result[key + ":data"] = value.tobytes()
    return result


def verify(stage, arrays, metadata):
    actual_hash = base_fingerprint(arrays, metadata)
    if actual_hash == snapshot["hash"]:
        return actual_hash
    actual = contents(arrays, metadata)
    changes = []
    for key in sorted(snapshot["bytes"].keys() | actual.keys()):
        previous = snapshot["bytes"].get(key, b"")
        following = actual.get(key, b"")
        if previous != following:
            offsets = [i for i, (a, b) in enumerate(zip(previous, following)) if a != b]
            changes.append(dict(field=key, offsets=offsets[:64], before_length=len(previous), after_length=len(following)))
            name = key.replace(":", "-")
            (ROOT / f"subclass-instrumented-{name}-before.bin").write_bytes(previous)
            (ROOT / f"subclass-instrumented-{name}-after.bin").write_bytes(following)
    failure = dict(status="failed", epoch=time.time(), index=snapshot["index"], stage=stage, changes=changes, before=snapshot["hash"], after=actual_hash, repeated_after=base_fingerprint(arrays, metadata))
    (ROOT / "subclass-instrumented-difference.json").write_text(json.dumps(failure, indent=2) + "\n")
    raise AssertionError(failure)


def fingerprint(arrays, metadata):
    if "bytes" not in snapshot:
        snapshot["bytes"] = contents(arrays, metadata)
        snapshot["hash"] = base_fingerprint(arrays, metadata)
        return verify("before-constructors", arrays, metadata)
    return verify("after-constructors", arrays, metadata)


def invoke(constructor, arrays, metadata):
    label = "original" if constructor is namespace["original"].MotionClips else "current"
    result = base_invoke(constructor, arrays, metadata)
    verify("after-" + label, arrays, metadata)
    return result


namespace["fingerprint"] = fingerprint
namespace["invoke"] = invoke
run = Run(__doc__)
run.script_hashes["scripts/subclass_endurance.py"] = hashlib.sha256(SCRIPT.read_bytes()).hexdigest()
run.report["script_sha256"] = run.script_hashes
run.report["base_configurations_expected"] = len(namespace["CONFIGURATIONS"])
run.report["case_index_offset"] = 0
run.report["additional_scope"] = "Retain exact initial field bytes through each case; compare fingerprints after the original and current constructor separately. On mismatch preserve changed field bytes and stage. Does not explain or erase the earlier unclassified failure."
try:
    while run.active():
        snapshot.clear()
        snapshot["index"] = run.report["case_index_offset"] + run.report["cases"]
        frames, configuration, outcome, refs = namespace["case"](snapshot["index"])
        assert all(ref() is None for ref in refs), "Subclass input retained"
        run.record(frames=frames, configuration=configuration, outcome=outcome)
    if run.args.cases is None:
        assert len(run.report["configurations"]) == len(namespace["CONFIGURATIONS"])
    run.finish()
except BaseException:
    if run.report["status"] != "stopped":
        run.failed()
    raise
