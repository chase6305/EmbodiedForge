"""Validate an in-memory snapshot while leaving formal outputs absent."""

import json
import time

from report import ARCHIVE, REPORT, ROOT, START, members, packed, preservation, verify_archive

assert not REPORT.exists() and not ARCHIVE.exists()
preserved=preservation()
contents=members()
data=packed(contents)
count=verify_archive(data)
result=dict(status='passed',epoch=time.time(),actual_elapsed_seconds=time.time()-START,regular_members=count,compressed_bytes=len(data),preservation=preserved,all_manifest_hashes_and_gzip_crc_verified=True,formal_outputs_created=False,scope='Active in-memory snapshot; final export requires real seven-hour gate and completed cohorts.')
(ROOT/'archive-preflight.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
