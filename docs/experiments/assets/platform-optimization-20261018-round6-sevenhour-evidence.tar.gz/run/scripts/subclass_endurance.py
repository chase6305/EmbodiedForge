"""Whole-array subclass dispatch, masked payloads, readonly bytes and release."""

import itertools
import json
import random
import sys
import weakref

import numpy as np
from endurance_support import Run, invoke
from fixture import ROOT, arrange, assert_equal, fingerprint, make_input, versions


class PlainView(np.ndarray):
    pass


class RejectAll(np.ndarray):
    def all(self, *args, **kwargs):
        return False


class UnitNorm(np.ndarray):
    def __array_function__(self, function, types, args, kwargs):
        if function is np.linalg.norm:
            return np.ones(self.shape[:-1], dtype=np.float64)
        return super().__array_function__(function, types, args, kwargs)


FIELDS = (
    "joint_pos",
    "joint_vel",
    "body_pos_w",
    "body_quat_w",
    "body_lin_vel_w",
    "body_ang_vel_w",
    "object_pos_w",
    "object_quat_w",
    "object_lin_vel_w",
    "object_ang_vel_w",
    "contact_label",
)
MODES = (
    "masked-partial",
    "masked-tail",
    "masked-all",
    "plain-view",
    "reject-all",
    "unit-norm",
)
CONFIGURATIONS = list(
    itertools.product(
        (1, 4096, 4097, 16384, 16385, 65536, 65537, 87383, 262145),
        ("contiguous", "fortran", "strided"),
        ("float32", "float64", ">f4"),
        FIELDS,
        MODES,
    )
)
random.Random(170519).shuffle(CONFIGURATIONS)
original, current = versions()


def case(index):
    frames, layout, dtype, field, mode = CONFIGURATIONS[index % len(CONFIGURATIONS)]
    bodies, joints = (1, 1) if frames == 262145 else (4, 17)
    arrays, metadata = make_input(
        [frames],
        bodies=bodies,
        joints=joints,
        dtype=dtype,
        layout=layout,
        seed=171519 + index,
    )
    value = arrays[field].copy(order="K")
    payload = "valid"
    if mode.startswith("masked"):
        mask = np.zeros(value.shape, dtype=bool)
        if mode == "masked-partial":
            mask[::3] = True
        elif mode == "masked-tail":
            mask[-max(1, frames // 3) :] = True
        else:
            mask[:] = True
        if index % 2:
            if "quat" in field:
                value[mask] = 0
                payload = "masked-zero-quaternion"
            elif field == "contact_label":
                value[mask] = 2
                payload = "masked-invalid-contact"
            else:
                value[mask] = np.nan
                payload = "masked-nan"
        value = arrange(value, layout)
        mask = arrange(mask, layout)
        value = np.ma.array(value, mask=mask, copy=False)
    else:
        cls = {"plain-view": PlainView, "reject-all": RejectAll, "unit-norm": UnitNorm}[
            mode
        ]
        if mode == "unit-norm" and "quat" in field:
            value[:] = 0
            payload = "overridden-unit-norm"
        value = arrange(value, layout).view(cls)
    value.flags.writeable = False
    arrays[field] = value
    refs = [weakref.ref(v) for v in arrays.values()]
    before = fingerprint(arrays, metadata)
    with np.errstate(all="ignore"):
        old, old_error = invoke(original.MotionClips, arrays, metadata)
        new, new_error = invoke(current.MotionClips, arrays, metadata)
    assert old_error == new_error, (index, field, mode, payload, old_error, new_error)
    if old_error is None:
        assert_equal(old, new, arrays, metadata)
    if mode == "reject-all":
        assert old_error is not None, (index, mode)
    if mode == "unit-norm" and "quat" in field:
        assert old_error is None, (index, mode, old_error)
    assert before == fingerprint(arrays, metadata), (index, "input modified")
    assert all(not v.flags.writeable for v in arrays.values())
    if isinstance(value, np.ma.MaskedArray):
        assert not value.data.flags.writeable and not value.mask.flags.writeable
    configuration = dict(
        frames=frames, layout=layout, dtype=dtype, field=field, mode=mode
    )
    return (
        frames,
        configuration,
        f"{mode}:{payload}:{'accepted' if old_error is None else 'rejected'}",
        refs,
    )


run = Run(__doc__)
run.report["base_configurations_expected"] = len(CONFIGURATIONS)
try:
    while run.active():
        frames, configuration, outcome, refs = case(run.report["cases"])
        assert all(ref() is None for ref in refs), (
            "Subclass input retained after completed case"
        )
        run.record(frames=frames, configuration=configuration, outcome=outcome)
    if run.args.cases is None:
        assert len(run.report["configurations"]) == len(CONFIGURATIONS)
    run.finish()
except BaseException:
    trace = sys.exc_info()[2]
    while trace is not None:
        local = trace.tb_frame.f_locals
        if trace.tb_frame.f_code.co_name == "case" and "arrays" in local:
            payload = {}
            for key, value in local["arrays"].items():
                payload[key] = np.asarray(value.data if isinstance(value, np.ma.MaskedArray) else value)
                if isinstance(value, np.ma.MaskedArray):
                    payload[key + "__mask"] = np.ma.getmaskarray(value)
            payload["diagnostic_metadata"] = np.array(json.dumps(local["metadata"]))
            payload["diagnostic_index"] = np.array(local["index"])
            payload["diagnostic_before_fingerprint"] = np.array(local.get("before", "unavailable"))
            np.savez_compressed(ROOT / (run.name + "-failure-input.npz"), **payload)
            break
        trace = trace.tb_next
    if run.report["status"] != "stopped":
        run.failed()
    raise
