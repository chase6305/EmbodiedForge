"""Auditable wall-clock bounded probes, atomic progress and frozen-source checks."""

import argparse
import hashlib
import json
import os
import sys
import threading
import time
import traceback
from pathlib import Path

import numpy as np
from fixture import ROOT, source_hashes


def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    os.replace(temporary, path)


def resource_snapshot():
    status = dict(
        line.split(":", 1)
        for line in Path("/proc/self/status").read_text().splitlines()
        if ":" in line
    )
    return {
        "epoch": time.time(),
        "fds": len(os.listdir("/proc/self/fd")),
        "python_threads": threading.active_count(),
        "os_threads": len(os.listdir("/proc/self/task")),
        "rss_bytes": int(status["VmRSS"].split()[0]) * 1024,
    }


def state_digest(rng):
    def encode(value):
        return value.tolist() if isinstance(value, np.ndarray) else value.item()

    return hashlib.sha256(
        json.dumps(rng.bit_generator.state, sort_keys=True, default=encode).encode()
    ).hexdigest()


class Run:
    def __init__(self, description):
        parser = argparse.ArgumentParser(description=description)
        parser.add_argument("--name", required=True)
        parser.add_argument("--cases", type=int)
        self.args = parser.parse_args()
        if self.args.cases is not None and self.args.cases <= 0:
            parser.error("--cases must be positive")
        self.name = self.args.name
        self.state = json.loads((ROOT / "state.json").read_text())
        self.stop_epoch = self.state["probe_stop_epoch"]
        self.stop_file = ROOT / f"{self.name}-stop.json"
        self.source_hashes = source_hashes()
        files = [
            ROOT / "scripts/fixture.py",
            ROOT / "scripts/endurance_support.py",
            ROOT / "scripts" / os.path.basename(sys.argv[0]),
        ]
        self.script_hashes = {
            str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in files
        }
        self.full_source = {
            str(path.relative_to((ROOT / "initial"))): hashlib.sha256(
                path.read_bytes()
            ).hexdigest()
            for path in sorted((ROOT / "initial/src").rglob("*.py"))
        }
        self.resource_initial = resource_snapshot()
        self.report = dict(
            name=self.name,
            pid=os.getpid(),
            argv=sys.argv,
            python=sys.version,
            numpy=np.__version__,
            status="running",
            mode="bounded_oracle"
            if self.args.cases is not None
            else "sustained_endurance",
            started_epoch=time.time(),
            probe_stop_epoch=self.stop_epoch,
            source_sha256=self.source_hashes,
            script_sha256=self.script_hashes,
            runtime_source_sha256=self.full_source,
            cases=0,
            reference_input_frames=0,
            configurations={},
            outcomes={},
            resources=[self.resource_initial],
            scope="Frozen historical MotionClips reference versus previous-round final source; not validation of live runtime changes. Frame totals count generated reference inputs, including expected rejected cases. Resource snapshots describe this run and allocator history, not a process memory bound or general leak proof.",
        )
        self.last_checkpoint = 0.0
        self.last_source_check = 0.0
        self.checkpoint(force=True)

    def active(self):
        if self.stop_file.exists():
            self.report["operator_stop"] = json.loads(self.stop_file.read_text())
            return False
        return time.time() < self.stop_epoch and (
            self.args.cases is None or self.report["cases"] < self.args.cases
        )

    def record(self, *, frames, configuration, outcome):
        self.report["cases"] += 1
        self.report["reference_input_frames"] += frames
        key = json.dumps(configuration, sort_keys=True, separators=(",", ":"))
        self.report["configurations"][key] = (
            self.report["configurations"].get(key, 0) + 1
        )
        self.report["outcomes"][outcome] = self.report["outcomes"].get(outcome, 0) + 1
        self.checkpoint()

    def checkpoint(self, force=False):
        now = time.time()
        if force or now - self.last_checkpoint >= 20:
            assert self.source_hashes == source_hashes(), (
                "Motion source changed during probe"
            )
            if force or now - self.last_source_check >= 60:
                for name, expected in self.full_source.items():
                    assert (
                        hashlib.sha256(
                            (ROOT / "initial" / name).read_bytes()
                        ).hexdigest()
                        == expected
                    ), ("Runtime source changed", name)
                for name, expected in self.script_hashes.items():
                    assert (
                        hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                        == expected
                    ), ("Harness changed", name)
                self.last_source_check = now
            snapshot = resource_snapshot()
            assert snapshot["fds"] == self.resource_initial["fds"], snapshot
            assert (
                snapshot["python_threads"] == self.resource_initial["python_threads"]
            ), snapshot
            self.report["resources"].append(snapshot)
            self.report.update(
                updated_epoch=now,
                elapsed_seconds=now - self.report["started_epoch"],
                configuration_count=len(self.report["configurations"]),
            )
            atomic_json(ROOT / f"{self.name}-progress.json", self.report)
            self.last_checkpoint = now

    def finish(self):
        self.report["status"] = "stopped" if self.stop_file.exists() else "passed"
        self.report["finished_epoch"] = time.time()
        self.checkpoint(force=True)
        atomic_json(ROOT / f"{self.name}.json", self.report)
        print(
            json.dumps(
                {
                    name: self.report[name]
                    for name in (
                        "name",
                        "status",
                        "cases",
                        "reference_input_frames",
                        "configuration_count",
                        "elapsed_seconds",
                    )
                }
            ),
            flush=True,
        )
        if self.report["status"] != "passed":
            raise SystemExit(75)

    def failed(self):
        now = time.time()
        self.report.update(
            status="failed",
            finished_epoch=now,
            updated_epoch=now,
            elapsed_seconds=now - self.report["started_epoch"],
            traceback=traceback.format_exc(),
        )
        atomic_json(ROOT / f"{self.name}-failure.json", self.report)
        atomic_json(ROOT / f"{self.name}-progress.json", self.report)


def invoke(function, arrays, metadata):
    try:
        result = function(arrays, metadata)
    except Exception as error:
        return None, (type(error).__name__, str(error))
    return result, None
