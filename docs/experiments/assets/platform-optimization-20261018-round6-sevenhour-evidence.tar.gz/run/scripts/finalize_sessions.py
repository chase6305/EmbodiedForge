"""Require actually reaped successful tool sessions before marking cohorts done."""

import json
import time
from pathlib import Path

from report import ARCHIVE, PROBES, REPORT, ROOT, START, preservation, read, sha

operator=read(ROOT/'operator-state.json');state=read(ROOT/'state.json')
assert state['start_epoch']==1792328278 and state['deadline_epoch']==1792353478
assert state['required_elapsed_seconds']==25200 and time.time()>=state['probe_stop_epoch']
results=read(ROOT/'tool-session-results.json')
assert set(results)==set(operator['active_sessions'])==set(PROBES)
assert not (ROOT/'session-completions.json').exists()
completed={}
for name in PROBES:
    session=operator['active_sessions'][name];result=results[name]
    assert result['session_id']==session['session_id'] and result['reaped'] is True
    assert result['tool_result']['exit_code']==0
    probe=read(ROOT/(name+'.json'))
    assert probe['status']=='passed' and probe['pid']==session['pid']
    assert probe['configuration_count']==probe['base_configurations_expected']
    assert not (Path('/proc')/str(session['pid'])).exists()
    completed[name]={**session,'exit_code':0,'reaped':True,'status':'passed','cases':probe['cases'],'elapsed_seconds':probe['elapsed_seconds']}
with (ROOT/'session-completions.json').open('x') as stream:json.dump(completed,stream,indent=2);stream.write('\n')
operator.update(status='closing',active_sessions={},completed_sessions=completed,updated_epoch=time.time())
state.update(status='closing',active_sessions={},updated_epoch=time.time())
for name,value in (('operator-state.json',operator),('state.json',state)):
    temporary=ROOT/(name+'.tmp');temporary.write_text(json.dumps(value,indent=2)+'\n');temporary.replace(ROOT/name)
print(json.dumps(dict(status='closing',all_four_sessions_actually_reaped=True,cases={k:v['cases'] for k,v in completed.items()})))
