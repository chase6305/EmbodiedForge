"""Observe real elapsed time, source identity, progress freshness and resources."""

import hashlib
import json
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


state = json.loads((ROOT/'state.json').read_text())
assert state['start_epoch']==1792328278 and state['deadline_epoch']==1792353478
assert state['required_elapsed_seconds']==25200
assert not list(ROOT.glob('*-failure.json')), 'A new probe recorded a failure'
frozen=json.loads((ROOT/'frozen-runtime.json').read_text())['sha256']
actual={str(p.relative_to(WORKSPACE)):sha(p) for p in sorted((WORKSPACE/'src').rglob('*.py'))}
assert actual==frozen,'Live runtime source drift'
initial=json.loads((ROOT/'initial-hashes.json').read_text())
for name,digest in initial.items(): assert sha(ROOT/'initial'/name)==digest,('Initial snapshot drift',name)
for name,digest in json.loads((ROOT/'frozen-harness.json').read_text())['sha256'].items():
    assert sha(ROOT/name)==digest,('Harness drift',name)
operator=json.loads((ROOT/'operator-state.json').read_text())
now=time.time()
rows={}
for name,session in operator['active_sessions'].items():
    report=json.loads((ROOT/(name+'-progress.json')).read_text())
    assert report['status'] in ('running','passed')
    assert report['pid']==session['pid']
    if report['status']=='running':
        assert now-report['updated_epoch']<90,(name,'Stale progress')
        args=(Path('/proc')/str(session['pid'])/'cmdline').read_bytes().split(b'\0')
        assert name.encode() in args and any(a.endswith(session['script'].encode()) for a in args)
    expected=frozen if session['source_scope']=='live_final' else {p:sha(ROOT/'initial'/p) for p in frozen}
    assert report['runtime_source_sha256']==expected
    for key in ('fds','python_threads','os_threads'):
        assert all(row[key]==report['resources'][0][key] for row in report['resources']),(name,key)
    for path,digest in report['script_sha256'].items(): assert sha(ROOT/path)==digest,path
    rows[name]=dict(status=report['status'],cases=report['cases'],configuration_count=report['configuration_count'],expected_configurations=report['base_configurations_expected'],scope=session['source_scope'])
event=dict(status='passed_with_prior_unclassified_anomaly',epoch=now,elapsed_seconds=now-state['start_epoch'],remaining_seconds=max(0,state['deadline_epoch']-now),frozen_live_sources=len(frozen),initial_files_verified=len(initial),probes=rows)
with (ROOT/'monitor-audit.jsonl').open('a') as stream: stream.write(json.dumps(event,separators=(',',':'))+'\n')
(ROOT/'monitor-latest.json').write_text(json.dumps(event,indent=2)+'\n')
print(json.dumps(event))
