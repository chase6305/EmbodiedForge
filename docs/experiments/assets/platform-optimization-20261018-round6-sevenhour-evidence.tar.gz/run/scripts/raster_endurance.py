"""Independent dense pixel oracle, initial-source parity and output release."""

import importlib.util
import itertools
import random
import weakref

import numpy as np
from embodiedforge.backends.render import RasterRenderer
from embodiedforge.core import Config, SceneSpec, SceneUpdate, StateSnapshot

from raster_support import ROOT, Run

path = ROOT/'initial/src/embodiedforge/backends/render.py'
spec = importlib.util.spec_from_file_location('baseline_raster', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
PALETTE = np.array([[20,24,32],[70,155,255],[65,210,120]],np.uint8)
ALL_CHANNELS = ("rgb", "depth", "instance_id", "semantic_id")
CHANNELS = [channels for count in range(1, 5) for channels in itertools.combinations(ALL_CHANNELS, count)]
CONFIGS = list(itertools.product((1,32,64,128,512),(1,4,16),(.06,.35,4.0),('float32','float64','longdouble'),('contiguous','fortran','strided'),range(len(CHANNELS))))
random.Random(181018).shuffle(CONFIGS)


def case(index):
    size,count,radius,dtype,layout,channel_index = CONFIGS[index%len(CONFIGS)]
    rng = np.random.default_rng(181019+index)
    position,target = rng.uniform(-2-radius,2+radius,(2,count,2)).astype(dtype)
    if layout=='fortran':
        position,target=np.asfortranarray(position),np.asfortranarray(target)
    elif layout=='strided':
        position,target=np.repeat(position,2,axis=0)[::2],np.repeat(target,2,axis=0)[::2]
    position[0]=target[0]=0
    coord=(np.arange(size)+.5)*3/size-1.5
    if count>1:
        position[-1]=[coord[size//3]+radius,-coord[size//2]]
    position.flags.writeable=target.flags.writeable=False
    before=position.tobytes(),target.tobytes()
    state=StateSnapshot(position,np.zeros_like(position),np.arange(count,dtype=float),np.arange(count))
    update=SceneUpdate(state,dict(agent=position,target=target))
    ids=np.array([] if index%11==0 else [count-1,0,count-1],np.int64)
    ids.flags.writeable=False
    channels=CHANNELS[channel_index][::-1] if index%2 else CHANNELS[channel_index]
    renderers=[cls() for cls in (module.RasterRenderer,RasterRenderer)]
    for renderer in renderers:
        renderer.build(SceneSpec(radius=radius),Config(num_envs=count,image_size=size,channels=channels))
        renderer.sync(update)
    old,new=[renderer.render(ids) for renderer in renderers]
    expected=np.zeros((len(ids),1,size,size),np.int32)
    # Work per requested row to bound dense-oracle scratch while preserving
    # ndarray promotion rules, including float128 under NumPy 1.24.
    for row,identity in enumerate(ids):
        for label,centers,disk_radius in ((2,target,.1),(1,position,radius)):
            selected=centers[identity:identity+1]
            mask=(coord[None,None,:]-selected[:,0,None,None])**2+(-coord[None,:,None]-selected[:,1,None,None])**2<=disk_radius**2
            expected[row,0][mask[0]]=label
    reference=dict(rgb=PALETTE[expected],depth=np.where(expected!=0,np.float32(2),np.float32(0)),depth_valid=expected!=0,instance_id=expected,semantic_id=expected)
    refs=[]
    assert old.calibration==new.calibration
    for key,value in new.images.items():
        assert value.dtype==old.images[key].dtype==reference[key].dtype
        assert value.tobytes()==old.images[key].tobytes()==reference[key].tobytes(),(index,key)
        assert value.flags.owndata and value.flags.c_contiguous
        refs.append(weakref.ref(value))
        for other,array in new.images.items():
            if other!=key: assert not np.shares_memory(value,array)
    for value in new.images.values(): value[:]=0
    again=renderers[1].render(ids)
    for key,value in again.images.items(): assert value.tobytes()==reference[key].tobytes()
    assert before==(position.tobytes(),target.tobytes())
    for renderer in renderers: renderer.close()
    refs.extend(weakref.ref(v) for v in (position,target,new.time,new.version))
    return dict(size=size,count=count,radius=radius,dtype=dtype,layout=layout,channels=CHANNELS[channel_index]),refs


run=Run()
run.report['base_configurations_expected']=len(CONFIGS)
try:
    while run.active():
        config,refs=case(run.report['cases'])
        assert all(ref() is None for ref in refs),'Input or output retained'
        run.record(config)
    if run.args.cases is None: assert len(run.report['configurations'])==len(CONFIGS)
    run.finish()
except BaseException:
    run.failed()
    raise
