"""Export reviewable round evidence only after seven real elapsed hours."""

import argparse
import gzip
import hashlib
import io
import json
import tarfile
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
WORKSPACE=ROOT.parents[1]
START=1792328278
DEADLINE=1792353478
DURATION=25200
STEM='platform-optimization-20261018-round6-sevenhour'
REPORT=WORKSPACE/'docs'/f'{STEM}.json'
ARCHIVE=WORKSPACE/'docs/assets'/f'{STEM}-evidence.tar.gz'
FIGURE=WORKSPACE/'docs'/f'{STEM}-allocations.svg'
CORE=('src/embodiedforge/backends/render.py','tests/test_raster_channel_buffers.py','docs/interfaces.md')
PROBES=('raster-live-py312','raster-live-numpy124','historical-raw-py312','historical-staged-py312')


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def preservation():
    initial=read(ROOT/'initial-hashes.json')
    changed=[]
    for name,digest in initial.items():
        assert sha(ROOT/'initial'/name)==digest,('Initial snapshot changed',name)
        if sha(WORKSPACE/name)!=digest:changed.append(name)
    assert set(changed)=={'src/embodiedforge/backends/render.py','docs/interfaces.md'},changed
    frozen=read(ROOT/'frozen-runtime.json')['sha256']
    actual={str(p.relative_to(WORKSPACE)):sha(p) for p in sorted((WORKSPACE/'src').rglob('*.py'))}
    assert actual==frozen
    return dict(initial_files_verified=len(initial),runtime_sources_verified=len(frozen),changed_initial_files=changed,prior_changes_preserved=True)


def members():
    result={}
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file():continue
        rel=path.relative_to(ROOT)
        if '__pycache__' in rel.parts or path.suffix in ('.pyc','.tmp'):continue
        if path.name in ('preview-report.json','archive-preflight.json'):continue
        if rel.parts[0]=='initial':
            if path.suffix not in ('.py','.md','.toml','.json','.txt','.xml','.svg','.js','.html') and not path.name.startswith(('LICENSE','NOTICE')):continue
        result[str(Path('run')/rel)]=path.read_bytes()
    for name in CORE:result['final/'+name]=(WORKSPACE/name).read_bytes()
    result['final/'+str(FIGURE.relative_to(WORKSPACE))]=FIGURE.read_bytes()
    manifest={name:dict(bytes=len(value),sha256=hashlib.sha256(value).hexdigest()) for name,value in result.items()}
    result['manifest.json']=(json.dumps(dict(status='passed',manifest_excludes_itself=True,members=manifest),indent=2)+'\n').encode()
    return result


def packed(contents):
    target=io.BytesIO()
    with tarfile.open(fileobj=target,mode='w:gz') as archive:
        for name,value in contents.items():
            path=Path(name);assert not path.is_absolute() and '..' not in path.parts
            item=tarfile.TarInfo(name);item.mode=0o644;item.mtime=START;item.size=len(value)
            archive.addfile(item,io.BytesIO(value))
    return target.getvalue()


def verify_archive(data):
    gzip.decompress(data)
    with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
        items=archive.getmembers();names={p.name for p in items}
        assert len(names)==len(items)
        manifest=json.load(archive.extractfile('manifest.json'))['members']
        assert names==set(manifest)|{'manifest.json'}
        for item in items:
            path=Path(item.name)
            assert item.isfile() and not path.is_absolute() and '..' not in path.parts
            value=archive.extractfile(item).read()
            if item.name!='manifest.json':
                assert len(value)==manifest[item.name]['bytes']
                assert hashlib.sha256(value).hexdigest()==manifest[item.name]['sha256']
    return len(items)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--preview',action='store_true');args=parser.parse_args()
    now=time.time();state=read(ROOT/'state.json')
    assert state['start_epoch']==START and state['deadline_epoch']==DEADLINE
    assert state['required_elapsed_seconds']==DURATION==DEADLINE-START
    if not args.preview:
        assert now-START>=DURATION,'Seven-hour elapsed-time gate: actual elapsed time must reach 25200 seconds'
        assert not REPORT.exists() and not ARCHIVE.exists()
    preserved=preservation()
    validation=read(ROOT/'validation.json');assert validation['status']=='passed'
    for name,digest in validation['sha256'].items():assert sha(WORKSPACE/name)==digest,name
    performances={}
    for path in sorted(ROOT.glob('raster-performance-*.json')):
        data=read(path);assert data['status']=='passed' and len(data['cases'])==29
        assert data['source_sha256']['current']==sha(WORKSPACE/CORE[0])
        assert data['source_sha256']['initial']==sha(ROOT/'initial'/CORE[0])
        assert data['script_sha256']==sha(ROOT/'scripts/raster_performance.py')
        performances[path.name]=dict(sha256=sha(path),data=data)
    assert len(performances)==3
    figure=read(ROOT/'figure-provenance.json')
    assert figure['figure_sha256']==sha(FIGURE) and figure['timing_speedup_claim'] is False
    assert figure['script_sha256']==sha(ROOT/'scripts/plot.py')
    for name,digest in figure['reports_sha256'].items():assert sha(ROOT/name)==digest
    control=read(ROOT/'capture-control.json');assert control['status']=='passed'
    assert control['script_sha256']==sha(ROOT/'scripts/capture_control.py')
    assert control['harness_sha256']==sha(ROOT/'scripts/subclass_endurance.py')
    assert control['capture_sha256']==sha(ROOT/'controls/raw-capture/injected-failure-input.npz')
    probes={}
    frozen=read(ROOT/'frozen-runtime.json')['sha256']
    historical_frozen={name:sha(ROOT/'initial'/name) for name in frozen}
    for name in PROBES:
        data=read(ROOT/(name+('-progress' if args.preview else '')+'.json'))
        assert data['runtime_source_sha256']==(historical_frozen if name.startswith('historical') else frozen)
        for path,digest in data['script_sha256'].items():assert sha(ROOT/path)==digest
        if not args.preview:
            assert data['status']=='passed'
            assert data['configuration_count']==data['base_configurations_expected']
        probes[name]={key:data[key] for key in ('status','started_epoch','elapsed_seconds','cases','configuration_count','base_configurations_expected')}
        probes[name]['scope']='frozen_historical' if name.startswith('historical') else 'live_final'
        probes[name]['raw_report_sha256']=sha(ROOT/(name+('-progress' if args.preview else '')+'.json'))
        if name.startswith('historical'):probes[name]['prior_failure_index_completed']=data['cases']>115660
        for key in ('fds','python_threads','os_threads'):
            observed=sorted({p[key] for p in data['resources']});assert len(observed)==1,(name,key,observed)
            probes[name]['observed_'+key]=observed
    assert not list(ROOT.glob('*-failure.json')),'A new probe has failed; preserve and diagnose before export'
    assert all(p['data']['finished_epoch']<min(q['started_epoch'] for name,q in probes.items() if name.startswith('raster-live')) for p in performances.values())
    prior=read(ROOT/'prior-diagnostic/diagnostic.json')
    assert prior['status']=='unclassified'
    for name,digest in prior['preserved_files_sha256'].items():
        # The identical prior progress/failure records have the same digest.
        actual=ROOT/'prior-diagnostic'/name
        if actual.exists():assert sha(actual)==digest,name
        else:
            assert name=='subclasses-py312-progress.json'
            assert digest==sha(ROOT/'prior-diagnostic/subclasses-py312-failure.json')
    report=dict(status='active_preview' if args.preview else 'closing_after_elapsed_gate',objective='持续优化 EmbodiedForge 七个实际小时，保留既有改动，依据验证记录收益和限制。',start_epoch=START,deadline_epoch=DEADLINE,required_elapsed_seconds=DURATION,actual_elapsed_seconds=now-START,parallel_durations_added=False,preservation=preserved,review_files_sha256={name:sha(WORKSPACE/name) for name in CORE},changes=['Depth-only raster uses an owned boolean foreground buffer as depth_valid, avoiding int32 labels and a full-frame label scan.','RGB-only raster allocates native palette indices directly, avoiding an int32-to-intp frame conversion.','One ID output directly owns the private int32 labels; when both ID channels are requested the other remains independently copied. Public dtypes, pixels and ownership are preserved.'],scope='Synthetic CPU orthographic point-reach raster and NumPy VectorEnv.step; no GPU, robot or training throughput measurement.',performance_claims=dict(primary='Transient traced allocation reduction in selective-channel cases',cpu_time='Inconclusive: unchanged controls also varied strongly on the shared unpinned host. Raw signed timings are retained; no timing speedup claim.',rss_bound=False),validation=validation,performance=performances,figure=figure,probe_results=probes,historical_anomaly=dict(status='unclassified',prior=prior,prior_failure_sha256=sha(ROOT/'prior-diagnostic/subclasses-py312-failure.json'),interpretation='A prior one-shot input fingerprint mismatch remains unclassified. Frozen historical followups are separate from live-renderer validation; successful replays do not erase the original failure or establish its cause.'),capture_control=control,diagnostics=[dict(kind='test_command_path',classification='The first focused command named a nonexistent tests/test_sensors.py and collected no tests. Its log is preserved; the corrected focused suite passed 217 cases.',log='initial-focused.log'),dict(kind='timing_controls',classification='The superseded first candidate had large apparent timing changes in unmodified mixed-channel paths. Final-source measurements also overlap two frozen historical probes. Timing claims are withheld and all signed raw results from both candidates are retained.')],evidence_selection='Raw reports, logs, scripts, historical failure records, recorder control, initial text snapshots and final changed files/figure retained. Initial binary assets and prior compressed archives excluded; their initial hashes remain recorded.')
    phase=read(ROOT/'phase1-selective-depth-rgb/preservation.json')
    for name,digest in phase['sha256'].items():assert sha(ROOT/'phase1-selective-depth-rgb'/name)==digest,name
    for row in phase['sessions'].values():assert row['exit_code']==143 and row['reaped'] is True
    report['superseded_phase']=dict(path='phase1-selective-depth-rgb',classification='Initial depth/RGB-only candidate superseded to include owned ID-buffer reuse. Intermediate CI/performance/cohorts retained separately; stopped cohort exits were actually observed as 143 and reaped before runtime mutation.',preserved_files=len(phase['sha256']),sessions=phase['sessions'])
    report['seven_hour_round_scope']='The round includes initial and final candidates, measured allocation comparisons, diagnosis and validation. Live final-renderer cohorts restart after the owned-ID change; frozen historical MotionClips trajectories continue separately. Per-cohort starts and elapsed times are reported without adding parallel durations.'
    if args.preview:
        (ROOT/'preview-report.json').write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps(dict(status=report['status'],actual_elapsed_seconds=now-START)))
        return
    early=read(ROOT/'duration-gate-control.json')
    assert early['status']=='passed' and early['real_clock_used'] and not early['clock_simulated']
    assert early['actual_elapsed_seconds']<DURATION and early['reporter_sha256']==sha(Path(__file__))
    completed=read(ROOT/'session-completions.json')
    for name in PROBES:
        assert completed[name]['exit_code']==0 and completed[name]['reaped'] is True
        assert not (Path('/proc')/str(completed[name]['pid'])).exists()
    assert not read(ROOT/'operator-state.json')['active_sessions']
    assert read(ROOT/'closing-preflight.json')['status']=='passed'
    gate=dict(status='passed',actual_elapsed_seconds=now-START,required_elapsed_seconds=DURATION,early_control=early,real_clock_used=True,parallel_durations_added=False)
    (ROOT/'duration-gate.json').write_text(json.dumps(gate,indent=2)+'\n')
    payload=packed(members());count=verify_archive(payload)
    with ARCHIVE.open('xb') as stream:stream.write(payload)
    report['duration_gate']=gate
    report['evidence_archive']=dict(path=str(ARCHIVE.relative_to(WORKSPACE)),sha256=hashlib.sha256(payload).hexdigest(),bytes=len(payload),regular_members=count)
    with REPORT.open('x') as stream:json.dump(report,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(status=report['status'],actual_elapsed_seconds=now-START,archive_members=count,archive_bytes=len(payload))))


if __name__=='__main__':main()
