"""Use the real clock to prove premature completion is rejected."""

import json
import subprocess
import sys
import time
from pathlib import Path

from report import ARCHIVE, DURATION, REPORT, ROOT, START, sha

assert time.time()-START<DURATION
assert not REPORT.exists() and not ARCHIVE.exists()
result=subprocess.run([sys.executable,str(ROOT/'scripts/report.py')],text=True,capture_output=True)
assert result.returncode!=0
assert 'Seven-hour elapsed-time gate' in result.stderr,result.stderr
assert not REPORT.exists() and not ARCHIVE.exists()
data=dict(status='passed',epoch=time.time(),actual_elapsed_seconds=time.time()-START,real_clock_used=True,clock_simulated=False,final_outputs_created=False,reporter_sha256=sha(ROOT/'scripts/report.py'),exit_code=result.returncode,stderr=result.stderr)
(ROOT/'duration-gate-control.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({key:data[key] for key in ('status','actual_elapsed_seconds','final_outputs_created')}))
