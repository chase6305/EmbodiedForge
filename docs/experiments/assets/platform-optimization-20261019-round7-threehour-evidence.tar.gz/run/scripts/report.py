"""Export evidence only after three real elapsed hours and successful reaping."""
import argparse,gzip,hashlib,io,json,tarfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];WORKSPACE=ROOT.parents[1]
START=1792375540;DEADLINE=1792386340;DURATION=10800
STEM='platform-optimization-20261019-round7-threehour'
REPORT=WORKSPACE/'docs'/(STEM+'.json');ARCHIVE=WORKSPACE/'docs/assets'/(STEM+'-evidence.tar.gz');FIGURE=WORKSPACE/'docs'/(STEM+'-performance.svg')
CORE=('src/embodiedforge/backends/physics.py','tests/test_physics_partial_buffers.py','benchmarks/reference_step.py','docs/interfaces.md')
PROBES=('physics-py312','physics-numpy124','environment-py312')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def preservation():
 initial=read(ROOT/'initial-hashes.json');changed=[]
 for p,h in initial.items():
  assert sha(ROOT/'initial'/p)==h,('Initial snapshot drift',p)
  if sha(WORKSPACE/p)!=h:changed.append(p)
 assert set(changed)==set(CORE)-{'tests/test_physics_partial_buffers.py'},changed
 current={str(p.relative_to(WORKSPACE)):sha(p) for p in sorted((WORKSPACE/'src').rglob('*.py'))}
 assert current==read(ROOT/'frozen-runtime.json')['sha256']
 return dict(initial_files_verified=len(initial),runtime_sources_verified=len(current),changed_initial_files=changed,prior_changes_preserved=True)
def members():
 data={}
 for p in sorted(ROOT.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(ROOT)
  if '__pycache__' in rel.parts or p.suffix=='.pyc' or (p.suffix=='.tmp' and rel.parts[0]!='interrupted-filesystem-pressure') or p.name in ('preview-report.json','archive-preflight.json'):continue
  if rel.parts[0]=='initial' and p.suffix not in ('.py','.md','.json','.toml','.txt','.xml','.svg','.html','.js') and not p.name.startswith(('LICENSE','NOTICE')):continue
  data['run/'+str(rel)]=p.read_bytes()
 for p in CORE:data['final/'+p]=(WORKSPACE/p).read_bytes()
 data['final/'+str(FIGURE.relative_to(WORKSPACE))]=FIGURE.read_bytes()
 manifest={n:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for n,v in data.items()}
 data['manifest.json']=(json.dumps(dict(status='passed',manifest_excludes_itself=True,members=manifest),indent=2)+'\n').encode()
 return data

def pack(data):
 target=io.BytesIO()
 with tarfile.open(fileobj=target,mode='w:gz') as tar:
  for name,value in data.items():
   p=Path(name);assert not p.is_absolute() and '..' not in p.parts
   item=tarfile.TarInfo(name);item.mode=0o644;item.mtime=START;item.size=len(value);tar.addfile(item,io.BytesIO(value))
 return target.getvalue()
def verify_archive(payload):
 gzip.decompress(payload)
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tar:
  items=tar.getmembers();names={p.name for p in items};assert len(names)==len(items)
  manifest=json.load(tar.extractfile('manifest.json'))['members'];assert names==set(manifest)|{'manifest.json'}
  for p in items:
   path=Path(p.name);assert p.isfile() and not path.is_absolute() and '..' not in path.parts
   value=tar.extractfile(p).read()
   if p.name!='manifest.json':assert len(value)==manifest[p.name]['bytes'] and hashlib.sha256(value).hexdigest()==manifest[p.name]['sha256'],p.name
 return len(items)

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--preview',action='store_true');args=parser.parse_args()
 now=time.time();state=read(ROOT/'state.json');assert state['start_epoch']==START and state['deadline_epoch']==DEADLINE and state['required_elapsed_seconds']==DURATION==DEADLINE-START
 if not args.preview:
  assert now-START>=DURATION,'Three-hour elapsed-time gate: actual elapsed time must reach 10800 seconds'
  assert not REPORT.exists() and not ARCHIVE.exists()
 preserved=preservation();validation=read(ROOT/'validation.json');assert validation['status']=='passed'
 for p,h in validation['sha256'].items():assert sha(WORKSPACE/p)==h,p
 perf={}
 for p in sorted(ROOT.glob('performance-*.json')):
  d=read(p);assert d['status']=='passed' and len(d['cases'])==72 and d['pairs']==21
  assert d['runtime_source_sha256']==read(ROOT/'frozen-runtime.json')['sha256'] and d['initial_source_sha256']==sha(ROOT/'initial'/CORE[0])
  for n,h in d['script_sha256'].items():assert sha(ROOT/n)==h,n
  selected=[c for c in d['cases'] if c['num_envs']==1024 and c['active_fraction']==.5 and c['substeps'] in (4,16)]
  controls=[dict(num_envs=c['num_envs'],substeps=c['substeps'],scope=c['scope'],elapsed_reduction_percent=c['elapsed_reduction_percent']) for c in d['cases'] if c['active_fraction']==1]
  perf[p.name]=dict(sha256=sha(p),python=d['python'],numpy=d['numpy'],cpu_affinity=d['cpu_affinity'],cases=len(d['cases']),pairs=d['pairs'],selected_1024_env_50pct_active=selected,all_active_controls=controls)
 assert len(perf)==3
 figure=read(ROOT/'figure-provenance.json');assert figure['status']=='passed' and sha(FIGURE)==figure['figure_sha256'] and sha(ROOT/'scripts/plot.py')==figure['script_sha256']
 for p,h in figure['reports_sha256'].items():assert sha(ROOT/p)==h
 control=read(ROOT/'capture-control.json');assert control['status']=='passed' and control['raw_before_and_after_arrays_verified']
 assert control['capture_sha256']==sha(ROOT/'controls/capture-control-failure-input.npz')
 assert control['harness_sha256']==sha(ROOT/'scripts/endurance.py') and control['common_sha256']==sha(ROOT/'scripts/common.py')
 assert control['failed_report_sha256']==sha(ROOT/'controls/capture-control-failure.json')
 probes={}
 for n in PROBES:
  p=ROOT/(n+('-progress' if args.preview else '')+'.json');d=read(p)
  assert d['runtime_source_sha256']==read(ROOT/'frozen-runtime.json')['sha256']
  for f,h in d['script_sha256'].items():assert sha(ROOT/f)==h
  if not args.preview:assert d['status']=='passed' and d['configuration_count']==d['base_configurations_expected']
  probes[n]={k:d[k] for k in ('status','scope','started_epoch','elapsed_seconds','cases','configuration_count','base_configurations_expected')};probes[n]['raw_report_sha256']=sha(p)
  for k in ('fds','python_threads','os_threads'):
   values=sorted({v[k] for v in d['resources']});assert len(values)==1;probes[n]['observed_'+k]=values
 assert not list(ROOT.glob('*-failure.json'))
 phase=read(ROOT/'phase1-harness-before-capture/preservation.json')
 for p,h in phase['sha256'].items():assert sha(ROOT/'phase1-harness-before-capture'/p)==h
 for v in phase['actual_stop_exits'].values():assert v['tool_result']['exit_code']==143 and v['reaped'] is True
 prior=ROOT/'inherited-diagnostic/subclasses-py312-failure.json';assert read(prior)['status']=='failed'
 assert sha(prior)=='de44b89feaf11365036e4fafb15bc4e0163a39d247c4693c9b1ea68123b265de'
 report=dict(status='active_preview' if args.preview else 'closing_after_elapsed_gate',objective='持续优化 EmbodiedForge 三个实际小时，保留已有改动，完成测量、回归和持续验证。',start_epoch=START,deadline_epoch=DEADLINE,required_elapsed_seconds=DURATION,actual_elapsed_seconds=now-START,parallel_durations_added=False,preservation=preserved,review_files_sha256={p:sha(WORKSPACE/p) for p in CORE},changes=['Partial active-row NumPy physics gathers independent plain float64 state buffers once, preserves every Euler operation and scatters after substeps. Constant control delta is evaluated once.','All-active, all-frozen, single-substep, aliased/subclass/non-float64 buffers and strict floating-error modes retain the previous path.','Reference benchmark accepts --substeps, default 4; thirteen regression cases cover aliases/layouts and completed substeps before a floating error.'],scope='Synthetic two-dimensional CPU point-reach reference dynamics; direct control+physics+owned snapshot and complete no-camera VectorEnv.step. No MuJoCo, GPU or training-throughput claim.',performance=perf,performance_caveats=['Three Python/NumPy environments, 72 scenarios each, 21 alternating pairs, one pinned CPU on a shared host. Construction/warmup/tracing/digests excluded from timing.','All signed results retained. Some tiny unchanged controls fluctuate; speed claims are scoped to the explicitly plotted 1024-environment cases. First versioned measurements preceded the cohorts; later runs overlapped pinned cohorts and/or CI.','Transient allocation peaks are separately traced, not RSS. No general memory reduction claim.'],validation=validation,figure=figure,probe_results=probes,capture_control=control,superseded_harness=dict(status='superseded',path='phase1-harness-before-capture',preserved_files=len(phase['sha256']),classification='Three intermediate sessions actually stopped with exit 143 and reaped before strengthening post-failure byte capture and object-release checks. Runtime source unchanged; intermediate progress is not counted as completed final cohorts.'),inherited_diagnostic=dict(status='unclassified',original_failure_sha256=sha(prior),scope='Previous MotionClips input fingerprint anomaly retained unchanged. This round changes a separate physics component and does not classify or erase that historical event.'),round_scope='Three-hour wall-clock round includes analysis, implementation, measurements, final-source CI, strengthened harness controls, sustained differential validation and export. Cohort durations are individually reported; no parallel durations are added.',evidence_selection='Raw measurements, final and superseded harnesses, logs, capture control, inherited failure, initial text/source snapshots, and final changed files/figure retained. Initial binary assets and earlier compressed evidence archives omitted; all their initial hashes remain preserved.')
 interruption=read(ROOT/'interrupted-filesystem-pressure/diagnostic.json')
 assert interruption['status']=='unclassified_persistence_interruption'
 for p,h in interruption['sha256'].items():assert sha(ROOT/'interrupted-filesystem-pressure'/p)==h
 for v in interruption['observed_sessions'].values():assert v['exit_code']==120 and v['reaped'] is True
 persistence=read(ROOT/'persistence-control.json');assert persistence['status']=='passed' and persistence['actual_process_exit']==0 and persistence['simulated_errno']==28
 assert persistence['harness_sha256']==sha(ROOT/'scripts/endurance.py') and persistence['ram_report_sha256']==sha(ROOT/'controls/root-write-failure-ram.json')
 report['validation_interruption']=dict(status=interruption['status'],diagnostic_sha256=sha(ROOT/'interrupted-filesystem-pressure/diagnostic.json'),data=interruption,interpretation='Interrupted sessions remain incomplete, not passed. Their observed exit 120, zero-byte temporary reports and last successful progress are preserved. Later successful runs do not conclusively identify the initiating exception; disk pressure is supporting context, not a proven root cause.')
 report['persistence_control']=persistence
 report['ram_evidence_scope']='Restarted final cohorts mirror progress and failure arrays into /dev/shm before root writes, and emit exceptions directly through tool stderr. Mirrors are copied into final archive after actual reaping.'
 if args.preview:
  (ROOT/'preview-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],actual_elapsed_seconds=now-START)));return
 early=read(ROOT/'duration-gate-control.json');assert early['status']=='passed' and early['real_clock_used'] and not early['clock_simulated'] and early['actual_elapsed_seconds']<DURATION and early['reporter_sha256']==sha(Path(__file__))
 completions=read(ROOT/'session-completions.json')
 for n in PROBES:
  assert completions[n]['exit_code']==0 and completions[n]['reaped'] is True and not (Path('/proc')/str(completions[n]['pid'])).exists()
 assert not read(ROOT/'operator-state.json')['active_sessions'] and read(ROOT/'closing-preflight.json')['status']=='passed'
 gate=dict(status='passed',real_clock_used=True,actual_elapsed_seconds=now-START,required_elapsed_seconds=DURATION,parallel_durations_added=False,early_control=early)
 (ROOT/'duration-gate.json').write_text(json.dumps(gate,indent=2)+'\n');report['duration_gate']=gate
 payload=pack(members());count=verify_archive(payload)
 with ARCHIVE.open('xb') as f:f.write(payload)
 report['evidence_archive']=dict(path=str(ARCHIVE.relative_to(WORKSPACE)),sha256=hashlib.sha256(payload).hexdigest(),bytes=len(payload),regular_members=count)
 with REPORT.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
 print(json.dumps(dict(status=report['status'],actual_elapsed_seconds=now-START,archive_members=count,archive_bytes=len(payload))))
if __name__=='__main__':main()
