import importlib.util,json,time,tracemalloc
from pathlib import Path
import numpy as np
from embodiedforge.core import Config,SceneSpec
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'initial/src/embodiedforge/backends/physics.py'
spec=importlib.util.spec_from_file_location('old_physics',p);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
class Cached(old.NumpyPhysics):
 def step(self,dt,substeps,active):
  h=dt/substeps;ids=np.flatnonzero(active)
  if not len(ids):return
  if len(ids)==len(active):return super().step(dt,substeps,active)
  velocity=self.velocity[ids];position=self.position[ids]
  delta=self.control[ids]*h/self.scene.mass
  for _ in range(substeps):
   velocity+=delta;position+=velocity*h
  self.velocity[ids]=velocity;self.position[ids]=position
  self.time[ids]+=dt;self.version[ids]+=1

def run(cls,n,f,substeps,loops):
 rng=np.random.default_rng(19);b=cls();b.build(SceneSpec(mass=1.3),Config(num_envs=n));b.position[:]=rng.normal(size=(n,2));b.velocity[:]=rng.normal(size=(n,2));b.apply_control(rng.normal(size=(n,2)));active=rng.random(n)<f
 start=time.perf_counter()
 for _ in range(loops):b.step(.02,substeps,active)
 elapsed=time.perf_counter()-start
 return elapsed,b
rows=[]
for n in (16,128,1024,8192):
 for f in (.1,.5,.9,1):
  for s in (1,4,16):
   results={c.__name__:[] for c in (old.NumpyPhysics,Cached)}
   for i in range(7):
    for c in ((old.NumpyPhysics,Cached) if i%2==0 else (Cached,old.NumpyPhysics)):
     t,b=run(c,n,f,s,100);results[c.__name__].append(t)
   a=run(old.NumpyPhysics,n,f,s,30)[1];b=run(Cached,n,f,s,30)[1]
   for k in ('position','velocity','time','version'):assert np.array_equal(getattr(a,k),getattr(b,k)),(n,f,s,k)
   row=dict(n=n,f=f,substeps=s,seconds=results,reduction_percent=100*(1-np.median(results['Cached'])/np.median(results['NumpyPhysics'])))
   rows.append(row);print(n,f,s,round(row['reduction_percent'],1),flush=True)
(ROOT/'explore-physics.json').write_text(json.dumps(rows,indent=2)+'\n')
