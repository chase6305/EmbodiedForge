"""Alternating paired timing; setup, tracing and digests outside timing."""
import itertools,json,os,platform,statistics,time,tracemalloc
from pathlib import Path
import numpy as np
from common import ROOT,WORKSPACE,OLD,NEW,equal,fields,fingerprint,physics,environment,sha,source_map,pin
CPU=pin();PAIRS=21

def measure(cls,n,f,sub,pipeline,trace=False):
 b,a,active=(environment if pipeline else physics)(cls,n,f,sub)
 def call():
  if pipeline:b.step(a)
  else:b.apply_control(a);b.step(.02,sub,active);b.snapshot()
 try:
  for _ in range(3):call()
  loops=1 if trace else (12 if pipeline else 32)
  if trace:tracemalloc.start()
  start=time.perf_counter()
  for _ in range(loops):call()
  elapsed=(time.perf_counter()-start)/loops
  peak=tracemalloc.get_traced_memory()[1] if trace else None
  if trace:tracemalloc.stop()
  values=fields(b.physics if pipeline else b)
  if pipeline:values={**values,**{'obs/'+k:v for k,v in b.observe().items()},'steps':b.steps,'terminated':b.terminated,'truncated':b.truncated}
  return elapsed,peak,{k:v.copy() for k,v in values.items()}
 finally:
  if tracemalloc.is_tracing():tracemalloc.stop()
  b.close()

started=time.time();rows=[]
cases=[(*c,False) for c in itertools.product((16,128,1024,8192),(0,.1,.5,.9,1),(1,4,16))]
cases += [(*c,True) for c in itertools.product((128,1024),(.1,.5,1),(4,16))]
for n,f,sub,pipeline in cases:
 samples={'initial':[],'current':[]}
 for i in range(PAIRS):
  last={}
  for label,cls in ((('initial',OLD),('current',NEW)) if i%2==0 else (('current',NEW),('initial',OLD))):
   t,_,values=measure(cls,n,f,sub,pipeline);samples[label].append(t);last[label]=values
  equal(last['initial'],last['current'])
 peaks={}
 for label,cls in (('initial',OLD),('current',NEW)):
  peaks[label]=[measure(cls,n,f,sub,pipeline,True)[1] for _ in range(3)]
 a,b=(statistics.median(samples[k]) for k in ('initial','current'))
 row=dict(num_envs=n,active_fraction=f,substeps=sub,scope='environment_step' if pipeline else 'physics_control_step_snapshot',seconds=samples,median_seconds={k:statistics.median(v) for k,v in samples.items()},traced_peak_bytes=peaks,elapsed_reduction_percent=100*(1-b/a),peak_reduction_percent=100*(1-statistics.median(peaks['current'])/statistics.median(peaks['initial'])),output_sha256=fingerprint(last['current']))
 rows.append(row);print(n,f,sub,pipeline,round(row['elapsed_reduction_percent'],2),flush=True)
name=f'performance-py{platform.python_version()}-numpy{np.__version__}'
report=dict(status='passed',started_epoch=started,finished_epoch=time.time(),python=platform.python_version(),numpy=np.__version__,cpu_affinity=sorted(os.sched_getaffinity(0)),pairs=PAIRS,scope='CPU planar reference dynamics; direct includes apply_control/step/owned snapshot. Environment includes complete step/task/observations with fixed frozen rows and no cameras. Setup, warmup, tracing and digest comparison excluded from timing. Shared host pinned to one allowed CPU; raw signed results include unchanged controls. Three transient tracemalloc peak samples, not RSS. No GPU or training throughput inference.',runtime_source_sha256=source_map(),initial_source_sha256=sha(ROOT/'initial/src/embodiedforge/backends/physics.py'),script_sha256={f'scripts/{p}':sha(ROOT/'scripts'/p) for p in ('performance.py','common.py')},cases=rows)
(ROOT/(name+'.json')).write_text(json.dumps(report,indent=2)+'\n');print(name,flush=True)
