"""Independently read the real exported archive and resolve evidence links."""
import hashlib,io,json,tarfile,time
import numpy as np
from report import ROOT,WORKSPACE,REPORT,ARCHIVE,FIGURE,CORE,PROBES,START,DURATION,read,sha,verify_archive
report=read(REPORT);assert report['actual_elapsed_seconds']>=DURATION and report['duration_gate']['actual_elapsed_seconds']>=DURATION
payload=ARCHIVE.read_bytes();assert len(payload)==report['evidence_archive']['bytes'] and hashlib.sha256(payload).hexdigest()==report['evidence_archive']['sha256']
count=verify_archive(payload);assert count==report['evidence_archive']['regular_members']
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tar:
 def data(n):return tar.extractfile(n).read()
 def digest(n):return hashlib.sha256(data(n)).hexdigest()
 initial=json.loads(data('run/initial-hashes.json'));initial_runtime=0
 for p,h in initial.items():
  if p.startswith('src/') and p.endswith('.py'):assert digest('run/initial/'+p)==h;initial_runtime+=1
 assert initial_runtime==105
 for p,h in report['review_files_sha256'].items():assert sha(WORKSPACE/p)==digest('final/'+p)==h
 assert digest('final/'+str(FIGURE.relative_to(WORKSPACE)))==sha(FIGURE)==report['figure']['figure_sha256']
 assert b'<text' in data('final/'+str(FIGURE.relative_to(WORKSPACE)))
 assert digest('run/scripts/plot.py')==report['figure']['script_sha256']
 root_rel=ROOT.relative_to(WORKSPACE)
 for p,h in report['validation']['sha256'].items():
  assert sha(WORKSPACE/p)==h
  location='run/'+str((WORKSPACE/p).relative_to(ROOT)) if p.startswith(str(root_rel)+'/') else 'final/'+p if p in CORE else 'run/initial/'+p
  assert digest(location)==h,location
 frozen=json.loads(data('run/frozen-runtime.json'))['sha256'];assert frozen=={str(p.relative_to(WORKSPACE)):sha(p) for p in (WORKSPACE/'src').rglob('*.py')}
 for n in PROBES:
  p='run/'+n+'.json';d=json.loads(data(p));assert digest(p)==report['probe_results'][n]['raw_report_sha256']
  assert d['status']=='passed' and d['runtime_source_sha256']==frozen and d['cases']==report['probe_results'][n]['cases'] and d['configuration_count']==d['base_configurations_expected']
  for p,h in d['script_sha256'].items():assert digest('run/'+p)==h
 for n,d in report['performance'].items():
  assert digest('run/'+n)==d['sha256'];raw=json.loads(data('run/'+n));assert len(raw['cases'])==72 and raw['status']=='passed' and raw['runtime_source_sha256']==frozen
  for p,h in raw['script_sha256'].items():assert digest('run/'+p)==h
 gate=json.loads(data('run/duration-gate.json'));assert gate==report['duration_gate'];early=gate['early_control']
 assert early['real_clock_used'] and not early['clock_simulated'] and early['actual_elapsed_seconds']<DURATION and early['actual_rejection_exit']==1 and not early['final_outputs_created']
 assert digest('run/scripts/report.py')==sha(ROOT/'scripts/report.py')==early['reporter_sha256']
 for n,d in json.loads(data('run/session-completions.json')).items():assert d['exit_code']==0 and d['reaped'] is True and n in PROBES
 capture=report['capture_control'];p='run/controls/capture-control-failure-input.npz';assert digest(p)==capture['capture_sha256']
 with np.load(io.BytesIO(data(p)),allow_pickle=False) as f:
  for k in ('position','velocity','control','time','version'):
   assert np.array_equal(f['before_initial/'+k],f['before_current/'+k]);assert 'after_initial/'+k in f and 'after_current/'+k in f
  assert not np.array_equal(f['after_initial/position'],f['after_current/position'])
 assert json.loads(data('run/controls/capture-control-failure.json'))['status']=='failed'
 prior='run/inherited-diagnostic/subclasses-py312-failure.json';assert json.loads(data(prior))['status']=='failed' and digest(prior)==report['inherited_diagnostic']['original_failure_sha256']
 phase=json.loads(data('run/phase1-harness-before-capture/preservation.json'))
 for p,h in phase['sha256'].items():assert digest('run/phase1-harness-before-capture/'+p)==h
 for v in phase['actual_stop_exits'].values():assert v['tool_result']['exit_code']==143 and v['reaped'] is True
 interruption=report['validation_interruption']
 assert digest('run/interrupted-filesystem-pressure/diagnostic.json')==interruption['diagnostic_sha256']
 for p,h in interruption['data']['sha256'].items():assert digest('run/interrupted-filesystem-pressure/'+p)==h
 for v in interruption['data']['observed_sessions'].values():assert v['exit_code']==120 and v['reaped'] is True
 persistence=report['persistence_control'];assert digest('run/controls/root-write-failure-ram.json')==persistence['ram_report_sha256']
 assert digest('run/scripts/endurance.py')==persistence['harness_sha256']
 ram_control=json.loads(data('run/controls/root-write-failure-ram.json'));assert ram_control['status']=='passed' and ram_control['cases']==20 and all(e['errno']==28 for e in ram_control['persistence_events'])
 for n in PROBES:assert data('run/'+n+'.json')==data('run/ram-mirror/'+n+'.json')
report['artifact_verification']=dict(status='passed',epoch=time.time(),actual_elapsed_seconds=time.time()-START,regular_archive_members=count,gzip_crc_and_all_manifest_hashes_verified=True,source_tests_logs_performance_and_harness_links_verified=True,real_early_rejection_and_final_duration_verified=True,capture_control_before_after_bytes_verified=True,prior_failed_record_and_superseded_sessions_preserved=True)
report['status']='complete_with_unclassified_diagnostics'
tmp=REPORT.with_suffix('.json.tmp');tmp.write_text(json.dumps(report,indent=2)+'\n');tmp.replace(REPORT)
print(json.dumps(report['artifact_verification'],indent=2))
