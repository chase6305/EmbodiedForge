"""Check immutable runtime, preserved initial files, probe progress and real time."""
import hashlib,json,time,os
from pathlib import Path
from common import ROOT,WORKSPACE,atomic,read,sha,guard
state=read(ROOT/'state.json');assert state['start_epoch']==1792375540 and state['deadline_epoch']==1792386340 and state['required_elapsed_seconds']==10800
RAM_ROOT=Path('/dev/shm')/ROOT.name
assert not list(RAM_ROOT.glob('*-failure.json'))
assert not list(ROOT.glob('*-failure.json')),'New failure evidence requires diagnosis'
guard();initial=read(ROOT/'initial-hashes.json')
for n,h in initial.items():assert sha(ROOT/'initial'/n)==h,n
for n,h in read(ROOT/'validation.json')['sha256'].items():assert sha(WORKSPACE/n)==h,n
rows={};now=time.time()
for name,s in read(ROOT/'operator-state.json')['active_sessions'].items():
 candidates=[read(p) for p in (ROOT/(name+'-progress.json'),RAM_ROOT/(name+'-progress.json')) if p.exists()]
 d=max(candidates,key=lambda x:x['updated_epoch']);assert d['pid']==s['pid'] and d['status'] in ('running','passed')
 if d['status']=='running':
  assert now-d['updated_epoch']<90,(name,'stale')
  args=(Path('/proc')/str(s['pid'])/'cmdline').read_bytes().split(b'\0');assert name.encode() in args and any(v.endswith(b'/endurance.py') for v in args)
 assert d['runtime_source_sha256']==read(ROOT/'frozen-runtime.json')['sha256']
 for p,h in d['script_sha256'].items():assert sha(ROOT/p)==h
 for k in ('fds','python_threads','os_threads'):assert len({r[k] for r in d['resources']})==1,(name,k)
 rows[name]={k:d[k] for k in ('status','cases','configuration_count','base_configurations_expected')}
 rows[name]['persistence_events']=len(d.get('persistence_events',[]))
disk=os.statvfs(ROOT);free_bytes=disk.f_bavail*disk.f_frsize
event=dict(disk_free_bytes=free_bytes,storage_pressure=free_bytes<256*1024*1024,status='passed',epoch=now,elapsed_seconds=now-state['start_epoch'],remaining_seconds=max(0,state['deadline_epoch']-now),initial_files_verified=len(initial),runtime_files_verified=105,probes=rows)
RAM_ROOT.mkdir(exist_ok=True)
with (RAM_ROOT/'monitor-audit.jsonl').open('a') as f:f.write(json.dumps(event,separators=(',',':'))+'\n')
atomic(RAM_ROOT/'monitor-latest.json',event)
try:
 with (ROOT/'monitor-audit.jsonl').open('a') as f:f.write(json.dumps(event,separators=(',',':'))+'\n')
 atomic(ROOT/'monitor-latest.json',event)
except OSError as error:event['observer_write_error']=str(error)
print(json.dumps(event))
