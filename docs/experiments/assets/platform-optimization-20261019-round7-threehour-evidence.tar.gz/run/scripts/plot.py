"""Plot paired median ratios from all three versioned performance reports."""
import hashlib,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parents[1];WORKSPACE=ROOT.parents[1]
paths=sorted(ROOT.glob('performance-*.json'));assert len(paths)==3
plt.rcParams.update({'svg.fonttype':'none','font.size':10})
fig,axes=plt.subplots(3,2,figsize=(12,10),sharey=True)
for row,path in enumerate(paths):
 d=json.loads(path.read_text())
 for col,(scope,fractions) in enumerate((('physics_control_step_snapshot',(.1,.5,.9,1)),('environment_step',(.1,.5,1)))):
  ax=axes[row,col];x=np.arange(len(fractions));width=.34
  for offset,sub,color in ((-.5,4,'#168782'),(.5,16,'#4678bd')):
   ratios=[]
   for f in fractions:
    c=next(c for c in d['cases'] if c['num_envs']==1024 and c['active_fraction']==f and c['substeps']==sub and c['scope']==scope)
    ratios.append(c['median_seconds']['current']/c['median_seconds']['initial'])
   bars=ax.bar(x+offset*width,ratios,width,label=f'{sub} substeps',color=color)
   ax.bar_label(bars,labels=[f'{v:.2f}' for v in ratios],padding=3,fontsize=9)
  ax.axhline(1,color='#666666',ls='--',lw=1);ax.set_xticks(x,[f'{int(f*100)}%' for f in fractions]);ax.set_ylim(0,1.23);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
  ax.set_title(f"Python {d['python']} / NumPy {d['numpy']}",fontsize=11)
  if row==2:ax.set_xlabel('Configured active fraction (fixed seeded mask)')
  if col==0:ax.set_ylabel('Current / initial median time')
  if row==0 and col==0:ax.legend(loc='upper left',fontsize=9)
fig.suptitle('Partial NumPy physics: observed time ratios at 1024 environments',fontsize=15,y=.98)
fig.text(.25,.94,'Control + Euler step + owned snapshot',ha='center',fontsize=12)
fig.text(.75,.94,'Complete environment step, no cameras',ha='center',fontsize=12)
fig.subplots_adjust(top=.89,bottom=.20,hspace=.4,wspace=.16,left=.08,right=.98)
fig.text(.08,.045,'Lower is faster; dashed line = initial median. 21 alternating pairs, one pinned CPU on a shared host.\nSetup, warmup, tracing and checksums are excluded from timing. Full signed results and unchanged controls retained.\nSynthetic CPU point-reach reference; no inference about MuJoCo, GPU or training throughput.',fontsize=10)
figure=WORKSPACE/'docs/platform-optimization-20261019-round7-threehour-performance.svg'
fig.savefig(figure);fig.savefig('/tmp/ef-round7-performance.png',dpi=120)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(status='passed',figure_sha256=sha(figure),script_sha256=sha(Path(__file__)),reports_sha256={p.name:sha(p) for p in paths},scope='Selected 1024-environment scenarios; all 72 scenarios per version retained in raw reports.')
(ROOT/'figure-provenance.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
