"""Differential trajectories with immutable source guards and raw failure inputs."""
import argparse,errno,gc,itertools,json,os,sys,threading,time,traceback,weakref
from pathlib import Path
import numpy as np
from common import ROOT,OLD,NEW,atomic,equal,fields,fingerprint,physics,environment,result_fields,source_map,guard,read,sha,pin
parser=argparse.ArgumentParser();parser.add_argument('--name',required=True);parser.add_argument('--scope',choices=('physics','environment'),required=True);parser.add_argument('--cpu',type=int,required=True);parser.add_argument('--smoke',type=int,default=0);parser.add_argument('--inject-failure',action='store_true');args=parser.parse_args()
assert not args.inject_failure or args.smoke>0
RAM_ROOT=Path('/dev/shm')/ROOT.name;RAM_ROOT.mkdir(exist_ok=True)
persistence_events=[]
def stderr(message):
 try:print(message,file=sys.stderr,flush=True)
 except OSError:pass
def persist(path,data):
 mirror=RAM_ROOT/path.relative_to(ROOT);mirror.parent.mkdir(parents=True,exist_ok=True)
 atomic(mirror,data)
 try:atomic(path,data)
 except OSError as error:
  if error.errno not in (errno.ENOSPC,errno.EDQUOT,errno.EIO):raise
  event=dict(epoch=time.time(),path=str(path),errno=error.errno,error=str(error));persistence_events.append(event);stderr(json.dumps({'artifact_write_interruption':event,'ram_mirror':str(mirror)}))
CPU=pin(args.cpu);stop=read(ROOT/'state.json')['probe_stop_epoch'];started=time.time();cases=0;covered=set();resources=[];last_progress=last_guard=0
class Numeric(np.ndarray):pass

def resource():
 return dict(fds=len(list(Path('/proc/self/fd').iterdir())),python_threads=threading.active_count(),os_threads=len(list(Path('/proc/self/task').iterdir())))

def physics_case(index,configuration):
 n,f,sub,layout,dtype,alias=configuration;rng=np.random.default_rng(190000+index)
 pair=[]
 for cls in (OLD,NEW):
  b,a,mask=physics(cls,n,f,sub,190000+index)
  for name in ('position','velocity','control'):
   v=getattr(b,name).astype(dtype)
   if layout=='F':v=np.asfortranarray(v)
   elif layout=='strided':v=np.repeat(v,2,axis=0)[::2]
   elif layout=='subclass':v=v.view(Numeric)
   setattr(b,name,v)
  if alias=='position_velocity':b.velocity=b.position
  elif alias=='position_control':b.control=b.position
  elif alias=='velocity_control':b.control=b.velocity
  pair.append(b)
 before={}
 for step in range(8):
  action=rng.uniform(-1,1,(n,2));action.flags.writeable=False
  active=rng.random(n)<f
  if step%4==0:active[:]=True
  elif step%4==1:active[:]=False
  active=np.repeat(active,2)[::2];active.flags.writeable=False
  inputs={'action':action,'active':active};before={k:v.copy() for k,v in inputs.items()};digest=fingerprint(inputs)
  for b in pair:b.apply_control(action)
  globals()['failure_context']={**inputs,**{'before_initial/'+k:v.copy() for k,v in fields(pair[0]).items()},**{'before_current/'+k:v.copy() for k,v in fields(pair[1]).items()},'case':np.array(index),'step':np.array(step),'configuration':np.array(json.dumps(configuration))}
  for b in pair:b.step(.005+.001*(index%7),sub,active)
  if args.inject_failure and index==0 and step==0:pair[1].position[0,0]+=1
  equal(fields(pair[0]),fields(pair[1]));assert fingerprint(inputs)==digest;equal(inputs,before)
  if step==3:
   ids=np.arange(0,n,3);positions=rng.uniform(-1,1,(len(ids),2));positions.flags.writeable=False
   for b in pair:b.reset(ids,positions)
   equal(fields(pair[0]),fields(pair[1]))
  snapshots=[b.snapshot() for b in pair];equal(vars(snapshots[0]),vars(snapshots[1]))
  for b,s in zip(pair,snapshots,strict=True):
   for k,v in vars(s).items():assert v.flags.owndata and not np.shares_memory(v,getattr(b,k));v[:]=0
 refs=[weakref.ref(b) for b in pair]
 refs.extend(weakref.ref(v) for b in pair for v in fields(b.physics if args.scope=='environment' else b).values())
 for b in pair:b.close()
 globals()['failure_context']={}
 return refs


def environment_case(index,configuration):
 n,f,sub,render=configuration
 pair=[environment(c,n,f,sub,render,190000+index)[0] for c in (OLD,NEW)]
 rng=np.random.default_rng(290000+index)
 for step in range(12):
  a=rng.uniform(-.1,.1,(n,2));a.flags.writeable=False;before=a.tobytes()
  globals()['failure_context']={'action':a,'case':np.array(index),'step':np.array(step),'configuration':np.array(json.dumps(configuration)),**{'before_initial/'+k:v.copy() for k,v in fields(pair[0].physics).items()},**{'before_current/'+k:v.copy() for k,v in fields(pair[1].physics).items()}}
  results=[b.step(a) for b in pair];equal(result_fields(results[0]),result_fields(results[1]));assert a.tobytes()==before
  for r in results:
   for v in result_fields(r).values():assert v.flags.owndata
  if step in (3,7):
   ids=np.arange(1,n,3)[::-1];obs=[b.reset(ids) for b in pair];equal(obs[0],obs[1])
  if step%3==0:
   for b in pair:
    b.terminated[::4]=True;b.truncated[2::4]=True
  equal(pair[0].observe(),pair[1].observe())
 refs=[weakref.ref(b) for b in pair]
 refs.extend(weakref.ref(v) for b in pair for v in fields(b.physics if args.scope=='environment' else b).values())
 for b in pair:b.close()
 globals()['failure_context']={}
 return refs

if args.scope=='physics':
 configs=list(itertools.product((1,7,128,1024,8192),(.1,.5,.9),(1,4,16),('C','F','strided','subclass'),('float64','float32','>f8'),('none','position_velocity','position_control','velocity_control')))
else:configs=list(itertools.product((1,7,128,1024),(.1,.5,.9),(1,4,16),(False,True)))
np.random.default_rng(197).shuffle(configs)
report=dict(status='running',name=args.name,scope=args.scope,pid=os.getpid(),started_epoch=started,python=__import__('platform').python_version(),numpy=np.__version__,cpu_affinity=[CPU],base_configurations_expected=len(configs),runtime_source_sha256=source_map(),script_sha256={f'scripts/{p}':sha(ROOT/'scripts'/p) for p in ('endurance.py','common.py')},resources=resources,ram_evidence_directory=str(RAM_ROOT),persistence_events=persistence_events)
failure_context={}

def progress(status='running'):
 global last_progress
 now=time.time();resources.append(dict(epoch=now,**resource()))
 for k in ('fds','python_threads','os_threads'):assert len({r[k] for r in resources})==1,(k,resources[-1])
 report.update(status=status,updated_epoch=now,elapsed_seconds=now-started,cases=cases,configuration_count=len(covered));persist(ROOT/(args.name+'-progress.json'),report);last_progress=now
try:
 guard();progress()
 while (cases<args.smoke if args.smoke else time.time()<stop):
  config=configs[cases%len(configs)]
  refs=(physics_case if args.scope=='physics' else environment_case)(cases,config)
  assert all(ref() is None for ref in refs),'Completed case retained backend or state arrays'
  covered.add(cases%len(configs));cases+=1
  now=time.time()
  if now-last_guard>60:guard();last_guard=now
  if now-last_progress>20:progress()
 guard();progress('passed');report['finished_epoch']=time.time();persist(ROOT/(args.name+'.json'),report)
except BaseException:
 original_traceback=traceback.format_exc();stderr(original_traceback)
 tb=sys.exc_info()[2]
 while tb is not None:
  frame=tb.tb_frame
  if frame.f_code.co_name in ('physics_case','environment_case') and 'pair' in frame.f_locals:
   for label,b in zip(('initial','current'),frame.f_locals['pair'],strict=True):
    failure_context.update({'after_'+label+'/'+k:v for k,v in fields(b.physics if args.scope=='environment' else b).items()})
  tb=tb.tb_next
 if failure_context:
  ram=RAM_ROOT/(args.name+'-failure-input.npz');ram.parent.mkdir(parents=True,exist_ok=True)
  np.savez_compressed(ram,**failure_context)
  try:(ROOT/(args.name+'-failure-input.npz')).write_bytes(ram.read_bytes())
  except OSError as error:stderr(json.dumps({'failure_capture_copy_error':str(error),'ram_capture':str(ram)}))
 report.update(status='failed',cases=cases,configuration_count=len(covered),finished_epoch=time.time(),traceback=original_traceback)
 persist(ROOT/(args.name+'-failure.json'),report);raise
