"""Frozen old/new implementations and exact state/observation comparisons."""
import hashlib,importlib.util,json,os,sys
from pathlib import Path
import numpy as np
from embodiedforge import Config,VectorEnv
from embodiedforge.backends import PHYSICS,Registration
from embodiedforge.backends.physics import NumpyPhysics
from embodiedforge.core import SceneSpec
from embodiedforge.tasks import ReachTask
ROOT=Path(__file__).resolve().parents[1];WORKSPACE=ROOT.parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def atomic(p,d):
 t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n');t.replace(p)
def versions():
 spec=importlib.util.spec_from_file_location('r7_old_physics',ROOT/'initial/src/embodiedforge/backends/physics.py')
 mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 return mod.NumpyPhysics,NumpyPhysics
OLD,NEW=versions()
def fingerprint(values):
 h=hashlib.sha256()
 for key,value in sorted(values.items()):
  a=np.asanyarray(value);h.update(key.encode());h.update(str((a.shape,a.dtype.str)).encode());h.update(a.tobytes())
 return h.hexdigest()
def fields(b):return dict(position=b.position,velocity=b.velocity,control=b.control,time=b.time,version=b.version)
def result_fields(r):
 return {**{'obs/'+k:v for k,v in r.observation.items()},'reward':r.reward,'terminated':r.terminated,'truncated':r.truncated,**{'info/'+k:v for k,v in r.info.items()}}
def equal(a,b):
 assert a.keys()==b.keys()
 for k in a:
  assert a[k].dtype==b[k].dtype and a[k].shape==b[k].shape,k
  assert a[k].tobytes()==b[k].tobytes(),k

def physics(cls,n,f,sub,seed=19):
 rng=np.random.default_rng(seed);b=cls();b.build(SceneSpec(mass=1.3),Config(num_envs=n))
 b.position[:]=rng.normal(size=(n,2));b.velocity[:]=rng.normal(size=(n,2));a=rng.uniform(-1,1,(n,2));active=rng.random(n)<f
 return b,a,active

def environment(cls,n,f,sub,render=False,seed=19):
 name='_r7_'+('initial' if cls is OLD else 'current')
 PHYSICS[name]=Registration(cls,cls.capabilities)
 task=ReachTask();task.scene=SceneSpec(mass=1.3)
 b=VectorEnv(Config(num_envs=n,physics=name,physics_hz=50*sub,max_steps=1000000,render='raster' if render else 'null',channels=('depth',) if render else (),image_size=32,seed=seed),task)
 b.physics.position[:]=0;b.physics.velocity[:]=0;b.task.target[:]=1
 active=np.random.default_rng(seed).random(n)<f;b.terminated[:]=~active
 a=np.zeros((n,2));a[:,0]=.01
 return b,a,active

def source_map():return {str(p.relative_to(WORKSPACE)):sha(p) for p in sorted((WORKSPACE/'src').rglob('*.py'))}
def guard():
 assert source_map()==read(ROOT/'frozen-runtime.json')['sha256'],'Runtime source drift'
 for p,h in read(ROOT/'frozen-harness.json')['sha256'].items():assert sha(ROOT/p)==h,p

def pin(cpu=None):
 allowed=sorted(os.sched_getaffinity(0));chosen=allowed[0] if cpu is None else cpu
 assert chosen in allowed;os.sched_setaffinity(0,{chosen});return chosen
