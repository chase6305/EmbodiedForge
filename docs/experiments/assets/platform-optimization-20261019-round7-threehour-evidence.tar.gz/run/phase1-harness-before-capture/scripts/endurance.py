"""Differential trajectories with immutable source guards and raw failure inputs."""
import argparse,gc,itertools,json,os,threading,time,traceback,weakref
from pathlib import Path
import numpy as np
from common import ROOT,OLD,NEW,atomic,equal,fields,fingerprint,physics,environment,result_fields,source_map,guard,read,sha,pin
parser=argparse.ArgumentParser();parser.add_argument('--name',required=True);parser.add_argument('--scope',choices=('physics','environment'),required=True);parser.add_argument('--cpu',type=int,required=True);parser.add_argument('--smoke',type=int,default=0);args=parser.parse_args()
CPU=pin(args.cpu);stop=read(ROOT/'state.json')['probe_stop_epoch'];started=time.time();cases=0;covered=set();resources=[];last_progress=last_guard=0
class Numeric(np.ndarray):pass

def resource():
 return dict(fds=len(list(Path('/proc/self/fd').iterdir())),python_threads=threading.active_count(),os_threads=len(list(Path('/proc/self/task').iterdir())))

def physics_case(index,configuration):
 n,f,sub,layout,dtype,alias=configuration;rng=np.random.default_rng(190000+index)
 pair=[]
 for cls in (OLD,NEW):
  b,a,mask=physics(cls,n,f,sub,190000+index)
  for name in ('position','velocity','control'):
   v=getattr(b,name).astype(dtype)
   if layout=='F':v=np.asfortranarray(v)
   elif layout=='strided':v=np.repeat(v,2,axis=0)[::2]
   elif layout=='subclass':v=v.view(Numeric)
   setattr(b,name,v)
  if alias=='position_velocity':b.velocity=b.position
  elif alias=='position_control':b.control=b.position
  elif alias=='velocity_control':b.control=b.velocity
  pair.append(b)
 before={}
 for step in range(8):
  action=rng.uniform(-1,1,(n,2));action.flags.writeable=False
  active=rng.random(n)<f
  if step%4==0:active[:]=True
  elif step%4==1:active[:]=False
  active=np.repeat(active,2)[::2];active.flags.writeable=False
  inputs={'action':action,'active':active};before={k:v.copy() for k,v in inputs.items()};digest=fingerprint(inputs)
  for b in pair:b.apply_control(action)
  globals()['failure_context']={**inputs,**{'before_initial/'+k:v.copy() for k,v in fields(pair[0]).items()},**{'before_current/'+k:v.copy() for k,v in fields(pair[1]).items()},'case':np.array(index),'step':np.array(step),'configuration':np.array(json.dumps(configuration))}
  for b in pair:b.step(.005+.001*(index%7),sub,active)
  equal(fields(pair[0]),fields(pair[1]));assert fingerprint(inputs)==digest;equal(inputs,before)
  if step==3:
   ids=np.arange(0,n,3);positions=rng.uniform(-1,1,(len(ids),2));positions.flags.writeable=False
   for b in pair:b.reset(ids,positions)
   equal(fields(pair[0]),fields(pair[1]))
  snapshots=[b.snapshot() for b in pair];equal(vars(snapshots[0]),vars(snapshots[1]))
  for b,s in zip(pair,snapshots,strict=True):
   for k,v in vars(s).items():assert v.flags.owndata and not np.shares_memory(v,getattr(b,k));v[:]=0
 for b in pair:b.close()
 globals()['failure_context']={}


def environment_case(index,configuration):
 n,f,sub,render=configuration
 pair=[environment(c,n,f,sub,render,190000+index)[0] for c in (OLD,NEW)]
 rng=np.random.default_rng(290000+index)
 for step in range(12):
  a=rng.uniform(-.1,.1,(n,2));a.flags.writeable=False;before=a.tobytes()
  globals()['failure_context']={'action':a,'case':np.array(index),'step':np.array(step),'configuration':np.array(json.dumps(configuration)),**{'before_initial/'+k:v.copy() for k,v in fields(pair[0].physics).items()},**{'before_current/'+k:v.copy() for k,v in fields(pair[1].physics).items()}}
  results=[b.step(a) for b in pair];equal(result_fields(results[0]),result_fields(results[1]));assert a.tobytes()==before
  for r in results:
   for v in result_fields(r).values():assert v.flags.owndata
  if step in (3,7):
   ids=np.arange(1,n,3)[::-1];obs=[b.reset(ids) for b in pair];equal(obs[0],obs[1])
  if step%3==0:
   for b in pair:
    b.terminated[::4]=True;b.truncated[2::4]=True
  equal(pair[0].observe(),pair[1].observe())
 for b in pair:b.close()
 globals()['failure_context']={}

if args.scope=='physics':
 configs=list(itertools.product((1,7,128,1024,8192),(.1,.5,.9),(1,4,16),('C','F','strided','subclass'),('float64','float32','>f8'),('none','position_velocity','position_control','velocity_control')))
else:configs=list(itertools.product((1,7,128,1024),(.1,.5,.9),(1,4,16),(False,True)))
np.random.default_rng(197).shuffle(configs)
report=dict(status='running',name=args.name,scope=args.scope,pid=os.getpid(),started_epoch=started,python=__import__('platform').python_version(),numpy=np.__version__,cpu_affinity=[CPU],base_configurations_expected=len(configs),runtime_source_sha256=source_map(),script_sha256={f'scripts/{p}':sha(ROOT/'scripts'/p) for p in ('endurance.py','common.py')},resources=resources)
failure_context={}

def progress(status='running'):
 global last_progress
 now=time.time();resources.append(dict(epoch=now,**resource()))
 for k in ('fds','python_threads','os_threads'):assert len({r[k] for r in resources})==1,(k,resources[-1])
 report.update(status=status,updated_epoch=now,elapsed_seconds=now-started,cases=cases,configuration_count=len(covered));atomic(ROOT/(args.name+'-progress.json'),report);last_progress=now
try:
 guard();progress()
 while (cases<args.smoke if args.smoke else time.time()<stop):
  config=configs[cases%len(configs)]
  (physics_case if args.scope=='physics' else environment_case)(cases,config)
  covered.add(cases%len(configs));cases+=1
  now=time.time()
  if now-last_guard>60:guard();last_guard=now
  if now-last_progress>20:progress()
 guard();progress('passed');report['finished_epoch']=time.time();atomic(ROOT/(args.name+'.json'),report)
except BaseException:
 if failure_context:np.savez_compressed(ROOT/(args.name+'-failure-input.npz'),**failure_context)
 report.update(status='failed',cases=cases,configuration_count=len(covered),finished_epoch=time.time(),traceback=traceback.format_exc());atomic(ROOT/(args.name+'-failure.json'),report);raise
