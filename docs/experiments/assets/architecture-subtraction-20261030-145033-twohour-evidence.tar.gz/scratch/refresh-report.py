"""Reconcile source, artifacts and actual workflow exits; enforce two hours."""
import argparse
import ast
import hashlib
import json
import runpy
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
WORK = Path('/tmp/embodiedforge-subtraction-20261030-145033-twohour')
STEM = 'architecture-subtraction-20261030-145033-twohour'


def read(path):
    return json.loads(path.read_text())


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def declarations(tree, prefix=''):
    result = {}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            key = prefix + node.name
            result[key] = ('class' if isinstance(node, ast.ClassDef) else
                           (ast.dump(node.args, include_attributes=False),
                            ast.dump(node.returns, include_attributes=False) if node.returns else None))
            result.update(declarations(node, key + '.'))
    return result


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--final', action='store_true')
args = parser.parse_args()
state = read(WORK / 'state.json')
now = datetime.now(timezone.utc)
elapsed = (now - datetime.fromisoformat(state['started_at'])).total_seconds()
if args.final:
    assert now >= datetime.fromisoformat(state['deadline']) and elapsed >= 7200
baseline = read(WORK / 'baseline-files.json')
changed = sorted(name for name, original in baseline.items()
                 if not (ROOT / name).is_file() or digest(ROOT / name) != original['sha256'])
assert set(changed) == set(state['changed_files_this_round']) | set(state.get('generated_build_files', [])), changed
history = read(WORK / 'historical-files.json')
assert all(digest(ROOT / name) == checksum for name, checksum in history.items())
for row in state['preserved_models'] + state['preserved_data']:
    path = Path(row['path'])
    assert digest(path if path.is_absolute() else ROOT / path) == row['sha256'], path
modules = sorted((ROOT / 'src/embodiedforge').rglob('*.py'))
before_bytes = after_bytes = 0
for path in modules:
    relative = path.relative_to(ROOT)
    assert digest(path) == digest(WORK / 'candidate' / relative), path
    old = WORK / 'baseline' / relative
    assert declarations(ast.parse(path.read_text())) == declarations(ast.parse(old.read_text())), path
    before_bytes += old.stat().st_size
    after_bytes += path.stat().st_size
after_lines = sum(len(path.read_text().splitlines()) for path in modules)
state['metrics'] = {'modules_before': state['baseline_modules'], 'modules_after': len(modules),
                    'source_lines_before': state['baseline_source_lines'], 'source_lines_after': after_lines,
                    'source_lines_delta': after_lines - state['baseline_source_lines'],
                    'source_bytes_before': before_bytes, 'source_bytes_after': after_bytes,
                    'source_bytes_delta': after_bytes - before_bytes,
                    'interpretation': 'Five full-array validation calls reuse existing bounded validators; production module/function count is unchanged.'}
graph_tools = runpy.run_path(str(ROOT / 'tests/test_architecture.py'))
graph = graph_tools['GRAPH']
assert not graph_tools['cycles'](graph)
state['validation']['architecture'] = {'modules': len(graph), 'explicit_import_edges': sum(map(len, graph.values())),
                                      'cycles': [], 'production_declarations_and_signatures_retained': True,
                                      'scope': 'Explicit imports and existing declaration signatures, including methods and directly nested definitions.'}
jobs = []
for job in state['workflow_jobs']:
    summary = read(Path(job['summary']))
    assert not summary['failures']
    observed_path = Path(job['supervisor']) / 'result.json'
    observed = read(observed_path) if observed_path.exists() else None
    samples = [json.loads(line) for line in (Path(job['summary']).parent / 'samples.jsonl').read_text().splitlines()]
    resources = {'samples': len(samples), 'fds_observed': sorted({row['fds'] for row in samples}),
                 'rss_min_kib': min(row['rss_kib'] for row in samples), 'rss_max_kib': max(row['rss_kib'] for row in samples)}
    jobs.append({'name': job['name'], 'summary': summary, 'supervisor': observed, 'resources': resources})
    if args.final:
        assert summary['status'] == 'complete' and summary['seconds'] >= job['requested_seconds']
        assert summary['counts']['compact_cycles'] > 0 and summary['counts']['transition_cycles'] > 0
        assert summary['counts']['invalid_marker_rejections_per_side'] > 0
        assert summary['counts']['large_validation_cycles'] > 0 and summary['counts']['rejected_transitions_per_side'] > 0
        assert observed['completed_successfully'] and observed['exit_observed'] and observed['process_returncode'] == 0
        assert not observed['timed_out'] and not observed['forced_stop'] and observed['supervisor_signal'] is None
        assert state['validation']['workflow_tool_exits'][job['name']] == 0
state['validation']['workflow_sustained'] = jobs
if args.final:
    for name in ['baseline-targets', 'candidate-targets', 'candidate-full', 'source-release-targets', 'candidate-numpy126-targets']:
        assert state['validation'][name]['failures'] == state['validation'][name]['errors'] == 0
        assert state['validation'][name]['tool_exit'] == 0
    assert state['validation']['release']['status'] == 'passed'
    assert read(WORK / 'monitor-result.json')['status'] == 'complete'
    assert state['validation']['monitor_tool_exit'] == 0
    state.update(status='complete', finished_at=now.isoformat())
state['preservation'] = {'checked_at': now.isoformat(), 'baseline_files_checked': len(baseline),
                         'expected_changed_files': changed, 'unexpected_changes': [],
                         'historical_files_unchanged': len(history),
                         'models_and_registry': len(state['preserved_models']), 'reference_data_files': len(state['preserved_data']),
                         'frozen_production_source_matches': True}
state['limits'] = [
    'Allocation measurements isolate validation scratch; they do not include already-retained input/pending payloads, output copies, whole-recorder RSS or training memory.',
    'The actual recorder rejection benchmark uses a synthetic 48 MiB uint8 image and first/middle/last continuity errors before snapshot copying. Required owned copies are retained.',
    'Finite-check measurements execute expressions extracted from the four production sites on 64 MiB float32 arrays, separately from archive decode or writer snapshot allocation.',
    'Two NumPy environments each run real CPU recording, reading, window generation and paired evaluation with periodic >4M-element discontinuities and successful retries. This does not evaluate learned robot skill quality.',
    'Only changed baseline modules are loaded alongside unchanged shared dependencies; all production code is separately frozen and checked.',
    'Overlapping test suites are reported separately. Optional SDK dependencies are skipped by the main suite.',
    'The private structural-audit selector was corrected to exclude an unchanged reader call; production code needed no correction.',
    'Existing checkpoints, reference datasets, task/training parameters and dependency versions are retained.',
]
state.update(elapsed_seconds=elapsed, last_updated_at=now.isoformat())
for path in [WORK / 'state.json', ROOT / 'runs' / STEM / 'optimization.json', ROOT / 'docs/experiments' / (STEM + '.json')]:
    path.write_text(json.dumps(state, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
print(json.dumps({'status': state['status'], 'elapsed_minutes': elapsed / 60,
                  'metrics': state['metrics'], 'history_preserved': len(history),
                  'workflows': [{'name': row['name'], 'minutes': row['summary']['seconds'] / 60,
                                 'cycles': row['summary']['cycles'], 'status': row['summary']['status']} for row in jobs]}, indent=2))
