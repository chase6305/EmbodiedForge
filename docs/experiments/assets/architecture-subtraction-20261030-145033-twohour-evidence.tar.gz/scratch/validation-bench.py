"""Validation scratch, not retained payloads or whole-recording memory."""
import argparse
import ast
import hashlib
import json
import statistics
import tempfile
import time
import tracemalloc
from pathlib import Path

import numpy as np

import embodiedforge.data as data
from embodiedforge import Config, VectorEnv

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()


def measure(function):
    times = []
    for _ in range(7):
        began = time.perf_counter()
        result = function()
        times.append(time.perf_counter() - began)
    tracemalloc.start()
    result = function()
    peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    return {'seconds': times, 'median_seconds': statistics.median(times),
            'peak_traced_bytes': peak, 'result': result}


results = []
with tempfile.TemporaryDirectory(prefix='ef-validation-bench-') as temporary:
    with VectorEnv(Config(num_envs=1, max_steps=3)) as env:
        with data.EpisodeRecorder(Path(temporary) / 'recording', env,
                                  max_buffer_bytes=512 * 1024**2) as writer:
            observation = env.observe()
            first = env.step(np.zeros((1, 2)))
            shape = (1, 4, 2048, 2048, 3)
            observation['large_image'] = np.zeros(shape, dtype=np.uint8)
            first.observation['large_image'] = np.zeros(shape, dtype=np.uint8)
            writer.append(observation, first)
            second = env.step(np.zeros((1, 2)))
            second.observation['large_image'] = np.zeros(shape, dtype=np.uint8)
            broken = dict(first.observation)
            broken['large_image'] = np.zeros(shape, dtype=np.uint8)
            retained = writer.buffered_bytes
            for name, index in [('first', (0, 0, 0, 0, 0)), ('middle', (0, 2, 0, 0, 0)), ('last', (0, -1, -1, -1, -1))]:
                broken['large_image'][index] = 1
                def reject():
                    try:
                        writer._prepare(broken, second)
                    except ValueError as error:
                        assert 'continuity broken' in str(error).lower()
                        assert writer.buffered_bytes == retained and len(next(iter(writer.pending.values()))) == 1
                        return type(error).__name__
                    raise AssertionError('discontinuous input was accepted')
                results.append({'operation': 'real recorder rejected continuity', 'damage': name,
                                'image_bytes_per_env': broken['large_image'][0].nbytes,
                                **measure(reject)})
                broken['large_image'][index] = 0

# Extract the finite checks from their actual production call sites. This
# isolates validation scratch from the required snapshot/decode payloads.
tree = ast.parse(Path(data.__file__).read_text())
for owner_name, fields in [('_prepare', ['action', 'result.reward']), ('_load_episode', ["data['action']", "data['reward']"])]:
    owner = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == owner_name)
    checks = []
    for node in ast.walk(owner):
        if not isinstance(node, ast.Call):
            continue
        if isinstance(node.func, ast.Name) and node.func.id == '_all_finite':
            checks.append((ast.unparse(node.args[0]), node))
        elif isinstance(node.func, ast.Attribute) and node.func.attr == 'all' and isinstance(node.func.value, ast.Call):
            call = node.func.value
            if isinstance(call.func, ast.Attribute) and call.func.attr == 'isfinite':
                checks.append((ast.unparse(call.args[0]), node))
    wanted = {ast.dump(ast.parse(field, mode='eval').body, include_attributes=False) for field in fields}
    for text, node in checks:
        parsed = ast.parse(text, mode='eval').body
        if ast.dump(parsed, include_attributes=False) not in wanted:
            continue
        code = compile(ast.fix_missing_locations(ast.Expression(body=node)), str(data.__file__), 'eval')
        values = np.ones((2, 8 * 1024 * 1024), dtype=np.float32)
        namespace = {**vars(data), 'action': values,
                     'result': type('Result', (), {'reward': values})(),
                     'data': {'action': values, 'reward': values}}
        for damage in ['finite', 'last_nan']:
            if damage == 'last_nan':
                values[-1, -1] = np.nan
            def validate():
                actual = bool(eval(code, namespace))
                assert actual == (damage == 'finite')
                return actual
            results.append({'operation': 'extracted finite check', 'owner': owner_name,
                            'field': text, 'damage': damage, 'input_bytes': values.nbytes,
                            **measure(validate)})
report = {'status': 'measured', 'scope': __doc__, 'source': data.__file__,
          'source_sha256': hashlib.sha256(Path(data.__file__).read_bytes()).hexdigest(),
          'numpy': np.__version__, 'results': results,
          'limits': 'Recorder rejection uses a real pending episode with a synthetic 48 MiB uint8 image. Finite-check measurements isolate the actual production expressions on 64 MiB float32 input; required snapshots and archive decode are excluded. Traced peaks are not RSS.'}
args.output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
