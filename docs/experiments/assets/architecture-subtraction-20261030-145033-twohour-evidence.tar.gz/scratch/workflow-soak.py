"""Compare real recording, compact/transitions reads, windows and paired evaluation."""
import argparse
import ast
import gc
import hashlib
import importlib.util
import json
import os
import sys
import tempfile
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from embodiedforge import Config, VectorEnv
from embodiedforge.tasks import ReachTask

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--baseline', type=Path, required=True)
parser.add_argument('--candidate', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--seconds', type=float, required=True)
args = parser.parse_args()
args.output.mkdir(parents=True)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


modules = {}
watched = {}
for side, root in [('baseline', args.baseline), ('candidate', args.candidate)]:
    modules[side] = {}
    for name in ['data', 'rollout']:
        path = root / 'src/embodiedforge' / (name + '.py')
        modules[side][name] = load('embodiedforge._subtraction_' + side + '_' + name, path)
        watched[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()


def array_hash(arrays):
    digest = hashlib.sha256()
    for name, value in arrays.items():
        digest.update(f'{name}:{value.dtype}:{value.shape}:'.encode())
        digest.update(value.tobytes())
    return digest.hexdigest()


def side_run(side, root, seed, compact, workers, verify, projected):
    data, rollout = modules[side]['data'], modules[side]['rollout']
    large = seed % 19 == 0
    count = 1 if large else [1, 2, 3][seed % 3]
    steps = 3 if large else [1, 3, 5][(seed // 3) % 3]
    workers = 0 if large else workers
    channels = ('rgb', 'depth') if seed % 2 else ()
    config = Config(num_envs=count, max_steps=steps, seed=seed, render='raster', channels=channels, image_size=16)
    def act(observation):
        ids = observation['env_id'].astype(np.float32)
        return np.stack([np.sin(ids + seed) * .2, np.cos(ids + seed) * .2], axis=-1)
    class LargeTask(ReachTask):
        def observe(self, state):
            observation = super().observe(state)
            image = np.zeros((len(state.time), 2051, 2048), dtype=np.uint8)
            observation['large_numeric'] = image[:, :, ::-1] if seed % 2 else image
            return observation

        def evaluate(self, state, actions, previous):
            reward, _, _ = super().evaluate(state, actions, previous)
            return reward, np.zeros(count, bool), np.zeros(count, bool)

    rejected_transitions = 0
    with VectorEnv(config, task=LargeTask() if large else None) as env:
        policy = rollout.DemonstrationPolicy(act)
        with data.EpisodeRecorder(root, env, episode_format='compact' if compact else 'transitions',
                                  write_workers=workers, verify_archive=True) as writer:
            class CheckedWriter:
                def append(self, observation, result):
                    nonlocal rejected_transitions
                    if large and observation['step_id'].min() > 0:
                        broken = dict(observation)
                        image = observation['large_numeric'].copy(order='K')
                        if seed % 2:
                            image = image[:, :, ::-1]
                        image[-1, -1, -1] ^= 1
                        broken['large_numeric'] = image
                        before = writer.buffered_bytes
                        lengths = {key: len(rows) for key, rows in writer.pending.items()}
                        try:
                            writer.append(broken, result)
                        except ValueError as error:
                            assert 'continuity broken' in str(error).lower()
                        else:
                            raise AssertionError('discontinuous image accepted')
                        assert writer.buffered_bytes == before and writer.failure is None
                        assert {key: len(rows) for key, rows in writer.pending.items()} == lengths
                        rejected_transitions += 1
                    writer.append(observation, result)
            summary = rollout.run_rollout(env, policy, steps=steps * 2, writer=CheckedWriter())
        evaluated = rollout.run_episode_batch(env, policy)
    options = data.EpisodeReadOptions(verify_archive=verify, observation_keys=() if projected else None)
    episode_digests, episodes, transitions = [], 0, 0
    for episode in data.read_episodes(root, options=options):
        assert all(value.flags.owndata for value in episode.values())
        for key in episode:
            if key.startswith('obs/'):
                assert not np.shares_memory(episode[key], episode['next/' + key[4:]])
        episode_digests.append((tuple(episode), array_hash(episode)))
        episodes += 1
        transitions += len(episode['action'])
    windows = []
    for window in data.action_windows(root, history=1, horizon=1, options=options):
        assert window['action'].flags.owndata
        assert all(value.flags.owndata for value in window['observation'].values())
        windows.append((array_hash(window['observation']), array_hash({'action': window['action']}), window['instruction']))
    # A malformed marker must fail before a successful episode can be returned.
    rejected = None
    if seed % 17 == 0:
        marker = sorted(root.glob('env*.json'))[0]
        metadata = json.loads(marker.read_text())
        metadata['steps'] += 1
        marker.write_text(json.dumps(metadata))
        try:
            list(data.read_episodes(root, options=options))
        except ValueError as error:
            rejected = (type(error).__name__, str(error).replace(str(root), '<dataset>'))
        assert rejected is not None
    return {
        'rollout': vars(summary), 'evaluation': {
            'arrays': array_hash({name: getattr(evaluated, name) for name in ['success', 'returns', 'lengths']}),
            'initial_observation_sha256': evaluated.initial_observation_sha256,
        },
        'episode_digests': episode_digests, 'windows': windows, 'episodes': episodes,
        'transitions': transitions, 'rejected': rejected,
        'large_validation': large, 'rejected_transitions': rejected_transitions,
    }


counts = Counter()
started = time.monotonic()
began = datetime.now(timezone.utc).isoformat()
cycles, failures = 0, []


def sample(status):
    values = dict(line.split(':', 1) for line in Path('/proc/self/status').read_text().splitlines() if ':' in line)
    row = {'time': datetime.now(timezone.utc).isoformat(), 'seconds': time.monotonic() - started,
           'cycles': cycles, 'rss_kib': int(values['VmRSS'].split()[0]), 'fds': len(os.listdir('/proc/self/fd'))}
    with (args.output / 'samples.jsonl').open('a') as stream:
        stream.write(json.dumps(row) + '\n')
    report = {'status': status, 'scope': __doc__, 'started_at': began, 'requested_seconds': args.seconds,
              'seconds': row['seconds'], 'cycles': cycles, 'counts': dict(counts), 'last_sample': row,
              'source_hashes': watched, 'failures': failures, 'numpy': np.__version__, 'python': sys.version,
              'limits': 'Real deterministic CPU VectorEnv and local NPZ workflows with small raster images plus periodic >4M-element continuity failures/retries; no trained robot actor or training-throughput claim. Changed baseline modules loaded alongside unchanged shared dependencies.'}
    temporary = args.output / 'summary.tmp'
    temporary.write_text(json.dumps(report, indent=2) + '\n')
    temporary.replace(args.output / 'summary.json')
    print(json.dumps(row), flush=True)


try:
    last_sample = 0
    while cycles == 0 or time.monotonic() - started < args.seconds:
        seed = cycles + 114
        compact, workers, verify, projected = bool(cycles % 2), 2 if cycles % 3 else 0, bool(cycles % 5), bool((cycles // 2) % 2)
        with tempfile.TemporaryDirectory(prefix='ef-workflow-parity-') as directory:
            root = Path(directory)
            before = side_run('baseline', root / 'before', seed, compact, workers, verify, projected)
            after = side_run('candidate', root / 'after', seed, compact, workers, verify, projected)
            assert before == after, f'workflow mismatch in cycle {cycles}'
        counts['episodes_per_side'] += before['episodes']
        counts['transitions_per_side'] += before['transitions']
        counts['windows_per_side'] += len(before['windows'])
        counts['paired_evaluations'] += 1
        counts['compact_cycles' if compact else 'transition_cycles'] += 1
        counts['large_validation_cycles'] += int(before['large_validation'])
        counts['rejected_transitions_per_side'] += before['rejected_transitions']
        if before['rejected'] is not None:
            counts['invalid_marker_rejections_per_side'] += 1
        cycles += 1
        if time.monotonic() - last_sample >= 30:
            gc.collect()
            sample('running')
            last_sample = time.monotonic()
        time.sleep(.2)
    assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest for path, digest in watched.items())
    sample('complete')
except BaseException as error:
    failures.append({'type': type(error).__name__, 'error': str(error)})
    sample('failed')
    raise
