import hashlib
import json
import shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path

root = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
work = Path('/tmp/embodiedforge-subtraction-20261030-145033-twohour')
prior = root / 'docs/experiments/architecture-subtraction-20261030-124341-twohour.json'
previous = json.loads(prior.read_text())
started = datetime.fromtimestamp(1793371833, timezone.utc)


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


names = set(json.loads(Path('/tmp/embodiedforge-subtraction-20261030-124341-twohour/baseline-files.json').read_text()))
for directory in ['src/embodiedforge', 'tests', 'benchmarks']:
    names.update(p.relative_to(root).as_posix() for p in (root / directory).rglob('*')
                 if p.is_file() and not {'__pycache__', '.pytest_cache'} & set(p.parts) and p.suffix != '.pyc')
baseline = {}
for name in sorted(names):
    source = root / name
    if not source.is_file():
        continue
    destination = work / 'baseline' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    baseline[name] = {'sha256': digest(source), 'bytes': source.stat().st_size}
history = {p.relative_to(root).as_posix(): digest(p) for p in (root / 'docs/experiments').rglob('*') if p.is_file()}
for row in previous['preserved_models'] + previous['preserved_data']:
    p = Path(row['path'])
    assert digest(p if p.is_absolute() else root / p) == row['sha256'], p
modules = sorted((root / 'src/embodiedforge').rglob('*.py'))
state = {
    'status': 'running',
    'objective': 'Two-hour subtraction across runtime, data and training boundaries; preserve behavior and existing work.',
    'started_at': started.isoformat(), 'deadline': (started + timedelta(hours=2)).isoformat(),
    'scratch': str(work), 'baseline_modules': len(modules),
    'baseline_source_lines': sum(len(p.read_text().splitlines()) for p in modules),
    'baseline_files': len(baseline), 'historical_files': len(history),
    'changed_files_this_round': [], 'changes': [], 'audit_decisions': [], 'validation': {},
    'preserved_models': previous['preserved_models'], 'preserved_data': previous['preserved_data'],
}
for name, value in [('baseline-files.json', baseline), ('historical-files.json', history), ('state.json', state)]:
    (work / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
run = root / 'runs/architecture-subtraction-20261030-145033-twohour'
run.mkdir(parents=True)
(run / 'optimization.json').write_text(json.dumps(state, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: state[k] for k in ['started_at', 'deadline', 'baseline_modules', 'baseline_source_lines', 'baseline_files', 'historical_files']}, indent=2))
