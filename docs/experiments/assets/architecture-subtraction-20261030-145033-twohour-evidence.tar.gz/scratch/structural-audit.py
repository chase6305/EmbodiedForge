"""Verify the complete production edit consists of five validator reuses."""
import ast
import copy
import hashlib
import json
from pathlib import Path

root = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
work = Path('/tmp/embodiedforge-subtraction-20261030-145033-twohour')
relative = Path('src/embodiedforge/data.py')
before = ast.parse((work / 'baseline' / relative).read_text())
after = ast.parse((root / relative).read_text())
counts = {'finite': 0, 'equal': 0}


class Expand(ast.NodeTransformer):
    def visit_FunctionDef(self, node):
        if node.name not in {'_prepare', '_load_episode'}:
            return self.generic_visit(node)
        class Calls(ast.NodeTransformer):
            def visit_Call(self, call):
                if isinstance(call.func, ast.Name) and call.func.id == '_all_finite':
                    assert len(call.args) == 1 and not call.keywords
                    counts['finite'] += 1
                    return ast.Call(func=ast.Attribute(value=ast.Call(func=ast.Attribute(value=ast.Name(id='np', ctx=ast.Load()), attr='isfinite', ctx=ast.Load()), args=call.args, keywords=[]), attr='all', ctx=ast.Load()), args=[], keywords=[])
                if node.name == '_prepare' and isinstance(call.func, ast.Name) and call.func.id == '_array_equal':
                    counts['equal'] += 1
                    call.func = ast.Attribute(value=ast.Name(id='np', ctx=ast.Load()), attr='array_equal', ctx=ast.Load())
                return self.generic_visit(call)
        return Calls().visit(node)


expanded = Expand().visit(copy.deepcopy(after))
assert counts == {'finite': 4, 'equal': 1}, counts
assert ast.dump(before, include_attributes=False) == ast.dump(expanded, include_attributes=False)
result = {'status': 'passed', 'validator_call_sites_reused': counts,
          'entire_module_ast_identical_after_expanding_five_calls': True,
          'new_production_modules': 0, 'new_production_functions': 0,
          'existing_validator_bodies_unchanged': True,
          'source_sha256': hashlib.sha256((root / relative).read_bytes()).hexdigest()}
(work / 'structural-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
