"""Fixed-budget evaluation over the shared borrowed CPU environment contract."""

from collections.abc import Callable
from dataclasses import dataclass

import numpy as np

from embodiedforge.core import Array, Observation

from .base import BatchEnvironment, TransitionWriter
from .observations import replace_reset_rows
from .specs import validate_environment_spec


@dataclass(frozen=True)
class EvaluationSummary:
    """Only complete episodes contribute to episode-return and success metrics."""

    transitions: int
    completed_episodes: int
    terminated_episodes: int
    truncated_episodes: int
    mean_step_reward: float
    mean_episode_return: float | None
    success_rate: float | None


def evaluate_policy(
    env: BatchEnvironment,
    action_fn: Callable[[Observation], Array],
    *,
    steps: int,
    writer: TransitionWriter | None = None,
    on_reset: Callable[[Array], None] | None = None,
) -> EvaluationSummary:
    """Start fresh episodes, record final observations, and explicitly reset done.

    action_fn receives all rows and returns one [N,A] action batch. The caller
    owns policy state and may clear history through on_reset. Resources and
    reseeding stay with the caller. A sink must copy retained arrays before
    returning; it receives post-action transitions before any reset occurs.
    """
    if type(steps) is not int or steps <= 0:
        raise ValueError("Evaluation steps must be a positive integer")
    spec = env.spec
    validate_environment_spec(spec)
    count = spec["num_envs"]
    observation = env.reset()
    if on_reset is not None:
        on_reset(np.arange(count, dtype=np.int64))
    returns = np.zeros(count, dtype=np.float64)
    completed = terminated = truncated = successes = success_episodes = 0
    reward_sum = episode_return_sum = 0.0
    for index in range(steps):
        result = env.step(action_fn(observation))
        if (
            not isinstance(result.reward, np.ndarray)
            or result.reward.shape != (count,)
            or result.reward.dtype.kind not in "fiu"
            or not np.isfinite(result.reward).all()
        ):
            raise ValueError("Evaluation reward must be finite numeric[N]")
        if any(
            not isinstance(value, np.ndarray)
            or value.shape != (count,)
            or value.dtype != bool
            for value in (result.terminated, result.truncated)
        ):
            raise ValueError("Evaluation done flags must be boolean[N]")
        if np.any(result.terminated & result.truncated):
            raise ValueError("Evaluation transition cannot be terminated and truncated")
        success = result.info.get("success")
        if "success" in result.info and (
            not isinstance(success, np.ndarray)
            or success.shape != (count,)
            or success.dtype != bool
        ):
            raise ValueError("Evaluation success flags must be boolean[N]")
        if writer is not None:
            writer.append(observation, result)
        done = result.terminated | result.truncated
        returns += result.reward
        reward_sum += float(np.sum(result.reward, dtype=np.float64))
        completed += int(done.sum())
        terminated += int(result.terminated.sum())
        truncated += int((result.truncated & ~result.terminated).sum())
        episode_return_sum += float(returns[done].sum())
        if success is not None:
            success_episodes += int(done.sum())
            successes += int((success & done).sum())
        observation = result.observation
        if done.any() and index + 1 < steps:
            ids = np.flatnonzero(done)
            selected = env.reset(ids)
            # Never mutate a terminal observation already delivered to a sink.
            if selected.keys() != observation.keys():
                raise ValueError("Reset observation fields differ from step fields")
            for name, value in observation.items():
                reset = selected[name]
                if (
                    reset.shape != (len(ids), *value.shape[1:])
                    or reset.dtype != value.dtype
                ):
                    raise ValueError(
                        "Reset observation shape/dtype differs from step fields"
                    )
            observation = replace_reset_rows(observation, selected, ids)
            returns[ids] = 0
            if on_reset is not None:
                on_reset(ids.copy())
    return EvaluationSummary(
        transitions=steps * count,
        completed_episodes=completed,
        terminated_episodes=terminated,
        truncated_episodes=truncated,
        mean_step_reward=reward_sum / (steps * count),
        mean_episode_return=episode_return_sum / completed if completed else None,
        success_rate=successes / success_episodes if success_episodes else None,
    )
