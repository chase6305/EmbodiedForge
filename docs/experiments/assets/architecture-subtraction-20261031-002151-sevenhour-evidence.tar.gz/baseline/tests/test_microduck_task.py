"""Local task helpers and anatomical randomization selection in the real SDK."""

import re
from types import SimpleNamespace

import pytest

pytest.importorskip("mjlab")
torch = pytest.importorskip("torch")
mujoco = pytest.importorskip("mujoco")

from embodiedforge.locomotion.microduck.robot.microduck_constants import (  # noqa: E402
    MICRODUCK_WALK_XML,
)
from embodiedforge.locomotion.microduck.tasks import mdp  # noqa: E402
from embodiedforge.locomotion.microduck.tasks.microduck_velocity_env_cfg import (  # noqa: E402
    make_microduck_velocity_env_cfg,
)


@pytest.mark.parametrize("dtype", [torch.float32, torch.float64])
def test_relative_height_terrain_offsets_nonfinite_values_and_gradients(dtype):
    positions = torch.tensor(
        [
            [1, 2, 0.5],
            [1, 2, -0.5],
            [1, 2, float("nan")],
            [1, 2, float("inf")],
            [1, 2, -float("inf")],
        ],
        dtype=dtype,
        requires_grad=True,
    )
    origins = torch.tensor(
        [[0, 0, 0.25], [0, 0, -0.75], [0, 0, 0], [0, 0, 0], [0, 0, 0]],
        dtype=dtype,
        requires_grad=True,
    )
    env = SimpleNamespace(
        scene=SimpleNamespace(terrain=SimpleNamespace(env_origins=origins))
    )
    asset = SimpleNamespace(data=SimpleNamespace(root_link_pos_w=positions))
    height = mdp._relative_root_height(env, asset)
    limit = torch.finfo(dtype).max
    torch.testing.assert_close(
        height,
        torch.tensor([0.25, 0.25, 0, limit, -limit], dtype=dtype),
        rtol=0,
        atol=0,
    )
    position_grad, origin_grad = torch.autograd.grad(height.sum(), (positions, origins))
    expected_grad = torch.zeros_like(positions)
    expected_grad[:2, 2] = 1
    torch.testing.assert_close(position_grad, expected_grad, rtol=0, atol=0)
    torch.testing.assert_close(origin_grad, -expected_grad, rtol=0, atol=0)


@pytest.mark.parametrize("dtype", [torch.float32, torch.float64])
@pytest.mark.parametrize("overrides", [None, {}, {0: 0.75, -1: -0.25}])
def test_pose_override_keeps_default_storage_and_unmodified_joint_gradients(
    dtype, overrides
):
    default = (
        torch.arange(24, dtype=dtype).reshape(4, 6)[:, ::2].detach().requires_grad_()
    )
    original = default.detach().clone()
    pose = mdp._pose_override(default, overrides)
    expected = original.clone()
    expected_gradient = torch.ones_like(default)
    if overrides:
        expected[:, 0] = 0.75
        expected[:, -1] = -0.25
        expected_gradient[:, [0, -1]] = 0
    torch.testing.assert_close(pose, expected, rtol=0, atol=0)
    (gradient,) = torch.autograd.grad(pose.sum(), default)
    torch.testing.assert_close(gradient, expected_gradient, rtol=0, atol=0)
    with torch.no_grad():
        pose.fill_(-99)
    torch.testing.assert_close(default, original, rtol=0, atol=0)


def test_pose_override_preserves_tensor_override_gradient():
    default = torch.zeros((3, 4), dtype=torch.float64, requires_grad=True)
    value = torch.tensor(0.5, dtype=default.dtype, requires_grad=True)
    pose = mdp._pose_override(default, {2: value})
    default_gradient, value_gradient = torch.autograd.grad(pose.sum(), (default, value))
    torch.testing.assert_close(value_gradient, torch.tensor(3.0, dtype=default.dtype))
    assert torch.count_nonzero(default_gradient[:, 2]) == 0
    assert torch.count_nonzero(default.detach()) == 0


@pytest.mark.parametrize("blend", [mdp.crouch_pose_blend, mdp.phase_pose_blend])
def test_pose_phase_boundaries_values_and_gradients(blend):
    phase = torch.tensor(
        [0.0, 0.1, 0.2, 0.3, 0.5, 0.65, 0.8, 1.0],
        dtype=torch.float64,
        requires_grad=True,
    )
    # A strided phase view exercises the same batched helper used by rewards.
    result = blend(phase.reshape(2, 4).T, 0.2, 0.5, 0.8)
    expected = torch.tensor([0, 0.5, 1, 1, 1, 0.5, 0, 0], dtype=phase.dtype)
    torch.testing.assert_close(result.T.flatten(), expected)
    (gradient,) = torch.autograd.grad(result.sum(), phase)
    torch.testing.assert_close(
        gradient,
        torch.tensor([5, 5, 0, 0, -10 / 3, -10 / 3, 0, 0], dtype=phase.dtype),
    )


@pytest.mark.parametrize("dtype", [torch.float32, torch.float64])
def test_reset_quaternion_axes_and_gradients(dtype):
    angles = torch.zeros((4, 3), dtype=dtype)
    angles[1:, :] = torch.eye(3, dtype=dtype) * (torch.pi / 2)
    roll, pitch, yaw = angles.unbind(dim=1)  # Noncontiguous batch columns.
    quat = mdp._quat_from_roll_pitch(
        roll, pitch, torch.cos(yaw * 0.5), torch.sin(yaw * 0.5)
    )
    half = 2**-0.5
    expected = torch.tensor(
        [[1, 0, 0, 0], [half, half, 0, 0], [half, 0, half, 0], [half, 0, 0, half]],
        dtype=dtype,
    )
    torch.testing.assert_close(quat, expected)
    if dtype == torch.float64:
        mixed = torch.tensor([0.2, -0.6, 1.1], dtype=dtype, requires_grad=True)
        assert torch.autograd.gradcheck(
            lambda a: mdp._quat_from_roll_pitch(
                a[0:1], a[1:2], torch.cos(a[2:3] * 0.5), torch.sin(a[2:3] * 0.5)
            ),
            (mixed,),
        )


@pytest.mark.parametrize("reward", [mdp.phase_pose_track, mdp.phase_pose_track_l1])
def test_phase_pose_uses_named_joints_and_preserves_default_pose(reward):
    positions = torch.tensor([[0.3, 99.0, 0.2], [-0.2, 77.0, 1.0]])
    defaults = torch.tensor([[0.1, 0.0, 0.2], [0.4, 0.0, 0.6]])
    original = defaults.clone()
    indices = {"left": 0, "passive": 1, "right": 2}
    asset = SimpleNamespace(
        data=SimpleNamespace(joint_pos=positions, default_joint_pos=defaults),
        find_joints=lambda names: ([indices[n] for n in names], names),
    )
    env = SimpleNamespace(
        device="cpu",
        scene={"robot": asset},
        command_manager=SimpleNamespace(
            get_command=lambda _: torch.tensor([[1.0, 0.0, 0.0], [-1.0, 0.0, 0.0]])
        ),
    )
    result = reward(
        env, target_pose={"right": 1.0, "left": -0.2}, source_pose={"left": 0.3}
    )
    expected = torch.ones(2) if reward is mdp.phase_pose_track else torch.zeros(2)
    torch.testing.assert_close(result, expected)
    torch.testing.assert_close(defaults, original, rtol=0, atol=0)
    with pytest.raises(ValueError, match="non-empty target_pose"):
        reward(env)


def test_head_randomization_selects_only_head_subtree():
    model = mujoco.MjModel.from_xml_path(str(MICRODUCK_WALK_XML))
    cfg = make_microduck_velocity_env_cfg()
    selection = cfg.events["randomize_head_com"].params["asset_cfg"].body_names
    neck = model.body("neck").id
    selected = set()
    for pattern in selection:
        matches = {
            i for i in range(model.nbody) if re.fullmatch(pattern, model.body(i).name)
        }
        assert matches, f"Head body pattern matches nothing: {pattern}"
        selected.update(matches)
    assert len(selected) == 4
    for body in selected:
        ancestor = body
        while ancestor and ancestor != neck:
            ancestor = int(model.body_parentid[ancestor])
        assert ancestor == neck, f"{model.body(body).name} is outside the head subtree"
    assert model.body("bearing_roll").id not in selected


def test_pose_match_preserves_effective_positional_and_keyword_interface():
    positions = torch.tensor([[0.0, 0.5, 1.0], [0.0, 0.25, 0.5]])
    asset = SimpleNamespace(
        data=SimpleNamespace(
            joint_pos=positions,
            default_joint_pos=torch.zeros_like(positions),
        ),
        find_joints=lambda pattern: ([0, 1, 2], ["left", "middle", "right"]),
    )
    env = SimpleNamespace(scene={"robot": asset})
    overrides = {2: 0.75}
    entity = mdp.SceneEntityCfg("robot")
    expected = torch.exp(
        -(((positions[:, [1, 2]] - torch.tensor([0, 0.75])) / 0.2) ** 2)
    ).mean(-1)
    torch.testing.assert_close(
        mdp.pose_target_match(env, overrides, entity, 0.2, [1, 2]), expected
    )
    torch.testing.assert_close(
        mdp.pose_target_match(
            env,
            target_overrides=overrides,
            asset_cfg=entity,
            std=0.2,
            joint_indices=[1, 2],
        ),
        expected,
    )
