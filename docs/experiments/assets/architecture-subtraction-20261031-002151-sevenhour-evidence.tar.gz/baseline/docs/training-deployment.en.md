# Training and deployment commands

[简体中文](training-deployment.md) | **English** · [Back to README](../README.en.md)

Choose the section for your task; installing every SDK is unnecessary. Run commands from the EmbodiedForge repository root. Replace `/path/to/...` with local paths and use nonexistent paths for new output directories or exported files. Example budgets reproduce workflows without promising behavioral acceptance.

[Environment setup](#setup) · [Core PPO](#core) · [Go1](#go1) · [Microduck](#microduck) · [H1](#h1) · [Wuji](#wuji) · [GMR / SONIC (Chinese)](humanoid-motion.md) · [Weave (Chinese)](weave-reference.md) · [RLinf (Chinese)](rlinf.md) · [MPC / CEM](#solvers) · [Web serving and remote access](#serving) · [Wheel deployment](#package) · [Artifacts and limits](#artifacts)

| Task | Training / solver runtime | Available execution or export |
| --- | --- | --- |
| `reach` / `hold` | Project-owned VectorEnv + CPU PPO; NumPy, MuJoCo, or other physics backends | Headless checkpoint evaluation and recording |
| Go1 | Project-owned Go1 environment + PPO; CPU MuJoCo/mjbatch via installed packages or a pinned SDK | Shared Web live policy and motion replay |
| Microduck | Repository-owned flat walking task/assets; mjlab CUDA PPO | Native / Viser policy execution, ONNX export and comparison |
| Native H1 | Project-owned MuJoCo/mjbatch CPU PPO; no IsaacLab | Fixed-command evaluation and shared Web motion replay |
| H1 | External IsaacLab environment + RSL-RL; Newton / MuJoCo-Warp GPU physics | Fixed-command evaluation, offline HTML / Web motion replay |
| Wuji / Wuji Light | External Wuji/UniLab environment and training stack; GPU PPO | Sequential trial evaluation and video recording |
| [GMR / SONIC X2](humanoid-motion.md) | External GMR BVH retargeting and SONIC ONNX tracking | Headless reference generation / MuJoCo evaluation; these entries do not train policies |
| [Weave / G1 HOI](weave-reference.md) | Pinned external Weave / IsaacLab SDK; motion-conditioned PPO | Training/resume, per-clip evaluation and policy export; full simulation remains unvalidated |
| [RLinf / PickCube](rlinf.md) | Pinned external RLinf / ManiSkill SDK; single-node, single-GPU MLP SAC | Headless training, full-state resume, simulation evaluation, CPU ONNX export and closed-loop evaluation; GPU training, checkpoint recovery and evaluation validated on PickCube |
| Cartpole / arm throwing | External mjbatch examples, adapted CPU MPC / CEM | Solver metrics and trajectories |

Deployment here means running policies in simulation, serving viewers, and exporting models. There is currently no unified hardware deployment command or generic Go1/H1 ONNX export entry point.

ONNX evaluation serves different purposes across entry points. [Microduck's `evaluate --onnx`](microduck.md) also needs a checkpoint and compares actions on live observations while PyTorch drives the simulation. [RLinf's `evaluate --onnx`](rlinf.md) loads the exported policy alone and uses CPU ONNX actions to drive PickCube. [SONIC's `evaluate`](humanoid-motion.md) drives X2 MuJoCo using the pinned bundle's pretrained ONNX model and its matching control parameters.

The [humanoid integration study (Chinese)](experiments/humanoid-integration-study-20260928.md) covers GMR reference replay and SONIC model sizes, control presets and force ablations.

The [2026-09-28 restart study (Chinese)](experiments/rl-resume-study-20260928.md) provides RLinf training, full-state restart, and ONNX evaluation commands, with results for both training seeds and measured model and checkpoint sizes. The [compression and post-training study (Chinese)](experiments/rl-compression-study-20260928.md) adds FP16/INT8 storage export commands, layer-wise dynamic INT8 ablations, and inference batch comparisons.

**Which implementation trains the policy?** `train` uses the core `VectorEnv`. Go1 and `h1-native` use robot environments and PPO maintained in this repository, but are not yet integrated into `VectorEnv`; MuJoCo/mjbatch remains the physics engine. Go1 supports `--standalone` with installed packages; its default mode retains the pinned mjbatch SDK checkout. The `h1` command uses IsaacLab, while `h1-native` does not. The shared Web viewer is a separate visualization path, not the training environment.

New core PPO, Go1 PPO and native H1 training runs write `training-runtime.json` in their output directory, including resumed Go1/H1 runs. It records the actual loaded environment, task, learner and physics adapter, their module/file paths, Python source hashes, package versions, interpreter, CPU execution and whether the core `VectorEnv` is used. Go1 paths point to the run's implementation snapshot. This records entry-point provenance, not every transitive dependency, a checkpoint compatibility lock or policy quality. Older runs and external workflows do not gain this file retroactively.

Core PPO and native H1 reuse the value of an unchanged observation across adjacent steps within a rollout. A 24-step rollout without resets needs 25 critic calls instead of 48. Partial resets recompute only the affected rows; a full reset recomputes the batch directly without extra indexed copies. Each new rollout recomputes values, so the cache never crosses policy updates. Timeout bootstrapping still uses the observation before reset.

A local measurement on 2026-09-22 used actual policies, a stand-in environment, Torch 2.9.0 and one CPU thread, alternating implementations and taking the median of five groups. For 128 steps, 1024 environments and 32 reset rows per step, Core PPO collection fell from about 136.6 to 102.4 ms and native H1 from 393.2 to 288.6 ms. No-reset and full-reset cases remained close to the previous implementation. Sampled actions and RNG state matched; smaller critic batches introduced value differences up to about `3e-8`, with post-update weight and Adam differences of about `7.5e-9` and `3.8e-9`. Bitwise equality is not guaranteed. These are collection timings, not full physics simulation or training throughput.

Actual-environment comparisons also covered reach/hold with NumPy and MuJoCo, and native H1 with MuJoCo/mjbatch: 16 environments, 64 steps and staggered timeouts. Current values differed by at most about `6.8e-8`; actions, observations, rewards, next values and termination/truncation flags matched exactly.

Both collectors allocate independent arrays using the current rollout length and actual data shapes and dtypes, then write each step directly. This avoids retaining per-step data alongside the final stacked copy. Buffers are not reused across rollouts, so subsequent collection or environment resets cannot overwrite earlier data. Using stand-in environments and policies to isolate storage costs, `tracemalloc` peaks for 128 steps and 1024 environments fell from about 10.2 to 6.4 MiB for Core PPO and from 93.2 to 47.1 MiB for H1. These measurements cover NumPy/Python allocations, not the memory of the full simulation and training process.

Their shared GAE batches TD errors and recurrence discounts, leaving only the dependent advantage recurrence in the time loop, at the cost of storing intermediate arrays for the full batch. A local NumPy measurement on 2026-09-21 (median of seven groups of 100 calls) reduced the 128-step, 1024-environment case from about 0.62 ms to 0.27 ms. Results matched exactly for float32/float64, noncontiguous arrays, and termination/timeout boundaries; Core PPO and H1 updates also matched in loss, weights, Adam state, and RNG state. These timings measure GAE alone, not full training throughput.

Native Go1's Torch GAE also batches independent terms while preserving input validation and timeout bootstrapping. Measurements on the same date using Torch 2.9.0, one CPU thread, and the timing method above included validation: at 1024 environments, 24 steps fell from about 0.40 to 0.24 ms and 128 steps from 1.99 to 1.12 ms, at the cost of temporary batch-sized TD error and discount tensors. Thirty cases spanning lengths, dtypes, mask types, and noncontiguous inputs matched exactly; the existing upstream comparison also confirmed identical weights and Adam state after a full policy update. This change optimizes native Go1 GAE; Light Loco still calls its pinned upstream implementation.

Policy updates reuse gathered observations and advantages within each minibatch; H1 also reuses old values and return targets. Tensor gathers per minibatch drop from seven to five in Core PPO and from ten to six in H1, avoiding duplicate copies. CPU profiling confirmed the reduced index counts, with exactly matching loss, gradients, weights, Adam state, and RNG state. These counts do not imply a proportional reduction in total runtime.

<a id="setup"></a>

## Environment setup

Install the launchers and required viewer dependencies in the main environment. Use an existing Python 3.11 environment, or create `ef-viewer` following the README:

```bash
python -m pip install -e '.[viz-robot]' 'mujoco==3.11.0'
python -m embodiedforge recipes list
```

Keep training SDKs isolated. Recipe and Microduck setup require Git, `uv`, and network access. Run only the setup commands you need. External recipe sources must be clean checkouts at the pinned revisions; these commands do not switch the revision of your source repository.

```bash
python -m embodiedforge recipes setup --source mjbatch \
  --repo /path/to/mjbatch --python 3.12 --timeout 1200
python -m embodiedforge recipes setup --source wuji_unilab \
  --repo /path/to/wuji_unilab --python 3.12 --timeout 1200
python -m embodiedforge.microduck setup
python -m embodiedforge.microduck check
```

| Source | Pinned revision | Environment location |
| --- | --- | --- |
| mjbatch | `b84c0c20aedbdf048122cbc47f554e9b93cc4754` | `.cache/external/mjbatch/.venv` |
| Wuji UniLab | `91ccfa0ec8c129b300865bd36c59dc9eed56a744` | `.cache/external/wuji_unilab/.venv` |
| Microduck | `53b8971b61baf5b7f3c16d135dd7cac37623de4b` | `.cache/microduck-native-venv` |
| IsaacLab H1 | `2e44ddb2e19536579140496023b5ccb060bc4152` | Existing environment selected with `--environment` |

H1 has no automatic `setup` subcommand. Prepare the isolated Python 3.12 / RSL-RL 5.0.1 environment described in the [H1 guide](h1-isaaclab.md) first. `--environment` takes the environment root, not its Python executable. Wuji, Microduck, and IsaacLab H1 require their respective CUDA stacks; Go1 and both solver tasks run on CPU. When customizing caches, pass the same `--cache` or Microduck `--env-dir` at every step.

<a id="core"></a>

## Core PPO: reach / hold

Install Torch and MuJoCo in the current main environment. Train the two point tasks separately, evaluate their policies, and record reach evaluation data:

```bash
python -m pip install -e '.[train,mujoco]'
python -m embodiedforge train --task reach --physics mujoco \
  --num-envs 32 --updates 100 --output runs/commands-reach
python -m embodiedforge evaluate \
  --checkpoint runs/commands-reach/checkpoint.pt \
  --num-envs 32 --steps 300 --output runs/commands-reach-eval
python -m embodiedforge inspect --dataset runs/commands-reach-eval
python -m embodiedforge train --task hold --physics numpy \
  --num-envs 32 --updates 100 --output runs/commands-hold
python -m embodiedforge evaluate \
  --checkpoint runs/commands-hold/checkpoint.pt --num-envs 32 --steps 300
```

Core PPO uses proprioception, not images. Evaluation restores configuration from the checkpoint; avoid changing its task or physics arbitrarily. Point-task `visualization` runs a demonstration controller rather than loading these PPO checkpoints. The core CLI supports resume; ONNX export is not available.

New runs save after the first update, every 10 updates, and at completion; `--checkpoint-interval` changes the interval. `checkpoints/` retains the two most recent committed snapshots, and `checkpoint.pt` is a convenience copy of the most recently published snapshot. `run.json` records status, completed and saved update counts, the versioned checkpoint path and SHA256. A failed save or manifest publication preserves the preceding recovery point. Ctrl+C/SIGTERM records `interrupted`; other failures record `failed`. Atomic replacement does not guarantee durability across host power loss.

```bash
python -m embodiedforge train --resume runs/commands-reach \
  --updates 100 --checkpoint-interval 10 --output runs/commands-reach-resumed
```

`--updates` is the additional budget. A directory selects the committed, hash-verified checkpoint referenced by its run record; a trained legacy v2 checkpoint containing Adam state is also accepted. A running directory can supply a saved snapshot for an independent new run without stopping or modifying the source. If the source prunes the selected file before it is opened, the reader makes at most three attempts, selecting a newer committed update only when progress has advanced. Missing files with unchanged progress and hash mismatches still fail. The CLI inherits environment/PPO settings unless compatible environment overrides are supplied. Task, observation/action semantics and control period must match. Policy and Adam are restored, but environments and RNG streams restart; this is not exact continuation of the original process. Metric `update` is cumulative, while `transitions` counts only the new run.

The Python API accepts `train_ppo(env_config, ppo_config, new_directory, resume=source, checkpoint_interval=10)`. The supplied PPO configuration defines the new budget and hyperparameters; its learning rate replaces the saved Adam rate. `load_training_checkpoint` can read and validate an input once and pass that object to training, preventing a later file replacement from changing the loaded input.

The Python API's `PPOConfig` validates positive integer training counts, a finite positive learning rate, and an integer seed in `[0, 2**64 - 1]` at construction. Invalid configurations fail before creating the training output directory or simulation environment; booleans are rejected as counts or seeds.

`load_checkpoint` / `load_policy` check loaded actor, critic, and `log_std` parameters on CPU, rejecting NaN/Inf with the affected parameter name before returning a policy. Action bounds must be finite and strictly increasing. When a checkpoint includes an environment specification, loading also checks that the policy's observation dimensions, action dimensions, and action range match that record, without creating simulation resources. Existing v1/v2 checkpoints remain supported; legacy models without an environment specification must also match the actual environment's dimensions and action range during evaluation.

Core and native H1 PPO explicitly retain unit `log_std` gradients at both endpoints of `[-5, 2]`, with zero gradients outside. Forward values and NaN propagation remain unchanged. [PyTorch 2.14 changed clamp's endpoint gradients](https://github.com/pytorch/pytorch/issues/195931), which otherwise freezes parameters projected exactly onto a bound. The helper is verified on Torch 2.9, 2.13 and 2.14; exploration bounds and entropy coefficients are unchanged.

To compare trained and untrained policies, run these commands in an environment with core training dependencies. The script preserves the checkpoint’s task, physics, control period, and episode length. Both policies use matching network dimensions and evaluation seeds. Output includes the model SHA256 and environment configuration for comparison provenance. The digest comes from the `sha256` returned by `load_checkpoint`, computed from the same bytes used for deserialization. Replacing the source file after loading cannot make the report identify a different model's hash.

```bash
python benchmarks/check_learning.py runs/commands-reach/checkpoint.pt --num-envs 128 --seeds 1001 1002 1003
python benchmarks/check_learning.py runs/commands-hold/checkpoint.pt --num-envs 128 --seeds 1001 1002 1003
```

<a id="go1"></a>

## Go1: train → resume → evaluate → run live

### Installed-package mode: no upstream checkout

Add `--standalone` to Go1 train, resume and evaluation commands. The launcher uses the current Python interpreter with MuJoCo 3.11.0, mjbatch 0.1.0, PyTorch 2.9.0 (CPU or CUDA wheel) and Menagerie 2026.9.0. Physics and learning run on CPU. It requires no `recipes setup`, IsaacLab, upstream examples or SDK source checkout; `--cache` is unused in this mode. Menagerie still supplies robot assets and may download them on first use; `MENAGERIE_CACHE_DIR` selects an existing asset cache.

```bash
conda create -n ef-go1-native python=3.12 pip -y
conda activate ef-go1-native
python -m pip install -e '.[go1-native]'
python -m embodiedforge recipes train --task go1-joystick --standalone \
  --num-envs 128 --horizon 24 --updates 1000 --threads 4 \
  --timeout 1200 --output runs/commands-go1-native
python -m embodiedforge recipes train --task go1-joystick --standalone \
  --resume-run runs/commands-go1-native --num-envs 128 --horizon 24 \
  --updates 100 --threads 4 --timeout 1200 --output runs/commands-go1-native-resumed
python -m embodiedforge recipes evaluate --task go1-joystick --standalone \
  --run runs/commands-go1-native-resumed --velocity 0.5 0 0 \
  --num-envs 8 --steps 500 --record-motion --timeout 1200 \
  --min-survival-fraction 0.8 --max-planar-rmse 0.3 --max-yaw-rmse 0.3 \
  --output runs/commands-go1-native-eval
conda activate ef-viewer
python -m embodiedforge live --run runs/commands-go1-native-resumed \
  --render-backend rtx --port 8081
```

Resume and evaluation accept complete Go1 runs from either launch mode and keep checkpoint hashes and task/profile checks. Continue passing `--standalone` when using the installed-package environment. Live Web control selects the training interpreter recorded in the run; the viewer environment still needs its rendering dependencies. Evaluation thresholds can reject an insufficiently trained policy; inspect the report before live diagnosis. An existing directory is never overwritten.

Each run still freezes this repository's implementation and records actual package versions and paths. `run.json` marks `source.kind=installed_packages`; it does not claim to have checked an upstream Git revision. This changes the launcher, not the task, rewards or PPO, and does not merge Go1 into the core `VectorEnv`.

Go1 live Web control loads the task, configuration, policy network and scene from the training run's `implementation` snapshot after checking each recorded SHA256 and copying the files into a private session directory. Transport and asset verification use the current version. Damaged snapshots prevent startup; legacy runs with no snapshot record use current code with an explicit warning. Startup logs and policy metadata identify the loaded implementation. Keep the complete training directory; these fixed inputs do not guarantee identical trajectories across hardware, seeds or episode settings.

Go1 evaluation also loads the training snapshot and checks dependency versions recorded during training. Its output directory retains the verified training code in `input-implementation/`; `evaluation-implementation.json` and `result.implementation` record the loaded task, policy and scene paths and hashes. `implementation/embodiedforge` retains the current evaluation adapter and metric code. Legacy artifacts without a snapshot record use current code with a warning; recorded but damaged snapshots prevent execution. Evaluation uses the requested commands, seeds and episode length, inheriting the training task semantics and profiles by default.

Resume continues using the current repository's task and PPO and saves a new implementation snapshot so training fixes can take effect. It does not promise to preserve the previous training code or match uninterrupted training trajectories. Subsequent evaluation and live control use the resumed run's snapshot.

Go1 resume retains the source run record as `input-run.json` and writes `resume-report.json` after successfully loading the policy and optimizer. The report compares recorded snapshot file hashes, environment count, rollout length, seed, thread count, task semantics, reward/command profiles, learning-rate override and actual dependency versions; missing historical evidence is marked `unknown`. Code comparison uses recorded hashes without revalidating or executing the old source, and does not infer behavioral impact. Report and source-record hashes are checked, and completion logs summarize changes. The report confirms that continuation state was loaded; `run.json.status` still determines whether training completed.

Policy parameters, normalization statistics and optimizer state are restored. Simulation state, episodes and random generators are reinitialized; learning rate is computed from the resumed iteration and current override. Unchanged recorded inputs therefore do not imply equivalence to uninterrupted training.

Go1 resume, evaluation and live control share checkpoint validation: the hash covers the exact deserialized bytes, the saved iteration must be a nonnegative integer matching the run record, and task profiles must match the source record. Normalization mean and variance must be finite floating-point vectors, variance must be nonnegative, and count must be a positive finite floating-point scalar. Invalid inputs are rejected before creating the simulation environment; valid zero variance and legacy profile defaults remain supported. Multi-seed/command evaluation reads and validates the checkpoint once, while each case still creates its own policy and environment.

The native and Light Loco Go1 paths both use FP32 policies. Policy state tensors must be FP32 on load, preventing Torch's implicit conversion from turning finite FP64 values into infinities. The action standard deviation `exp(log_std)` must also be finite and positive; finite `log_std` alone does not rule out exponential overflow or underflow.

Before creating the simulation, resume also checks Adam state against the current parameters: parameter groups, complete and unique parameter mappings, moment shapes/dtypes, nonnegative second moments, valid step counters and hyperparameters. Incompatible optimizer modes are rejected to avoid silently changing algorithms. Checkpoints are still saved every 25 updates and at training completion: optimizer state and tensor finiteness are checked before writing a temporary file and replacing the checkpoint. Validation or write failures preserve the previously saved file and mark the run as failed.

Go1 writes every update's metrics to `metrics.jsonl`, retaining only the latest row and completed count in memory. The final report's `latest_metrics` matches the last log row, avoiding a second in-memory copy of the full history during long training runs.

A failed or interrupted save attempts to remove the temporary file. Cleanup failures log the remaining path and cause while preserving the original save exception or Ctrl+C. Successful checkpoint replacement requires no subsequent temporary-file deletion.

New Go1 runs also commit `recovery.json` at each successful save, recording an independent checkpoint's hash, saved progress, configuration, dependencies and assets. `checkpoints/` retains the two most recent snapshots; `model.pt` remains the standard completed-run artifact. Once stopped, runs marked `interrupted`, `timed_out` or `failed` can be resumed with `--resume-run`, which verifies the recovery record, request, implementation snapshot and checkpoint hash. Resume starts from the saved iteration; later unsaved updates are not counted. The original run status is preserved and the resume report identifies the recovery source; the new directory's `input-run.json` is augmented with the verified saved-checkpoint result and a `checkpoint_origin` marker.

An interruption while publishing the recovery record or `model.pt` retains its original cause even if temporary-file cleanup fails; the remaining file is logged. Before the recovery record commits, the previous checkpoint remains recoverable. After it commits, the newly saved independent checkpoint remains recoverable even if updating `model.pt` fails.

For example, after the standalone training above stops through Ctrl+C or a timeout, inspect `recoverable_checkpoint` and resume into a new directory:

```bash
python -m embodiedforge recipes status --run runs/commands-go1-native
python -m embodiedforge recipes train --task go1-joystick --standalone \
  --resume-run runs/commands-go1-native --num-envs 128 --horizon 24 \
  --updates 100 --threads 4 --timeout 1200 --output runs/commands-go1-native-recovered
```

Runs without a successfully saved checkpoint, older interrupted runs without a recovery record, and directories still marked `running` are not recovered automatically. `status` reports `recovery_error` for stopped runs that cannot be recovered. Evaluation and live control still require a completed training directory; use the new directory after resumed training succeeds.

Go1 training, resume, evaluation and live policy startup verify the published asset cache and compare robot/tree/archive identity with the training record when available. If `MENAGERIE_CACHE_DIR` is unset, standalone resume/evaluation and live control reuse the recorded cache when it still exists; an explicit cache choice is preserved and verified. Older `assets.json` records remain readable. `MENAGERIE_ROOT` local-checkout overrides are rejected because the cache verifier cannot verify that separate directory. Use `MENAGERIE_CACHE_DIR` for published assets. This checks robot assets; it does not guarantee identical simulation across code or dependency changes.

### Fixed SDK mode

Complete mjbatch setup first. Resume writes to a new directory, and `--updates` specifies additional updates for that invocation. Timeouts below are in seconds; increase them for slower machines.

```bash
python -m embodiedforge recipes train --task go1-joystick \
  --num-envs 512 --horizon 24 --updates 600 --threads 4 \
  --timeout 1200 --output runs/commands-go1
python -m embodiedforge recipes status --run runs/commands-go1
python -m embodiedforge recipes train --task go1-joystick \
  --resume-run runs/commands-go1 --num-envs 512 --horizon 24 \
  --updates 100 --threads 4 --timeout 1200 --output runs/commands-go1-resumed
python -m embodiedforge recipes evaluate --task go1-joystick \
  --run runs/commands-go1-resumed --suite basic --seeds 0 1 2 \
  --num-envs 32 --steps 3000 --record-motion --timeout 1200 \
  --min-survival-fraction 0.8 --max-planar-rmse 0.3 --max-yaw-rmse 0.3 \
  --output runs/commands-go1-eval
python -m embodiedforge live --run runs/commands-go1-resumed \
  --render-backend mujoco --num-envs 2 \
  --width 960 --height 540 --fps 30 --port 8080
```

The evaluation thresholds are example requirements. Any failing case/seed produces `rejected` and retains reports; inspect results before deciding whether to diagnose the policy live. Run the live command in the viewer environment; it launches the policy in the training environment automatically. Open `http://127.0.0.1:8080`, click “前进” (Forward), then “继续” (Resume). Use `--worker-python /path/to/venv/bin/python` to select a compatible policy environment explicitly.

After fixed-command evaluation, test continuous command transitions separately using a new output directory:

```bash
python -m embodiedforge recipes evaluate --task go1-joystick \
  --run runs/commands-go1-resumed --suite switching --seeds 0 1 2 \
  --num-envs 32 --steps 3000 --record-motion --timeout 1200 \
  --output runs/commands-go1-switching
```

This transition example reports metrics without acceptance thresholds. See [task recipes](recipes.md) for `extended`, lateral, and compound transition suites. View recordings with a matching MJCF using the Web replay command below.

<a id="microduck"></a>

## Microduck: training, export, and policy execution

After the initial Microduck setup, start training directly. Training and resume are headless by default; `--headless` is also accepted explicitly. No desktop or Xvfb is needed. CUDA and sufficient GPU memory are still required. The default uses the local port without an upstream checkout; optional `--repo` selects the legacy implementation and its separate environment.

```bash
python -m embodiedforge.microduck train --headless \
  --num-envs 4096 --iterations 4000 --output runs/commands-microduck
python -m embodiedforge.microduck progress \
  --run runs/commands-microduck
```

Training/evaluation retain an implementation snapshot and per-stage logs. Workspace edits do not affect an already-started local task. `progress` reports the phase, log path, and verifiable launcher status. Training accepts `--seed` (default 0); SIGTERM preserves saved checkpoints and records interruption.


Pass a completed training directory directly; the launcher selects the checkpoint recorded in `run.json`. For training only, `--resume-run` also accepts finalized `interrupted` or `failed` runs and selects the latest checkpoint from their recorded list. It refuses running jobs, ambiguous lists or missing selected models; the original directory is preserved. Run resume, native playback, or Viser playback as needed:

```bash
python -m embodiedforge.microduck train --headless \
  --resume-run runs/commands-microduck --num-envs 4096 --iterations 1000 \
  --output runs/commands-microduck-resumed
python -m embodiedforge.microduck play \
  --run runs/commands-microduck --viewer native --steps 500 --seed 0
python -m embodiedforge.microduck play \
  --run runs/commands-microduck --viewer viser
```

Viser uses the upstream page, separate from the shared Go1/H1 Web viewer, and does not support the native mode’s `--steps` option. Export the same checkpoint, then compare ONNX and Torch actions on actual observations:

```bash
python -m embodiedforge.microduck export \
  --run runs/commands-microduck --output runs/commands-microduck.onnx
python -m embodiedforge.microduck evaluate \
  --run runs/commands-microduck --onnx runs/commands-microduck.onnx \
  --velocity 0.2 0 0 --no-pushes --num-envs 16 --steps 500 --seeds 0 1 2 \
  --output runs/commands-microduck-eval
```

Export runs headless by default and includes observation normalization, with 61 input and 14 output dimensions. The ONNX file is published only after inference validation; logs and snapshots remain in a separate hidden directory beside the output, including on failure. Export supports `--quiet` and refuses to overwrite either an existing model or validation report. Torch actions still drive simulation during comparison; this is not independent ONNX closed-loop or hardware validation. No behavioral thresholds are set in this example; add RMSE or survival requirements as described in the [Microduck guide](microduck.md).

Evaluation also runs headless by default and accepts `--headless --quiet --video`. Video uses offscreen EGL without a desktop or Xvfb; multi-seed runs save `policy.mp4` inside each `seed-N/` directory.

Evaluation copies the checkpoint and optional ONNX model into the run's `inputs/` directory once for all seeds. Replacing external files after capture does not change the evaluation. `run.json.input_snapshot` records source paths and SHA256 hashes, which are checked against evaluation reports during execution and offline assessment.

<a id="h1"></a>

## H1: native CPU and IsaacLab training and replay

### Native CPU workflow

The independent `h1-native` entry point uses no IsaacLab, RSL-RL, or upstream trainer. Run it in a separate Python environment with the following dependencies; the original GPU workflow remains below.

```bash
python -m pip install -e '.[h1-native]'
python -m embodiedforge h1-native train --headless \
  --model /path/to/unitree_h1/h1.xml --num-envs 128 --threads 2 --updates 5000 \
  --seed 0 --learning-rate 0.0003 \
  --output runs/commands-h1-native
python -m embodiedforge h1-native train --headless \
  --resume runs/commands-h1-native --num-envs 128 --threads 2 --updates 1000 \
  --output runs/commands-h1-native-resumed
python -m embodiedforge h1-native evaluate --headless \
  --run runs/commands-h1-native-resumed --threads 2 --steps 500 --velocity 0.5 0 0 \
  --record-motion --min-survival 0.8 --max-planar-rmse 0.3 --max-yaw-rmse 0.3 \
  --output runs/commands-h1-native-eval
```

The 128-environment, 5000-update starting budget follows the [three-seed study](experiments/rl-training-study-20260925.md). More updates alone do not establish walking quality: apply the evaluation thresholds to every trained or resumed policy. The example covers forward walking; evaluate standing and turns separately with other `--velocity` values and new output directories. The smaller-batch [checkpoint study](experiments/h1-checkpoint-publication-20260929.md) checks software consistency and is not a deployment recipe.

Evaluation defaults to the nominal initial state. Add `--randomized-reset --num-envs 32 --seed 9701` with a new output directory to sample initial states and physics from the training distribution while keeping fixed commands and observation noise disabled. See the [H1 evaluation guide](h1-native.en.md#evaluate-and-replay) for ranges and metric definitions.

After native H1 stops through interruption or failure, the same `--resume` command can load its last recorded, validated checkpoint. Runs that stopped before saving, are still marked `running`, or fail artifact validation cannot be recovered. Unsaved updates do not count toward resumed progress.

Use the resumed run’s `model.mjb` and evaluation `motion.npz` with the shared `replay` command in `ef-viewer`. See [native H1](h1-native.en.md) for reset/torque contracts and acceptance limits. These checkpoints are incompatible with the IsaacLab workflow.

### IsaacLab GPU workflow

Use the prepared pinned IsaacLab checkout and isolated environment, and specify the training budget directly. Keep `--repo` and `--environment` consistent across commands.

```bash
python -m embodiedforge h1 train \
  --repo /path/to/IsaacLab --environment /path/to/envs/isaaclab \
  --num-envs 512 --updates 1000 --output runs/commands-h1
python -m embodiedforge h1 status --run runs/commands-h1
python -m embodiedforge h1 train \
  --repo /path/to/IsaacLab --environment /path/to/envs/isaaclab \
  --resume-run runs/commands-h1 --num-envs 512 --updates 1000 \
  --output runs/commands-h1-resumed
python -m embodiedforge h1 evaluate \
  --repo /path/to/IsaacLab --environment /path/to/envs/isaaclab \
  --run runs/commands-h1-resumed --suite basic --num-envs 32 \
  --steps 500 --seeds 0 1 2 --record-motion --record-env 0 --timeout 600 \
  --min-survival-fraction 0.8 --max-planar-rmse 0.3 --max-yaw-rmse 0.3 \
  --output runs/commands-h1-eval
python -m embodiedforge h1 replay \
  --motion runs/commands-h1-eval/motion-seed-0-forward-env-0.npz \
  --output runs/commands-h1-forward.html
```

Training requires an explicit `--updates` budget and has no extra timeout; add `--timeout` to bound wall-clock time. Five hundred steps cover ten seconds. For longer validation, use `--steps 3000` with a new output directory. Open the HTML file offline for skeleton replay; see below for mesh replay. H1 currently has no shared Web live-command entry point: `live --run` cannot load H1 training directories.

<a id="wuji"></a>

## Wuji / Wuji Light: reorientation training

Training is headless by default (`--headless` is also accepted). For either Wuji task,
add `--no-headless --viewer-port 8083 --viewer-fps 10` to preview training environment 0
at `http://127.0.0.1:8083`. This shows exploratory rollout actions with a fixed camera
and no goal overlay. Rendering adds overhead and requires working EGL/OpenGL drivers.
Closing the browser does not stop training; the preview server exits with training.
Go1 also supports `--no-headless`. TensorBoard remains a separate service.
See the [complete Wuji walkthrough (Chinese)](wuji-training.md).

Complete wuji_unilab setup first. Standard and Light are different tasks: use separate run directories and preserve `--task` for resume and evaluation. Training requires `--updates` and has no wall-clock limit unless `--timeout` is supplied. These example budgets do not guarantee behavioral acceptance:

```bash
python -m embodiedforge recipes train --task wuji-reorient \
  --num-envs 512 --horizon 40 --updates 1000 \
  --output runs/commands-wuji
python -m embodiedforge recipes train --task wuji-reorient-light \
  --num-envs 512 --horizon 40 --updates 1000 \
  --output runs/commands-wuji-light
python -m embodiedforge recipes train --task wuji-reorient-light \
  --resume-run runs/commands-wuji-light --num-envs 512 --horizon 40 \
  --updates 1000 --output runs/commands-wuji-light-resumed
python -m embodiedforge recipes status --run runs/commands-wuji-light-resumed
python -m embodiedforge recipes evaluate --task wuji-reorient-light \
  --run runs/commands-wuji-light-resumed --num-envs 1 --seed 0 \
  --num-trials 50 --steps 280 --timeout 1200 \
  --min-success-rate 0.5 --max-drop-rate 0.2 --output runs/commands-wuji-eval
```

Evaluation runs single-environment trials sequentially; Go1 options `--suite`, `--seeds`, and `--record-motion` do not apply. To evaluate the standard task, change `--task` to `wuji-reorient`, `--run` to `runs/commands-wuji`, and choose a new output directory. Record a separate small video sample if `ffprobe` is available:

```bash
python -m embodiedforge recipes evaluate --task wuji-reorient-light \
  --run runs/commands-wuji-light-resumed --num-envs 1 --seed 0 \
  --num-trials 1 --steps 280 --record-video --timeout 600 \
  --output runs/commands-wuji-video
```

Video supports behavioral inspection, not full acceptance. Wuji currently has no shared Web live-control or model-export command.

<a id="solvers"></a>

## CPU MPC and CEM solvers

Reuse mjbatch setup. `--num-envs` means candidate trajectories for MPC and population size for CEM; neither produces a PPO checkpoint.

```bash
python -m embodiedforge recipes solve --task cartpole-mpc \
  --num-envs 1024 --horizon 25 --steps 150 --threads 4 --timeout 600 \
  --output runs/commands-cartpole
python -m embodiedforge recipes solve --task arm-throw-codesign \
  --num-envs 512 --generations 30 --threads 4 --timeout 600 \
  --output runs/commands-arm
python -m embodiedforge recipes status --run runs/commands-arm
```

Outputs include solver metrics, baselines, and trajectories. Solver directories cannot be passed to Go1 `live`. See [task recipes](recipes.md) for objectives and trajectory semantics.

<a id="serving"></a>

## Web serving and remote access

Install the desired renderer in the viewer environment. The OVRTX installation below uses validated constraints and requires a compatible RTX GPU and driver. Then select `--render-backend rtx` for live Go1 rendering as well.

```bash
python -m pip install --extra-index-url https://pypi.nvidia.com \
  -c configs/viewer-constraints.txt -e '.[viz-robot,viz-rtx]' 'mujoco==3.11.0'
python -m embodiedforge.visualization --viewer web --render-backend rtx --check
```

`--check` checks installation metadata only. These replay examples use recordings generated above and matching local MJCF models; model directories must include referenced meshes and materials. Run separately, or use different ports in different terminals:

```bash
python -m embodiedforge replay --model /path/to/unitree_go1/go1.xml \
  --motion runs/commands-go1-switching/motion-seed-0-switching.npz \
  --render-backend mujoco --width 960 --height 540 --fps 30 --port 8081
python -m embodiedforge replay --model /path/to/unitree_h1/h1.xml \
  --motion runs/commands-h1-eval/motion-seed-0-forward-env-0.npz \
  --render-backend rtx --width 960 --height 540 --fps 30 --port 8082
```

Servers bind to loopback by default. In a separate client terminal, forward the Go1 live server and both replay ports, then open their local addresses:

```bash
ssh -N -L 8080:127.0.0.1:8080 -L 8081:127.0.0.1:8081 \
  -L 8082:127.0.0.1:8082 user@server
```

Open `http://127.0.0.1:8080`, `:8081`, or `:8082` while the corresponding server is running. The page supports resolution changes and 1–60 FPS. Live Go1 starts paused; replay only reads recordings. Stop/Ctrl+C ends the entire shared session. These commands run foreground processes; they do not install system services or automatic restart configuration. See [viewers](viewers.md) for lifecycle and remote-access details.

For EGL warnings or unexpected GPU selection, render a test frame and inspect `graphics.vendor`, `graphics.renderer`, and retained driver warnings:

```bash
python -m embodiedforge doctor --graphics egl
```

The diagnostic runs in an isolated process without changing system driver configuration. A successful frame does not mean NVIDIA was selected. See [EGL diagnostics](graphics-diagnostics.md) for the local missing-registration case and driver-package repair steps (Chinese).

<a id="package"></a>

## Wheel deployment: run on another machine

Build a wheel from the source checkout. This packages EmbodiedForge without bundling training SDKs, models, or caches:

```bash
python -m pip wheel --no-deps --wheel-dir dist .
```

Copy `dist/embodiedforge-0.1.0-py3-none-any.whl` and the complete Go1 run directory to the target machine. Prepare a compatible isolated mjbatch SDK environment there, then run these commands in its Python 3.11 viewer environment, replacing all placeholder paths:

```bash
python -m pip install '/path/to/embodiedforge-0.1.0-py3-none-any.whl[viz-robot]' 'mujoco==3.11.0'
python -m embodiedforge live --run /path/to/runs/go1-trained \
  --worker-python /path/to/mjbatch-venv/bin/python \
  --render-backend mujoco --port 8080
```

After installation, the CLI works independently of the source working directory. The wheel includes Web HTML/JavaScript, the Go1 scene XML, and the port’s license. Keep `--worker-python` pointed at the virtual environment entry point rather than resolving its symlink to a generic Python binary. The wheel contains EmbodiedForge code plus Microduck walking assets and license; external SDKs and other tasks’ assets must still be prepared as described above. OVRTX also requires its viewer dependencies and driver.

A source checkout remains useful for development and reproducing examples. Source distributions additionally include bilingual documentation, the illustration, configuration, examples, and benchmark scripts; training artifacts and caches are excluded. After a version change, substitute the actual built wheel filename above.

<a id="artifacts"></a>

## Artifacts, resume, and acceptance

| Workflow | Inputs / artifacts to retain | Next use |
| --- | --- | --- |
| Core PPO | `checkpoint.pt` and training directory | `evaluate --checkpoint` |
| Managed Go1 / H1 / Wuji training | Entire run directory and `run.json`, including configuration, model, and version records | Same-task resume and evaluation; only Go1 supports `live --run` |
| Microduck | `run.json`, actual checkpoint, configuration, and runtime records | `--resume`, `play`, `evaluate`, `export` |
| Microduck export | ONNX file and validation report | Inference interface checks and action comparison |
| Go1 / H1 motion recording | NPZ and matching MJCF / asset directory | Shared Web replay; H1 also supports offline skeleton HTML |
| MPC / CEM | Complete solver directory, results, and trajectories | Result analysis, not PPO policy loading |

Run `status` or Microduck `progress` from another terminal during training; a status file is not a process-liveness guarantee. Resume restores the model, optimizer, normalization, curricula, and other state supported by the task, but not each environment’s physical state and all RNG state. It is not step-equivalent continuation. Managed Go1/H1/Wuji resume requires a compatible `complete` run of the same task.

To run a model on another machine, retain the full training directory and recreate compatible SDKs and robot assets. Go1 supports a new interpreter path through `--worker-python`, but still checks SDK and asset versions; copying only `model.pt` does not bypass these requirements. An evaluation marked `complete` merely finished execution. Acceptance is meaningful under its stated conditions only when thresholds were set and every required check passed.
