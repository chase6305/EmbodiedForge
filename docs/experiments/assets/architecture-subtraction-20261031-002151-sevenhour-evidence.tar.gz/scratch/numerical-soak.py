"""Compare real old/new SDK functions: values, gradients, ownership and RNG."""
import argparse
import hashlib
import importlib.util
import json
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace as NS

import torch

WORK = Path('/tmp/embodiedforge-subtraction-20261031-002151-sevenhour')
MDP = Path('src/embodiedforge/locomotion/microduck/tasks/mdp.py')
EVAL = Path('src/embodiedforge/workflows/supermimic_reference_evaluate.py')
HISTORY = ('leg_action_rate_l2', 'neck_action_rate_l2', 'leg_action_acceleration_l2', 'neck_action_acceleration_l2')
CACHES = ('_prev_leg_actions', '_prev_neck_actions', '_prev_leg_actions_for_acc', '_prev_prev_leg_actions_for_acc', '_prev_neck_actions_for_acc', '_prev_prev_neck_actions_for_acc')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def modules():
    return [(load('sevenhour_' + kind + '_mdp', WORK / kind / MDP),
             load('sevenhour_' + kind + '_evaluate', WORK / kind / EVAL))
            for kind in ('baseline', 'candidate')]


def exact(first, second, label):
    assert first.shape == second.shape and first.dtype == second.dtype, label
    assert torch.equal(first.detach().contiguous().view(torch.uint8), second.detach().contiguous().view(torch.uint8)), label


def arranged(value, layout, gradient=False):
    if layout == 1:
        value = value.T.contiguous().T
    elif layout == 2:
        padded = torch.zeros(value.shape[0], value.shape[1] * 2, dtype=value.dtype, device=value.device)
        padded[:, ::2] = value
        value = padded[:, ::2]
    else:
        value = value.clone()
    return value.detach().requires_grad_(gradient)


def random_matrix(count, width, dtype, device, seed):
    return torch.randn(count, width, dtype=dtype, device=device,
                       generator=torch.Generator(device=device).manual_seed(seed))


def history_environment(count, dtype, device, layout, seed):
    forces = arranged(random_matrix(count, 16, dtype, device, seed), layout)
    return NS(num_envs=count, device=device, action_manager=NS(action=None),
              scene={'robot': NS(data=NS(actuator_force=forces))},
              _prev_actuator_forces=torch.zeros_like(forces))


def reset_environment(mdp, count, dtype, device, layout, seed):
    names = list(mdp._CROUCH_ANCHOR_BY_NAME) + ['servo_' + str(i) for i in range(8)] + ['passive_left', 'passive_right']
    positions = arranged(random_matrix(count, 16, dtype, device, seed) * .1, layout)
    velocities = arranged(random_matrix(count, 16, dtype, device, seed + 1) * .1, layout)
    defaults = arranged(random_matrix(count, 16, dtype, device, seed + 2) * .1, layout)
    qpos = torch.zeros(count, 23, dtype=dtype, device=device)
    qpos[:, 3] = 1
    qpos[:, 7:] = positions
    qvel = torch.ones(count, 22, dtype=dtype, device=device)
    writes = []

    def find(pattern):
        ids = [i for i, name in enumerate(names) if re.fullmatch(pattern, name)]
        return ids, [names[i] for i in ids]

    def joint_write(position, velocity, env_ids):
        writes.append(('joint', position, velocity, env_ids))

    def velocity_write(value, env_ids):
        writes.append(('root', value, env_ids))

    asset = NS(data=NS(joint_pos=positions, joint_vel=velocities, default_joint_pos=defaults,
                       data=NS(qpos=qpos), indexing=NS(free_joint_q_adr=torch.arange(7, device=device))),
               find_joints=find, write_joint_state_to_sim=joint_write,
               write_root_link_velocity_to_sim=velocity_write)
    env = NS(num_envs=count, device=device, common_step_counter=0, scene={'robot': asset},
             sim=NS(data=NS(qpos=qpos, qvel=qvel)))
    return env, writes


def rng():
    return [torch.random.get_rng_state(), torch.cuda.get_rng_state()]


def restore(state):
    torch.random.set_rng_state(state[0])
    torch.cuda.set_rng_state(state[1])


def resources():
    return {'rss_kib': int(Path('/proc/self/statm').read_text().split()[1]) * os.sysconf('SC_PAGE_SIZE') // 1024,
            'fds': len(list(Path('/proc/self/fd').iterdir())),
            'cuda_allocated_bytes': torch.cuda.memory_allocated(),
            'cuda_reserved_bytes': torch.cuda.memory_reserved()}


def cycle(before, after, seed, counters):
    device = ('cpu', 'cuda:0')[seed % 2]
    dtype = (torch.float32, torch.float64)[(seed // 2) % 2]
    layout = (seed // 4) % 3
    count = (1, 5, 17, 64)[(seed // 12) % 4]
    gradient = seed % 5 == 0
    envs = [history_environment(count, dtype, device, layout, seed) for _ in range(2)]
    inputs, losses = [[], []], [[], []]
    with torch.set_grad_enabled(gradient):
        for step in range(3):
            raw = random_matrix(count, 14, dtype, device, seed * 7 + step)
            for side, ((mdp, _), env) in enumerate(zip((before, after), envs, strict=True)):
                action = arranged(raw, layout, gradient)
                inputs[side].append(action)
                env.action_manager.action = action
                values = [getattr(mdp, name)(env) for name in HISTORY]
                if side == 0:
                    previous_values = values
                else:
                    for name, old, new in zip(HISTORY, previous_values, values, strict=True):
                        exact(old, new, name)
                        counters['reward_comparisons'] += 1
                if step:
                    losses[side].extend(values)
            for name in CACHES:
                exact(getattr(envs[0], name), getattr(envs[1], name), name)
            for env in envs:
                assert len({getattr(env, name).untyped_storage().data_ptr() for name in CACHES}) == len(CACHES)
                if not gradient:
                    saved = [getattr(env, name).clone() for name in CACHES]
                    env.action_manager.action.fill_(-99)
                    for name, original in zip(CACHES, saved, strict=True):
                        exact(getattr(env, name), original, 'input ownership:' + name)
                    counters['ownership_checks'] += len(CACHES)

        states, source_inputs, snapshots = [], [[], []], [[], []]
        for side, (_, evaluator) in enumerate((before, after)):
            tensors = [arranged(random_matrix(count, width, dtype, device, seed + width), layout, gradient)
                       for width in (36, 35, 3)]
            source_inputs[side] = tensors
            snapshots[side] = [value.detach().clone() for value in tensors]
            qpos, qvel, origins = tensors
            state = evaluator.actual_state(NS(sim=NS(data=NS(qpos=qpos, qvel=qvel)), origins=origins))
            states.append(state)
            inputs[side].extend(tensors)
            losses[side].append(state)
        exact(*states, 'actual_state')
        counters['state_comparisons'] += 1
        if gradient:
            gradients = [torch.autograd.grad(sum(value.sum() for value in loss), values)
                         for loss, values in zip(losses, inputs, strict=True)]
            for old, new in zip(*gradients, strict=True):
                torch.testing.assert_close(old, new, rtol=1e-5 if dtype == torch.float32 else 1e-12,
                                           atol=1e-5 if dtype == torch.float32 else 1e-12)
                counters['gradient_comparisons'] += 1
                counters['gradient_max_abs_error'] = max(counters['gradient_max_abs_error'], float((old - new).abs().max()))
                counters['gradient_bitwise_equal'] += int(torch.equal(old.contiguous().view(torch.uint8), new.contiguous().view(torch.uint8)))

    for side, state in enumerate(states):
        state.detach().fill_(99)
        for tensor, original in zip(source_inputs[side], snapshots[side], strict=True):
            exact(tensor, original, 'state source ownership')
            counters['ownership_checks'] += 1

    ids = torch.arange(count, device=device)[::2]
    for (mdp, _), env in zip((before, after), envs, strict=True):
        with torch.no_grad():
            mdp.reset_action_history(env, ids)
    for name in CACHES + ('_prev_actuator_forces',):
        exact(getattr(envs[0], name), getattr(envs[1], name), 'partial reset:' + name)
        counters['reset_comparisons'] += 1

    for operation in ('reset_with_forward_velocity', 'set_random_crouch_state'):
        resets = [reset_environment(mdp, count, torch.float32, device, layout, seed) for mdp, _ in (before, after)]
        initial_rng = rng()
        states_after = []
        for (mdp, _), (env, _) in zip((before, after), resets, strict=True):
            restore(initial_rng)
            asset = env.scene['robot']
            originals = [value.clone() for value in (asset.data.joint_pos, asset.data.joint_vel, asset.data.default_joint_pos)]
            getattr(mdp, operation)(env, ids if seed % 7 else ids[:0])
            states_after.append(rng())
            for value, original in zip((asset.data.joint_pos, asset.data.joint_vel, asset.data.default_joint_pos), originals, strict=True):
                exact(value, original, operation + ':source unchanged')
                counters['ownership_checks'] += 1
        for old, new in zip(*states_after, strict=True):
            exact(old, new, operation + ':RNG')
            counters['rng_comparisons'] += 1
        for field in ('qpos', 'qvel'):
            exact(getattr(resets[0][0].sim.data, field), getattr(resets[1][0].sim.data, field), operation + ':' + field)
            counters['reset_comparisons'] += 1
        first_writes, second_writes = resets[0][1], resets[1][1]
        assert len(first_writes) == len(second_writes)
        for old, new in zip(first_writes, second_writes, strict=True):
            assert old[0] == new[0]
            for old_value, new_value in zip(old[1:], new[1:], strict=True):
                exact(old_value, new_value, operation + ':written tensor')
                counters['reset_comparisons'] += 1
    counters['cpu_cycles' if device == 'cpu' else 'cuda_cycles'] += 1
    counters['float32_cycles' if dtype == torch.float32 else 'float64_cycles'] += 1
    counters['layout_' + str(layout) + '_cycles'] += 1
    counters['cycles'] += 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds', type=float, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    assert torch.cuda.is_available(), 'CPU and actual CUDA coverage are required'
    torch.set_num_threads(1)
    before, after = modules()
    paths = [WORK / kind / name for kind in ('baseline', 'candidate') for name in (MDP, EVAL)]
    hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
    counters = {key: 0 for key in ('cycles', 'cpu_cycles', 'cuda_cycles', 'float32_cycles', 'float64_cycles',
                                   'layout_0_cycles', 'layout_1_cycles', 'layout_2_cycles', 'reward_comparisons', 'state_comparisons',
                                   'gradient_comparisons', 'gradient_bitwise_equal', 'gradient_max_abs_error',
                                   'ownership_checks', 'reset_comparisons', 'rng_comparisons')}
    started_at = datetime.now(timezone.utc).isoformat()
    start, sampled = time.monotonic(), -30
    failure = []

    def publish(status):
        elapsed = time.monotonic() - start
        row = {'time': datetime.now(timezone.utc).isoformat(), 'seconds': elapsed, **resources(), 'cycles': counters['cycles']}
        with (args.output / 'samples.jsonl').open('a') as stream:
            stream.write(json.dumps(row) + '\n')
        result = {'status': status, 'scope': __doc__, 'started_at': started_at, 'requested_seconds': args.seconds,
                  'seconds': elapsed, 'counts': counters, 'failures': failure, 'source_hashes': hashes,
                  'torch': torch.__version__, 'cuda': torch.version.cuda, 'gpu': torch.cuda.get_device_name(),
                  'last_sample': row, 'limits': 'Real SDK modules on synthetic CPU/CUDA tensors; simulator writes captured on tensor fixtures. Values/RNG/ownership exact; gradients use recorded dtype tolerances. No learned-skill or throughput claim.'}
        temporary = args.output / 'summary.json.tmp'
        temporary.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
        temporary.replace(args.output / 'summary.json')
        print(json.dumps({'status': status, **row, 'comparisons': counters['reward_comparisons']}), flush=True)

    try:
        publish('running')
        while time.monotonic() - start < args.seconds:
            cycle(before, after, counters['cycles'] + 312, counters)
            if time.monotonic() - start - sampled >= 30:
                assert all(hashlib.sha256(path.read_bytes()).hexdigest() == hashes[str(path)] for path in paths)
                publish('running')
                sampled = time.monotonic() - start
            time.sleep(.02)
        assert counters['cpu_cycles'] and counters['cuda_cycles'] and counters['gradient_comparisons']
        assert all(hashlib.sha256(path.read_bytes()).hexdigest() == hashes[str(path)] for path in paths)
        publish('complete')
    except BaseException as error:
        failure.append(repr(error))
        publish('failed')
        raise


if __name__ == '__main__':
    main()
