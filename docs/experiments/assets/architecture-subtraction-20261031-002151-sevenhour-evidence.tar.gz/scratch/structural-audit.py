"""Prove that the complete production diff only removes 13 redundant clones."""
import ast
import difflib
import hashlib
import json
import shutil
from collections import Counter
from pathlib import Path

ROOT = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
WORK = Path('/tmp/embodiedforge-subtraction-20261031-002151-sevenhour')
ALLOWED = {
    'reset_with_forward_velocity': {'asset.data.joint_pos[warmstart_ids]', 'asset.data.joint_vel[warmstart_ids]'},
    'reset_action_history': {'asset.data.actuator_force[env_ids]'},
    'leg_action_rate_l2': {'leg_actions'},
    'neck_action_rate_l2': {'neck_actions'},
    'leg_action_acceleration_l2': {'leg_actions'},
    'neck_action_acceleration_l2': {'neck_actions'},
    'set_random_crouch_state': {'asset.data.default_joint_pos[env_ids]'},
    'actual_state': {'torch.cat((env.sim.data.qpos[:], env.sim.data.qvel[:]), -1)'},
}


class RemoveAllowedClones(ast.NodeTransformer):
    def __init__(self):
        self.function = None
        self.assignment = None
        self.counts = Counter()

    def visit_Assign(self, node):
        previous, self.assignment = self.assignment, tuple(ast.unparse(t) for t in node.targets)
        node = self.generic_visit(node)
        self.assignment = previous
        return node

    def visit_FunctionDef(self, node):
        previous, self.function = self.function, node.name
        node = self.generic_visit(node)
        self.function = previous
        return node

    def visit_Call(self, node):
        node = self.generic_visit(node)
        primary = {'leg_action_acceleration_l2': 'env._prev_leg_actions_for_acc',
                   'neck_action_acceleration_l2': 'env._prev_neck_actions_for_acc'}
        if self.function in primary and self.assignment != (primary[self.function],):
            return node
        if (isinstance(node.func, ast.Attribute) and node.func.attr == 'clone'
                and not node.args and not node.keywords
                and ast.unparse(node.func.value) in ALLOWED.get(self.function, ())):
            self.counts[self.function] += 1
            return node.func.value
        return node


state = json.loads((WORK / 'state.json').read_text())
changed = []
patch = []
counts = Counter()
before_bytes = after_bytes = 0
for path in sorted((ROOT / 'src/embodiedforge').rglob('*.py')):
    name = path.relative_to(ROOT).as_posix()
    old = (WORK / 'baseline' / name).read_text()
    new = path.read_text()
    before_bytes += len(old.encode())
    after_bytes += len(new.encode())
    if old == new:
        continue
    audit = RemoveAllowedClones()
    expanded = audit.visit(ast.parse(old))
    assert ast.dump(expanded, include_attributes=False) == ast.dump(ast.parse(new), include_attributes=False), name
    counts.update(audit.counts)
    changed.append(name)
assert counts == Counter(reset_with_forward_velocity=2, reset_action_history=1,
                         leg_action_rate_l2=2, neck_action_rate_l2=2,
                         leg_action_acceleration_l2=2, neck_action_acceleration_l2=2,
                         set_random_crouch_state=1, actual_state=1), counts
assert len(changed) == 2 and before_bytes - after_bytes == 104
state['changed_files_this_round'] = changed + ['tests/test_microduck_task.py', 'tests/test_supermimic_reference.py']
for name in state['changed_files_this_round']:
    old = (WORK / 'baseline' / name).read_text()
    new = (ROOT / name).read_text()
    patch.extend(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True), fromfile='a/' + name, tofile='b/' + name))
(WORK / 'this-round.patch').write_text(''.join(patch))
assert not (WORK / 'candidate').exists()
for path in sorted((ROOT / 'src/embodiedforge').rglob('*.py')) + [ROOT / name for name in state['changed_files_this_round'] if name.startswith('tests/')]:
    target = WORK / 'candidate' / path.relative_to(ROOT)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
result = {'status': 'passed', 'clone_calls_removed': sum(counts.values()),
          'removed_by_function': dict(counts), 'production_files_changed': changed,
          'complete_module_asts_identical_after_removing_allowed_clones': True,
          'all_other_production_bytes_unchanged': True, 'production_bytes_delta': after_bytes - before_bytes,
          'new_production_modules': 0, 'new_production_functions': 0,
          'source_sha256': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in changed}}
state['validation']['structural'] = result
state['changes'] = [
    {'area': 'action history', 'change': 'Keep each fresh advanced-indexed action tensor as its primary history snapshot; retain independent second-history copies.'},
    {'area': 'partial resets', 'change': 'Remove extra clones after integer tensor indexing and before assignment into owned history storage.'},
    {'area': 'physical evaluation state', 'change': 'Use the owned torch.cat result directly before terrain-origin subtraction.'},
]
state['audit_decisions'] = ['Preserve clones where indexing can produce a view or where two history arrays require independent storage.',
                            'Retain reward formulas, reset distributions, RNG order, trained weights and all dependency versions.',
                            'Verify ownership and autograd independently from copy-volume measurements.']
state['validation']['lint'] = 'passed'
state['validation']['candidate_full_tool_exit'] = 0
state['audit_fixture_adjustments'] = ['The private AST selector was restricted to primary history assignment targets; independent secondary-history clone calls are deliberately unchanged.']
for name, value in [('state.json', state), ('structural-audit.json', result)]:
    (WORK / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, indent=2))
