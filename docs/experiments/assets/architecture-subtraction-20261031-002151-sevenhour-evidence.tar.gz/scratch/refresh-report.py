"""Reconcile frozen production, actual validation and retained inputs."""
import argparse
import ast
import hashlib
import json
import runpy
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
WORK = Path('/tmp/embodiedforge-subtraction-20261031-002151-sevenhour')
STEM = 'architecture-subtraction-20261031-002151-sevenhour'


def read(path):
    return json.loads(path.read_text())


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--final', action='store_true')
args = parser.parse_args()
state = read(WORK / 'state.json')
now = datetime.now(timezone.utc)
elapsed = (now - datetime.fromisoformat(state['started_at'])).total_seconds()
if args.final:
    assert now >= datetime.fromisoformat(state['deadline']) and elapsed >= 25200
baseline = read(WORK / 'baseline-files.json')
changed = sorted(name for name, original in baseline.items()
                 if not (ROOT / name).is_file() or digest(ROOT / name) != original['sha256'])
generated = sorted(set(changed) & {'src/embodiedforge.egg-info/SOURCES.txt'})
assert set(changed) - set(generated) == set(state['changed_files_this_round']), changed
state['generated_build_files'] = generated
for name, checksum in state.get('generated_build_hashes', {}).items():
    assert digest(ROOT / name) == checksum, name
history = read(WORK / 'historical-files.json')
assert all(digest(ROOT / name) == checksum for name, checksum in history.items())
for row in state['preserved_models'] + state['preserved_data']:
    path = Path(row['path'])
    assert digest(path if path.is_absolute() else ROOT / path) == row['sha256'], path
watched = list((WORK / 'candidate').rglob('*.py'))
for path in watched:
    assert digest(path) == digest(ROOT / path.relative_to(WORK / 'candidate')), path
modules = sorted((ROOT / 'src/embodiedforge').rglob('*.py'))
assert len(modules) == state['baseline_modules'] == 141
before_bytes = sum((WORK / 'baseline' / path.relative_to(ROOT)).stat().st_size for path in modules)
after_bytes = sum(path.stat().st_size for path in modules)
after_lines = sum(len(path.read_text().splitlines()) for path in modules)
assert after_bytes - before_bytes == -104
assert after_lines == state['baseline_source_lines']
audit = state['validation']['structural']
assert audit['status'] == 'passed' and audit['clone_calls_removed'] == 13
assert all(digest(ROOT / name) == checksum for name, checksum in audit['source_sha256'].items())
state['metrics'] = {'modules_before': 141, 'modules_after': 141,
                    'source_lines_before': state['baseline_source_lines'], 'source_lines_after': after_lines,
                    'source_lines_delta': after_lines - state['baseline_source_lines'],
                    'source_bytes_before': before_bytes, 'source_bytes_after': after_bytes,
                    'source_bytes_delta': after_bytes - before_bytes,
                    'clone_calls_removed': 13, 'new_production_functions': 0,
                    'interpretation': 'Thirteen redundant clones removed. Required independent histories and view snapshots retained; reward/reset formulas and public signatures unchanged.'}
graph_tools = runpy.run_path(str(ROOT / 'tests/test_architecture.py'))
graph = graph_tools['GRAPH']
assert not graph_tools['cycles'](graph)
state['validation']['architecture'] = {'modules': len(graph), 'explicit_import_edges': sum(map(len, graph.values())), 'cycles': []}
jobs = []
for job in state['workflow_jobs']:
    summary = read(Path(job['summary']))
    assert not summary['failures'] and summary['status'] in {'running', 'complete'}
    result_path = Path(job['supervisor']) / 'result.json'
    observed = read(result_path) if result_path.exists() else None
    if observed:
        assert observed['completed_successfully'] and observed['process_returncode'] == 0
    rows = [json.loads(line) for line in (Path(job['summary']).parent / 'samples.jsonl').read_text().splitlines()]
    warmed = [row for row in rows if row['seconds'] >= 300]
    resources = {'scope': 'Sampled combined worker process resources, not separate old/new memory measurements. CUDA counters come from the Torch allocator and exclude Warp/driver allocations.',
                 'samples': len(rows), 'fds_observed': sorted({row['fds'] for row in rows}),
                 'fds_after_five_minutes': sorted({row['fds'] for row in warmed}),
                 'rss_min_kib': min(row['rss_kib'] for row in rows), 'rss_max_kib': max(row['rss_kib'] for row in rows),
                 'max_cuda_allocated_bytes': max(row['cuda_allocated_bytes'] for row in rows),
                 'max_cuda_reserved_bytes': max(row['cuda_reserved_bytes'] for row in rows)}
    jobs.append({'name': job['name'], 'summary': summary, 'supervisor': observed, 'resources': resources})
    if args.final:
        assert summary['status'] == 'complete' and summary['seconds'] >= job['requested_seconds']
        assert observed['completed_successfully'] and observed['exit_observed'] and observed['process_returncode'] == 0
        assert not observed['timed_out'] and not observed['forced_stop'] and observed['supervisor_signal'] is None
        assert state['validation']['workflow_tool_exits'][job['name']] == 0
        counts = summary['counts']
        if job['name'] == 'numerical':
            assert all(counts[key] > 0 for key in ('cpu_cycles', 'cuda_cycles', 'float32_cycles', 'float64_cycles', 'layout_0_cycles', 'layout_1_cycles', 'layout_2_cycles', 'gradient_comparisons', 'ownership_checks', 'rng_comparisons', 'reset_comparisons'))
            assert counts['reward_comparisons'] == counts['cycles'] * 12
        else:
            assert counts['steps'] > 512 and counts['reward_comparisons'] == counts['steps'] * 4
            assert counts['physics_transitions'] == counts['steps'] * summary['num_envs']
            assert counts['reset_events'] > 0 and counts['state_comparisons'] > 0
state['validation']['workflow_sustained'] = jobs
if args.final:
    for name in ('baseline-sdk', 'candidate-sdk', 'candidate-microduck', 'candidate-full', 'source-release-targets', 'source-release-sdk'):
        assert state['validation'][name]['failures'] == state['validation'][name]['errors'] == 0
        assert state['validation'][name]['tool_exit'] == 0
    assert state['validation']['build_tool_exit'] == state['validation']['release_tool_exit'] == 0
    assert state['validation']['release']['status'] == 'passed'
    assert state['benchmarks']['clone_payload']['status'] == 'passed'
    assert state['validation']['monitor_tool_exit'] == 0 and read(WORK / 'monitor-result.json')['status'] == 'complete'
    state.update(status='complete', finished_at=now.isoformat())
state['preservation'] = {'checked_at': now.isoformat(), 'baseline_files_checked': len(baseline),
                         'expected_changed_files': changed, 'unexpected_changes': [],
                         'historical_files_unchanged': len(history), 'models_and_registry': len(state['preserved_models']),
                         'reference_data_files': len(state['preserved_data']), 'frozen_source_and_test_files_checked': len(watched)}
state['limits'] = [
    'Paired eager helper timings use seven alternating-order pairs on the shared host. They include four helpers and action pointer selection; they are local observations rather than end-to-end training throughput guarantees.',
    'Profiler results sum clone payload allocations on synthetic CPU batches. They exclude index/cat allocations and retained snapshots; they are not process RSS, GPU memory or training throughput improvements.',
    'The four action-history rewards remove four per-step clone calls while retaining two required secondary-history copies. At batch 4096 float32, clone payloads change from 672 KiB to 224 KiB per control step.',
    'Tensor fixtures load the full real SDK modules. Rewards and state snapshots cover float32/float64, CPU/CUDA and three layouts; reset fixtures use the SDK float32 convention.',
    'Numerical reward/state outputs, ownership and RNG are checked exactly. Gradient comparisons use the recorded dtype tolerances and retain observed bitwise equality/error counts.',
    'Physical comparison uses independent histories on the same actual 32-environment robot states. Small seeded actions are not a trained actor or robot skill evaluation.',
    'Changed baseline modules load beside unchanged shared dependencies; all 141 production modules and both changed test files are separately frozen.',
    'Main, SDK and source-release suites overlap and are separate runs. Optional dependencies are skipped by the main environment.',
    'Existing checkpoints, registry entries, reference data, training/reset/reward parameters and dependency versions are unchanged.',
]
state.update(elapsed_seconds=elapsed, last_updated_at=now.isoformat())
for path in (WORK / 'state.json', ROOT / 'runs' / STEM / 'optimization.json', ROOT / 'docs/experiments' / (STEM + '.json')):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(state, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)
print(json.dumps({'status': state['status'], 'elapsed_minutes': elapsed / 60, 'metrics': state['metrics'],
                  'history_preserved': len(history), 'workflows': [{'name': job['name'], 'minutes': job['summary']['seconds'] / 60,
                                                                 'status': job['summary']['status']} for job in jobs]}, indent=2))
