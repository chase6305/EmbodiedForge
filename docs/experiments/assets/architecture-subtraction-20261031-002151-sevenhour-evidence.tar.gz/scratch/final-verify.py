"""Independently verify the final report, frozen inputs and evidence archive."""
import hashlib
import json
import tarfile
from datetime import datetime
from pathlib import Path

ROOT = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
WORK = Path('/tmp/embodiedforge-subtraction-20261031-002151-sevenhour')
STEM = 'architecture-subtraction-20261031-002151-sevenhour'


def read(path):
    return json.loads(path.read_text())


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


report = read(ROOT / 'docs/experiments' / (STEM + '.json'))
assert report == read(WORK / 'state.json') == read(ROOT / 'runs' / STEM / 'optimization.json')
assert report['status'] == 'complete' and report['elapsed_seconds'] >= 25200
assert datetime.fromisoformat(report['finished_at']) >= datetime.fromisoformat(report['deadline'])
assert (datetime.fromisoformat(report['finished_at']) - datetime.fromisoformat(report['started_at'])).total_seconds() >= 25200
assert report['validation']['structural']['status'] == 'passed'
assert report['validation']['structural']['clone_calls_removed'] == 13
for name, checksum in report['validation']['structural']['source_sha256'].items():
    assert digest(ROOT / name) == checksum
assert report['benchmarks']['clone_payload']['status'] == 'passed'
assert report['validation']['monitor_tool_exit'] == 0
monitor = read(WORK / 'monitor-result.json')
assert monitor['status'] == 'complete' and monitor['last_sample']['remaining_minutes'] == 0
for job in report['workflow_jobs']:
    summary = read(Path(job['summary']))
    observed = read(Path(job['supervisor']) / 'result.json')
    assert summary['status'] == 'complete' and summary['seconds'] >= job['requested_seconds'] and not summary['failures']
    assert summary['counts']['reward_comparisons'] > 0
    assert summary['counts']['ownership_checks'] > 0
    assert observed['completed_successfully'] and observed['exit_observed']
    assert observed['process_returncode'] == report['validation']['workflow_tool_exits'][job['name']] == 0
    assert not observed['timed_out'] and not observed['forced_stop'] and observed['supervisor_signal'] is None
for name, expected in report['validation']['release']['artifacts'].items():
    artifact = WORK / 'distribution' / name
    assert artifact.stat().st_size == expected['bytes'] and digest(artifact) == expected['sha256']
for name, checksum in read(WORK / 'historical-files.json').items():
    assert digest(ROOT / name) == checksum
for row in report['preserved_models'] + report['preserved_data']:
    path = Path(row['path'])
    assert digest(path if path.is_absolute() else ROOT / path) == row['sha256']
for path in (WORK / 'candidate').rglob('*.py'):
    assert digest(ROOT / path.relative_to(WORK / 'candidate')) == digest(path)
evidence = report['evidence_bundle']
archive = ROOT / evidence['path']
assert archive.stat().st_size == evidence['bytes'] and digest(archive) == evidence['sha256']
with tarfile.open(archive) as bundle:
    names = bundle.getnames()
    assert len(names) == len(set(names)) == evidence['verified_members']
    manifest = json.load(bundle.extractfile('manifest.json'))
    assert set(names) == set(manifest['files']) | {'manifest.json'}
    for member in bundle.getmembers():
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert not {'__pycache__', '.pytest_cache'} & set(Path(member.name).parts)
    for name, expected in manifest['files'].items():
        content = bundle.extractfile(name).read()
        assert len(content) == expected['bytes'] and hashlib.sha256(content).hexdigest() == expected['sha256']
    snapshot = json.load(bundle.extractfile(evidence['report_snapshot']))
    assert snapshot == {key: value for key, value in report.items() if key != 'evidence_bundle'}
    for name in report['changed_files_this_round']:
        assert bundle.extractfile('final/' + name).read() == (ROOT / name).read_bytes()
print(json.dumps({'status': 'passed', 'elapsed_seconds': report['elapsed_seconds'],
                  'historical_files_unchanged': len(read(WORK / 'historical-files.json')),
                  'archive_bytes': evidence['bytes'], 'verified_archive_members': evidence['verified_members'],
                  'workflows': [{'name': row['name'], 'seconds': row['summary']['seconds'],
                                 'units': row['summary']['counts'].get('cycles', row['summary']['counts'].get('steps'))} for row in report['validation']['workflow_sustained']]}, indent=2))
