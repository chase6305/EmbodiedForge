"""Preserve source and evidence until the authorized seven-hour deadline."""
import hashlib
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
WORK = Path('/tmp/embodiedforge-subtraction-20261031-002151-sevenhour')
state = json.loads((WORK / 'state.json').read_text())
deadline = datetime.fromisoformat(state['deadline']).timestamp()
watched = {p.relative_to(WORK / 'candidate'): hashlib.sha256(p.read_bytes()).hexdigest()
           for p in (WORK / 'candidate').rglob('*.py')}
last_integrity, samples = 0, 0
started = time.monotonic()
try:
    while True:
        now = datetime.now(timezone.utc)
        assert all(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == checksum for name, checksum in watched.items())
        jobs = []
        for job in state['workflow_jobs']:
            summary = json.loads(Path(job['summary']).read_text())
            assert not summary['failures'] and summary['status'] in {'running', 'complete'}
            result_path = Path(job['supervisor']) / 'result.json'
            observed = json.loads(result_path.read_text()) if result_path.exists() else None
            if observed:
                assert observed['completed_successfully'] and observed['process_returncode'] == 0
            jobs.append({'name': job['name'], 'minutes': round(summary['seconds'] / 60, 2),
                         'units': summary['counts'].get('cycles', summary['counts'].get('steps')),
                         'status': summary['status'], 'fds': summary['last_sample']['fds'],
                         'rss_kib': summary['last_sample']['rss_kib'],
                         'observed_exit': observed['process_returncode'] if observed else None})
        integrity = False
        if time.monotonic() - last_integrity >= 600:
            subprocess.run([sys.executable, str(WORK / 'refresh-report.py')], check=True, stdout=subprocess.DEVNULL, timeout=60)
            last_integrity = time.monotonic()
            integrity = True
        row = {'time': now.isoformat(), 'jobs': jobs, 'source_files_verified': len(watched),
               'full_preservation_check': integrity, 'remaining_minutes': round(max(0, deadline - now.timestamp()) / 60, 2)}
        with (WORK / 'monitor-samples.jsonl').open('a') as stream:
            stream.write(json.dumps(row) + '\n')
        print(json.dumps(row), flush=True)
        samples += 1
        if now.timestamp() >= deadline:
            assert all(job['status'] == 'complete' and job['observed_exit'] == 0 for job in jobs)
            break
        time.sleep(min(45, max(.1, deadline - time.time())))
    (WORK / 'monitor-result.json').write_text(json.dumps({'status': 'complete', 'samples': samples,
                                                        'seconds': time.monotonic() - started, 'last_sample': row}, indent=2) + '\n')
except BaseException as error:
    (WORK / 'monitor-result.json').write_text(json.dumps({'status': 'failed', 'error': repr(error)}, indent=2) + '\n')
    raise
