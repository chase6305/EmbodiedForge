"""Paired eager helper timings under the shared host; exclude simulator/training."""
import importlib.util
import json
import statistics
import sys
import time
from pathlib import Path

import torch

WORK = Path('/tmp/embodiedforge-subtraction-20261031-002151-sevenhour')
spec = importlib.util.spec_from_file_location('sevenhour_call_cost_helpers', WORK / 'numerical-soak.py')
helper = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = helper
spec.loader.exec_module(helper)
torch.set_num_threads(1)
versions = helper.modules()
rows = []
iterations = 200


def execute(mdp, env, actions, count):
    for index in range(count):
        env.action_manager.action = actions[index % 2]
        values = [getattr(mdp, name)(env) for name in helper.HISTORY]
    return values


with torch.inference_mode():
    for device in ('cpu', 'cuda:0'):
        for batch in (1, 1024, 4096, 16384):
            actions = [helper.random_matrix(batch, 14, torch.float32, device, seed) for seed in (820, 821)]
            envs = [helper.history_environment(batch, torch.float32, device, 0, 822) for _ in versions]
            for (mdp, _), env in zip(versions, envs, strict=True):
                execute(mdp, env, actions, 40)
            timings = [[], []]
            device_timings = [[], []]
            for pair in range(7):
                outputs = [None, None]
                for side in ((0, 1) if pair % 2 == 0 else (1, 0)):
                    if device.startswith('cuda'):
                        torch.cuda.synchronize()
                        first, last = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
                        first.record()
                    start = time.perf_counter()
                    outputs[side] = execute(versions[side][0], envs[side], actions, iterations)
                    if device.startswith('cuda'):
                        last.record()
                        last.synchronize()
                        device_timings[side].append(first.elapsed_time(last) * 1000 / iterations)
                    timings[side].append((time.perf_counter() - start) * 1e6 / iterations)
                for old, new in zip(*outputs, strict=True):
                    helper.exact(old, new, 'timed helper outputs')
            old_median, new_median = map(statistics.median, timings)
            row = {'device': device, 'batch': batch, 'dtype': 'torch.float32', 'pairs': 7,
                   'iterations_per_sample': iterations, 'host_us_before': timings[0], 'host_us_after': timings[1],
                   'host_median_us_before': old_median, 'host_median_us_after': new_median,
                   'host_median_ratio_after_before': new_median / old_median,
                   'cuda_event_us_before': device_timings[0], 'cuda_event_us_after': device_timings[1],
                   'outputs_bitwise_identical': True}
            rows.append(row)
            print(json.dumps({'device': device, 'batch': batch, 'old_us': old_median,
                              'new_us': new_median, 'ratio': new_median / old_median}), flush=True)
result = {'status': 'passed', 'scope': __doc__, 'torch': torch.__version__, 'helpers': list(helper.HISTORY), 'results': rows,
          'limits': 'Seven alternating-order pairs with warm caches while the sustained workloads share the same CPU/GPU. Samples include four helpers and action pointer selection; CUDA host times synchronize completion. These are local observations, not end-to-end training throughput guarantees.'}
(WORK / 'call-cost.json').write_text(json.dumps(result, indent=2) + '\n')
