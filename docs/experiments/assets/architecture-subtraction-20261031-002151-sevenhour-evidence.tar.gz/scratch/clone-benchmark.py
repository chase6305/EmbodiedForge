"""Measure clone payload/call counts; this is not a whole-process RSS benchmark."""
import importlib.util
import json
import sys
from pathlib import Path
from types import SimpleNamespace as NS

import torch
from torch.profiler import ProfilerActivity, profile

WORK = Path('/tmp/embodiedforge-subtraction-20261031-002151-sevenhour')
spec = importlib.util.spec_from_file_location('sevenhour_numeric_helpers', WORK / 'numerical-soak.py')
helper = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = helper
spec.loader.exec_module(helper)
torch.set_num_threads(1)
before, after = helper.modules()


def measured(operation):
    with profile(activities=[ProfilerActivity.CPU], profile_memory=True) as profiler:
        values = operation()
    events = [event for event in profiler.key_averages() if event.key == 'aten::clone']
    return {'clone_calls': sum(event.count for event in events),
            'cloned_payload_bytes': sum(event.cpu_memory_usage for event in events)}, values


results = []
for count in (4096, 65536):
    for dtype in (torch.float32, torch.float64):
        pairs = []
        for mdp, evaluator in (before, after):
            env = helper.history_environment(count, dtype, 'cpu', 0, 812)
            env.action_manager.action = helper.random_matrix(count, 14, dtype, 'cpu', 813)

            def step():
                return [getattr(mdp, name)(env) for name in helper.HISTORY]

            initial, initial_values = measured(step)
            env.action_manager.action = helper.random_matrix(count, 14, dtype, 'cpu', 814)
            steady, steady_values = measured(step)
            qpos = helper.random_matrix(count, 36, dtype, 'cpu', 815)
            qvel = helper.random_matrix(count, 35, dtype, 'cpu', 816)
            origins = helper.random_matrix(count, 3, dtype, 'cpu', 817)
            state_env = NS(sim=NS(data=NS(qpos=qpos, qvel=qvel)), origins=origins)
            snapshot, state = measured(lambda: evaluator.actual_state(state_env))
            pairs.append(({'history_initial': initial, 'history_steady': steady, 'state_snapshot': snapshot},
                          initial_values + steady_values + [state]))
        for old, new in zip(pairs[0][1], pairs[1][1], strict=True):
            helper.exact(old, new, 'profiler output')
        old, new = pairs[0][0], pairs[1][0]
        for phase in ('history_initial', 'history_steady'):
            assert old[phase]['clone_calls'] - new[phase]['clone_calls'] == 4
            assert old[phase]['cloned_payload_bytes'] - new[phase]['cloned_payload_bytes'] == count * 28 * torch.empty((), dtype=dtype).element_size()
        assert old['state_snapshot']['clone_calls'] == 1 and new['state_snapshot']['clone_calls'] == 0
        assert old['state_snapshot']['cloned_payload_bytes'] == count * 71 * torch.empty((), dtype=dtype).element_size()
        results.append({'batch': count, 'dtype': str(dtype), 'before': old, 'after': new,
                        'output_values_bitwise_identical': True})
reset_results = []
for name in ('reset_with_forward_velocity', 'set_random_crouch_state'):
    observations = []
    for mdp, _ in (before, after):
        env, writes = helper.reset_environment(mdp, 4096, torch.float32, 'cpu', 2, 818)
        ids = torch.arange(4096)[::2]
        torch.manual_seed(819)
        observation, _ = measured(lambda: getattr(mdp, name)(env, ids))
        observations.append(observation)
    assert observations[0]['clone_calls'] - observations[1]['clone_calls'] == (2 if name == 'reset_with_forward_velocity' else 1)
    reset_results.append({'operation': name, 'before': observations[0], 'after': observations[1]})
result = {'status': 'passed', 'scope': __doc__, 'torch': torch.__version__, 'device': 'cpu',
          'history_helpers_per_control_step': list(helper.HISTORY), 'results': results, 'reset_results': reset_results,
          'limits': 'Profiler CPU clone payload allocation sums, excluding input/cat/index allocations and retained histories. Synthetic batch sizes; no end-to-end training memory, RSS or throughput claim.'}
(WORK / 'clone-benchmark.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
