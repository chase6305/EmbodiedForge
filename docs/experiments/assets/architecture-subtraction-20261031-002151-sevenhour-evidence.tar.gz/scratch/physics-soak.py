"""Compare stateful reward helpers on actual mjlab/MuJoCo-Warp robot states."""
import argparse
import hashlib
import importlib.util
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace as NS

import torch
from mjlab.envs import ManagerBasedRlEnv
from mjlab.utils.torch import configure_torch_backends

from embodiedforge._microduck_worker import close_environment
from embodiedforge.locomotion.microduck.tasks.microduck_velocity_env_cfg import make_microduck_velocity_env_cfg

WORK = Path('/tmp/embodiedforge-subtraction-20261031-002151-sevenhour')
spec = importlib.util.spec_from_file_location('sevenhour_physics_helpers', WORK / 'numerical-soak.py')
helper = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = helper
spec.loader.exec_module(helper)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds', type=float, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(1)
    configure_torch_backends(allow_tf32=False)
    before, after = helper.modules()
    paths = [WORK / kind / name for kind in ('baseline', 'candidate') for name in (helper.MDP, helper.EVAL)]
    hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
    cfg = make_microduck_velocity_env_cfg(play=False)
    cfg.scene.num_envs = 32
    cfg.seed = 31281
    env = ManagerBasedRlEnv(cfg=cfg, device='cuda:0')
    counts = {key: 0 for key in ('steps', 'physics_transitions', 'reward_comparisons', 'history_comparisons',
                                'reset_events', 'reset_comparisons', 'state_comparisons', 'ownership_checks')}
    started_at = datetime.now(timezone.utc).isoformat()
    start, sampled = time.monotonic(), -30
    failures = []

    def publish(status):
        elapsed = time.monotonic() - start
        row = {'time': datetime.now(timezone.utc).isoformat(), 'seconds': elapsed,
               **helper.resources(), 'steps': counts['steps']}
        with (args.output / 'samples.jsonl').open('a') as stream:
            stream.write(json.dumps(row) + '\n')
        result = {'status': status, 'scope': __doc__, 'started_at': started_at,
                  'requested_seconds': args.seconds, 'seconds': elapsed, 'num_envs': 32,
                  'counts': counts, 'failures': failures, 'source_hashes': hashes,
                  'torch': torch.__version__, 'gpu': torch.cuda.get_device_name(), 'last_sample': row,
                  'limits': 'Actual 32-environment physics with small seeded random actions. Old/new stateful reward helpers use independent histories on the same physics states. State snapshot comparison centers the actual robot qpos/qvel. No trained actor or skill-quality claim.'}
        temporary = args.output / 'summary.json.tmp'
        temporary.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
        temporary.replace(args.output / 'summary.json')
        print(json.dumps({'status': status, **row, 'comparisons': counts['reward_comparisons']}), flush=True)

    try:
        env.reset()
        asset = env.scene['robot']
        defaults = asset.data.default_joint_pos.clone()
        proxies = [NS(num_envs=env.num_envs, device=env.device, scene=env.scene,
                      action_manager=NS(action=env.action_manager.action),
                      _prev_actuator_forces=asset.data.actuator_force.clone()) for _ in range(2)]
        generator = torch.Generator(device='cuda:0').manual_seed(31281)
        publish('running')
        with torch.inference_mode():
            while time.monotonic() - start < args.seconds:
                action = torch.randn(env.action_space.shape, device='cuda:0', generator=generator) * .05
                _, reward, terminated, truncated, _ = env.step(action)
                assert torch.isfinite(env.sim.data.qpos).all(), 'nonfinite actual qpos'
                assert torch.isfinite(reward).all(), 'nonfinite configured physics reward'
                for proxy in proxies:
                    proxy.action_manager.action = env.action_manager.action
                values = [[getattr(mdp, name)(proxy) for name in helper.HISTORY]
                          for (mdp, _), proxy in zip((before, after), proxies, strict=True)]
                for name, old, new in zip(helper.HISTORY, *values, strict=True):
                    helper.exact(old, new, 'physics:' + name)
                    counts['reward_comparisons'] += 1
                for name in helper.CACHES:
                    helper.exact(getattr(proxies[0], name), getattr(proxies[1], name), 'physics history:' + name)
                    counts['history_comparisons'] += 1
                ids = torch.nonzero(terminated | truncated, as_tuple=False).flatten()
                if len(ids):
                    for (mdp, _), proxy in zip((before, after), proxies, strict=True):
                        mdp.reset_action_history(proxy, ids)
                    for name in helper.CACHES + ('_prev_actuator_forces',):
                        helper.exact(getattr(proxies[0], name), getattr(proxies[1], name), 'physics reset:' + name)
                        counts['reset_comparisons'] += 1
                    counts['reset_events'] += len(ids)
                if counts['steps'] % 17 == 0:
                    owner = NS(sim=env.sim, origins=env.scene.env_origins)
                    initial_qpos, initial_qvel = env.sim.data.qpos.clone(), env.sim.data.qvel.clone()
                    old_state, new_state = before[1].actual_state(owner), after[1].actual_state(owner)
                    helper.exact(old_state, new_state, 'actual physics state snapshot')
                    old_state.fill_(99)
                    new_state.fill_(-99)
                    helper.exact(env.sim.data.qpos, initial_qpos, 'qpos snapshot ownership')
                    helper.exact(env.sim.data.qvel, initial_qvel, 'qvel snapshot ownership')
                    counts['state_comparisons'] += 1
                    counts['ownership_checks'] += 2
                helper.exact(asset.data.default_joint_pos, defaults, 'robot defaults retained')
                counts['steps'] += 1
                counts['physics_transitions'] += env.num_envs
                if time.monotonic() - start - sampled >= 30:
                    assert all(hashlib.sha256(path.read_bytes()).hexdigest() == hashes[str(path)] for path in paths)
                    publish('running')
                    sampled = time.monotonic() - start
                time.sleep(.05)
        assert counts['steps'] > 0 and counts['reward_comparisons'] == counts['steps'] * 4
        assert all(hashlib.sha256(path.read_bytes()).hexdigest() == hashes[str(path)] for path in paths)
        close_environment(env)
        env = None
        publish('complete')
    except BaseException as error:
        failures.append(repr(error))
        publish('failed')
        raise
    finally:
        if env is not None:
            close_environment(env)


if __name__ == '__main__':
    main()
