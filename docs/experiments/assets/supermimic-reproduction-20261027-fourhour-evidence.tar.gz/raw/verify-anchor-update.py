"""Independent functional Adam control: zero extra features retain the old update."""
import argparse,hashlib,json,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--anchor',type=Path,required=True);p.add_argument('--implementation',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();sys.path.insert(0,str(a.implementation.resolve()))
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
inputs={'source_checkpoint_sha256':sha(a.source),'anchor_checkpoint_sha256':sha(a.anchor)}
import torch
from supermimic.policy.nets import Policy,PolicyCfg,Critic,CriticCfg
torch.set_num_threads(1);original=torch.load(a.source,map_location='cpu',weights_only=False);augmented=torch.load(a.anchor,map_location='cpu',weights_only=False);torch.manual_seed(321);results={}
for section,optkey,insert in [('policy','policy_opt',680),('critic','critic_opt',751)]:
 old_cfg=PolicyCfg(**original['config']['policy']);new_cfg=PolicyCfg(**augmented['config']['policy'])
 if section=='policy':old,new=Policy(old_cfg),Policy(new_cfg)
 else:old,new=Critic(CriticCfg(**original['config']['critic']),pcfg=old_cfg),Critic(CriticCfg(**augmented['config']['critic']),pcfg=new_cfg)
 old.load_state_dict(original[section]);new.load_state_dict(augmented[section]);old.double();new.double();oldopt=torch.optim.Adam(old.parameters());newopt=torch.optim.Adam(new.parameters());oldopt.load_state_dict(original[optkey]);newopt.load_state_dict(augmented[optkey])
 goal=torch.randn(8,680,dtype=torch.float64);aug=torch.cat([goal,torch.zeros(8,9,dtype=torch.float64)],dim=-1)
 if section=='policy':obs=torch.randn(8,930,dtype=torch.float64);out_old=old(obs,goal);out_new=new(obs,aug)
 else:
  feat=torch.randn(8,71,dtype=torch.float64);xi=torch.randn(8,33,dtype=torch.float64);root=torch.randn(8,4,dtype=torch.float64);out_old=old(feat,goal,xi,root);out_new=new(feat,aug,xi,root)
 target=torch.randn_like(out_old);(out_old-target).square().mean().backward();(out_new-target).square().mean().backward();oldopt.step();newopt.step();maximum=0.;moment_error=0.;zero_columns=True
 for (name,x),(other,y) in zip(old.named_parameters(),new.named_parameters(),strict=True):
  assert name==other
  indices=torch.arange(x.shape[1]) if x.ndim==2 and x.shape!=y.shape else None
  if indices is not None:indices=indices+(indices>=insert)*9;projected=y[:,indices];zero_columns=zero_columns and not bool(torch.count_nonzero(y[:,insert:insert+9]))
  else:projected=y
  maximum=max(maximum,float((x-projected).abs().max().detach()))
  for key,v in oldopt.state[x].items():
   w=newopt.state[y][key]
   if isinstance(v,torch.Tensor):
    if indices is not None and v.shape==x.shape:w=w[:,indices]
    moment_error=max(moment_error,float((v-w).abs().max()))
 assert maximum<1e-10 and moment_error<1e-10 and zero_columns,(section,maximum,moment_error)
 results[section]={'max_old_parameter_error_after_adam':maximum,'max_old_optimizer_state_error':moment_error,'extra_columns_remained_zero':zero_columns}
assert inputs=={'source_checkpoint_sha256':sha(a.source),'anchor_checkpoint_sha256':sha(a.anchor)}
proof={**inputs,'status':'complete','dtype':'float64','device':'cpu','results':results,'scope':'One real Adam step with all9newfeatureszero. This checks old-parameter/moment projection, not learning equivalence with nonzero anchors or restored RNG.'};a.output.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
