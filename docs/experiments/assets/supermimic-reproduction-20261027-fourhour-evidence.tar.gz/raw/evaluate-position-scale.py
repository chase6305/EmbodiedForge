"""Evaluate a trusted local checkpoint against its frozen upstream implementation."""
import argparse,hashlib,json,math,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--implementation',type=Path,required=True);p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--motions',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--expected-iteration',type=int);p.add_argument('--anchor-position-scale',type=float,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(a.implementation.resolve()))
import supermimic,torch
from supermimic.eval.benchmark import load_policy_from_checkpoint,run_benchmark,save_results,summarize
from supermimic.envs.mdp.motion_library import discover_npz
assert Path(supermimic.__file__).resolve().is_relative_to(a.implementation.resolve())
torch.set_num_threads(1)
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
checkpoint_sha=sha(a.checkpoint);checkpoint=torch.load(a.checkpoint,map_location='cpu',weights_only=False);iteration=checkpoint['iteration'];updates=checkpoint['num_updates'];assert a.expected_iteration is None or iteration==a.expected_iteration;del checkpoint;model,cfg=load_policy_from_checkpoint(a.checkpoint,'cuda:0');assert cfg['env'].get('anchor_obs',False) and cfg['policy']['goal_dim']==689 and math.isfinite(a.anchor_position_scale) and a.anchor_position_scale>0
with torch.no_grad():model.encoders['motion'].scale[-9:-6].mul_(a.anchor_position_scale)
files=discover_npz(a.motions);assert len(files)==40
started=time.monotonic();rows=run_benchmark(model,[str(f) for f in files],device='cuda:0',num_envs=40,future_frames=cfg['env']['future_frames'],anchor_obs=cfg['env'].get('anchor_obs',False));assert len(rows)==40 and all(math.isfinite(x.norm_return) for x in rows)
save_results(rows,a.output/'evaluation.json');summary=summarize(rows);summary['full_clip_zero_padded_return']=sum(x.norm_return*x.steps for x in rows)/sum(x.frames for x in rows);summary['raw_steps_to_nominal_frames']=sum(x.steps for x in rows)/sum(x.frames for x in rows);summary['completed_frames_fraction']=sum(min(x.steps,x.frames) for x in rows)/sum(x.frames for x in rows);assert sha(a.checkpoint)==checkpoint_sha
proof={'test_time_anchor_position_scale':a.anchor_position_scale,'iteration':iteration,'updates':updates,'status':'complete','summary':summary,'seconds':time.monotonic()-started,'checkpoint_sha256':checkpoint_sha,'anchor_obs':cfg['env'].get('anchor_obs',False),'goal_dim':cfg['policy']['goal_dim'],'source_package':str(Path(supermimic.__file__).resolve()),'scope':'Exploratory test-time anchor-position scaling on the same40training clips; no retraining or checkpoint modification. Fixed upstreamseed0 settings. Repeats are fresh-process repeatability checks, not held-out generalization.'}
(a.output/'result.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof),flush=True)
