"""Select common steps before reading quality, then evaluate in balanced order."""
import copy,datetime,hashlib,json,os,statistics,subprocess,sys,time
from pathlib import Path
r=Path(__file__).parent;repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');run=repo/'runs/supermimic-reproduction-20261027-fourhour';sdk=repo/'.cache/external/supermimic-reproduced/.venv/bin/python';motions=run/'recovered-motions';names=('paper-resume','anchor-resume')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
while True:
 observations=[r/'tool-observations'/f'{n}.json' for n in names]
 if all(p.is_file() for p in observations):
  assert [json.loads(p.read_text())['actual_tool_exit'] for p in observations]==[0,1]
  break
 assert datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat('2026-10-27T07:55:00+00:00'),'Training jobs not observed closed in time'
 time.sleep(15)
for name in names:
 d=json.loads((run/name/'result.json').read_text());s=json.loads((run/(name+'-supervisor')/'result.json').read_text());expected_exit=0 if name=='paper-resume' else 1;assert s['exit_observed'] and s['process_returncode']==expected_exit and not s['timed_out'];assert d['status']==('complete' if expected_exit==0 else 'failed');assert expected_exit==0 or d.get('error')=='Motion content changed during this run'
training_records={name:json.loads((run/name/'result.json').read_text()) for name in names}
def scrub(cfg):
 cfg=copy.deepcopy(cfg);cfg.pop('log_root');cfg.pop('resume');cfg['env'].pop('anchor_obs');cfg['policy'].pop('goal_dim');cfg['policy_trainer'].pop('anchor_obs');return cfg
assert scrub(training_records[names[0]]['configuration'])==scrub(training_records[names[1]]['configuration'])
assert training_records[names[0]]['environment']==training_records[names[1]]['environment']
assert training_records[names[0]]['implementation_manifest']==training_records[names[1]]['implementation_manifest']
assert training_records[names[0]]['motion_files']==training_records[names[1]]['motion_files']
motion_files=training_records[names[0]]['motion_files']
assert len(motion_files)==40 and all(sha(motions/name)==value for name,value in motion_files.items())
iterations=[]
for name in names:iterations.append({int(p.stem.split('_')[-1]) for p in (run/name/'training').glob('ckpt_[0-9]*.pt')})
common=max(set.intersection(*iterations));assert common>10400
selected={name:run/name/'training'/f'ckpt_{common:07d}.pt' for name in names};selection={'rule':'Largest common saved iteration, selected before reading any common-evaluation quality values','iteration':common,'checkpoints':{n:{'path':str(p),'sha256':sha(p)} for n,p in selected.items()},'at':datetime.datetime.now(datetime.timezone.utc).isoformat()};(r/'matched-selection.json').write_text(json.dumps(selection,indent=2)+'\n')
env=os.environ.copy();env.pop('PYTHONPATH',None);env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1');helper_hash=sha(r/'evaluate.py');records={}
def evaluate(label,condition,checkpoint,expected):
 implementation=run/condition/'implementation'
 command=[sys.executable,str(repo/'benchmarks/process_supervisor.py'),'--output',str(run/(label+'-supervisor')),'--timeout','600','--grace','30','--',str(sdk),'-I','-X','faulthandler',str(r/'evaluate.py'),'--implementation',str(implementation),'--checkpoint',str(checkpoint),'--motions',str(motions),'--output',str(run/label),'--expected-iteration',str(expected)]
 with (r/(label+'-outer.log')).open('x') as log:child=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'label':label,'condition':condition,'supervisor_wait_returncode':child.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (r/'comparison-exits.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 assert child.returncode==0,row
 outer=json.loads((run/(label+'-supervisor')/'result.json').read_text());assert outer['exit_observed'] and outer['process_returncode']==0 and outer['completed_successfully'] and not outer['timed_out']
 result=json.loads((run/label/'result.json').read_text());assert result['status']=='complete' and result['iteration']==expected
 assert result['checkpoint_sha256']==sha(checkpoint)
 assert result['anchor_obs']==(condition=='anchor-resume') and result['goal_dim']==(689 if condition=='anchor-resume' else 680)
 records[label]={'condition':condition,'result':result,'supervisor':outer,'driver_observed_wait':row}
for kind in ('matched','initial'):
 for repeat in range(1,4):
  order=names if repeat%2 else tuple(reversed(names))
  for condition in order:
   if kind=='initial' and datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat('2026-10-27T08:00:00+00:00'):break
   label=f'{kind}-{condition}-r{repeat}'
   checkpoint=selected[condition] if kind=='matched' else repo/'runs/supermimic-reproduction-20261026/lafan-training/training/ckpt_latest.pt' if condition=='paper-resume' else run/'anchor-init/anchor-initial.pt'
   evaluate(label,condition,checkpoint,common if kind=='matched' else 10400)
assert sha(r/'evaluate.py')==helper_hash
assert all(sha(motions/name)==value for name,value in motion_files.items())
aggregate={}
for kind in ('matched','initial'):
 aggregate[kind]={}
 for condition in names:
  values=[x for label,x in records.items() if label.startswith(kind+'-'+condition+'-')];summaries=[x['result']['summary'] for x in values]
  stats={}
  for metric in ('failed','mean_norm_return','step_weighted_norm_return','full_clip_zero_padded_return','completed_frames_fraction'):
   nums=[x[metric] for x in summaries]
   if nums:stats[metric]={'mean':statistics.mean(nums),'min':min(nums),'max':max(nums),'median':statistics.median(nums)}
  clip_rows=[json.loads((run/label/'evaluation.json').read_text())['clips'] for label,x in records.items() if label.startswith(kind+'-'+condition+'-')]
  if clip_rows:
   by_name={row['name']:[] for row in clip_rows[0]}
   for rows in clip_rows:
    assert {x['name'] for x in rows}==set(by_name)
    for row in rows:by_name[row['name']].append(row)
   per_clip={name:{'failed_repeats':sum(x['failed'] for x in rows),'mean_return':statistics.mean(x['norm_return'] for x in rows),'min_return':min(x['norm_return'] for x in rows),'max_return':max(x['norm_return'] for x in rows),'frames':rows[0]['frames']} for name,rows in by_name.items()}
  else:per_clip={}
  aggregate[kind][condition]={'repeats':len(values),'metrics':stats,'per_clip':per_clip,'scope':'Fresh-process fixedseed0 evaluation repeats, not independent training seeds or generalization.'}
assert all(aggregate['matched'][n]['repeats']==3 for n in names)
assert len({x['result']['updates'] for label,x in records.items() if label.startswith('matched-')})==1
proof={'training_integrity_status':{'paper-resume':'accepted original run actual0','anchor-resume':'quarantined original run actual1: terminal motion-integrity failure; checkpoint evaluations separately accepted only on recovered exact-original inputs'},'motion_recovery':json.loads((r/'motion-recovery.json').read_text()),'recovered_motion_snapshot':json.loads((r/'recovered-motion-snapshot.json').read_text()),'motion_files_verified':motion_files,'non_observation_hyperparameters_matched':True,'framework_and_source_manifests_matched':True,'stage':'complete','selection':selection,'evaluations':records,'aggregate':aggregate,'evaluation_helper_sha256':helper_hash,'scope':'One training seed per condition. Shared physical GPU during training; inputs and optimizer initial projections checked, but RNG/replay trajectories differ. Matched iteration and optimizer-update counts, balanced evaluation order. Anchor condition changes the paper observation protocol.'}
(r/'comparison.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'stage':'comparison_complete','matched_iteration':common,'evaluations_closed':len(records),'matched_failed':{n:aggregate['matched'][n]['metrics']['failed'] for n in names}}),flush=True)
