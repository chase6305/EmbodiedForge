import datetime,hashlib,json,re,subprocess
from pathlib import Path
r=Path(__file__).parent;repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');run=repo/'runs/supermimic-reproduction-20261027-fourhour'
source=json.loads((r/'source-hashes.json').read_text());history=json.loads((r/'history-hashes.json').read_text())
for name,expected in {**source,**history}.items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==expected,name
for name,expected in source.items():assert hashlib.sha256((r/'final'/name).read_bytes()).hexdigest()==expected,name
motion_checks={}
for label,root in [('restored-cache',repo/'.cache/external/supermimic-reproduced/data/npz/lafan1'),('recovered-evaluation-snapshot',run/'recovered-motions')]:
 if root.is_dir():
  inputs=json.loads((run/'paper-resume/result.json').read_text())['motion_files']
  bad=[name for name,expected in inputs.items() if hashlib.sha256((root/name).read_bytes()).hexdigest()!=expected]
  motion_checks[label]={'files':len(inputs),'mismatches':bad};assert not bad,(label,bad)
profiles={}
for name,plan in json.loads((r/'plan.json').read_text()).items():
 log=run/(name+'-supervisor')/'command.log';lines=log.read_text(errors='replace').splitlines();progress=next((x for x in reversed(lines) if x.startswith('it ')),None);resource={}
 pid=plan['identities']['worker']['pid'];proc=Path('/proc')/str(pid)
 try:
  parts=(proc/'stat').read_text().split(') ',1)[1].split();assert int(parts[19])==plan['identities']['worker']['start_ticks'];status=dict(x.split(':',1) for x in (proc/'status').read_text().splitlines());resource={'rss_bytes':int(status['VmRSS'].split()[0])*1024,'fds':len(list((proc/'fd').iterdir())),'threads':int(status['Threads'])}
 except (FileNotFoundError,ProcessLookupError):resource={'worker_gone':True}
 summary=run/name/'result.json';d=json.loads(summary.read_text()) if summary.exists() else {};profiles[name]={'progress':progress,'stage':d.get('status'),'resource':resource,'evaluation':d.get('evaluation')}
q=subprocess.run(['nvidia-smi','--query-gpu=memory.used,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10);gpu=q.stdout.strip() if q.returncode==0 else None
value={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_files_verified':len(source),'history_reports_verified':len(history),'motion_input_checks':motion_checks,'profiles':profiles,'global_shared_gpu_memory_used_free_MiB_util_percent':gpu}
if not (r/'archive-freeze').exists():
 (r/'latest-health.json').write_text(json.dumps(value,indent=2)+'\n')
 with (r/'health.jsonl').open('a') as f:f.write(json.dumps(value)+'\n')
print(json.dumps({'at':value['at'],'profiles':{n:{'progress':x['progress'],'stage':x['stage']} for n,x in profiles.items()},'shared_gpu':gpu,'source_files_verified':len(source)}))
