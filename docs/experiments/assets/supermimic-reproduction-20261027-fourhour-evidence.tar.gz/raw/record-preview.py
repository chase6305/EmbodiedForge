"""Local-only simulator footage with a translucent reference; no dataset export."""
import argparse,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--implementation',type=Path,required=True);p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--motions',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--seconds',type=float,default=12);p.add_argument('--label',default='Local reproduction');a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);sys.path.insert(0,str(a.implementation.resolve()))
import mujoco,numpy as np,torch
from PIL import Image,ImageDraw
from supermimic.data.motion_convert import g1_xml_path
from supermimic.envs import SuperMimicEnvCfgArgs,make_env
from supermimic.envs.state_io import StateIO
from supermimic.eval.benchmark import load_policy_from_checkpoint
torch.set_num_threads(1);policy,cfg=load_policy_from_checkpoint(a.checkpoint,'cuda:0');clip=a.motions/'walk1_subject1.npz';assert clip.exists()
env=make_env(SuperMimicEnvCfgArgs(npz_files=[str(clip)],num_envs=1,future_frames=cfg['env']['future_frames'],episode_length_s=1e5,action_noise_std=0.,obs_noise=False,reset_noise=False,domain_randomization=False,sampling_mode='start',record_transitions=False,seed=0,anchor_obs=cfg['env'].get('anchor_obs',False)),device='cuda:0')
poses=[];failed=False;ended_at=None
try:
 command=env.command_manager.get_term('motion');command.forced_frame[:]=command.library.clip_start[0];obs,_=env.reset();io=StateIO(env)
 with torch.no_grad():
  for step in range(int(a.seconds*50)+1):
   if step%10==0:
    qpos=io.read()[0,:36].cpu().numpy().copy();reference=command.library.ref(command.frame);reference_q=torch.cat([reference.root_pos_w[0],reference.root_quat_w[0],reference.joint_pos[0]]).cpu().numpy().copy();assert np.isfinite(qpos).all() and np.isfinite(reference_q).all();poses.append((step/50,qpos,reference_q))
   if step==int(a.seconds*50):break
   action=policy(obs['policy'],obs['goal']);obs,_,term,tout,_=env.step(action)
   if bool(term[0]) or bool(tout[0]):failed=bool(term[0]);ended_at=(step+1)/50;break
finally:env.close()
spec=mujoco.MjSpec.from_file(str(g1_xml_path()));spec.worldbody.add_geom(type=mujoco.mjtGeom.mjGEOM_PLANE,size=[30,30,.1],rgba=[.88,.89,.9,1]);spec.worldbody.add_light(pos=[0,0,5],dir=[0,0,-1],type=mujoco.mjtLightType.mjLIGHT_DIRECTIONAL);model=spec.compile();data=mujoco.MjData(model);reference_data=mujoco.MjData(model);camera=mujoco.MjvCamera();camera.azimuth=135;camera.elevation=-18;option=mujoco.MjvOption();ghost=mujoco.MjvScene(model,maxgeom=10000);target=a.output/'preview.mp4';command=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','480x360','-r','5','-i','pipe:0','-an','-c:v','libx264','-pix_fmt','yuv420p',str(target)]
with (a.output/'ffmpeg.log').open('x') as log:
 encoder=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT)
 try:
  with mujoco.Renderer(model,height=360,width=480,max_geom=10000) as renderer:
   for index,(time_value,q,qr) in enumerate(poses):
    data.qpos[:]=q;reference_data.qpos[:]=qr;mujoco.mj_forward(model,data);mujoco.mj_forward(model,reference_data);camera.lookat[:]=(q[:3]+qr[:3])/2;camera.distance=max(3.,float(np.linalg.norm(q[:3]-qr[:3]))*1.4+1.8);renderer.update_scene(data,camera=camera,scene_option=option);mujoco.mjv_updateScene(model,reference_data,option,None,camera,mujoco.mjtCatBit.mjCAT_DYNAMIC,ghost);scene=renderer.scene
    for g in ghost.geoms[:ghost.ngeom]:
     dst=scene.geoms[scene.ngeom];mujoco.mjv_initGeom(dst,g.type,np.asarray(g.size,dtype=np.float64),np.asarray(g.pos,dtype=np.float64),np.asarray(g.mat,dtype=np.float64).reshape(9),np.array([.15,.55,.95,.30],dtype=np.float32));dst.dataid=g.dataid;dst.category=mujoco.mjtCatBit.mjCAT_DECOR;scene.ngeom+=1
    image=Image.fromarray(renderer.render());draw=ImageDraw.Draw(image);draw.rectangle((0,0,480,38),fill='white');draw.text((8,5),f'{a.label} | t={time_value:.2f}s',fill='black');draw.text((8,21),'Solid: policy   Blue: reference   Local research footage',fill='black')
    if index==0:image.save(a.output/'first-frame.png')
    encoder.stdin.write(image.tobytes())
 finally:encoder.stdin.close()
 assert encoder.wait(timeout=30)==0
result={'status':'complete','clip':'walk1_subject1','seconds_requested':a.seconds,'frames_rendered':len(poses),'last_recorded_time':poses[-1][0],'terminated':failed,'done_time':ended_at,'anchor_obs':cfg['env'].get('anchor_obs',False),'scope':'Fixed clip illustration only. Rendering uses actual simulator qpos. Auto-reset terminal state is excluded; footage and derived trajectories remain local and are not part of the public evidence archive.'};(a.output/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
