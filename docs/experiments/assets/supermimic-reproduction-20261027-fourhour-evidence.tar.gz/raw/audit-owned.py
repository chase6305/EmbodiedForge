"""Read-only check of owned worker identities and remaining run-prefix processes."""
import datetime,json,os
from pathlib import Path
r=Path(__file__).parent;repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');relative='runs/supermimic-reproduction-20261027-fourhour';absolute=str(repo/relative);plan=json.loads((r/'plan.json').read_text());ancestors=set();pid=os.getpid()
while pid>1:
 ancestors.add(pid)
 try:pid=int((Path('/proc')/str(pid)/'stat').read_text().split(') ',1)[1].split()[1])
 except (FileNotFoundError,ProcessLookupError):break
identities=[]
for name,entry in plan.items():
 for role,v in entry['identities'].items():
  try:now=int((Path('/proc')/str(v['pid'])/'stat').read_text().split(') ',1)[1].split()[19])
  except (FileNotFoundError,ProcessLookupError):now=None
  identities.append({'profile':name,'role':role,**v,'same_owned_process_alive':now==v['start_ticks']})
remaining=[]
for d in Path('/proc').iterdir():
 if not d.name.isdigit() or int(d.name) in ancestors:continue
 try:argv=(d/'cmdline').read_bytes().split(b'\0');parts=(d/'stat').read_text().split(') ',1)[1].split()
 except (FileNotFoundError,PermissionError,ProcessLookupError):continue
 if any(x.startswith((relative+'/').encode()) or x.startswith((absolute+'/').encode()) for x in argv):remaining.append({'pid':int(d.name),'start_ticks':int(parts[19]),'state':parts[0]})
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'identities':identities,'remaining_run_prefix_processes':remaining,'all_recorded_workers_gone':not any(x['same_owned_process_alive'] for x in identities),'scope':'Read-only PID/start-tick and run-namespace argv-prefix check; current audit ancestors excluded. No signals or environment collection.'};(r/'ownership-audit.json').write_text(json.dumps(result,indent=2)+'\n');assert result['all_recorded_workers_gone'] and not remaining,result;print(json.dumps({'owned_workers_remaining':0,'identities':len(identities)}))
