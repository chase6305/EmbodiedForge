"""Inspect a trusted local checkpoint and export metadata; not a robot approval."""
import argparse,json,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');sys.path.insert(0,str(repo/'src'));sys.path.insert(0,str((a.run/'implementation').resolve()))
from embodiedforge.runtime.hashing import snapshot_file_hashes
from embodiedforge.runtime.artifacts import write_json
from embodiedforge.supermimic import validate_contract
import torch,mujoco
from supermimic.data.motion_convert import load_g1_model
from supermimic.envs import SuperMimicEnvCfgArgs,make_env_cfg
sha=snapshot_file_hashes(a.checkpoint)[0];ck=torch.load(a.checkpoint,map_location='cpu',weights_only=False);cfg=ck['config'];source=json.loads((a.run/'result.json').read_text())['source'];model=load_g1_model();names=[mujoco.mj_id2name(model,mujoco.mjtObj.mjOBJ_JOINT,i) for i in range(1,model.njnt)];assert len(names)==29
weights=ck['policy'];history=cfg['policy']['history'];assert weights['decoder.scale'].numel()==history*93
assert weights['encoders.motion.scale'].numel()==cfg['policy']['goal_dim']
last=max((k for k in weights if k.startswith('decoder.mlp.net.') and k.endswith('.weight')),key=lambda k:int(k.split('.')[3]));assert weights[last].shape[0]==29
npz_dir=Path(cfg['data']['npz_dir']);env_cfg=make_env_cfg(SuperMimicEnvCfgArgs(npz_files=[str(next(npz_dir.glob('*.npz')))],num_envs=1));hz=1/(env_cfg.sim.mujoco.timestep*env_cfg.decimation);assert hz==50
contract={'schema':'ef-supermimic-contract-v1','backend':'cuboi-reproduced','source_revision':source['revision'],'checkpoint_sha256':sha,'robot':'unitree-g1-29dof','control_hz':int(hz),'action_dim':29,'history_frames':history,'future_frames':cfg['env']['future_frames'],'observation_dim':93,'observation_layout':'term-major','goal_dim':cfg['policy']['goal_dim'],'anchor_obs':cfg['env']['anchor_obs'],'joint_names':names}
validate_contract(contract,'cuboi-reproduced',sha);assert snapshot_file_hashes(a.checkpoint)[0]==sha;a.output.parent.mkdir(parents=True,exist_ok=True);write_json(a.output,contract);print(json.dumps({'exported':str(a.output),'goal_dim':contract['goal_dim'],'actual_tensor_widths_inspected':True,'joint_order_read_from_model':True,'scope':'Metadata export for a trusted locally trained checkpoint; no hardware compatibility claim.'}))
