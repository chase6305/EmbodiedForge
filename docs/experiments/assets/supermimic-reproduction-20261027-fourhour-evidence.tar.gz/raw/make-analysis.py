"""Derive labelled training diagnostics and matched-step coverage from raw files."""
import argparse,csv,json,math,re
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--final',action='store_true');a=p.parse_args();r=Path(__file__).parent;repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');run=repo/'runs/supermimic-reproduction-20261027-fourhour'
number=r'(?:[-+0-9.eE]+|nan)';pattern=re.compile(r'^it (\d+) \| ('+number+r') h \| ('+number+r') it/s \| updates (\d+) \| train_ret ('+number+r') .*?wm nse1 ('+number+r') nse8 ('+number+r') \| imag_ret ('+number+r') surv ('+number+r')')
curves={}
for name in ('paper-resume','anchor-resume'):
 rows=[]
 for line in (run/(name+'-supervisor')/'command.log').read_text(errors='replace').splitlines():
  m=pattern.search(line)
  if m:
   v=m.groups();row=dict(zip(('iteration','hours','iterations_per_second','updates','training_return','wm_nse1','wm_nse8','imag_return','imag_survival'),[float(x) for x in v]));row['iteration']=int(row['iteration']);row['updates']=int(row['updates']);rows.append(row)
 curves[name]=rows
 fields=list(next(iter(curves.values()))[0])
 with (r/(name+'-curve.csv')).open('w',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)
if a.final:
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,axes=plt.subplots(1,2,figsize=(10,3.8),layout='constrained')
 for name,color in [('paper-resume','#335caa'),('anchor-resume','#d67927')]:
  rows=curves[name];x=[v['iteration'] for v in rows];label='680 goal: paper observations' if name.startswith('paper') else '689 goal: anchor experiment'
  axes[0].plot(x,[v['training_return'] for v in rows],color=color,label=label,alpha=.75,lw=1)
  axes[1].plot(x,[v['wm_nse8'] for v in rows],color=color,label=label,alpha=.75,lw=1)
 axes[0].set(ylabel='Sampled training episode return',xlabel='Global environment iterations',title='Training diagnostics (not benchmark scores)')
 axes[1].set(ylabel='8-step recent-replay error',xlabel='Global environment iterations',yscale='log',title='Different on-policy replay distributions')
 fig.suptitle('Anchor training quarantined: terminal input-integrity check failed (exit 1)',fontsize=10)
 for ax in axes:ax.grid(alpha=.2);ax.legend(fontsize=8)
 for ext in ('svg','png'):fig.savefig(r/('training-diagnostics.'+ext),dpi=140)
 plt.close(fig)
 if (r/'comparison.json').exists():
  comparison=json.loads((r/'comparison.json').read_text());aggregate=comparison['aggregate']['matched'];fig,axes=plt.subplots(1,3,figsize=(10.5,3.6),layout='constrained');names=['paper-resume','anchor-resume'];labels=['Original680','Anchor689*']
  for ax,metric,title,limit in zip(axes,['failed','mean_norm_return','full_clip_zero_padded_return'],['Failed clips (lower better)','Surviving-step return','Full-clip zero-padded return'],[40,1,1],strict=True):
   values=[aggregate[n]['metrics'][metric] for n in names];means=[v['mean'] for v in values];errors=[[v['mean']-v['min'] for v in values],[v['max']-v['mean'] for v in values]];ax.bar(labels,means,color=['#335caa','#d67927'],yerr=errors,capsize=4,width=.55);ax.set_ylim(0,limit);ax.set_title(title,fontsize=10);ax.grid(axis='y',alpha=.2)
  fig.suptitle(f"Matched iteration {comparison['selection']['iteration']}; 3 fixed-seed inference repeats on recovered inputs\n*Anchor training terminal-integrity failure preserved (exit 1); one training seed",fontsize=10)
  for ext in ('svg','png'):fig.savefig(r/('coverage-comparison.'+ext),dpi=140)
  plt.close(fig)
print(json.dumps({'training_log_points':{n:len(v) for n,v in curves.items()},'final_plot_created':a.final}))
