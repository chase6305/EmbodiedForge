"""Inspect matched local models and run the existing metadata-only CLI."""
import datetime,json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).parent;repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');run=repo/'runs/supermimic-reproduction-20261027-fourhour';backend=repo/'.cache/external/supermimic-reproduced';sdk=backend/'.venv/bin/python';selection=json.loads((r/'matched-selection.json').read_text());records=[]
for short in ('paper','anchor'):
 condition=short+'-resume';checkpoint=selection['checkpoints'][condition]['path'];contract=run/f'contracts/common-{short}.json'
 commands=[('export',[str(sdk),'-I',str(r/'export-contract.py'),'--run',str(run/condition),'--checkpoint',checkpoint,'--output',str(contract)]),('preflight',[sys.executable,'-m','embodiedforge','supermimic','preflight','--backend','cuboi-reproduced','--root',str(backend),'--python',str(sdk),'--checkpoint',checkpoint,'--contract',str(contract),'--motions',str(backend/'data/npz/lafan1'),'--output',str(run/f'preflight-common-{short}')])]
 for kind,command in commands:
  env=os.environ.copy();env.update(PYTHONPATH=str(repo/'src'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
  with (r/f'{kind}-common-{short}.log').open('x') as f:child=subprocess.run(command,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
  record={'condition':condition,'kind':kind,'command':command,'observed_wait_returncode':child.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()};records.append(record);(r/'contract-preflight-exits.json').write_text(json.dumps(records,indent=2)+'\n');assert child.returncode==0,record
 d=json.loads(contract.read_text());assert d['checkpoint_sha256']==selection['checkpoints'][condition]['sha256'] and d['goal_dim']==(680 if short=='paper' else 689)
 result=json.loads((run/f'preflight-common-{short}/result.json').read_text());assert result['prerequisites_passed'] and result['status']=='complete' and result['inference_executed'] is False
print(json.dumps({'actual_wait_codes':[x['observed_wait_returncode'] for x in records],'models':2,'metadata_only_cli_preserved':True}))
