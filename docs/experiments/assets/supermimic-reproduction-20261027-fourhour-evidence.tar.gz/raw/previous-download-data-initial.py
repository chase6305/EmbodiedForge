import concurrent.futures,hashlib,json,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parent; dest=Path('.cache/external/supermimic-reproduced/data/raw/lafan1');dest.mkdir(parents=True,exist_ok=True)
base='https://huggingface.co';dataset='lvhaidong/LAFAN1_Retargeting_Dataset'
def get(url):
 with urllib.request.urlopen(url,timeout=60) as f:return f.read()
info=json.loads(get(f'{base}/api/datasets/{dataset}'));revision=info['sha'];tree=json.loads(get(f'{base}/api/datasets/{dataset}/tree/{revision}/g1?recursive=true&limit=1000'));files=[x['path'] for x in tree if x['type']=='file' and x['path'].endswith('.csv')];assert len(files)==40,len(files)
def download(name):
 p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);content=get(f'{base}/datasets/{dataset}/resolve/{revision}/{name}');p.write_bytes(content);return name,{'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:proof=dict(pool.map(download,files))
readme=get(f'{base}/datasets/{dataset}/resolve/{revision}/README.md');(dest/'README.upstream.md').write_bytes(readme)
(root/'data-source.json').write_text(json.dumps({'dataset':dataset,'revision':revision,'source_url':f'{base}/datasets/{dataset}','license':'CC-BY-NC-ND-4.0, as identified by dataset card; local research copy; no redistribution of CSV/derived arrays in report','files':proof},indent=2)+'\n');print(json.dumps({'downloaded_csv_files':len(proof),'bytes':sum(x['bytes'] for x in proof.values()),'revision':revision}),flush=True)
