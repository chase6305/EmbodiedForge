"""One verified evidence snapshot; keep weights, motions, SDKs and footage local."""
import datetime,hashlib,io,json,os,tarfile
from pathlib import Path
r=Path(__file__).parent;repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');run=repo/'runs/supermimic-reproduction-20261027-fourhour';old=repo/'runs/supermimic-reproduction-20261026';target=repo/'docs/experiments/assets/supermimic-reproduction-20261027-fourhour-evidence.tar.gz'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
for name in ('paper-resume','anchor-resume','comparison-retry','anchor-recovery-smoke','preview-pair'):
 assert json.loads((r/'tool-observations'/f'{name}.json').read_text())['actual_tool_exit']==(1 if name=='anchor-resume' else 0),name
comparison=json.loads((r/'comparison.json').read_text());assert comparison['stage']=='complete'
for name in ('paper-resume','anchor-resume'):
 value=json.loads((run/(name+'-supervisor')/'result.json').read_text());assert value['exit_observed'] and value['process_returncode']==(1 if name=='anchor-resume' else 0) and value['completed_successfully']==(name!='anchor-resume')
assert json.loads((r/'ownership-audit.json').read_text())['all_recorded_workers_gone']
for name,expected in json.loads((r/'source-hashes.json').read_text()).items():assert sha(repo/name)==expected
for name,expected in json.loads((r/'history-hashes.json').read_text()).items():assert sha(repo/name)==expected
files={}
def add(name,p):
 assert name not in files and p.is_file() and not p.is_symlink(),name
 files[name]=p
for folder in ('baseline','final'):
 for p in (r/folder).rglob('*'):
  if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts:add(p.relative_to(r).as_posix(),p)
exclude={'archive-integrity.json','final-integrity.json','report-draft.json','publication-proof.json','archive-build.log','post-staging.log'}
for p in r.iterdir():
 if p.is_file() and not p.is_symlink() and p.suffix in ('.json','.jsonl','.py','.log','.xml','.patch','.txt','.svg','.png') and p.name not in exclude:add('raw/'+p.name,p)
for p in [*r.glob('*-curve.csv'),*r.glob('matched-clip-diagnostics.csv')]:add('raw/'+p.name,p)
for p in (r/'tool-observations').glob('*.json'):add('raw/tool-observations/'+p.name,p)
# These two run trees contain only metadata, source snapshots and generated models.
# Select file types explicitly; no weights, trajectories, meshes or footage.
for label,root in [('current',run),('previous',old)]:
 for p in root.rglob('*'):
  if not p.is_file() or p.is_symlink() or '__pycache__' in p.parts:continue
  if p.suffix not in ('.json','.jsonl','.log','.xml','.py','.txt','.patch','.lock'):continue
  add('runs/'+label+'/'+p.relative_to(root).as_posix(),p)
for name in ('docs/supermimic.md','docs/experiments/README.md','docs/experiments/supermimic-reproduction-20261026.json'):
 add('guides/'+Path(name).name,repo/name)
license=repo/'.cache/external/supermimic-reproduced/LICENSE';add('upstream/LICENSE',license)
if (repo/'LICENSE').is_file():add('host/LICENSE',repo/'LICENSE')
manifest={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in sorted(files.items())};payload=(json.dumps(manifest,indent=2)+'\n').encode();assert not target.exists();temporary=target.with_suffix('.gz.building');assert not temporary.exists()
with tarfile.open(temporary,'w:gz',compresslevel=1) as t:
 info=tarfile.TarInfo('MANIFEST.json');info.size=len(payload);t.addfile(info,io.BytesIO(payload))
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
seen=set()
with tarfile.open(temporary,'r:gz') as t:
 for member in t:
  assert member.isfile() and member.name not in seen;seen.add(member.name);f=t.extractfile(member);h=hashlib.sha256();size=0
  for b in iter(lambda:f.read(1048576),b''):h.update(b);size+=len(b)
  expected={'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()} if member.name=='MANIFEST.json' else manifest[member.name]
  assert expected=={'bytes':size,'sha256':h.hexdigest()},member.name
assert seen==set(manifest)|{'MANIFEST.json'};os.replace(temporary,target)
proof={'path':str(target.relative_to(repo)),'bytes':target.stat().st_size,'sha256':sha(target),'manifest_sha256':hashlib.sha256(payload).hexdigest(),'verified_files':len(manifest),'all_members_decompressed_and_hashed':True,'built_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Source versions, MIT notice, model/input identities, logs, closed supervision records, matched evaluations and scalar plots/curves. Includes failed controls, the original143waiter, and the quarantined anchor terminal input-integrity failure. Excludes all model binaries, original/derived motion arrays, meshes, SDK installations, Git metadata, cores, video and preview frames. Current final report/index excluded to avoid circular hashes.'}
(r/'archive-integrity.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
