import json,sys,hashlib,zipfile,datetime,os,shutil
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;run=repo/'runs/supermimic-reproduction-20261027-fourhour';sys.path.insert(0,str(run/'anchor-resume/implementation'))
import numpy as np
from supermimic.data.motion_convert import convert_csv_to_npz
path=repo/'.cache/external/supermimic-reproduced/data/npz/lafan1/sprint1_subject2.npz';saved=run/'motion-integrity/sprint1_subject2-corrupt.npz';out=run/'motion-integrity/sprint1_subject2-regenerated.npz'
with np.load(saved) as d:csv=str(d['source']);fps=float(d['input_fps'][0])
print('source',csv,flush=True)
if not Path(csv).is_absolute():os.chdir(repo/'.cache/external/supermimic-reproduced')
result=convert_csv_to_npz(csv,out,input_fps=fps,output_fps=50)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected=json.loads((run/'anchor-resume/result.json').read_text())['motion_files'][path.name]
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'corrupt_sha256':sha(saved),'regenerated_sha256':sha(out),'expected_sha256':expected,'conversion':result,'source_csv_sha256':sha(Path(csv)),'original_metadata':{'mtime_ns':saved.stat().st_mtime_ns,'ctime_ns':saved.stat().st_ctime_ns},'restored':False}
(r/'motion-recovery.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
assert sha(out)==expected,'Regeneration did not reproduce exact original bytes; do not restore'
shutil.copyfile(out,path.with_suffix('.recovered'));os.replace(path.with_suffix('.recovered'),path);assert sha(path)==expected
record['restored']=True;(r/'motion-recovery.json').write_text(json.dumps(record,indent=2)+'\n');print('restored exact original SHA256',flush=True)
