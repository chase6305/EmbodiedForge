"""Independent source, supervision, matched-counter and archive checks."""
import argparse,datetime,hashlib,json,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--complete',action='store_true');a=p.parse_args();r=Path(__file__).parent;repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');report_path=repo/'docs/experiments/supermimic-reproduction-20261027-fourhour.json';d=json.loads(report_path.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
for name,h in d['source_hashes'].items():assert sha(repo/name)==h and sha(r/'final'/name)==h,name
for name,h in d['historical_reports_unchanged'].items():assert sha(repo/name)==h,name
for name,record in d['training_profiles'].items():
 expected=1 if name=='anchor-resume' else 0
 assert record['record']['status']==('failed' if expected else 'complete') and record['supervisor']['process_returncode']==expected and record['supervisor']['exit_observed'] and record['tool_observation']['actual_tool_exit']==expected
 assert expected==0 or record['training_integrity_acceptance']=='quarantined_terminal_input_integrity_failure'
assert d['experiment_validation_status']=='complete_with_quarantined_anchor_training'
recovery=d['known_failures']['exact_motion_recovery'];assert recovery['restored'] and recovery['regenerated_sha256']==recovery['expected_sha256'] and len(recovery['byte_differences'])==2
smoke=d['post_integrity_recovery_smoke'];assert smoke['result']['status']=='complete' and smoke['result']['new_updates']>0 and smoke['supervisor']['process_returncode']==0 and smoke['tool_observation']['actual_tool_exit']==0
comp=d['matched_comparison'];assert comp['stage']=='complete';iteration=comp['selection']['iteration']
for name,entry in comp['selection']['checkpoints'].items():assert sha(Path(entry['path']))==entry['sha256']
rows=[x['result'] for name,x in comp['evaluations'].items() if name.startswith('matched-')];assert len(rows)==6 and {x['iteration'] for x in rows}=={iteration} and len({x['updates'] for x in rows})==1
for label,item in comp['evaluations'].items():
 if label.startswith('matched-'):assert item['result']['checkpoint_sha256']==comp['selection']['checkpoints'][item['condition']]['sha256']
for item in comp['evaluations'].values():assert item['supervisor']['process_returncode']==0 and item['supervisor']['exit_observed'] and item['driver_observed_wait']['supervisor_wait_returncode']==0
archive=repo/d['evidence_archive']['path'];assert sha(archive)==d['evidence_archive']['sha256'];seen=set()
with tarfile.open(archive,'r:gz') as t:
 manifest=json.load(t.extractfile('MANIFEST.json'))
 for member in t:
  if member.name=='MANIFEST.json':continue
  assert member.isfile() and member.name not in seen;seen.add(member.name);f=t.extractfile(member);h=hashlib.sha256();size=0
  for b in iter(lambda:f.read(1048576),b''):h.update(b);size+=len(b)
  assert manifest[member.name]=={'bytes':size,'sha256':h.hexdigest()},member.name
assert seen==set(manifest)
if a.complete:
 assert d['stage']=='complete' and d['work_period_complete'] and d['observed_seconds']>=14400
 start=datetime.datetime.fromisoformat(d['started_at']);end=datetime.datetime.fromisoformat(d['finished_at']);assert (end-start).total_seconds()==d['observed_seconds'] and datetime.datetime.now(datetime.timezone.utc)>=end
proof={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_checks_passed':True,'quarantined_original_training_exit1_preserved':True,'source_files_verified':len(d['source_hashes']),'archive_members_verified':len(seen),'matched_iteration_verified':iteration,'matched_fresh_process_evaluations':len(rows),'work_period_complete_verified':a.complete,'archive_sha256':sha(archive),'report_sha256':sha(report_path)};(r/('final-integrity.json' if a.complete else 'publication-proof.json')).write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
