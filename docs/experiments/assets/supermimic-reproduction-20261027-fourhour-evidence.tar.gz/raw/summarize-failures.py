"""Report every matched-iteration clip; do not select or drop failed motions."""
import csv,json,statistics
from pathlib import Path
r=Path(__file__).parent
run=Path('/home/ubuntu/workspace/chase/EmbodiedForge/runs/supermimic-reproduction-20261027-fourhour')
d=json.loads((r/'comparison.json').read_text());by={}
for label,record in d['evaluations'].items():
 if not label.startswith('matched-'):continue
 condition=record['condition'];raw=json.loads((run/label/'evaluation.json').read_text())['clips']
 for clip in raw:by.setdefault((condition,clip['name']),[]).append(clip)
rows=[]
for (condition,name),values in sorted(by.items()):
 assert len(values)==3
 frame_count=values[0]['frames'];assert all(v['frames']==frame_count for v in values)
 rows.append({'condition':condition,'clip':name,'repeats':3,'failed_repeats':sum(v['failed'] for v in values),'frames':frame_count,'completed_frame_fraction_mean':statistics.mean(min(1,v['steps']/frame_count) for v in values),'surviving_return_mean':statistics.mean(v['norm_return'] for v in values),'full_clip_return_mean':statistics.mean(v['norm_return']*v['steps']/frame_count for v in values),'root_position_reward_mean':statistics.mean(v['terms']['motion_global_root_pos'] for v in values),'root_orientation_reward_mean':statistics.mean(v['terms']['motion_global_root_ori'] for v in values)})
with (r/'matched-clip-diagnostics.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={}
for condition in ('paper-resume','anchor-resume'):
 values=[x for x in rows if x['condition']==condition];assert len(values)==40
 summary[condition]={'always_failed':[x['clip'] for x in values if x['failed_repeats']==3],'sometimes_failed':[x['clip'] for x in values if 0<x['failed_repeats']<3],'always_completed':[x['clip'] for x in values if x['failed_repeats']==0],'lowest_full_clip_return':sorted(values,key=lambda x:x['full_clip_return_mean'])[:5]}
paired=[]
for name in sorted({x['clip'] for x in rows}):
 paper=next(x for x in rows if x['condition']=='paper-resume' and x['clip']==name);anchor=next(x for x in rows if x['condition']=='anchor-resume' and x['clip']==name)
 paired.append({'clip':name,'anchor_minus_paper_failed_repeats':anchor['failed_repeats']-paper['failed_repeats'],'anchor_minus_paper_full_clip_return':anchor['full_clip_return_mean']-paper['full_clip_return_mean']})
result={'iteration':d['selection']['iteration'],'conditions':summary,'paired_all_clips':paired,'scope':'All40training clips;3fresh-process fixedseed0 repeats per condition, one training seed each. Reward terms are not physical position/orientation errors. No selection of model checkpoints or claims of held-out generalization.'}
(r/'matched-clip-diagnostics.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'rows':len(rows),'conditions':{k:{'always_failed':len(v['always_failed']),'sometimes_failed':len(v['sometimes_failed']),'always_completed':len(v['always_completed'])} for k,v in summary.items()}}))
