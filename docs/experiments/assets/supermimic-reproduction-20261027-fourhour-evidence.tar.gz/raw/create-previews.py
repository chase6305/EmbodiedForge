"""Private fixed-clip simulator footage; no trajectories or footage in public archive."""
import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).parent;repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');run=repo/'runs/supermimic-reproduction-20261027-fourhour';sdk=repo/'.cache/external/supermimic-reproduced/.venv/bin/python';selection=json.loads((r/'matched-selection.json').read_text());results={};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for condition in ('paper-resume','anchor-resume'):
 checkpoint=Path(selection['checkpoints'][condition]['path']);expected=selection['checkpoints'][condition]['sha256'];assert sha(checkpoint)==expected
 label='preview-common-'+condition;out=run/label;command=[sys.executable,str(repo/'benchmarks/process_supervisor.py'),'--output',str(run/(label+'-supervisor')),'--timeout','180','--grace','30','--',str(sdk),'-I',str(r/'record-preview.py'),'--implementation',str(run/condition/'implementation'),'--checkpoint',str(checkpoint),'--motions',str(run/'recovered-motions'),'--output',str(out),'--seconds','12','--label','Original680' if condition.startswith('paper') else 'Anchor689 / recovered inputs']
 env=os.environ.copy();env.pop('PYTHONPATH',None);env.update(MUJOCO_GL='egl',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
 with (r/(label+'-outer.log')).open('x') as log:child=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert child.returncode==0,(condition,child.returncode)
 outer=json.loads((run/(label+'-supervisor/result.json')).read_text());assert outer['process_returncode']==0 and outer['exit_observed']
 result=json.loads((out/'result.json').read_text());assert result['status']=='complete' and sha(checkpoint)==expected
 results[condition]={'result':result,'checkpoint_sha256':expected,'supervisor_wait_returncode':child.returncode,'supervisor':outer,'local_video':str(out/'preview.mp4'),'video_sha256':sha(out/'preview.mp4'),'video_bytes':(out/'preview.mp4').stat().st_size,'training_integrity':'original anchor run quarantined actual1' if condition=='anchor-resume' else 'original training accepted actual0','scope':'Fixed walk1_subject1 illustration selected before quality inspection; private simulator output, no aggregate benchmark claim.'}
 (r/'local-previews.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'previews':len(results),'all_wait_codes_zero':True,'footage_remains_local':True}))
