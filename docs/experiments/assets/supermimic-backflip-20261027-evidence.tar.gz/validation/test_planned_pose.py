import numpy as np
import pytest
from types import SimpleNamespace
from pathlib import Path
namespace = {}
exec(Path(__file__).with_name("pose-function.txt").read_text(), namespace)
backflip = SimpleNamespace(fixed_window_pose_quality=namespace["fixed_window_pose_quality"])


def pose_inputs(samples=130):
    joints = np.zeros((samples, 29))
    ankles = np.zeros((samples, 2, 3))
    ankles[:, 1, 1] = 0.4
    return joints, joints.copy(), ankles, ankles.copy()


def test_fixed_pose_window_keeps_pose_and_foot_spacing_failures_visible():
    actual, target, feet, reference_feet = pose_inputs()
    perfect = backflip.fixed_window_pose_quality(actual, target, feet, reference_feet)
    assert perfect["pose_quality_passed"] is True
    assert perfect["hip_knee_rmse_deg"] == 0
    actual[90:118, [0, 1, 2, 3, 6, 7, 8, 9]] = np.deg2rad(30)
    failed = backflip.fixed_window_pose_quality(actual, target, feet, reference_feet)
    assert failed["hip_knee_rmse_deg"] == pytest.approx(30)
    assert failed["pose_quality_passed"] is False
    actual[:] = target
    feet[90:118, 1, 1] = 0.6
    failed = backflip.fixed_window_pose_quality(actual, target, feet, reference_feet)
    assert failed["hip_knee_rmse_deg"] == 0
    assert failed["max_ankle_separation_m"] == pytest.approx(0.6)
    assert failed["reference_max_ankle_separation_m"] == pytest.approx(0.4)
    assert failed["pose_quality_passed"] is False


def test_fixed_pose_window_does_not_shift_to_a_better_pose():
    actual, target, feet, reference_feet = pose_inputs()
    actual[90:118, :12] = np.pi
    measured = backflip.fixed_window_pose_quality(actual, target, feet, reference_feet)
    assert measured["hip_knee_rmse_deg"] == pytest.approx(180)
    assert measured["pose_quality_passed"] is False
    # A mismatch outside the prescribed window does not enter this diagnostic.
    actual[:] = 0
    actual[:90] = np.pi
    assert backflip.fixed_window_pose_quality(actual, target, feet, reference_feet)[
        "pose_quality_passed"
    ] is True


def test_fixed_pose_window_missing_after_early_failure_is_unassessed():
    actual, target, feet, reference_feet = pose_inputs()
    measured = backflip.fixed_window_pose_quality(
        actual[:117], target, feet[:117], reference_feet
    )
    assert measured["pose_quality_passed"] is None
    assert measured["hip_knee_rmse_deg"] is None


def test_leg_asymmetry_is_reference_adjusted():
    actual, target, feet, reference_feet = pose_inputs()
    actual[:, 1] = target[:, 1] = 0.3
    measured = backflip.fixed_window_pose_quality(actual, target, feet, reference_feet)
    assert measured["reference_adjusted_leg_asymmetry_rmse_deg"] == 0
    actual[90:118, 1] += 0.2
    measured = backflip.fixed_window_pose_quality(actual, target, feet, reference_feet)
    assert measured["reference_adjusted_leg_asymmetry_rmse_deg"] == pytest.approx(
        np.degrees(0.2 / np.sqrt(6))
    )


def test_pose_diagnostic_rejects_nonfinite_or_mismatched_samples():
    actual, target, feet, reference_feet = pose_inputs()
    with pytest.raises(ValueError, match="sample counts"):
        backflip.fixed_window_pose_quality(actual, target, feet[:-1], reference_feet)
    with pytest.raises(ValueError, match="N29"):
        backflip.fixed_window_pose_quality(actual[:, :28], target, feet, reference_feet)
    actual[90, 0] = np.nan
    with pytest.raises(ValueError, match="finite"):
        backflip.fixed_window_pose_quality(actual, target, feet, reference_feet)
