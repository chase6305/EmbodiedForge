"""Independent scalar checks; fixed pose windows are never shifted to improve scores."""
import json,sys
from pathlib import Path
import numpy as np
import mujoco
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;run=repo/'runs/supermimic-backflip-20261027';sys.path.insert(0,str(repo/'src'))
from embodiedforge.workflows.supermimic_backflip import lateral_rotation_degrees
from supermimic.data.motion_convert import load_g1_model
with np.load(repo/'runs/supermimic/tasks/backflip/data/eval/backflip.npz',allow_pickle=False) as d:reference=np.concatenate((d['body_pos_w'][:,0],d['body_quat_w'][:,0],d['joint_pos']),axis=1);reference_q=d['joint_pos'].copy();ref_names=[str(x) for x in d['body_names']];reference_feet=d['body_pos_w'][:,[ref_names.index('left_ankle_roll_link'),ref_names.index('right_ankle_roll_link')]].copy()
model=load_g1_model();data=mujoco.MjData(model);foot_ids=[mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_BODY,n) for n in ('left_ankle_roll_link','right_ankle_roll_link')];assert -1 not in foot_ids;rows={}
folders=[run/'pilot-eval',*sorted(run.glob('intermediate-*')), *sorted(run.glob('main-eval-r[123]'))]
for folder in folders:
 if not (folder/'backflip-rollout.npz').is_file():continue
 with np.load(folder/'backflip-rollout.npz',allow_pickle=False) as d:state=d['state'].copy();times=d['time_s'].copy()
 assert state.ndim==2 and state.shape[1]==71 and np.isfinite(state).all() and np.allclose(np.diff(times),.02)
 diag=json.loads((folder/'backflip-diagnostics.json').read_text());spin=lateral_rotation_degrees(state[:,3:7]);assert abs(spin-diag['actual_lateral_rotation_deg'])<1e-9
 initial_velocity=float(np.max(np.abs(state[0,36:])));assert initial_velocity<1e-6
 quat_error=min(float(np.max(np.abs(state[0,3:7]-reference[0,3:7]))),float(np.max(np.abs(state[0,3:7]+reference[0,3:7]))));initial_pose_error=max(quat_error,float(np.max(np.abs(state[0,:3]-reference[0,:3]))),float(np.max(np.abs(state[0,7:36]-reference[0,7:36]))));assert initial_pose_error<1e-5
 metric={'actual_samples':len(state),'actual_last_time_s':float(times[-1]),'rotation_recomputed_deg':spin,'initial_velocity_max_abs':initial_velocity,'initial_pose_max_abs_error':initial_pose_error,'auto_reset_samples_included':False,'fixed_flight_window_frames':[90,118],'hip_knee_rmse_deg':None,'reference_adjusted_leg_asymmetry_rmse_deg':None,'max_ankle_separation_m':None,'reference_max_ankle_separation_m':float(np.max(np.linalg.norm(reference_feet[90:118,0]-reference_feet[90:118,1],axis=1)))}
 if len(state)>=118:
  actual=state[90:118,7:36];target=reference_q[90:118];ids=[0,1,2,3,6,7,8,9];metric['hip_knee_rmse_deg']=float(np.degrees(np.sqrt(np.mean((actual[:,ids]-target[:,ids])**2))));mirror=np.array([1,-1,-1,1,1,-1]);deviation=(actual[:,:6]-actual[:,6:12]*mirror)-(target[:,:6]-target[:,6:12]*mirror);metric['reference_adjusted_leg_asymmetry_rmse_deg']=float(np.degrees(np.sqrt(np.mean(deviation**2))));distances=[]
  for q in state[90:118,:36]:data.qpos[:]=q;mujoco.mj_kinematics(model,data);distances.append(float(np.linalg.norm(data.xpos[foot_ids[0]]-data.xpos[foot_ids[1]])))
  metric['max_ankle_separation_m']=max(distances)
 rows[folder.name]=metric
proof={'status':'complete','records':rows,'scope':'Offline arithmetic/FK of saved real states, fixed reference window90:118. Missing windows are null; no retiming. Geometry/pose statistics are not200Hzsolver forces, an airborne proof or a strictV14replication.'};(r/'rollout-integrity.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'rollouts_checked':len(rows),'initial_state_checks_passed':True}))
