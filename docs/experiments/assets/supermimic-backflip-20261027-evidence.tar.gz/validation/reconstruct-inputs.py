"""Independently reproduce the two prepared NPZ files without touching active inputs."""
import hashlib,json,sys
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;root=repo/'runs/supermimic/tasks/backflip/data';sys.path.insert(0,str(repo/'src'))
from embodiedforge.workflows.supermimic_backflip import prepared
from supermimic.data.motion_convert import convert_csv_to_npz,load_g1_model
record=prepared(root);model=load_g1_model();out=r/'reconstructed-inputs';out.mkdir();proof={};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for phase,csvname in [('train','backflip.csv'),('eval','backflip_eval.csv')]:
 target=out/(phase+'.npz');summary=convert_csv_to_npz(root/csvname,target,input_fps=50,output_fps=50,model=model);actual=sha(target);expected=record[phase+'_files']['backflip.npz'];assert actual==expected,(phase,actual,expected);proof[phase]={'sha256':actual,'frames':summary['output_frames'],'exact_bytes_reconstructed':True}
assert sha(root/'source.npz')==record['source_sha256'];(r/'input-reconstruction.json').write_text(json.dumps({'status':'complete','inputs':proof,'original_source_hash_reverified':True,'active_inputs_modified':False},indent=2)+'\n');print(json.dumps(proof))
