"""Read-only monitor: source, inputs, original resume checkpoint, progress and GPU."""
import datetime,hashlib,json,subprocess
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;run=repo/'runs/supermimic-backflip-20261027';name='main';job=run/name
source=json.loads((r/'main-source-hashes.json').read_text())
for file,digest in source.items():assert hashlib.sha256((repo/file).read_bytes()).hexdigest()==digest,file
record=json.loads((job/'training/result.json').read_text()) if (job/'training/result.json').exists() else {}
if 'motion_input_snapshot' in record:
 snap=record['motion_input_snapshot']
 for file,digest in snap['files'].items():assert hashlib.sha256((Path(snap['root'])/file).read_bytes()).hexdigest()==digest,file
checkpoint=run/'pilot/training/training/ckpt_latest.pt';assert hashlib.sha256(checkpoint.read_bytes()).hexdigest()=='b6de179853ee4293c5825608850d7d364fc3213b1080dc7672099d587757e543'
log=job/'command.log';lines=log.read_text(errors='replace').splitlines() if log.exists() else [];progress=next((x for x in reversed(lines) if x.startswith('it ')),None)
query=subprocess.run(['nvidia-smi','--query-gpu=memory.used,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10)
row={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':record.get('status','preparing'),'progress':progress,'source_files_verified':len(source),'private_motion_verified':'motion_input_snapshot' in record,'original_resume_checkpoint_verified':True,'gpu_used_free_MiB_util_percent':query.stdout.strip() if query.returncode==0 else None}
with (r/'main-health.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
(r/'latest-health.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row))
