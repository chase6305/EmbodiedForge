"""Plot actual saved policy states on the original time axis, including failure."""
import csv,json,re,sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;run=repo/'runs/supermimic-backflip-20261027';sys.path.insert(0,str(repo/'src'))
from embodiedforge.workflows.supermimic_backflip import lateral_rotation_degrees
with np.load(repo/'runs/supermimic/tasks/backflip/data/eval/backflip.npz',allow_pickle=False) as d:reference_q=d['body_quat_w'][:,0].copy();reference_z=d['body_pos_w'][:,0,2].copy()
def curve(q):return np.array([lateral_rotation_degrees(q[:i+1]) for i in range(len(q))])
fig,axes=plt.subplots(2,1,figsize=(9,6),layout='constrained',sharex=True)
target_t=np.arange(len(reference_q))/50;axes[0].plot(target_t,curve(reference_q),'--',color='#555555',label='Reference target (not a policy)');axes[1].plot(target_t,reference_z,'--',color='#555555',label='Reference target')
folders=[run/'pilot-eval',run/'intermediate-10000',run/'intermediate-20000',*sorted(run.glob('main-eval-r[123]'))]
for folder in folders:
 if not (folder/'backflip-rollout.npz').exists():continue
 with np.load(folder/'backflip-rollout.npz',allow_pickle=False) as d:s=d['state'].copy();t=d['time_s'].copy()
 metrics=json.loads((folder/'backflip-diagnostics.json').read_text());label=folder.name;colors={'pilot-eval':'#d47e27','intermediate-10000':'#c75555','intermediate-20000':'#288b67'};style={'color':colors.get(label,'#285fbb'),'alpha':.7}
 axes[0].plot(t,curve(s[:,3:7]),label=label,**style);axes[1].plot(t,s[:,2],label=label,**style)
 if not metrics['completed_extended_reference']:
  axes[0].scatter(t[-1],curve(s[:,3:7])[-1],marker='x',**style);axes[1].scatter(t[-1],s[-1,2],marker='x',**style)
for ax in axes:ax.axvspan(6.4,11.4,color='#999999',alpha=.1);ax.grid(alpha=.2);ax.legend(fontsize=8);ax.set_xlim(0,11.4)
axes[0].set(ylabel='Lateral rotation (degrees)',title='Actual SuperMimic/mjlab backflip policy rollouts; x marks early termination')
axes[1].set(ylabel='Pelvis height (m)',xlabel='Original simulation time (s); shaded: additional5shold')
fig.suptitle('Same final checkpoint across main repeats;50Hzdiagnostics; strict200Hzacceptance not assessed; rotation alone is not pose quality',fontsize=9)
for ext in ('svg','png'):fig.savefig(r/('backflip-progress.'+ext),dpi=140)
plt.close(fig)
log=(run/'main/command.log').read_text(errors='replace').splitlines();pattern=re.compile(r'^it (\d+) \| ([\d.]+) h .*?updates (\d+) \| train_ret ([\d.]+) .*?wm nse1 ([\d.]+) nse8 ([\d.]+)');rows=[]
for line in log:
 match=pattern.search(line)
 if match:rows.append(dict(zip(['iteration','hours','updates','training_return','wm_nse1','wm_nse8'],map(float,match.groups()))))
with (r/'training-curve.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=['iteration','hours','updates','training_return','wm_nse1','wm_nse8']);writer.writeheader();writer.writerows(rows)
print(json.dumps({'rollout_figures_created':True,'training_log_rows':len(rows),'scope':'Reference motion: mjbatchApache2.0; policy states: actual simulation. No retiming, pose replacement or performance inferred solely from training returns.'}))
