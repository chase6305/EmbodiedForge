"""Publish only after actual job closure, final model evaluation and final checks."""
import datetime
import hashlib
import io
import json
import os
import shutil
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

repo = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
r = Path(__file__).parent
run = repo/'runs/supermimic-backflip-20261027'
assets = repo/'docs/experiments/assets'
report_path = repo/'docs/experiments/supermimic-backflip-20261027.json'

def read(path):
    return json.loads(Path(path).read_text())

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(path, data):
    Path(path).write_text(json.dumps(data, indent=2)+'\n')

actual = read(r/'actual-main-exit.json')
assert actual['actual_tool_exit'] == 0
checks = read(r/'final-check-exits.json')
assert checks and all(value == 0 for value in checks.values())
main = read(run/'main/training/result.json')
main_outer = read(run/'main-supervisor/result.json')
assert main['status'] == 'complete' and main['new_updates'] > 0
assert main['finite_model_tensors'] and main['checkpoint_reload_action_parity']
assert main_outer['exit_observed'] and main_outer['process_returncode'] == 0
assert not main_outer['timed_out']
selected = read(r/'final-selection.json')
assert digest(selected['path']) == main['checkpoint_sha256'] == selected['sha256']
assert read(repo/'runs/supermimic/tasks/backflip/current.json')['checkpoint_sha256'] == selected['sha256']
repeats = read(r/'final-evaluations.json')
assert len(repeats) == 3
for repeat in repeats:
    assert repeat['observed']['driver_wait_returncode'] == 0
    assert repeat['worker']['checkpoint_sha256'] == selected['sha256']
    assert repeat['worker']['iteration'] == main['final_iteration']
    assert repeat['diagnostics']['strict_acceptance'] == 'not_assessed'
    assert 'fixed_window_pose' in repeat['diagnostics']
for name, expected in read(r/'main-source-hashes.json').items():
    assert digest(r/'phase-main'/name) == expected, name
for name, expected in read(r/'final-source-hashes.json').items():
    assert digest(repo/name) == digest(r/'phase-final'/name) == expected, name
for name, expected in read(r/'history-hashes.json').items():
    assert digest(repo/name) == expected, name
for phase, label in (('phase-initial-smoke', 'smoke'), ('phase-smoke', 'smoke-retry'), ('phase-main', 'main'), ('phase-final', 'main-eval-r1')):
    for name, expected in read(run/label/'launcher.json')['launcher_sources'].items():
        assert digest(r/phase/name) == expected, (phase, name)

# Read-only process audit; no signals or changes to other users' jobs.
identities = read(r/'main-identities.json')
alive = []
for entry in Path('/proc').iterdir():
    if not entry.name.isdigit():
        continue
    try:
        command = (entry/'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
        if str(run) in command or str(run.relative_to(repo)) in command:
            alive.append({'pid': int(entry.name), 'command': command})
    except (OSError, ProcessLookupError):
        pass
assert not alive, alive
process_audit = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'scoped_prefix': str(run), 'matching_live_processes': alive, 'owned_main_identities': identities, 'signals_sent_by_audit': 0}
write(r/'final-process-audit.json', process_audit)

def tests(name):
    root = ET.parse(r/name).getroot()
    suites = list(root.iter('testsuite'))
    result = {key: sum(int(suite.get(key, 0)) for suite in suites) for key in ('tests', 'failures', 'errors', 'skipped')}
    assert result['failures'] == result['errors'] == 0
    return result

integrity = read(r/'rollout-integrity.json')
for label in ('main-eval-r1', 'main-eval-r2', 'main-eval-r3'):
    assert label in integrity['records']
    recorded = next(repeat for repeat in repeats if repeat['label'] == label)['diagnostics']['fixed_window_pose']
    independent = integrity['records'][label]
    for key in ('hip_knee_rmse_deg', 'reference_adjusted_leg_asymmetry_rmse_deg', 'max_ankle_separation_m', 'reference_max_ankle_separation_m'):
        assert abs(recorded[key] - independent[key]) < 1e-6, (label, key)

report = read(report_path)
report.pop('hardware_execution', None)
report.update(
    status='complete',
    physical_robot_execution=False,
    gpu_hardware=read(r/'gpu-hardware.json'),
    updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    main_training={key: main[key] for key in ('status', 'initial_iteration', 'final_iteration', 'initial_updates', 'final_updates', 'new_environment_steps', 'new_updates', 'checkpoint_sha256', 'finite_model_tensors', 'checkpoint_reload_action_parity')},
    training_reference_evaluation={'reference_frames': 321, 'summary': main['evaluation'], 'scope': 'Original training-driver tracking benchmark; not physical backflip quality acceptance. Final extended571frame evaluations below include an additional5second static hold, so their average returns are not directly comparable to321frame averages.'},
    actual_main_original_tool_exit=actual,
    main_supervisor=main_outer,
    final_selection=selected,
    final_evaluations=[{'label': repeat['label'], 'actual_driver_wait_returncode': repeat['observed']['driver_wait_returncode'], 'iteration': repeat['worker']['iteration'], 'checkpoint_sha256': repeat['worker']['checkpoint_sha256'], 'summary': repeat['worker']['summary'], 'diagnostics': repeat['diagnostics']} for repeat in repeats],
    intermediate_20000={'actual_original_tool_exit': 0, 'diagnostics': read(run/'intermediate-20000/backflip-diagnostics.json'), 'additional_pose_diagnostics': integrity['records']['intermediate-20000'], 'selection': 'Predetermined diagnostic step. Kept unchanged; never substituted for the actual last model.'},
    independent_rollout_integrity=integrity,
    input_reconstruction=read(r/'input-reconstruction.json'),
    final_checks={'actual_exits': checks, 'related_tests': tests('final-tests.xml'), 'documentation_tests': tests('final-documentation.xml')},
    final_process_audit=process_audit,
    source_phases={'training': read(r/'main-source-hashes.json'), 'final_evaluation': read(r/'final-source-hashes.json'), 'change_scope': 'After actual main exit0 only evaluation diagnostics were extended with the predeclared fixed90:118 pose check. Training architecture, policy weights and reference arrays were unchanged.'},
    history_preservation={'verified_files': len(read(r/'history-hashes.json')), 'all_match': True},
    limitations=[
        'This is a SuperMimic/mjlab single-motion port; it is not an official pretrained policy or an exact IsaacLab3/vibedV14 reproduction.',
        'Final model selection uses the actual last checkpoint. Deterministic seed0 repeats check fresh-process repeatability, not independent-seed robustness.',
        '500initialsteps collect replay before joint updates; this is not the reference500world-model-only pretraining updates. Main90minute continuation starts from the separately recorded2500step pilot.',
        '50Hzsaved-state geometry cannot establish200Hzsolver-force quality. Dynamic airborne-window rotation/pose and full strict acceptance remain unimplemented.',
        'The added fixed reference-time leg diagnostic uses reference-informed25degree RMSE and+0.15mfoot-separation limits; its window protocol differs from the reference longest-airborne-window gate. No shift to improve scores is permitted.',
        'No hardware execution was performed. Motion arrays, policy checkpoints and videos remain local and are excluded from the evidence archive.',
    ],
)
report['skill_success'] = False if any(repeat['diagnostics']['skill_success'] is False for repeat in repeats) else None
report['known_failures']['planned_pose_test_environment'] = {
    'actual_exit': 1,
    'reason': 'Preinstalled launch_testing pytest plugin has an incompatible hook signature; no tests collected. Retry with plugin autoload disabled passed5tests; original log and exit retained.',
}
report['known_failures']['first_publication_attempt'] = read(r/'publication-first-attempt.json')
report['strict_acceptance'] = 'not_assessed'
report['latest_health'] = read(r/'latest-health.json')
report['progress_plot'] = 'assets/supermimic-backflip-20261027-progress.svg'
report['local_final_video'] = str((run/'main-eval-r1-video/policy.mp4').relative_to(repo))

assets.mkdir(exist_ok=True)
shutil.copyfile(r/'backflip-progress.svg', assets/'supermimic-backflip-20261027-progress.svg')
archive = assets/'supermimic-backflip-20261027-evidence.tar.gz'
members = {}
def add(path, name):
    path = Path(path)
    assert path.is_file() and path.suffix.lower() not in {'.npz', '.pt', '.mp4', '.stl'}
    assert path.stat().st_size < 50_000_000
    members[name] = path.read_bytes()

for path in sorted(run.rglob('*')):
    if path.is_file() and path.suffix in {'.json', '.jsonl', '.log', '.yaml', '.yml'}:
        add(path, 'runs/'+str(path.relative_to(run)))
for path in sorted(r.iterdir()):
    if path.is_file() and path.suffix in {'.py', '.json', '.jsonl', '.log', '.xml'}:
        add(path, 'validation/'+path.name)
for name in ('pose-function.txt', 'pose-tests.txt'):
    add(r/name, 'validation/'+name)
for phase in ('phase-initial-smoke', 'phase-smoke', 'phase-main', 'phase-final'):
    for path in sorted((r/phase).rglob('*')):
        if path.is_file():
            add(path, 'sources/'+phase+'/'+str(path.relative_to(r/phase)))
for pattern in ('src/embodiedforge/workflows/supermimic*.py', 'tests/test_supermimic*.py'):
    for path in sorted(repo.glob(pattern)):
        add(path, 'sources/final/'+str(path.relative_to(repo)))
for name in ('supermimic', 'src/embodiedforge/supermimic_run.py', 'benchmarks/supermimic_reproduce.py', 'benchmarks/process_supervisor.py', 'tests/test_documentation.py', 'docs/supermimic.md', 'README.md', 'pyproject.toml'):
    add(repo/name, 'sources/final/'+name)
for path, name in ((repo/'.cache/external/supermimic-reproduced/LICENSE', 'Cuboi-SuperMimic-MIT'), (repo/'.cache/external/supermimic-backflip-5090/LICENSE', 'backflip-reference-MIT'), (repo/'.cache/external/mjbatch/LICENSE', 'mjbatch-Apache-2.0')):
    add(path, 'licenses/'+name)
for name in ('scripts/prepare_data.py', 'scripts/evaluate_reference_backflip.py', 'docs/METHOD_AND_PROVENANCE.md', 'docs/EVALUATION.zh-CN.md'):
    add(repo/'.cache/external/supermimic-backflip-5090'/name, 'reference/'+name)
add(r/'training-curve.csv', 'derived/training-curve.csv')
add(r/'backflip-progress.svg', 'derived/backflip-progress.svg')
members['README.txt'] = b'Actual SuperMimic/mjlab backflip training and diagnostics. Each named source phase is retained. Failed initial smoke and missing-model evaluation exits are preserved. Arrays, checkpoints, SDKs, robot meshes and videos are excluded. Fixed-window pose gates are not strict V14 acceptance.\n'
manifest = {name: hashlib.sha256(data).hexdigest() for name, data in sorted(members.items())}
members['SHA256SUMS.json'] = (json.dumps(manifest, indent=2)+'\n').encode()
with tarfile.open(archive, 'w:gz') as target:
    for name, data in sorted(members.items()):
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        entry.mode = 0o644
        entry.mtime = 0
        target.addfile(entry, io.BytesIO(data))
with tarfile.open(archive) as source:
    actual_members = source.getmembers()
    assert all(member.isfile() for member in actual_members)
    assert len(actual_members) == len(members)
    for name, data in members.items():
        assert hashlib.sha256(source.extractfile(name).read()).hexdigest() == hashlib.sha256(data).hexdigest()
    assert json.loads(source.extractfile('SHA256SUMS.json').read()) == manifest
report['evidence'] = {'path': str(archive.relative_to(repo/'docs/experiments')), 'sha256': digest(archive), 'members': len(members), 'every_member_verified': True, 'excludes': ['model weights', 'motion arrays/CSVs', 'SDK', 'robot meshes', 'videos/frames', 'private agent notes']}
write(report_path, report)
print(json.dumps({'status': 'complete', 'final_iteration': main['final_iteration'], 'new_updates': main['new_updates'], 'skill_success': report['skill_success'], 'strict_acceptance': report['strict_acceptance'], 'archive_members': len(members), 'archive_sha256': report['evidence']['sha256']}))
