"""Apply evaluation-only diagnostics AFTER actual main training closure."""
import hashlib
import json
from pathlib import Path

repo = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
r = Path(__file__).parent
assert json.loads((r/'actual-main-exit.json').read_text())['actual_tool_exit'] == 0
guard = json.loads((r/'main-source-hashes.json').read_text())
for name, expected in guard.items():
    assert hashlib.sha256((repo/name).read_bytes()).hexdigest() == expected, name
path = repo/'src/embodiedforge/workflows/supermimic_backflip.py'
source = path.read_text()
def replace(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)

replace('def evaluate(policy, paths, cfg, output):', (r/'pose-function.txt').read_text() + '\ndef evaluate(policy, paths, cfg, output):')
replace('        reference_quat = data["body_quat_w"][:, 0].copy()', '''        reference_quat = data["body_quat_w"][:, 0].copy()
        reference_joints = data["joint_pos"].copy()
        body_names = [str(name) for name in data["body_names"]]
        foot_names = ("left_ankle_roll_link", "right_ankle_roll_link")
        reference_ankles = data["body_pos_w"][:, [body_names.index(name) for name in foot_names]].copy()''')
replace('    penetration_frames = 0', '    ankle_ids = [mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, name) for name in foot_names]\n    ankle_positions = []\n    penetration_frames = 0')
replace('        bad = False', '        ankle_positions.append(data.xpos[ankle_ids].copy())\n        bad = False')
replace('    diagnostics = {', '''    pose = fixed_window_pose_quality(state[:, 7:36], reference_joints, ankle_positions, reference_ankles)
    quality = basic and pose["pose_quality_passed"] is True
    diagnostics = {''')
replace('        "skill_success": None if basic else False,', '''        "fixed_window_pose": pose,
        "quality_checks_passed": quality,
        "skill_success": None if quality else False,''')
replace('A basic pass cannot establish robust success.', 'Fixed-window leg pose is additionally checked; even a quality pass cannot establish robust success.')
path.write_text(source)
print('Evaluation-only pose diagnostics applied after observed main exit0')
