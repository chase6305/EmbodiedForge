"""Evaluate the actual last completed main model; no checkpoint selection by score."""
import datetime,hashlib,json,subprocess,sys
from pathlib import Path
repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');r=Path(__file__).parent;run=repo/'runs/supermimic-backflip-20261027'
observation=json.loads((r/'actual-main-exit.json').read_text());main=json.loads((run/'main/training/result.json').read_text());launcher=json.loads((run/'main/launcher.json').read_text());outer=json.loads((run/'main-supervisor/result.json').read_text());assert observation['actual_tool_exit']==0 and main['status']=='complete' and launcher['worker_exit_observed'] and launcher['worker_returncode']==0 and outer['exit_observed'] and outer['process_returncode']==0 and not outer['timed_out']
checkpoint=run/'main/training/training/ckpt_latest.pt';expected=main['checkpoint_sha256'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(checkpoint)==expected
registry=json.loads((repo/'runs/supermimic/tasks/backflip/current.json').read_text());assert registry['checkpoint_sha256']==expected
(r/'final-selection.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rule':'Actual last checkpoint from successful90minute main continuation; no scoring-based selection','path':str(checkpoint),'sha256':expected,'iteration':main['final_iteration'],'updates':main['final_updates']},indent=2)+'\n')
records=[]
for repeat in range(1,4):
 label=f'main-eval-r{repeat}';command=[sys.executable,str(repo/'benchmarks/process_supervisor.py'),'--output',str(run/(label+'-supervisor')),'--timeout','600','--grace','30','--',str(repo/'supermimic'),'eval','--task','backflip','--checkpoint',str(checkpoint),'--output',str(run/label)]
 with (r/(label+'-outer.log')).open('x') as log:child=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 observed={'label':label,'driver_wait_returncode':child.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (r/'final-evaluation-exits.jsonl').open('a') as f:f.write(json.dumps(observed)+'\n')
 assert child.returncode==0,observed
 supervisor=json.loads((run/(label+'-supervisor/result.json')).read_text());worker=json.loads((run/label/'result.json').read_text());diagnostics=json.loads((run/label/'backflip-diagnostics.json').read_text())
 assert supervisor['exit_observed'] and supervisor['process_returncode']==0 and worker['status']=='complete' and worker['checkpoint_sha256']==expected and worker['iteration']==main['final_iteration'] and worker['updates']==main['final_updates'] and sha(checkpoint)==expected
 records.append({'label':label,'observed':observed,'supervisor':supervisor,'worker':worker,'diagnostics':diagnostics});(r/'final-evaluations.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps({'label':label,'actual_wait':child.returncode,'spin_deg':diagnostics['actual_lateral_rotation_deg'],'completed':diagnostics['completed_extended_reference'],'basic_checks':diagnostics['basic_checks_passed'],'strict':diagnostics['strict_acceptance']}),flush=True)
assert len(records)==3
