import json,hashlib,numpy as np
from pathlib import Path
p=Path('/home/ubuntu/workspace/chase/EmbodiedForge/.cache/external/mjbatch/examples/assets/flip.npz')
with np.load(p,allow_pickle=False) as d:
 print(json.dumps({k:{'shape':list(d[k].shape),'dtype':str(d[k].dtype),'value':d[k].tolist() if d[k].size<40 else None} for k in d.files},indent=2))
