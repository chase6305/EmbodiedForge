"""Render saved physical policy states at their original timeline; no re-simulation."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
import mujoco,numpy as np
from PIL import Image,ImageDraw
p=argparse.ArgumentParser();p.add_argument('--evaluation',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);repo=Path('/home/ubuntu/workspace/chase/EmbodiedForge');source=a.evaluation/'backflip-rollout.npz';source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
from supermimic.data.motion_convert import g1_xml_path
with np.load(source,allow_pickle=False) as d:states=d['state'].copy();times=d['time_s'].copy()
with np.load(repo/'runs/supermimic/tasks/backflip/data/eval/backflip.npz',allow_pickle=False) as d:reference=np.concatenate((d['body_pos_w'][:,0],d['body_quat_w'][:,0],d['joint_pos']),axis=1)
result=json.loads((a.evaluation/'result.json').read_text());spec=mujoco.MjSpec.from_file(str(g1_xml_path()));spec.worldbody.add_geom(type=mujoco.mjtGeom.mjGEOM_PLANE,size=[20,20,.1],rgba=[.84,.86,.9,1]);spec.worldbody.add_light(pos=[0,0,5],dir=[0,0,-1],type=mujoco.mjtLightType.mjLIGHT_DIRECTIONAL);model=spec.compile();data=mujoco.MjData(model);refdata=mujoco.MjData(model);camera=mujoco.MjvCamera();camera.azimuth=135;camera.elevation=-18;option=mujoco.MjvOption();ghost=mujoco.MjvScene(model,maxgeom=10000);target=a.output/'policy.mp4'
command=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','480x360','-r','25','-i','pipe:0','-an','-c:v','libx264','-threads','2','-pix_fmt','yuv420p',str(target)]
indices=list(range(0,len(states),2))
with (a.output/'ffmpeg.log').open('x') as log:
 encoder=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT)
 try:
  with mujoco.Renderer(model,height=360,width=480,max_geom=10000) as renderer:
   for frame_index,index in enumerate(indices):
    q=states[index,:36];qr=reference[min(index,len(reference)-1)];data.qpos[:]=q;refdata.qpos[:]=qr;mujoco.mj_forward(model,data);mujoco.mj_forward(model,refdata);camera.lookat[:]=(q[:3]+qr[:3])/2;camera.distance=max(3.2,float(np.linalg.norm(q[:3]-qr[:3]))*1.4+1.8);renderer.update_scene(data,camera=camera,scene_option=option);mujoco.mjv_updateScene(model,refdata,option,None,camera,mujoco.mjtCatBit.mjCAT_DYNAMIC,ghost);scene=renderer.scene
    for g in ghost.geoms[:ghost.ngeom]:
     dst=scene.geoms[scene.ngeom];mujoco.mjv_initGeom(dst,g.type,np.asarray(g.size,dtype=np.float64),np.asarray(g.pos,dtype=np.float64),np.asarray(g.mat,dtype=np.float64).reshape(9),np.array([.1,.45,.95,.25],dtype=np.float32));dst.dataid=g.dataid;dst.category=mujoco.mjtCatBit.mjCAT_DECOR;scene.ngeom+=1
    frame=Image.fromarray(renderer.render());draw=ImageDraw.Draw(frame);draw.rectangle((0,0,480,39),fill='white');draw.text((7,4),f'Actual SuperMimic/mjlab | iteration {result["iteration"]}',fill='black');draw.text((7,21),f'Blue = reference target | t={times[index]:.2f}s | no retiming',fill='black')
    if frame_index==0:frame.save(a.output/'first-frame.png')
    if abs(float(times[index])-2.0)<.021:frame.save(a.output/'flight-frame.png')
    if frame_index==len(indices)-1:frame.save(a.output/'last-frame.png')
    encoder.stdin.write(frame.tobytes())
 finally:encoder.stdin.close()
 assert encoder.wait(timeout=30)==0
assert hashlib.sha256(source.read_bytes()).hexdigest()==source_hash
proof={'status':'complete','source_rollout_sha256':source_hash,'checkpoint_sha256':result['checkpoint_sha256'],'iteration':result['iteration'],'frames':len(indices),'fps':25,'first_time_s':float(times[indices[0]]),'last_time_s':float(times[indices[-1]]),'video_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'video_bytes':target.stat().st_size,'scope':'Saved actual GPU policy states rendered with FK; no added physics integration, motion retiming or reference state substitution. Blue ghost is target only. Footage remains local; it does not certify pose/contact quality.'};(a.output/'result.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
