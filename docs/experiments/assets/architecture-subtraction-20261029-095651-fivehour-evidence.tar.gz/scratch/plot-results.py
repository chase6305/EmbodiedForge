import json
import statistics
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

work=Path('/tmp/embodiedforge-subtraction-20261029-095651-fivehour')
state=json.loads((work/'state.json').read_text())
allocation=json.loads((work/'hash-allocation.json').read_text())['results']
fig,axes=plt.subplots(1,2,figsize=(10.8,4.2))
colors=['#9aa5b1','#2b6cb0']
packages=[state['distribution_phase1']['before']['bytes']/1e6,state['validation']['installed_distribution_final']['distribution']['embodiedforge-0.1.0.tar.gz']['bytes']/1e6]
peaks=[statistics.median(row['peak_python_bytes'] for row in allocation if row['method']==method)/2**20 for method in ['read_bytes','stream']]
for ax,values,title,unit in [(axes[0],packages,'Source archive with populated cache','MB'),(axes[1],peaks,'Python allocation peak: file hash','MiB')]:
    bars=ax.bar(['Before','After'],values,color=colors,width=.58)
    ax.set_title(title,fontsize=12,pad=14)
    ax.set_ylabel(unit)
    ax.set_ylim(0,max(values)*1.17)
    ax.grid(axis='y',alpha=.18)
    ax.set_axisbelow(True)
    for spine in ['top','right']:
        ax.spines[spine].set_visible(False)
    for bar,value in zip(bars,values):
        ax.annotate(f'{value:.1f}',(bar.get_x()+bar.get_width()/2,value),xytext=(0,5),textcoords='offset points',ha='center',fontsize=11)
fig.suptitle('EmbodiedForge: fewer shipped bytes and bounded hashing',fontsize=14,y=.99)
fig.text(.5,.025,'Hash fixture: 128 MiB, three fresh processes per method, identical SHA256. Archive replay: 22 cached evidence blobs.',ha='center',fontsize=9,color='#465260')
fig.subplots_adjust(left=.08,right=.98,bottom=.17,top=.81,wspace=.3)
svg=Path('/home/ubuntu/workspace/chase/EmbodiedForge/docs/experiments/assets/architecture-subtraction-20261029-095651-fivehour-overview.svg')
fig.savefig(svg)
fig.savefig(work/'overview.png',dpi=150)
print(svg)
