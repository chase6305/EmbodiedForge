"""Sustained private CPU artifact fixtures; not robot training or a speed benchmark."""
import argparse
import ast
import copy
import hashlib
import io
import json
import logging
import os
import subprocess
import sys
import tarfile
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch


def utc():
    return datetime.now(timezone.utc).isoformat()


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--source', type=Path, required=True)
    cli.add_argument('--output', type=Path, required=True)
    cli.add_argument('--seconds', type=float, required=True)
    cli.add_argument('--fifo', action='store_true')
    args = cli.parse_args()
    sys.path.insert(0, str(args.source.resolve()))
    import torch
    from tensorboard.compat.proto.event_pb2 import Event
    from tensorboard.compat.proto.summary_pb2 import Summary
    from tensorboard.summary.writer.event_file_writer import EventFileWriter
    from embodiedforge import _h1_worker, _microduck_worker, morphmimic, native_h1
    from embodiedforge.learning.checkpoints import finite_tensors
    from embodiedforge.runtime import artifacts
    from embodiedforge.runtime.hashing import file_sha256
    from embodiedforge.runtime.process import termination_signals

    torch.set_num_threads(1)
    artifacts.LOGGER.setLevel(logging.CRITICAL + 1)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    fixture = output / 'fixtures'
    fixture.mkdir()
    source = fixture / 'source'
    source.mkdir()
    text = b'author-source-fixture\n'
    (source / 'algorithm.py').write_bytes(text)
    archive = fixture / 'source.tar.gz'
    with tarfile.open(archive, 'w:gz') as bundle:
        member = tarfile.TarInfo('commit/algorithm.py')
        member.size = len(text)
        bundle.addfile(member, io.BytesIO(text))
    morphmimic.ARCHIVE_SHA256 = file_sha256(archive)
    invalid_archive = fixture / 'invalid.tar'
    with tarfile.open(invalid_archive, 'w') as bundle:
        member = tarfile.TarInfo('commit/../escape')
        bundle.addfile(member, io.BytesIO(b''))
    invalid_digest = file_sha256(invalid_archive)
    good_digest = morphmimic.ARCHIVE_SHA256

    # Load exactly the two pure phase functions from this revision; avoid SDK/GPU imports.
    mdp_path = args.source / 'embodiedforge/locomotion/microduck/tasks/mdp.py'
    selected = [n for n in ast.parse(mdp_path.read_text()).body
                if isinstance(n, ast.FunctionDef) and n.name in ('crouch_pose_blend', 'phase_pose_blend')]
    assert len(selected) == 2
    namespace = {'torch': torch}
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(mdp_path), 'exec'), namespace)

    h1_root = fixture / 'h1'
    h1_run = h1_root / 'logs/rsl_rl/h1_flat/fixture'
    (h1_run / 'params').mkdir(parents=True)
    for name in ('agent.yaml', 'env.yaml'):
        (h1_run / 'params' / name).write_text('{}\n')
    h1_state = {'iter': 2, 'actor_state_dict': {
        'mlp.0.weight': torch.zeros(128, 69), 'mlp.6.weight': torch.zeros(19, 128)},
        'critic_state_dict': {'mlp.0.weight': torch.zeros(128, 69), 'mlp.6.weight': torch.zeros(1, 128)},
        'optimizer_state_dict': {}, 'metadata': {'rate': 0.25}}
    h1_checkpoint = h1_run / 'model_2.pt'
    torch.save(h1_state, h1_checkpoint)
    writer = EventFileWriter(str(h1_run))
    try:
        for step in range(3):
            writer.add_event(Event(step=step, summary=Summary(value=[
                Summary.Value(tag=tag, simple_value=1.0)
                for tag in ('Loss/value', 'Loss/surrogate', 'Policy/mean_std')])))
    finally:
        writer.close()
    h1_args = argparse.Namespace(run=h1_root, start=0, updates=3)
    expected_h1 = _h1_worker.verify(h1_args)
    assert expected_h1['finite_checkpoint_tensors'] == 4

    micro_state = {'iter': 42, 'infos': {'env_state': {'common_step_counter': 1032}},
        'actor_state_dict': {'weight': torch.ones(2)},
        'critic_state_dict': {'weight': torch.zeros(2)},
        'optimizer_state_dict': {'param_groups': [{'lr': 3e-5}],
                                 'state': {0: {'exp_avg': torch.zeros(2)}}}}
    micro_checkpoint = fixture / 'micro.pt'
    replacement = fixture / 'replacement.pt'
    saved = fixture / 'saved.pt'
    torch.save(micro_state, saved)
    saved_bytes = saved.read_bytes()
    saved_digest = hashlib.sha256(saved_bytes).hexdigest()
    altered = copy.deepcopy(micro_state)
    altered['iter'] = 43
    altered['infos']['env_state']['common_step_counter'] = 1056
    torch.save(altered, replacement)
    replacement_bytes = replacement.read_bytes()
    assert hashlib.sha256(replacement_bytes).hexdigest() != saved_digest
    record_path = fixture / 'publication.json'

    counts = Counter()
    failures = []
    started = time.monotonic()
    began = utc()
    last_sample = started
    last_cold = started - 60
    samples = []
    cycle = 0
    warmup = 8
    active_error = None
    source_hashes = {str(p.relative_to(args.source)): file_sha256(p)
                     for p in [Path(_h1_worker.__file__), Path(_microduck_worker.__file__),
                               Path(morphmimic.__file__), Path(native_h1.__file__), mdp_path,
                               args.source / 'embodiedforge/learning/checkpoints.py']}

    def reject(call, label):
        try:
            call()
        except ValueError:
            counts[label] += 1
        else:
            raise AssertionError('Accepted invalid fixture: ' + label)

    def sample(status):
        proc = Path('/proc/self/status').read_text()
        values = dict(line.split(':', 1) for line in proc.splitlines() if ':' in line)
        row = {'time': utc(), 'seconds': time.monotonic() - started,
               'cycles': max(0, cycle - warmup),
               'rss_kib': int(values['VmRSS'].split()[0]),
               'fds': len(os.listdir('/proc/self/fd'))}
        samples.append(row)
        with (output / 'samples.jsonl').open('a') as stream:
            stream.write(json.dumps(row) + '\n')
        state = {'status': status, 'started_at': began, 'requested_seconds': args.seconds,
                 'seconds': row['seconds'], 'cycles': row['cycles'], 'warmup_cycles': warmup,
                 'scenario_counts_including_warmup': dict(counts), 'last_sample': row,
                 'source': str(args.source), 'source_hashes': source_hashes,
                 'scope': __doc__, 'failures': failures}
        if status != 'running':
            state['finished_at'] = utc()
            stable = [r for r in samples if r['cycles'] >= 8]
            if stable:
                state['observed_rss_kib_range_after_warmup'] = [min(r['rss_kib'] for r in stable), max(r['rss_kib'] for r in stable)]
                state['observed_fd_range_after_warmup'] = [min(r['fds'] for r in stable), max(r['fds'] for r in stable)]
        artifacts.write_json(output / 'summary.json', state)
        print(json.dumps(row), flush=True)

    with termination_signals():
        try:
            while cycle < warmup or time.monotonic() - started < args.seconds:
                tick = time.monotonic()
                # Shared traversal remains tensor-only unless the H1 caller requests strict floats.
                value = {'weights': [torch.ones(2), (torch.zeros(1),)], 'metadata': float('nan')}
                assert finite_tensors(value) == 2
                reject(lambda: native_h1.validate_tensors(value), 'h1_scalar_rejection')
                value['metadata'] = {'nested': [(0.25,)]}
                assert native_h1.validate_tensors(value) is None
                counts['native_h1_validation'] += 1
                assert _h1_worker.check_checkpoint(h1_checkpoint) == {
                    'checkpoint_iteration': 2, 'finite_checkpoint_tensors': 4}
                counts['isaac_h1_checkpoint'] += 1

                micro_checkpoint.write_bytes(saved_bytes)
                result = _microduck_worker.checkpoint_metadata(micro_checkpoint)
                assert result['sha256'] == saved_digest and result['iteration'] == 42
                counts['microduck_checkpoint'] += 1
                replacement.write_bytes(replacement_bytes)
                original_load = torch.load
                def load_then_replace(*a, **kw):
                    result = original_load(*a, **kw)
                    os.replace(replacement, micro_checkpoint)
                    return result
                with patch.object(torch, 'load', load_then_replace):
                    assert _microduck_worker.checkpoint_metadata(micro_checkpoint) == result
                counts['atomic_replacement_same_descriptor'] += 1

                assert morphmimic.verify_source(source, archive)['verified_files'] == 1
                counts['source_validation'] += 1
                (source / 'algorithm.py').write_bytes(b'tampered source')
                reject(lambda: morphmimic.verify_source(source, archive), 'source_tamper_rejection')
                (source / 'algorithm.py').write_bytes(text)
                morphmimic.ARCHIVE_SHA256 = invalid_digest
                try:
                    reject(lambda: morphmimic.verify_source(source, invalid_archive), 'archive_traversal_rejection')
                finally:
                    morphmimic.ARCHIVE_SHA256 = good_digest
                if args.fifo and cycle % 20 == 0:
                    (source / 'algorithm.py').unlink()
                    os.mkfifo(source / 'algorithm.py')
                    reject(lambda: morphmimic.verify_source(source, archive), 'source_fifo_rejection')
                    (source / 'algorithm.py').unlink()
                    (source / 'algorithm.py').write_bytes(text)

                phase = torch.tensor([0., .1, .2, .3, .5, .65, .8, 1.], dtype=torch.float64, requires_grad=True)
                expected = torch.tensor([0., .5, 1., 1., 1., .5, 0., 0.], dtype=phase.dtype)
                expected_grad = torch.tensor([5., 5., 0., 0., -10/3, -10/3, 0., 0.], dtype=phase.dtype)
                for name in ('crouch_pose_blend', 'phase_pose_blend'):
                    blend = namespace[name](phase.reshape(2, 4).T, .2, .5, .8)
                    torch.testing.assert_close(blend.T.flatten(), expected)
                    (gradient,) = torch.autograd.grad(blend.sum(), phase)
                    torch.testing.assert_close(gradient, expected_grad)
                counts['phase_values_and_gradients'] += 1

                artifacts.write_json(record_path, {'cycle': cycle, 'status': 'committed'})
                committed = record_path.read_bytes()
                reject(lambda: artifacts.write_json(record_path, {'invalid': float('nan')}), 'json_serialization_failure')
                assert record_path.read_bytes() == committed
                primary = OSError('fixture publication failure')
                secondary = KeyboardInterrupt('fixture cleanup cancellation')
                unlink = os.unlink
                def fail_replace(*a, **kw):
                    raise primary
                def fail_unlink(path, *a, **kw):
                    if os.fspath(path).startswith(str(record_path) + '.'):
                        raise secondary
                    return unlink(path, *a, **kw)
                try:
                    with patch.object(os, 'replace', fail_replace), patch.object(os, 'unlink', fail_unlink):
                        artifacts.write_json(record_path, {'status': 'uncommitted'})
                except OSError as error:
                    assert error is primary
                else:
                    raise AssertionError('Publication failure disappeared')
                assert record_path.read_bytes() == committed
                for entry in os.scandir(fixture):
                    if entry.name.startswith('publication.json.') and entry.name.endswith('.tmp'):
                        os.unlink(entry.path)
                counts['json_cleanup_primary_exception'] += 1

                if time.monotonic() - last_cold >= 60:
                    micro_checkpoint.write_bytes(saved_bytes)
                    commands = [
                        [sys.executable, '-I', _h1_worker.__file__, 'verify', '--run', str(h1_root), '--start', '0', '--updates', '3', '--output', str(fixture / 'h1-cli.json')],
                        [sys.executable, '-I', _microduck_worker.__file__, 'checkpoint', str(micro_checkpoint), str(fixture / 'micro-cli.json')],
                    ]
                    for command in commands:
                        done = subprocess.run(command, cwd=fixture, capture_output=True, timeout=30)
                        assert done.returncode == 0, done.stderr.decode(errors='replace')
                        with (output / 'cold-processes.jsonl').open('a') as stream:
                            stream.write(json.dumps({'at': utc(), 'command': command, 'returncode': done.returncode,
                                'stdout_sha256': hashlib.sha256(done.stdout).hexdigest(),
                                'stderr_sha256': hashlib.sha256(done.stderr).hexdigest()}) + '\n')
                    assert json.loads((fixture / 'h1-cli.json').read_text()) == expected_h1
                    assert json.loads((fixture / 'micro-cli.json').read_text())['sha256'] == saved_digest
                    counts['isolated_cli_pairs'] += 1
                    last_cold = time.monotonic()
                cycle += 1
                if time.monotonic() - last_sample >= 30 or cycle == warmup:
                    sample('running')
                    last_sample = time.monotonic()
                time.sleep(max(0., .25 - (time.monotonic() - tick)))
            for name, digest in source_hashes.items():
                assert file_sha256(args.source / name) == digest, 'Source changed during soak: ' + name
            sample('complete')
        except BaseException as error:
            active_error = error
            failures.append(type(error).__name__ + ': ' + str(error))
            sample('failed')
            raise


if __name__ == '__main__':
    main()
