"""Reconcile the private evidence into the experiment report; enforce final gates."""
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
WORK = Path('/tmp/embodiedforge-subtraction-20261029-095651-fivehour')


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def refresh(final=False):
    state = read(WORK / 'state.json')
    now = datetime.now(timezone.utc)
    started = datetime.fromisoformat(state['started_at'])
    deadline = datetime.fromisoformat(state['deadline'])
    if final:
        assert now >= deadline, 'The requested five hours have not elapsed'
    expected = set(state['changed_files_this_round'])
    selected = read(WORK / 'baseline-files.json')
    changed = sorted(name for name, old in selected.items()
                     if not (ROOT / name).is_file() or digest(ROOT / name) != old['sha256'])
    assert set(changed) == expected, {'unexpected': sorted(set(changed) - expected),
                                    'expected_not_changed': sorted(expected - set(changed))}
    original = read(WORK / 'historical-files.json')
    assert all((ROOT / name).is_file() and digest(ROOT / name) == value
               for name, value in original.items()), 'An original historical artifact changed'
    assets = read(WORK / 'asset-identities.json')['baseline_resources']
    assert all(digest(ROOT / name) == value['sha256'] for name, value in assets.items())
    model_checks = []
    for name, old in state['preserved_models'].items():
        assert digest(ROOT / name) == old['sha256'], name
        model_checks.append({'path': name, 'sha256': old['sha256']})
    prior = read(ROOT / 'docs/experiments/optimization-resume-20261029.json')
    data_checks = prior['morphmimic']['verified_data']
    assert all(digest(Path(item['path'])) == item['sha256'] for item in data_checks)
    for robot, result in prior['morphmimic']['training_results'].items():
        path = Path(result['checkpoint'])
        assert digest(path) == result['checkpoint_sha256'], robot
        model_checks.append({'robot': robot, 'path': str(path), 'sha256': result['checkpoint_sha256']})
    registry = read(ROOT / 'runs/supermimic/tasks/backflip/reference/current.json')
    expected_backflip = prior['supermimic']['checkpoint_sha256']
    assert registry['checkpoint_sha256'] == expected_backflip
    assert digest(ROOT / registry['checkpoint']) == expected_backflip
    model_checks.append({'path': registry['checkpoint'], 'sha256': expected_backflip})
    revisions = {}
    for name in state['changed_production_files_this_round']:
        frozen = WORK / ('candidate-archive' if name.endswith('/morphmimic.py') else 'candidate-final') / name
        assert digest(ROOT / name) == digest(frozen), name
        revisions[name] = digest(ROOT / name)
    preservation = {'checked_at': now.isoformat(), 'baseline_files_checked': len(selected),
                    'changed_baseline_files': changed, 'unexpected_changes': [],
                    'original_historical_files_unchanged': len(original),
                    'baseline_packaged_resources_unchanged': len(assets),
                    'morphmimic_reference_checks': data_checks,
                    'model_and_registry_checks': model_checks, 'final_source_hashes': revisions}
    write(WORK / ('preservation-final.json' if final else 'preservation-current.json'), preservation)
    jobs = []
    for job in state['owned_jobs']:
        summary = read(Path(job['summary']))
        assert not summary['failures'], job['name']
        item = {**job, 'summary_data': summary}
        result_path = Path(job['supervisor']) / 'result.json'
        if result_path.exists():
            item['observed_process'] = read(result_path)
        if final:
            assert summary['status'] == 'complete', job['name']
            assert summary['seconds'] >= job['seconds'], job['name']
            observed = item['observed_process']
            assert observed['exit_observed'] and observed['completed_successfully'], job['name']
            assert observed['process_returncode'] == 0 and not observed['timed_out'], job['name']
            assert observed['supervisor_signal'] is None, job['name']
        jobs.append(item)
    modules = sorted((ROOT / 'src/embodiedforge').rglob('*.py'))
    after = sum(len(path.read_text().splitlines()) for path in modules)
    state['metrics'].update(modules_after=len(modules), source_lines_after=after,
                            source_lines_removed_net=state['baseline_source_lines'] - after)
    state['validation']['installed_distribution_final'] = read(WORK / 'distribution-verification.json')
    state['validation']['skip_audit'] = read(WORK / 'skip-audit.json')
    state['validation']['api_surface_audit'] = read(WORK / 'api-surface-audit.json')
    state['validation']['duplicate_function_bodies'] = read(WORK / 'duplication-audit.json')
    state['validation']['unused_private_declarations'] = read(WORK / 'unused-private-audit.json')
    patch = WORK / 'source-subtraction.patch'
    state['this_round_patch'] = {'path': str(patch), 'sha256': digest(patch),
                                 'scope': f'Only {len(expected)} selected files relative to the start-of-round working tree; excludes earlier work and new experiment artifacts.',
                                 'reverse_apply_check': 'git apply --check --reverse passed without changing the working tree'}
    state['validation']['sustained_jobs'] = jobs
    state['validation']['preservation'] = preservation
    state['elapsed_seconds'] = (now - started).total_seconds()
    state['last_updated_at'] = now.isoformat()
    state['limits'] = [
        'Source-size reduction reproduces an already populated cached source manifest containing 22 evidence archives; not every clean checkout has that baseline size.',
        'Allocation measurements isolate the hashing expression on a private 128 MiB fixture; they are not whole-training memory or throughput measurements.',
        'Baseline and final CPU fixture workloads differ because the final fixture also tests newly fixed failures; their timing and RSS are not compared as a speed or memory benchmark.',
        'The four-hour final CPU fixture freezes the H1/Microduck/learning/MDP changes with the earlier common MorphMimic reader; the final MorphMimic archive reader has its own 9900-second fixture.',
        'MorphMimic retains 13/18 completed clips with the same detailed episode results as the prior run; five failed clips and tracking quality are not claimed solved by this refactor.',
        'The SuperMimic acceptance is one rollout of the existing seed138 reference checkpoint with all implemented physical gates passing, not a multi-seed or exact IsaacLab V14 reproduction.',
    ]
    if final:
        validation = state['validation']['source-release-archive-final-tests']
        assert validation['exit_code'] == 0 and validation['failed'] == validation['errors'] == 0
        assert state['validation']['supervisor_tool_exit_codes'] == {str(job['session_id']): 0 for job in jobs}
        assert state['elapsed_seconds'] >= 18000
        state.update(status='complete', finished_at=now.isoformat())
    for path in [WORK / 'state.json', ROOT / 'runs/architecture-subtraction-20261029-095651-fivehour/optimization.json',
                 ROOT / 'docs/experiments/architecture-subtraction-20261029-095651-fivehour.json']:
        write(path, state)
    print(json.dumps({'status': state['status'], 'elapsed_hours': state['elapsed_seconds'] / 3600,
                      'preserved_historical_files': len(original), 'metrics': state['metrics'],
                      'jobs': [{'name': job['name'], 'status': job['summary_data']['status'],
                                'seconds': job['summary_data']['seconds']} for job in jobs]}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--final', action='store_true')
    refresh(parser.parse_args().final)
