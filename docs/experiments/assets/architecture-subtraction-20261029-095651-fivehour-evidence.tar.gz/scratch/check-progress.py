"""Read-only liveness/heartbeat checks for the three owned sustained jobs."""
import json
from datetime import datetime, timezone
from pathlib import Path

work = Path('/tmp/embodiedforge-subtraction-20261029-095651-fivehour')
state = json.loads((work / 'state.json').read_text())
now = datetime.now(timezone.utc)
result = {'utc': now.isoformat(), 'goal_hours': (now - datetime.fromisoformat(state['started_at'])).total_seconds() / 3600,
          'jobs': []}
for job in state['owned_jobs']:
    summary = json.loads(Path(job['summary']).read_text())
    assert not summary['failures'], job['name']
    supervisor = Path(job['supervisor'])
    completed = supervisor / 'result.json'
    if completed.exists():
        observed = json.loads(completed.read_text())
        assert observed['exit_observed'] and observed['completed_successfully'], job['name']
        assert observed['process_returncode'] == 0 and not observed['timed_out'], job['name']
        assert summary['status'] == 'complete' and summary['seconds'] >= job['seconds'], job['name']
    elif summary['status'] == 'running':
        sample_time = datetime.fromisoformat(summary['last_sample']['time'])
        assert (now - sample_time).total_seconds() < 90, ('stale heartbeat', job['name'])
        started = json.loads((supervisor / 'started.json').read_text())
        command = Path('/proc') / str(started['supervisor_pid']) / 'cmdline'
        assert command.exists(), ('missing supervisor', job['name'])
        assert b'process_supervisor.py' in command.read_bytes(), ('supervisor PID reused', job['name'])
    else:
        assert summary['status'] == 'complete', summary['status']
    result['jobs'].append({'name': job['name'], 'status': summary['status'],
                           'minutes': round(summary['seconds'] / 60, 1), 'cycles': summary['cycles'],
                           'fds': summary['last_sample']['fds'], 'failures': len(summary['failures']),
                           'observed_normal_exit': completed.exists()})
print(now.isoformat(), 'goal_hours=', round(result['goal_hours'], 3))
for item in result['jobs']:
    print(item['name'], item['status'], str(item['minutes']) + 'min',
          'cycles=' + str(item['cycles']), 'fds=' + str(item['fds']),
          'failures=' + str(item['failures']), 'observed_normal_exit=' + str(item['observed_normal_exit']))
