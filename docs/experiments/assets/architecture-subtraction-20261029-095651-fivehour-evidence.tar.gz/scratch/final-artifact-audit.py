"""Recheck the retained release blobs and the exact archive membership reduction."""
import hashlib
import json
import tarfile
from pathlib import Path

work = Path('/tmp/embodiedforge-subtraction-20261029-095651-fivehour')
state = json.loads((work / 'state.json').read_text())
verified = json.loads((work / 'distribution-verification.json').read_text())
before = state['distribution_phase1']['before']
sources = [(Path(before['path']), before)]
for name, expected in verified['distribution'].items():
    path = work / 'distribution-candidate5' / name
    if not path.exists():
        path = work / 'distribution-candidate4' / name
    sources.append((path, expected))
checks = []
for path, expected in sources:
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    assert value.hexdigest() == expected['sha256'], path
    assert path.stat().st_size == expected['bytes'], path
    checks.append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': value.hexdigest()})
with tarfile.open(before['path']) as old, tarfile.open(work / 'distribution-candidate5/embodiedforge-0.1.0.tar.gz') as new:
    a, b = set(old.getnames()), set(new.getnames())
    removed, added = sorted(a - b), sorted(b - a)
    assert len(removed) == 22 and not added, (removed, added)
    assert all('/docs/experiments/' in name and name.endswith('.tar.gz') for name in removed)
    assert not any('/docs/experiments/' in name and name.endswith('.tar.gz') for name in b)
result = {'status': 'passed', 'blobs': checks, 'source_members_removed': removed,
          'source_members_added': added, 'scope': 'Retained artifacts match recorded SHA256; only 22 historical TAR member names removed from the original cached-manifest source archive.'}
(work / 'distribution-integrity-final.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': 'passed', 'verified_blobs': len(checks),
                  'removed_historical_tar_members': len(removed), 'new_member_names': len(added)}))
