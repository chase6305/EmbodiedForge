"""Allocation control for the old H1 hash expression and shared bounded hashing."""
import argparse
import ast
import gc
import hashlib
import json
import resource
import subprocess
import sys
import time
import tracemalloc
from pathlib import Path

work = Path('/tmp/embodiedforge-subtraction-20261029-095651-fivehour')
parser = argparse.ArgumentParser()
parser.add_argument('--method', choices=['read_bytes', 'stream'])
parser.add_argument('--input', type=Path)
args = parser.parse_args()
if args.method:
    sys.path.insert(0, str(work / 'candidate-final/src'))
    from embodiedforge.runtime.hashing import stream_sha256
    text = (work / 'baseline/src/embodiedforge/_h1_worker.py').read_text()
    expression = next(n.value for n in ast.walk(ast.parse(text))
                      if isinstance(n, ast.keyword) and n.arg == 'checkpoint_sha256')
    expression = compile(ast.Expression(expression), '<baseline-h1-hash>', 'eval')
    checkpoint = args.input
    gc.collect()
    before_rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    tracemalloc.start()
    began = time.perf_counter()
    if args.method == 'read_bytes':
        digest = eval(expression, {'hashlib': hashlib, 'checkpoint': checkpoint})
    else:
        with checkpoint.open('rb') as stream:
            digest = stream_sha256(stream)
    seconds = time.perf_counter() - began
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    print(json.dumps({'method': args.method, 'bytes': checkpoint.stat().st_size,
          'digest': digest, 'peak_python_bytes': peak,
          'peak_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
          'initial_peak_rss_kib': before_rss, 'seconds': seconds}))
else:
    fixture = work / 'hash-allocation-input.bin'
    with fixture.open('xb') as stream:
        stream.truncate(128 * 1024 * 1024)
    results = []
    for repetition in range(3):
        for method in ['read_bytes', 'stream']:
            done = subprocess.run([sys.executable, '-I', '-S', __file__, '--method', method, '--input', str(fixture)],
                                  capture_output=True, text=True, check=True, timeout=30)
            result = json.loads(done.stdout)
            result['repetition'] = repetition
            results.append(result)
    assert len({r['digest'] for r in results}) == 1
    report = {'scope': 'Isolated H1 file-hash expression over a 128 MiB private sparse-zero fixture; Python allocations and process RSS, not robot training.', 'results': results}
    (work / 'hash-allocation.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
