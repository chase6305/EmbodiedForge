"""Differential compatibility controls against the saved pre-change source."""
import ast
import collections
import hashlib
import json
import math
import random
import sys
import time
from pathlib import Path
import numpy as np
import torch

torch.set_num_threads(1)
work=Path('/tmp/embodiedforge-subtraction-20261029-095651-fivehour')
roots={'before':work/'baseline/src/embodiedforge','after':work/'candidate-final/src/embodiedforge'}
namespaces={}
sources={}
for label,root in roots.items():
    namespace={'math':math,'torch':torch}
    for file,functions in [('learning/checkpoints.py',{'finite_tensors'}),('native_h1.py',{'validate_tensors'}),('locomotion/microduck/tasks/mdp.py',{'crouch_pose_blend','phase_pose_blend'})]:
        path=root/file
        text=path.read_text()
        sources[f'{label}/{file}']=hashlib.sha256(text.encode()).hexdigest()
        body=[n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name in functions]
        assert len(body)==len(functions)
        exec(compile(ast.Module(body=body,type_ignores=[]),str(path),'exec'),namespace)
    namespaces[label]=namespace

pool=[None,True,False,0,42,'nan',b'metadata',0.25,float('nan'),float('inf'),-float('inf'),complex(float('nan'),0),np.float32('nan'),np.float64('nan'),np.array([np.nan]),torch.empty(0),torch.zeros(3),torch.arange(8).reshape(2,4).T,torch.tensor([True,False]),torch.tensor([1.,float('nan')]),torch.tensor([complex(1,2)]),torch.tensor([complex(float('inf'),0)])]
counts=collections.Counter()
failures=[]
began=time.monotonic()
def outcome(function,value):
    try:
        result=function(value)
        return ('ok',type(result).__name__,result)
    except Exception as error:
        return (type(error).__name__,str(error))
def tree(rng,depth):
    if depth==0 or rng.random()<.45:
        return rng.choice(pool)
    children=[tree(rng,depth-1) for _ in range(rng.randrange(4))]
    kind=rng.randrange(3)
    return children if kind==0 else tuple(children) if kind==1 else {f'field{i}':v for i,v in enumerate(children)}
for seed in range(5):
    rng=random.Random(seed)
    for case in range(2500):
        value=tree(rng,4)
        for name in ['finite_tensors','validate_tensors']:
            before=outcome(namespaces['before'][name],value)
            after=outcome(namespaces['after'][name],value)
            assert before==after,(seed,case,name,before,after)
            counts[f'{name}/{before[0]}']+=1
    for case in range(100):
        bounds=sorted(rng.uniform(.01,.99) for _ in range(3))
        values=[rng.uniform(-.1,1.1) for _ in range(32)]+bounds+[0.0]
        for dtype in [torch.float32,torch.float64]:
            phase=torch.tensor(values,dtype=dtype,requires_grad=True).reshape(6,6).T
            for name in ['crouch_pose_blend','phase_pose_blend']:
                before=namespaces['before'][name](phase,*bounds)
                after=namespaces['after'][name](phase,*bounds)
                torch.testing.assert_close(before,after,rtol=0,atol=0,equal_nan=True)
                grad_before=torch.autograd.grad(before.sum(),phase)[0]
                grad_after=torch.autograd.grad(after.sum(),phase)[0]
                torch.testing.assert_close(grad_before,grad_after,rtol=0,atol=0,equal_nan=True)
                counts['phase_values_and_gradients_exact']+=1
report={'status':'complete','scope':'Saved-source vs final-source CPU validation outcomes and pure phase tensor values/gradients; no training quality claim.','seconds':time.monotonic()-began,'seeds':5,'nested_cases':12500,'counts':dict(counts),'source_sha256':sources,'failures':failures}
(work/'validation-differential.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
