"""Rebuild the final source archive after the documentation-only correction."""
import hashlib
import json
import os
import shutil
import subprocess
import tarfile
import time
from pathlib import Path

root = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
work = Path('/tmp/embodiedforge-subtraction-20261029-095651-fivehour')
previous = json.loads((work / 'distribution-verification.json').read_text())
before = work / 'distribution-candidate4/embodiedforge-0.1.0.tar.gz'
parent = work / 'release-stage5'
parent.mkdir()
with tarfile.open(before) as bundle:
    bundle.extractall(parent)
stage = parent / 'embodiedforge-0.1.0'
shutil.copy2(root / 'docs/README.md', stage / 'docs/README.md')
cached = (work / 'baseline-cached-SOURCES.txt').read_bytes()
(stage / 'src/embodiedforge.egg-info/SOURCES.txt').write_bytes(cached)
links = []
for name in cached.decode().splitlines():
    if name.startswith('docs/experiments/') and name.endswith('.tar.gz'):
        target = stage / name
        target.parent.mkdir(parents=True, exist_ok=True)
        os.link(root / name, target)
        links.append(name)
assert len(links) == 22
output = work / 'distribution-candidate5'
started = time.monotonic()
with (work / 'distribution-candidate5.log').open('wb') as log:
    subprocess.run([shutil.which('uv'), 'build', '--sdist', '--no-build-isolation', '--out-dir', str(output)],
                   cwd=stage, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=300)
after = output / before.name
with tarfile.open(before) as old, tarfile.open(after) as new:
    a = {member.name: member for member in old if member.isfile()}
    b = {member.name: member for member in new if member.isfile()}
    assert a.keys() == b.keys(), (a.keys() - b.keys(), b.keys() - a.keys())
    changed = [name.split('/', 1)[1] for name in a
               if old.extractfile(a[name]).read() != new.extractfile(b[name]).read()]
    assert changed == ['docs/README.md'], changed
    assert not any('/docs/experiments/' in name and name.endswith('.tar.gz') for name in b)
    release = work / 'source-release5'
    release.mkdir()
    new.extractall(release)
source = release / 'embodiedforge-0.1.0'
with (work / 'source-release-documentation-tests.log').open('wb') as log:
    subprocess.run(['/home/ubuntu/miniconda3/envs/xvla2/bin/python', '-m', 'pytest', '-q',
                    'tests/test_documentation.py', '--tb=short',
                    '--junitxml=' + str(work / 'source-release-documentation-tests.xml')],
                   cwd=source, env={**os.environ, 'PYTHONPATH': 'src', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1'},
                   stdout=log, stderr=subprocess.STDOUT, check=True, timeout=60)
previous.update(build_stage_root=str(stage), source_release_root=str(source))
previous['distribution'][after.name] = {'bytes': after.stat().st_size,
                                      'sha256': hashlib.sha256(after.read_bytes()).hexdigest()}
previous['documentation_only_rebuild'] = {
    'seconds': time.monotonic() - started, 'replayed_cached_evidence_archives': len(links),
    'source_files_changed_from_stage4': changed,
    'all_other_source_archive_members_byte_identical': True,
    'full_suite_source': str(work / 'source-release4/embodiedforge-0.1.0'),
    'installed_wheel': 'Stage4 wheel retained: all modules and resources unchanged; documentation is not shipped in wheels.',
    'source_documentation_tests': str(work / 'source-release-documentation-tests.xml'),
}
(work / 'distribution-verification.json').write_text(json.dumps(previous, indent=2) + '\n')
print(json.dumps(previous['documentation_only_rebuild'], indent=2))
print(json.dumps(previous['distribution'], indent=2))
