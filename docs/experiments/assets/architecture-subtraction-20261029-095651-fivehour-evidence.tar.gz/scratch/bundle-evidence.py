"""Archive selected final evidence without weights, caches or nested archives."""
import hashlib
import io
import json
import tarfile
from pathlib import Path

ROOT = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
WORK = Path('/tmp/embodiedforge-subtraction-20261029-095651-fivehour')
STEM = 'architecture-subtraction-20261029-095651-fivehour'
state = json.loads((WORK / 'state.json').read_text())
assert state['status'] == 'complete', 'Run refresh-report.py --final after all jobs and five hours'
target = ROOT / 'docs/experiments/assets' / (STEM + '-evidence.tar.gz')
assert not target.exists(), 'Do not silently replace a published evidence archive'
files = {}


def include(path, name):
    assert path.is_file() and not path.is_symlink(), str(path)
    assert name not in files and not name.startswith('/') and '..' not in Path(name).parts
    files[name] = path


for path in WORK.iterdir():
    if path.is_file() and path.suffix in {'.py', '.json', '.xml', '.log', '.strace', '.txt', '.patch'}:
        include(path, 'scratch/' + path.name)
for path in (WORK / 'baseline').rglob('*'):
    if path.is_file() and '__pycache__' not in path.parts and path.suffix.lower() != '.stl':
        include(path, 'baseline/' + path.relative_to(WORK / 'baseline').as_posix())
for name in state['changed_files_this_round']:
    include(ROOT / name, 'final/' + name)
for directory in WORK.iterdir():
    if not directory.is_dir():
        continue
    if directory.name.startswith(('soak-', 'archive-stream-')):
        for path in directory.iterdir():
            if path.is_file() and path.suffix in {'.json', '.jsonl', '.log'}:
                include(path, 'scratch/' + path.relative_to(WORK).as_posix())
    elif directory.name == 'parity-phase1':
        for path in directory.rglob('*'):
            if path.is_file() and path.suffix in {'.json', '.jsonl', '.log', '.xml'}:
                include(path, 'scratch/' + path.relative_to(WORK).as_posix())
run = ROOT / 'runs' / STEM
for path in run.rglob('*'):
    if path.is_file() and path.suffix in {'.json', '.jsonl', '.log', '.xml', '.npz'}:
        if path.suffix == '.npz' and {'assets', 'inputs'} & set(path.relative_to(run).parts):
            continue
        include(path, 'run/' + path.relative_to(run).as_posix())
include(ROOT / state['resources_plot'], 'figures/' + Path(state['resources_plot']).name)
manifest = {
    'description': 'Five-hour subtraction evidence. Baseline snapshot plus final changed files, private verification scripts, pytest logs, fixture progress/observed exits and selected real acceptance outputs.',
    'excluded': ['Model weights and ONNX exports (hashes retained)', 'Compiled physics model, copied reference clips and mesh assets from acceptance runs',
                 'Distribution archives and staging/install trees (hashes and contents validation retained)',
                 '128 MiB private allocation input', 'Unchanged baseline STL meshes (asset-identities.json retains hashes)',
                 'Nested historical evidence archives', 'Python bytecode'],
    'files': {},
}
with tarfile.open(target, 'w:gz', compresslevel=6) as bundle:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        manifest['files'][name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        entry.mode = 0o644
        bundle.addfile(entry, io.BytesIO(data))
    data = (json.dumps(manifest, indent=2) + '\n').encode()
    entry = tarfile.TarInfo('manifest.json')
    entry.size = len(data)
    entry.mode = 0o644
    bundle.addfile(entry, io.BytesIO(data))
with tarfile.open(target) as bundle:
    assert set(bundle.getnames()) == set(manifest['files']) | {'manifest.json'}
    for name, expected in manifest['files'].items():
        with bundle.extractfile(name) as incoming:
            data = incoming.read()
        assert len(data) == expected['bytes']
        assert hashlib.sha256(data).hexdigest() == expected['sha256'], name
value = hashlib.sha256()
with target.open('rb') as stream:
    for chunk in iter(lambda: stream.read(1024 * 1024), b''):
        value.update(chunk)
state['evidence_bundle'] = {'path': target.relative_to(ROOT).as_posix(), 'bytes': target.stat().st_size,
                            'sha256': value.hexdigest(), 'verified_members': len(manifest['files']) + 1,
                            'manifest': 'manifest.json',
                            'report_snapshot': 'scratch/state.json',
                            'report_snapshot_note': 'Frozen before adding this archive checksum to avoid self-reference.'}
for path in [WORK / 'state.json', run / 'optimization.json', ROOT / 'docs/experiments' / (STEM + '.json')]:
    path.write_text(json.dumps(state, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
print(json.dumps(state['evidence_bundle'], indent=2))
