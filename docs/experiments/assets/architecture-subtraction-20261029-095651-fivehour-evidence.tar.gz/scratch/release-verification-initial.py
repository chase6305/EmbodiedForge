"""Reproduce a populated source manifest and inspect the resulting distributions."""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import time
import zipfile
from pathlib import Path

root = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
work = Path('/tmp/embodiedforge-subtraction-20261029-095651-fivehour')
stage_parent = work / 'release-stage'
stage_parent.mkdir()
with tarfile.open(work / 'distribution-phase1/embodiedforge-0.1.0.tar.gz') as bundle:
    bundle.extractall(stage_parent)
stage = stage_parent / 'embodiedforge-0.1.0'
selected = json.loads((work / 'baseline-files.json').read_text())
for name in selected:
    source = root / name
    target = stage / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
with tarfile.open(work / 'distribution-before/embodiedforge-0.1.0.tar.gz') as bundle:
    names = bundle.getnames()
    manifest_name = next(n for n in names if n.endswith('.egg-info/SOURCES.txt'))
    cached_manifest = bundle.extractfile(manifest_name).read()
(work / 'baseline-cached-SOURCES.txt').write_bytes(cached_manifest)
(stage / 'src/embodiedforge.egg-info/SOURCES.txt').write_bytes(cached_manifest)
links = []
for name in cached_manifest.decode().splitlines():
    if name.startswith('docs/experiments/') and name.endswith('.tar.gz'):
        target = stage / name
        target.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.link(root / name, target)
        except OSError:
            target.symlink_to(root / name)
        links.append(name)
assert len(links) == 22
output = work / 'distribution-candidate'
started = time.monotonic()
with (work / 'distribution-candidate.log').open('wb') as log:
    completed = subprocess.run([shutil.which('uv'), 'build', '--no-build-isolation', '--out-dir', str(output)],
                               cwd=stage, stdout=log, stderr=subprocess.STDOUT, timeout=300)
assert completed.returncode == 0
result = {'build_returncode': completed.returncode, 'candidate_build_seconds': time.monotonic() - started,
          'cached_archive_entries_replayed': len(links), 'source_release_root': str(stage), 'distribution': {}}
for artifact in output.iterdir():
    if artifact.name.startswith('embodiedforge'):
        result['distribution'][artifact.name] = {'bytes': artifact.stat().st_size,
            'sha256': hashlib.sha256(artifact.read_bytes()).hexdigest()}
archive = output / 'embodiedforge-0.1.0.tar.gz'
with tarfile.open(archive) as bundle:
    names = [n.split('/', 1)[1] for n in bundle.getnames() if '/' in n]
    assert not any(n.startswith('docs/experiments/') and n.endswith('.tar.gz') for n in names)
    result['nested_evidence_archives'] = 0
wheel = output / 'embodiedforge-0.1.0-py3-none-any.whl'
modules = {p.relative_to(root / 'src').as_posix(): p for p in (root / 'src/embodiedforge').rglob('*.py')}
resources = {p.relative_to(root / 'src').as_posix(): p for p in (root / 'src/embodiedforge').rglob('*')
             if p.is_file() and p.suffix not in ('.py', '.pyc') and '__pycache__' not in p.parts}
with zipfile.ZipFile(wheel) as bundle:
    shipped_modules = {n for n in bundle.namelist() if n.startswith('embodiedforge/') and n.endswith('.py')}
    assert shipped_modules == modules.keys(), (shipped_modules - modules.keys(), modules.keys() - shipped_modules)
    for name, path in {**modules, **resources}.items():
        assert bundle.read(name) == path.read_bytes(), name
result.update(exact_modules=len(modules), preserved_resources=len(resources))
installed = work / 'installed-wheel'
with (work / 'installed-wheel.log').open('wb') as log:
    subprocess.run([shutil.which('uv'), 'pip', 'install', '--target', str(installed), '--no-deps', str(wheel)],
                   stdout=log, stderr=subprocess.STDOUT, check=True, timeout=120)
script = """import sys
from pathlib import Path
sys.path.insert(0, sys.argv[1])
import embodiedforge
from embodiedforge.runtime import records
assert str(embodiedforge.__file__).startswith(sys.argv[1])
with records.managed_run(Path(sys.argv[2]), records.run_identity('wheel-probe', 'test')):
    pass
assert records.read_run(sys.argv[2])['status'] == 'complete'
assert not {'numpy', 'torch', 'mujoco', 'mjlab'} & sys.modules.keys()
"""
subprocess.run([sys.executable, '-I', '-S', '-c', script, str(installed), str(work / 'wheel-record')], check=True, timeout=30)
probe = "import sys; sys.path.insert(0, sys.argv[1]); from embodiedforge.cli import main; main(['plan', '--task', 'hold', '--num-envs', '2'])"
with (work / 'wheel-plan.json').open('wb') as log:
    subprocess.run([sys.executable, '-I', '-c', probe, str(installed)], stdout=log, check=True, timeout=30)
fixture = work / 'soak-probe2/fixtures'
python = '/home/ubuntu/miniconda3/envs/xvla2/bin/python'
commands = [
    [python, '-I', str(installed / 'embodiedforge/_h1_worker.py'), 'verify', '--run', str(fixture / 'h1'), '--start', '0', '--updates', '3', '--output', str(work / 'wheel-h1.json')],
    [python, '-I', str(installed / 'embodiedforge/_microduck_worker.py'), 'checkpoint', str(fixture / 'saved.pt'), str(work / 'wheel-microduck.json')],
]
for command in commands:
    subprocess.run(command, cwd=work, capture_output=True, check=True, timeout=30)
assert json.loads((work / 'wheel-h1.json').read_text()) == json.loads((fixture / 'h1-cli.json').read_text())
assert json.loads((work / 'wheel-microduck.json').read_text())['sha256'] == hashlib.sha256((fixture / 'saved.pt').read_bytes()).hexdigest()
result.update(installed_root=str(installed), standard_library_records=True, core_plan=True, isolated_artifact_workers=True)
(work / 'distribution-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2), flush=True)
