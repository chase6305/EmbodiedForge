import importlib.util
import json
import sys
from pathlib import Path
from types import SimpleNamespace
w=Path('/tmp/embodiedforge-subtraction-20261029-095651-fivehour')
if sys.argv[1]=='before':
    spec=importlib.util.spec_from_file_location('baseline_h1_artifacts',w/'baseline/src/embodiedforge/_h1_worker.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
else:
    sys.path.insert(0,str(w/'candidate-final/src'))
    from embodiedforge import _h1_worker as module
args=SimpleNamespace(run=w/'soak-probe2/fixtures/h1',start=0,updates=3)
print(json.dumps(module.verify(args),sort_keys=True))
