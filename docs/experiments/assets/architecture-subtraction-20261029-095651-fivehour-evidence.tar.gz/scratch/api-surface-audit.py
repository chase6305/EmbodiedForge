"""Compare top-level source declarations, separately recording intentional options."""
import ast
import json
from pathlib import Path

root = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
work = Path('/tmp/embodiedforge-subtraction-20261029-095651-fivehour')


def declarations(path):
    result = {}
    for node in ast.parse(path.read_text()).body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            result[node.name] = {'kind': type(node).__name__,
                                 'arguments': ast.dump(node.args, include_attributes=False),
                                 'returns': ast.dump(node.returns, include_attributes=False)
                                 if node.returns else None}
        elif isinstance(node, ast.ClassDef):
            result[node.name] = {'kind': 'ClassDef',
                                 'bases': [ast.dump(value, include_attributes=False) for value in node.bases]}
    return result


removed, added, changed = [], [], []
modules = sorted((work / 'baseline/src/embodiedforge').rglob('*.py'))
for before in modules:
    name = before.relative_to(work / 'baseline').as_posix()
    after = root / name
    assert after.is_file(), name
    a, b = declarations(before), declarations(after)
    removed.extend({'path': name, 'name': key} for key in a.keys() - b.keys())
    added.extend({'path': name, 'name': key} for key in b.keys() - a.keys())
    changed.extend({'path': name, 'name': key, 'before': a[key], 'after': b[key]}
                   for key in a.keys() & b.keys() if a[key] != b[key])
expected = {('src/embodiedforge/learning/checkpoints.py', 'finite_tensors'),
            ('src/embodiedforge/_h1_worker.py', 'check_checkpoint')}
assert not removed, removed
assert {(entry['path'], entry['name']) for entry in changed} == expected
assert {(entry['path'], entry['name']) for entry in added} == {('src/embodiedforge/morphmimic.py', '_source_members')}
result = {'scope': 'Top-level functions and classes, AST arguments/return annotations and class bases. Does not establish behavioral compatibility; separately tested.',
          'modules': len(modules), 'removed': removed, 'added': added, 'signature_changes': changed,
          'intentional_options': {'finite_tensors': 'keyword-only check_scalars=False preserves tensor-only default',
                                  'check_checkpoint': 'keyword-only include_hash=False preserves metadata-only default'}}
(work / 'api-surface-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('modules', 'removed', 'added', 'intentional_options')}, indent=2))
