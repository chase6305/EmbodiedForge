import builtins
import importlib.util
import io
import json
import os
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

w=Path('/tmp/embodiedforge-subtraction-20261029-095651-fivehour')
sys.path.insert(0,str(w/'candidate-final/src'))
from embodiedforge import _h1_worker as after
spec=importlib.util.spec_from_file_location('baseline_h1_artifacts',w/'baseline/src/embodiedforge/_h1_worker.py')
before=importlib.util.module_from_spec(spec)
spec.loader.exec_module(before)
root=w/'soak-probe2/fixtures/h1'
checkpoint=root/'logs/rsl_rl/h1_flat/fixture/model_2.pt'
args=SimpleNamespace(run=root,start=0,updates=3)
original_builtin=builtins.open
original_io=io.open
original_os=os.open
reports={}
for label,module in [('before',before),('after',after)]:
    opens=[]
    def wrap(original):
        def call(path,*a,**kw):
            if isinstance(path,(str,os.PathLike)) and os.fspath(path)==str(checkpoint):
                opens.append(str(path))
            return original(path,*a,**kw)
        return call
    with patch.object(builtins,'open',wrap(original_builtin)),patch.object(io,'open',wrap(original_io)),patch.object(os,'open',wrap(original_os)):
        result=module.verify(args)
    reports[label]={'checkpoint_opens':len(opens),'result':result}
print(json.dumps({k:v['checkpoint_opens'] for k,v in reports.items()}),flush=True)
(w/'h1-open-count-probe.json').write_text(json.dumps(reports,indent=2)+'\n')
assert reports['before']['result']==reports['after']['result']
assert reports['before']['checkpoint_opens']==2
assert reports['after']['checkpoint_opens']==1
(w/'h1-open-count.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps({k:v['checkpoint_opens'] for k,v in reports.items()}))
