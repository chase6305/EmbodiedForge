"""Private plain/gzip TAR and atomic-replacement fixtures; no SDK execution."""
import argparse
import gzip
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile
import time
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
from unittest.mock import patch

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--seconds',type=float,required=True)
args=parser.parse_args()
sys.path.insert(0,str(args.source))
from embodiedforge import morphmimic
from embodiedforge.runtime.artifacts import write_json
from embodiedforge.runtime.hashing import file_sha256
from embodiedforge.runtime.process import termination_signals

output=args.output
output.mkdir(parents=True,exist_ok=False)
source=output/'source'
source.mkdir()
leaf=source/'algorithm.py'
archive=output/'source.tar'
replacement=output/'replacement.tar'
text_a=b'pinned source\n'
text_b=b'replacement source\n'

def tar_bytes(name,content):
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w') as bundle:
        member=tarfile.TarInfo(name)
        member.size=len(content)
        bundle.addfile(member,io.BytesIO(content))
    return buffer.getvalue()
raw=[tar_bytes('commit/algorithm.py',text_a),tar_bytes('commit/algorithm.py',text_b),tar_bytes('commit/../escape',b'')]
formats={'tar':raw,'gzip':[gzip.compress(value,mtime=0) for value in raw]}
stream_hash=morphmimic.stream_sha256
counts=Counter()
started=time.monotonic()
started_at=datetime.now(timezone.utc).isoformat()
last_sample=started
last_cold=started-60
cycles=0
warmup=8
watched={str(path.relative_to(args.source)):file_sha256(path) for path in [Path(morphmimic.__file__),args.source/'embodiedforge/runtime/hashing.py']}
failures=[]

def reject(call,phrase,label):
    try:
        call()
    except ValueError as error:
        assert phrase in str(error),(label,str(error))
        counts[label]+=1
    else:
        raise AssertionError('Accepted '+label)

def read_with_replacement():
    replaced=False
    def hash_then_publish(stream):
        nonlocal replaced
        digest=stream_hash(stream)
        if not replaced:
            os.replace(replacement,archive)
            replaced=True
        return digest
    with patch.object(morphmimic,'stream_sha256',hash_then_publish):
        return morphmimic.verify_source(source,archive)

def sample(status):
    values=dict(line.split(':',1) for line in Path('/proc/self/status').read_text().splitlines() if ':' in line)
    row={'time':datetime.now(timezone.utc).isoformat(),'seconds':time.monotonic()-started,'cycles':max(0,cycles-warmup),'rss_kib':int(values['VmRSS'].split()[0]),'fds':len(os.listdir('/proc/self/fd'))}
    assert not {'numpy','torch','mujoco','mjlab'} & sys.modules.keys()
    with (output/'samples.jsonl').open('a') as stream:
        stream.write(json.dumps(row)+'\n')
    data={'status':status,'started_at':started_at,'requested_seconds':args.seconds,'seconds':row['seconds'],'cycles':row['cycles'],'warmup_cycles':warmup,'scenario_counts_including_warmup':dict(counts),'last_sample':row,'source':str(args.source),'source_hashes':watched,'scope':__doc__,'failures':failures}
    if status!='running': data['finished_at']=datetime.now(timezone.utc).isoformat()
    write_json(output/'summary.json',data)
    print(json.dumps(row),flush=True)

with termination_signals():
    try:
        while cycles<warmup or time.monotonic()-started<args.seconds:
            tick=time.monotonic()
            for form,(a,b,bad) in formats.items():
                archive.write_bytes(a)
                leaf.write_bytes(text_a)
                morphmimic.ARCHIVE_SHA256=hashlib.sha256(a).hexdigest()
                assert morphmimic.verify_source(source,archive)['verified_files']==1
                counts[f'{form}_valid']+=1
                leaf.write_bytes(text_b)
                reject(lambda:morphmimic.verify_source(source,archive),'source changed',f'{form}_source_tamper')
                archive.write_bytes(a)
                replacement.write_bytes(b)
                reject(read_with_replacement,'source changed',f'{form}_replacement_rejects_wrong_source')
                archive.write_bytes(a)
                replacement.write_bytes(b)
                leaf.write_bytes(text_a)
                accepted=read_with_replacement()
                assert accepted['archive_sha256']==hashlib.sha256(a).hexdigest()
                assert accepted['verified_files']==1
                counts[f'{form}_replacement_reads_pinned_snapshot']+=1
                archive.write_bytes(bad)
                morphmimic.ARCHIVE_SHA256=hashlib.sha256(bad).hexdigest()
                reject(lambda:morphmimic.verify_source(source,archive),'Unexpected source archive entry',f'{form}_traversal')
                archive.write_bytes(a)
                morphmimic.ARCHIVE_SHA256=hashlib.sha256(a).hexdigest()
                if cycles%20==0:
                    leaf.unlink()
                    os.mkfifo(leaf)
                    reject(lambda:morphmimic.verify_source(source,archive),'Expected a regular file',f'{form}_fifo')
                    leaf.unlink()
                    leaf.write_bytes(text_a)
            if time.monotonic()-last_cold>=60:
                code="import sys,json; from pathlib import Path; sys.path.insert(0,sys.argv[1]); from embodiedforge import morphmimic; morphmimic.ARCHIVE_SHA256=sys.argv[4]; result=morphmimic.verify_source(Path(sys.argv[2]),Path(sys.argv[3])); assert result['verified_files']==1; assert not {'numpy','torch','mujoco','mjlab'} & sys.modules.keys(); print(json.dumps(result,sort_keys=True))"
                command=[sys.executable,'-I','-S','-c',code,str(args.source),str(source),str(archive),morphmimic.ARCHIVE_SHA256]
                result=subprocess.run(command,capture_output=True,check=True,timeout=15)
                with (output/'cold-processes.jsonl').open('a') as stream:
                    stream.write(json.dumps({'time':datetime.now(timezone.utc).isoformat(),'returncode':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest()})+'\n')
                counts['cold_stdlib_verifier']+=1
                last_cold=time.monotonic()
            cycles+=1
            if cycles==warmup or time.monotonic()-last_sample>=30:
                sample('running')
                last_sample=time.monotonic()
            time.sleep(max(0,.1-(time.monotonic()-tick)))
        for name,digest in watched.items(): assert file_sha256(args.source/name)==digest
        sample('complete')
    except BaseException as error:
        failures.append(type(error).__name__+': '+str(error))
        sample('failed')
        raise
