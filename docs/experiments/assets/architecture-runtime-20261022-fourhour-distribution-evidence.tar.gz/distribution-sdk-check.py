import json,runpy,sys
from pathlib import Path
import torch,mujoco,numpy
import embodiedforge
root=Path('/tmp/embodiedforge-fourhour-20261022')
package=Path(embodiedforge.__file__).resolve()
assert package.is_relative_to(root/'sdist-unpacked/embodiedforge-0.1.0/src')
torch.set_num_threads(1)
assert not torch.cuda.is_initialized()
preload={'package':str(package),'numpy':numpy.__version__,'torch':torch.__version__,'mujoco':mujoco.__version__,'cuda_initialized':False}
(root/'distribution-sdk-preload.json').write_text(json.dumps(preload,indent=2)+'\n')
script=root/'sdist-unpacked/embodiedforge-0.1.0/benchmarks/process_fault_soak.py'
sys.argv=[str(script),'--duration','1500','--preload-core','--gc-threshold','10','--output',str(root/'final-distribution-sdk-gdb')]
runpy.run_path(str(script),run_name='__main__')
