"""Real child startup failures must not hang while unwinding Popen ownership."""

import json
import os
import signal
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

from embodiedforge.runtime import process


@pytest.mark.parametrize(
    "timeout", [float("nan"), float("inf"), -float("inf"), -1, True, "1", 10**1000]
)
def test_invalid_timeout_does_not_spawn_worker_or_claim_log(tmp_path, timeout):
    marker = tmp_path / "worker-started"
    log = tmp_path / "worker.log"
    with pytest.raises(ValueError, match="timeout must be finite and nonnegative"):
        process.run_process(
            [
                sys.executable,
                "-c",
                f"from pathlib import Path;Path({str(marker)!r}).touch()",
            ],
            cwd=tmp_path,
            env=os.environ.copy(),
            timeout=timeout,
            log_path=log,
        )
    assert not marker.exists()
    assert not log.exists()


@pytest.mark.skipif(os.name != "posix", reason="POSIX process ownership")
@pytest.mark.parametrize("signum", [signal.SIGINT, signal.SIGTERM, signal.SIGHUP])
@pytest.mark.parametrize("echo", [False, True])
@pytest.mark.parametrize("handled_error", [False, True])
def test_cancellation_during_popen_return_reaps_the_started_child(
    tmp_path, monkeypatch, signum, echo, handled_error
):
    marker = tmp_path / "child.pid"
    ready = tmp_path / "ready"
    worker = textwrap.dedent(f"""
        import os,signal,time
        from pathlib import Path
        Path({str(marker)!r}).write_text(str(os.getpid()))
        def stop(*args):
            Path({str(tmp_path / "cleaned")!r}).touch()
            raise SystemExit(0)
        signal.signal(signal.SIGINT,stop)
        Path({str(ready)!r}).touch()
        time.sleep(30)
    """)
    original = subprocess.Popen
    saved = {
        sig: signal.getsignal(sig)
        for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP)
    }

    class InterruptOnReturn(original):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            import time

            deadline = time.monotonic() + 3
            while not ready.exists():
                if time.monotonic() >= deadline:
                    raise AssertionError("worker did not become ready")
                time.sleep(0.005)
            os.kill(os.getpid(), signum)

    monkeypatch.setattr(process.subprocess, "Popen", InterruptOnReturn)

    def launch():
        process.run_process(
            [sys.executable, "-c", worker],
            cwd=tmp_path,
            env=os.environ.copy(),
            log_path=tmp_path / "worker.log",
            echo=echo,
        )

    try:
        with pytest.raises(KeyboardInterrupt) as caught:
            if handled_error:
                try:
                    raise ValueError("previous attempt already handled")
                except ValueError:
                    launch()
            else:
                launch()
        assert getattr(caught.value, "signum", signal.SIGINT) == signum
        assert (tmp_path / "cleaned").exists()
        with pytest.raises(ProcessLookupError):
            os.kill(int(marker.read_text()), 0)
        assert {sig: signal.getsignal(sig) for sig in saved} == saved
    finally:
        if marker.exists():
            pid = int(marker.read_text())
            try:
                os.killpg(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            try:
                os.waitpid(pid, 0)
            except ChildProcessError:
                pass


@pytest.mark.skipif(os.name != "posix", reason="POSIX signal masks")
def test_startup_cancellation_protection_does_not_block_worker_signals(tmp_path):
    mask = tmp_path / "mask.json"
    inherited = set(signal.pthread_sigmask(signal.SIG_BLOCK, []))
    process.run_process(
        [
            sys.executable,
            "-c",
            "import json,signal;from pathlib import Path;"
            f"Path({str(mask)!r}).write_text(json.dumps(sorted(signal.pthread_sigmask(signal.SIG_BLOCK,[]))))",
        ],
        cwd=tmp_path,
        env=os.environ.copy(),
        log_path=tmp_path / "worker.log",
    )
    assert set(json.loads(mask.read_text())) == inherited


@pytest.mark.skipif(sys.platform != "linux", reason="Linux SIGSTOP fixture")
def test_stopped_worker_is_force_killed_and_reaped_after_startup_cancellation(
    tmp_path, monkeypatch
):
    import time

    ready = tmp_path / "ready"
    original = subprocess.Popen
    started = []

    class Stopped(original):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            started.append(self)
            deadline = time.monotonic() + 3
            while not ready.exists():
                if time.monotonic() >= deadline:
                    raise AssertionError("worker did not become ready")
                time.sleep(0.005)
            os.kill(self.pid, signal.SIGSTOP)
            os.kill(os.getpid(), signal.SIGTERM)

    monkeypatch.setattr(process.subprocess, "Popen", Stopped)
    try:
        with pytest.raises(process.ProcessInterrupted) as caught:
            process.run_process(
                [
                    sys.executable,
                    "-c",
                    f"import time;from pathlib import Path;Path({str(ready)!r}).touch();time.sleep(30)",
                ],
                cwd=tmp_path,
                env=os.environ.copy(),
                log_path=tmp_path / "worker.log",
            )
        assert caught.value.signum == signal.SIGTERM
        assert started[0].returncode == -signal.SIGKILL
        with pytest.raises(ProcessLookupError):
            os.kill(started[0].pid, 0)
    finally:
        for child in started:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()


@pytest.mark.skipif(os.name != "posix", reason="POSIX process ownership")
@pytest.mark.parametrize("stage", ["construct", "start", "started"])
def test_log_thread_startup_failure_stops_and_reaps_the_owned_child(tmp_path, stage):
    ready = tmp_path / "child.pid"
    child = (
        "import os,time;from pathlib import Path;"
        f"Path({str(ready)!r}).write_text(str(os.getpid()));time.sleep(30)"
    )
    wrapper = textwrap.dedent(f"""
        import os,sys,time
        from pathlib import Path
        sys.path.insert(0, {str(Path(__file__).resolve().parents[1] / "src")!r})
        from embodiedforge.runtime import process
        original = process.threading.Thread
        primary = RuntimeError('log thread startup failed')
        def wait_ready():
            deadline=time.monotonic()+3
            while not Path({str(ready)!r}).is_file():
                if time.monotonic()>deadline: raise AssertionError('child not ready')
                time.sleep(.01)
        class Thread(original):
            def __init__(self, *args, **kwargs):
                if {stage!r}=='construct':
                    wait_ready()
                    raise primary
                super().__init__(*args,**kwargs)
            def start(self):
                if {stage!r}=='started': super().start()
                wait_ready()
                raise primary
        process.threading.Thread=Thread
        try:
            process.run_process([sys.executable,'-c',{child!r}],cwd=Path({str(tmp_path)!r}),
                env=os.environ.copy(),log_path=Path({str(tmp_path / "output.log")!r}))
        except RuntimeError as error:
            assert error is primary, repr(error)
        else:
            raise AssertionError('startup error was hidden')
        assert not any(t.is_alive() for t in process.threading.enumerate()
                       if t is not process.threading.main_thread())
        print('original error preserved; reader stopped; child reaped')
    """)
    owner = subprocess.Popen(
        [sys.executable, "-c", wrapper],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        start_new_session=True,
    )
    stalled = False
    try:
        try:
            stdout, stderr = owner.communicate(timeout=3)
        except subprocess.TimeoutExpired:
            stalled = True
            # Reap the baseline failure's child through its still-owning wrapper.
            if ready.exists():
                try:
                    os.killpg(int(ready.read_text()), signal.SIGKILL)
                except ProcessLookupError:
                    pass
            stdout, stderr = owner.communicate(timeout=3)
    finally:
        if owner.poll() is None:
            os.killpg(owner.pid, signal.SIGKILL)
            owner.communicate(timeout=3)
    assert not stalled, f"Startup failure left Popen waiting for its child: {stderr}"
    assert owner.returncode == 0, stderr
    assert "child reaped" in stdout
    with pytest.raises(ProcessLookupError):
        os.kill(int(ready.read_text()), 0)


@pytest.mark.skipif(os.name != "posix", reason="POSIX termination handlers")
@pytest.mark.parametrize("after_install", [False, True])
def test_partial_termination_handler_setup_restores_previous_handlers(
    monkeypatch, after_install
):
    original = signal.signal
    saved = {sig: signal.getsignal(sig) for sig in (signal.SIGTERM, signal.SIGHUP)}
    primary = OSError("handler installation failed")
    injected = False

    def fail(sig, handler):
        nonlocal injected
        if sig == signal.SIGHUP and not injected:
            injected = True
            if after_install:
                original(sig, handler)
            raise primary
        return original(sig, handler)

    try:
        original(signal.SIGHUP, signal.SIG_DFL)
        monkeypatch.setattr(process.signal, "signal", fail)
        with pytest.raises(OSError) as caught:
            with process.termination_signals():
                pytest.fail("Partial setup entered the protected body")
        assert caught.value is primary
        assert signal.getsignal(signal.SIGTERM) == saved[signal.SIGTERM]
        assert signal.getsignal(signal.SIGHUP) == signal.SIG_DFL
    finally:
        for sig, handler in saved.items():
            original(sig, handler)


@pytest.mark.skipif(os.name != "posix", reason="POSIX termination handlers")
def test_restore_failure_during_retry_is_not_hidden_by_a_handled_outer_error(
    monkeypatch,
):
    original = signal.signal
    previous = signal.getsignal(signal.SIGTERM)
    failure = OSError("signal restore failed during retry")

    def restore(sig, handler):
        result = original(sig, handler)
        if sig == signal.SIGTERM and handler == previous:
            raise failure
        return result

    monkeypatch.setattr(process.signal, "signal", restore)
    try:
        raise ValueError("previous attempt already handled")
    except ValueError:
        with pytest.raises(OSError) as caught:
            with process.termination_signals():
                pass
    assert caught.value is failure
    assert signal.getsignal(signal.SIGTERM) == previous


@pytest.mark.skipif(os.name != "posix", reason="POSIX termination handlers")
@pytest.mark.parametrize(
    "primary", [None, RuntimeError("worker failed"), KeyboardInterrupt()]
)
@pytest.mark.parametrize("after_restore", [False, True])
def test_signal_restore_failure_attempts_all_handlers_and_keeps_primary_error(
    monkeypatch, caplog, primary, after_restore
):
    original = signal.signal
    saved = {sig: signal.getsignal(sig) for sig in (signal.SIGTERM, signal.SIGHUP)}
    restore_error = OSError("signal restore failed")
    restored = []

    def fail(sig, handler):
        if handler == signal.SIG_DFL:
            restored.append(sig)
            if sig == signal.SIGTERM:
                if after_restore:
                    original(sig, handler)
                raise restore_error
        return original(sig, handler)

    try:
        for sig in saved:
            original(sig, signal.SIG_DFL)
        monkeypatch.setattr(process.signal, "signal", fail)
        expected = primary if primary is not None else restore_error
        with pytest.raises(type(expected)) as caught:
            with process.termination_signals():
                if primary is not None:
                    raise primary
        assert caught.value is expected
        assert restored == [signal.SIGTERM, signal.SIGHUP]
        assert signal.getsignal(signal.SIGHUP) == signal.SIG_DFL
        assert "signal restore failed" in caplog.text
    finally:
        for sig, handler in saved.items():
            original(sig, handler)
