import datetime,json,os,subprocess,sys,time
from pathlib import Path
config=json.loads(Path(sys.argv[1]).read_text());root=Path(config['output']);start=time.monotonic();began=datetime.datetime.now(datetime.timezone.utc).isoformat()
with root.with_suffix('.log').open('xb') as log:
 result=subprocess.run(config['command'],env={**os.environ,**config.get('env',{})},stdout=log,stderr=subprocess.STDOUT,timeout=config['timeout'])
report={'command':config['command'],'started_utc':began,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':time.monotonic()-start,'returncode':result.returncode,'interpreter_exit_verified':result.returncode==0}
for name in ('summary.json','run.json'):
 path=root/name
 report[name]=json.loads(path.read_text()) if path.is_file() else None
root.with_suffix('.exit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('summary.json','run.json')}),flush=True)
sys.exit(0 if result.returncode==0 else 1)
