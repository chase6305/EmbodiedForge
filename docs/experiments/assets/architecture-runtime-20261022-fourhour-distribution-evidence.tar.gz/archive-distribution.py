import datetime
import hashlib
import io
import json
import tarfile
import time
from pathlib import Path

ROOT = Path('/tmp/embodiedforge-fourhour-20261022')
PROJECT = Path('/home/ubuntu/workspace/chase/EmbodiedForge')
report_path = PROJECT / 'docs/experiments/architecture-runtime-20261022-fourhour.json'
report = json.loads(report_path.read_text())
groups = {}
for name in ('final-distribution-stdlib', 'distribution-sdk-retry'):
    root = ROOT / name
    exit_path = next(path for path in (ROOT / (name + '.exit.json'), ROOT / (name + '.gdb-exit.json')) if path.is_file())
    exit_record = json.loads(exit_path.read_text())
    summary = json.loads((root / 'summary.json').read_text())
    run = json.loads((root / 'run.json').read_text())
    assert exit_record['interpreter_exit_verified'] and summary['all_scenarios_passed'] and run['status'] == 'complete'
    groups[name] = {'summary': summary, 'run': run, 'exit': {key: value for key, value in exit_record.items() if key not in ('summary.json', 'run.json')}}
report['distribution_followup'] = {'status': 'complete', 'duration_seconds': {'installed_stdlib': 1500, 'sdk_retry': 180}, 'groups': groups, 'sdk_preload': json.loads((ROOT / 'distribution-sdk-preload.json').read_text()), 'stdlib_result': json.loads((ROOT / 'final-distribution-stdlib-result.json').read_text()), 'verified_scenarios': sum(item['summary']['verified_scenarios'] for item in groups.values()), 'all_accepted_groups_exited_zero': True, 'all_attempts_succeeded': False, 'initial_sdk_attempt': json.loads((ROOT / 'distribution-sdk-initial-failure.json').read_text()), 'sdk_retry_scope': 'Three-minute retry with benchmark recording graceful and forced startup stops separately; production source unchanged.'}
report['stage'] = 'Validations complete; final source and documentation audit'
report['last_updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
followup = ROOT / 'distribution-followup.json'
followup.write_text(json.dumps({'primary_evidence': report['evidence'], 'source_distribution': report['source_distribution'], 'validation': report['post_build_validation'], 'followup': report['distribution_followup']}, indent=2) + '\n')
paths = {}
for name in ('post-build-validation.json', 'sdist-integrity.json', 'sdist-build.log', 'sdist-tests.log', 'sdist-tests.xml', 'final-documentation.log', 'final-documentation.xml', 'sdist-faults.log', 'distribution-followup.json', 'distribution-sdk-preload.json', 'distribution-sdk-check.py', 'distribution-stdlib-check.py', 'distribution-capture.gdb', 'supervise_command.py', 'final-distribution-stdlib.config.json', 'final-distribution-stdlib-result.json', 'archive-distribution.py'):
    paths[name] = ROOT / name
for name in ('sdist-faults', 'final-distribution-stdlib', 'final-distribution-sdk-gdb', 'distribution-sdk-retry'):
    for filename in ('benchmark.py', 'run.json', 'summary.json', 'samples.jsonl'):
        path = ROOT / name / filename
        if path.is_file():
            paths[name + '/' + filename] = path
for name in ('final-distribution-stdlib', 'final-distribution-sdk-gdb', 'distribution-sdk-retry'):
    for suffix in ('.log', '.supervisor.log', '.exit.json', '.gdb-exit.json'):
        path = ROOT / (name + suffix)
        if path.is_file():
            paths[path.name] = path
for name in ('distribution-sdk-initial-failure.json', 'distribution-sdk-retry.py', 'distribution-retry.gdb', 'distribution-sdk-preload-retry.json', 'fallback-regressions.log', 'fallback-regressions.xml', 'review-main-suite.log', 'review-main-suite.xml', 'review-native-suite.log', 'review-native-suite.xml'):
    paths[name] = ROOT / name
for name in ('benchmarks/process_fault_soak.py', 'tests/test_process_startup.py'):
    paths['worktree/' + name] = PROJECT / name
for path in (ROOT / 'final-distribution-sdk-gdb/cycle').rglob('*'):
    if path.is_file():
        paths[path.relative_to(ROOT).as_posix()] = path
inventory = {name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for name, path in sorted(paths.items())}
manifest = json.dumps({'schema_version': 1, 'scope': 'Post-build validation of the source distribution and installed wheel; primary evidence archive remains immutable', 'entries': inventory}, indent=2).encode() + b'\n'
target = PROJECT / 'docs/experiments/assets/architecture-runtime-20261022-fourhour-distribution-evidence.tar.gz'
with tarfile.open(target, 'w:gz', compresslevel=9) as archive:
    info = tarfile.TarInfo('MANIFEST.json')
    info.size = len(manifest)
    info.mtime = int(time.time())
    archive.addfile(info, io.BytesIO(manifest))
    for name, path in sorted(paths.items()):
        archive.add(path, arcname=name, recursive=False)
with tarfile.open(target) as archive:
    assert set(archive.getnames()) == {'MANIFEST.json', *inventory}
    for name, expected in inventory.items():
        payload = archive.extractfile(name).read()
        assert len(payload) == expected['bytes'] and hashlib.sha256(payload).hexdigest() == expected['sha256'], name
identity = {'path': str(target.relative_to(PROJECT / 'docs/experiments')), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'bytes': target.stat().st_size, 'verified_entries': len(inventory), 'all_entries_decompressed_and_sha256_verified': True}
report['post_build_evidence'] = identity
report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
(ROOT / 'distribution-archive-result.json').write_text(json.dumps(identity, indent=2) + '\n')
print(json.dumps(identity))
