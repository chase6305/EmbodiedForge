import json,runpy,sys
from pathlib import Path
out=Path('/tmp/embodiedforge-fourhour-20261022')
sys.path.insert(0,str(out/'wheel-env/lib/python3.10/site-packages'))
import embodiedforge
from embodiedforge.runtime.records import read_run
assert Path(embodiedforge.__file__).is_relative_to(out/'wheel-env')
assert 'numpy' not in sys.modules
script=out/'final-source-v2/benchmarks/process_fault_soak.py'
sys.argv=[str(script),'--duration','1500','--output',str(out/'final-distribution-stdlib')]
runpy.run_path(str(script),run_name='__main__')
assert 'numpy' not in sys.modules
assert read_run(out/'final-distribution-stdlib')['status']=='complete'
report={'stdlib_only':True,'numpy_loaded':False,'package':embodiedforge.__file__}
(out/'final-distribution-stdlib-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
