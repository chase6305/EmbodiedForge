set pagination off
set confirm off
set print thread-events off
set print frame-arguments none
set follow-fork-mode parent
set detach-on-fork on
handle SIGINT nostop noprint pass
handle SIGTERM nostop noprint pass
handle SIGHUP nostop noprint pass
source /tmp/embodiedforge-fourhour-20261022/cpython-v3.12.0-libpython.py
run
python
import gdb,json,datetime
inferior=gdb.selected_inferior()
value=gdb.parse_and_eval('$_exitcode')
exitcode=None if value.type.code==gdb.TYPE_CODE_VOID else int(value)
report={'inferior_exitcode':exitcode,'stopped_pid':inferior.pid,'interpreter_exit_verified':exitcode==0,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
if inferior.pid:
    gdb.execute('thread apply all bt')
    gdb.execute('info registers')
    try: gdb.execute('py-bt')
    except gdb.error: pass
    try: gdb.execute('generate-core-file /tmp/embodiedforge-fourhour-20261022/final-distribution-sdk-gdb.local.core')
    except gdb.error: pass
with open('/tmp/embodiedforge-fourhour-20261022/final-distribution-sdk-gdb.gdb-exit.json','w') as stream:json.dump(report,stream,indent=2)
gdb.execute('quit 0' if exitcode==0 else 'quit 1')
end
