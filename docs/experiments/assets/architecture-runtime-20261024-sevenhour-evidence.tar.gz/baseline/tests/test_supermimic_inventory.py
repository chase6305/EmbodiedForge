"""Pinned sources and bounded motion discovery use actual filesystem evidence."""

import hashlib
import os
import subprocess

import pytest

from embodiedforge import supermimic as sm


@pytest.fixture
def checkout(tmp_path):
    root = tmp_path / "source"
    root.mkdir()

    def git(*args):
        return subprocess.check_output(
            ["git", "-C", str(root), *args], text=True
        ).strip()

    git("init", "-q")
    (root / "required.py").write_text("original source\n")
    (root / "other.py").write_text("original helper\n")
    git("add", ".")
    git(
        "-c",
        "user.name=Test",
        "-c",
        "user.email=test@example.invalid",
        "commit",
        "-qm",
        "fixture",
    )
    return root, git("rev-parse", "HEAD"), git


@pytest.mark.parametrize("flag", ["--assume-unchanged", "--skip-worktree"])
@pytest.mark.parametrize("name", ["required.py", "other.py"])
def test_hidden_tracked_changes_cannot_pass_source_preflight(checkout, flag, name):
    root, revision, git = checkout
    git("update-index", flag, name)
    (root / name).write_text("changed locally\n")
    assert not git("status", "--porcelain", "--untracked-files=no")
    with pytest.raises(ValueError, match="differs from pinned commit"):
        sm.source_identity(root, revision, ["required.py"])
    # Inspection must not alter the caller's index flags or source.
    assert not git("status", "--porcelain", "--untracked-files=no")
    assert (root / name).read_text() == "changed locally\n"


@pytest.mark.parametrize("flag", ["--assume-unchanged", "--skip-worktree"])
def test_clean_hidden_files_are_verified_without_mutating_index(checkout, flag):
    root, revision, git = checkout
    git("update-index", flag, "other.py")
    before = git("ls-files", "-v")
    result = sm.source_identity(root, revision, ["required.py"])
    assert (
        result["files"]["other.py"]
        == hashlib.sha256((root / "other.py").read_bytes()).hexdigest()
    )
    assert git("ls-files", "-v") == before


def test_missing_sparse_file_can_remain_outside_required_source_set(checkout):
    root, revision, git = checkout
    git("update-index", "--skip-worktree", "other.py")
    (root / "other.py").unlink()
    assert sm.source_identity(root, revision, ["required.py"])["revision"] == revision
    with pytest.raises(ValueError, match="Missing regular source file"):
        sm.source_identity(root, revision, ["other.py"])


def test_git_environment_cannot_redirect_checkout_inspection(
    checkout, tmp_path, monkeypatch
):
    root, revision, git = checkout
    fake = tmp_path / "unrelated.git"
    monkeypatch.setenv("GIT_DIR", str(fake))
    monkeypatch.setenv("GIT_WORK_TREE", str(tmp_path))
    monkeypatch.setenv("GIT_INDEX_FILE", str(tmp_path / "unrelated-index"))
    assert sm.source_identity(root, revision, ["required.py"])["revision"] == revision
    assert not fake.exists() and not (tmp_path / "unrelated-index").exists()


def test_nested_checkout_path_is_not_the_framework_root(checkout):
    root, revision, git = checkout
    nested = root / "nested"
    nested.mkdir()
    with pytest.raises(ValueError, match="checkout root"):
        sm.source_identity(nested, revision)


def test_source_change_during_hashing_is_rejected(checkout, monkeypatch):
    root, revision, git = checkout
    git("update-index", "--assume-unchanged", "required.py")
    original = sm.file_sha256

    def changing_hash(path):
        digest = original(path)
        previous = path.stat()
        path.write_text("changed source!\n")
        os.utime(path, ns=(previous.st_atime_ns, previous.st_mtime_ns))
        return digest

    monkeypatch.setattr(sm, "file_sha256", changing_hash)
    with pytest.raises(ValueError, match="Source changed during inspection"):
        sm.source_identity(root, revision, ["required.py"])


def test_motion_entry_budget_counts_nonmatching_files(tmp_path):
    for i in range(100):
        (tmp_path / f"unrelated-{i}.txt").touch()
    result = sm.inspect_motions(tmp_path, ".npz", entry_limit=17)
    assert result["entries_scanned"] == 17
    assert result["matched_files_at_least"] == 0
    assert result["enumeration_capped"] and not result["content_verified"]


def test_motion_match_budget_and_descriptor_cleanup(tmp_path):
    for i in range(20):
        (tmp_path / f"clip-{i}.npz").write_bytes(b"not an array")
    before = len(os.listdir("/proc/self/fd"))
    for _ in range(50):
        result = sm.inspect_motions(tmp_path, ".npz", match_limit=3)
        assert result["matched_files_at_least"] == 3
        assert result["enumeration_capped"]
    assert len(os.listdir("/proc/self/fd")) == before


def test_motion_scan_does_not_follow_symlink_files_or_directory_loops(tmp_path):
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "clip.npz").touch()
    motions = tmp_path / "motions"
    motions.mkdir()
    (motions / "loop").symlink_to(motions, target_is_directory=True)
    (motions / "elsewhere").symlink_to(outside, target_is_directory=True)
    (motions / "clip.npz").symlink_to(outside / "clip.npz")
    result = sm.inspect_motions(motions, ".npz")
    assert result["entries_scanned"] == 3
    assert result["matched_files_at_least"] == 0
    assert not result["enumeration_capped"]


def test_motion_depth_limit_is_explicit(tmp_path):
    nested = tmp_path / "one" / "two"
    nested.mkdir(parents=True)
    (nested / "clip.csv").touch()
    result = sm.inspect_motions(tmp_path, ".csv", depth_limit=2)
    assert result["depth_limited"] and result["enumeration_capped"]
    assert result["matched_files_at_least"] == 0
    result = sm.inspect_motions(tmp_path, ".csv", depth_limit=3)
    assert result["matched_files_at_least"] == 1
    assert not result["enumeration_capped"]


def test_motion_scan_closes_parent_descriptor_on_child_error(tmp_path, monkeypatch):
    (tmp_path / "child").mkdir()
    original = os.scandir

    def fail_child(path):
        if str(path).endswith("/child"):
            raise PermissionError("directory became unreadable")
        return original(path)

    monkeypatch.setattr(os, "scandir", fail_child)
    before = len(os.listdir("/proc/self/fd"))
    with pytest.raises(PermissionError):
        sm.inspect_motions(tmp_path, ".npz")
    assert len(os.listdir("/proc/self/fd")) == before


@pytest.mark.parametrize("path", [None, "missing"])
def test_missing_motion_root_is_an_empty_inventory(tmp_path, path):
    result = sm.inspect_motions(None if path is None else tmp_path / path, ".npz")
    assert result["entries_scanned"] == result["matched_files_at_least"] == 0
    assert not result["enumeration_capped"]
