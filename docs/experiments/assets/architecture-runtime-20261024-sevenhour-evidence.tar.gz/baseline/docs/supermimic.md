# SuperMimic 兼容性预检与接入规范

当前入口支持来源目录和离线预检，**尚未实现策略推理、训练或行为评测**。预检完成只表示前置条件与声明的元数据通过检查；`evaluation_ready` 和 `inference_executed` 始终为 `false`。它不会下载模型、导入复现项目、反序列化 checkpoint 或读取动作数组。

## 来源与固定版本

2026-10-23 检查的来源如下。目录记录是该日期的快照，不会自动判断上游是否发布了新版。

| 来源 | 固定提交 / 框架 | 接入边界 |
| --- | --- | --- |
| [官方项目](https://supermimic.github.io/)与[论文](https://arxiv.org/abs/2610.28480) | 未确认可用于本地推理的官方模型包和导出 ABI | 当前官方预检明确拒绝执行；后续需要另行授权的模型与接口说明 |
| [CuboiLeo/SuperMimic-Reproduced](https://github.com/CuboiLeo/SuperMimic-Reproduced/tree/d9be385b3eeb13a638fb33fb200d3bfd9be9839f) | `d9be385b3eeb13a638fb33fb200d3bfd9be9839f`；mjlab `8bb2bc9e187797689ec82c78c35019afd2fd0376` | 独立复现，MIT 代码；NPZ 动作和 `policy` / `config` checkpoint |
| [zita-ch/supermimic_vibed](https://github.com/zita-ch/supermimic_vibed/tree/a1508d42c9d1699a52e8233ab16d08c488441ab9) | `a1508d42c9d1699a52e8233ab16d08c488441ab9`；Isaac Lab `46d6cc3d7b115906fad12efd372fbf69f4e3d3ed` | 独立复现，MIT 代码；Isaac Lab 3 kit-less / Newton / MuJoCo Warp，CSV 动作和 `pi` / `args` checkpoint |

[官方演示许可证](https://supermimic.github.io/demo/LICENSE.html)限定浏览器中的个人非商业使用，不包含下载其模型、在本地推理或用其材料评测其他模型的权限。因此本入口不提取演示资产。两个独立复现不能标记成官方实现或官方权重。代码许可证也不替代动作数据、机器人资产和权重各自的许可证；vibed 使用的 LAFAN1 数据另有 CC BY-NC-ND 4.0 条款。

## 当前 G1 接口不能直接共用 checkpoint

| 项目 | 论文描述 | CuboiLeo 固定版本 | vibed 固定版本 |
| --- | --- | --- | --- |
| 动作 | G1 的 29 个关节 | 29 | 29 |
| 单帧本体观测 | 93 | 93 | 99，增加 6 维参考相对方向 |
| 历史 | 10 帧 | term-major 展平，930 维 | time-major 展平，990 维 |
| 目标 | 10 个未来帧 | 680；`anchor_obs=true` 时 689 | 730 |
| 归一化 | 需官方导出说明 | 固定分量尺度，以 checkpoint 配置为准 | RunningNorm，以 checkpoint 状态为准 |
| 控制频率 | 50 Hz | 50 Hz | 50 Hz，原始 CSV 动作按上游逻辑重采样 |

维度相同也不足以证明接口兼容。实际适配必须核对关节顺序、默认姿态、动作尺度、PD 参数、四元数顺序、坐标系、历史更新方向和归一化状态。CuboiLeo 的锚点增强实验使用额外观测，不能直接作为论文观测条件下的结果。两个项目的数据筛选、初始化和终止规则也需要分别记录。

官方策略仍是目标入口。两个复现可用于提前确定适配边界：CuboiLeo 的默认 93 维观测和 MuJoCo 路线更接近当前平台已有的接入方式，但依赖版本需要独立环境；vibed 则应作为另一套完整 SDK 和策略接口接入。不能将 vibed 的 99 维输入裁掉 6 维，或只重排 checkpoint 字段来复用同一适配器。

这些数值来自固定版本的源码，而非运行得到的指标：CuboiLeo 的 [`nets.py`](https://github.com/CuboiLeo/SuperMimic-Reproduced/blob/d9be385b3eeb13a638fb33fb200d3bfd9be9839f/src/supermimic/policy/nets.py)；vibed 的 [`mdp.py`](https://github.com/zita-ch/supermimic_vibed/blob/a1508d42c9d1699a52e8233ab16d08c488441ab9/supermimic/mdp.py)、[`networks.py`](https://github.com/zita-ch/supermimic_vibed/blob/a1508d42c9d1699a52e8233ab16d08c488441ab9/supermimic/networks.py)。

## 使用预检

在已安装 EmbodiedForge 的环境中执行；源码开发可在命令前设置 `PYTHONPATH=src`。

```bash
python -m embodiedforge supermimic catalog
python -m embodiedforge supermimic preflight \
  --backend cuboi-reproduced \
  --root /path/to/pinned/SuperMimic-Reproduced \
  --python /path/to/dedicated-sdk/bin/python \
  --checkpoint /path/to/authorized/policy.pt \
  --contract /path/to/policy.contract.json \
  --motions /path/to/authorized/npz-motions \
  --output runs/supermimic/preflight-cuboi
```

vibed 使用 `--backend vibed`、其固定源码目录与 CSV 动作目录。框架若为 editable 安装且分发元数据没有记录提交，可提供 `--framework-root /path/to/pinned/framework`；预检要求导入位置位于该目录中，且该仓库提交匹配、已跟踪文件没有修改。输出目录必须是新目录，避免覆盖历史记录。

SDK 在独立 Python 子进程中使用 `-I` 探测，清除继承的 Python 路径污染，记录 Python/包版本、框架提交与 Torch CUDA 可用性。它不安装或升级依赖。CuboiLeo 固定版本要求 Python 3.12、Torch ≥2.14、MuJoCo / MuJoCo Warp 3.16.x、Warp ≥1.15 以及指定 mjlab 提交。vibed 以其固定 Dockerfile 和 Isaac Lab 栈为准，预检不据包版本推断整个容器已经兼容。

源码目录必须是仓库根目录。检查会清除继承的 `GIT_*` 路径和配置覆盖，核对固定提交及已跟踪文件状态，并将必需文件的字节哈希与提交中的 blob 比较。对 `assume-unchanged`、`skip-worktree` 隐藏的现存文件也会比较内容；稀疏检出中缺失的非必需文件可以保留。检查不修改索引标记。这是源码预检，不表示运行环境或模型张量已验证。

退出码：`0` 为本次前置检查通过；`2` 为缺少条件或命令参数无效；`1` 为探测子进程或文件处理失败。取消和超时会分别记录 `interrupted`、`timed_out`。输出包含 `run.json`、`result.json`；运行过 SDK 探测时还包含 `sdk.json` 和 `sdk.log`。缺少 checkpoint、契约或动作会返回拒绝记录，不视为已完成推理。

## checkpoint 元数据契约 v1

JSON sidecar 由模型提供方或接入方根据实际模型填写，不能通过填写期望数值来证明权重兼容。以下为 CuboiLeo 默认配置的结构示例，关节名和 SHA 必须替换为实际值；`joint_names` 必须完整包含 29 个互不重复的名称，并按策略输出顺序排列。

```json
{
  "schema": "ef-supermimic-contract-v1",
  "backend": "cuboi-reproduced",
  "source_revision": "d9be385b3eeb13a638fb33fb200d3bfd9be9839f",
  "checkpoint_sha256": "实际 checkpoint 的 SHA-256",
  "robot": "unitree-g1-29dof",
  "control_hz": 50,
  "action_dim": 29,
  "history_frames": 10,
  "future_frames": 10,
  "observation_dim": 93,
  "observation_layout": "term-major",
  "goal_dim": 680,
  "anchor_obs": false,
  "joint_names": ["此处填写完整的 29 个真实关节名"]
}
```

vibed 的 `backend`、`source_revision`、`observation_dim`、`observation_layout`、`goal_dim` 分别换为 `vibed`、上表提交、`99`、`time-major`、`730`。当前契约固定 10 帧历史和 10 帧目标；其他配置需要新增明确版本，不会自动猜测。

预检只校验声明值与 checkpoint 文件哈希。它不校验张量、动作内容或上述关节顺序在机器人资产中的含义，因此报告明确保留 `tensors_verified=false` 和 `content_verified=false`。动作文件只做存在性检查：最多扫描 10,000 个目录项、记录 129 个匹配文件、进入 64 层目录，不跟随扫描到的符号链接，也不读取文件内容。结果记录扫描量和截断标记；达到上限但未发现匹配项时，不能据此断定整个目录没有动作文件。计数不是完整数据集统计。

## 动作格式与 GMR 转换边界

平台当前 GMR 回放 NPZ 包含 `metadata`、`time`、`positions`、`quaternions`、`joints` 等字段，姿态采用 `xyzw`。它不能直接作为 CuboiLeo 的训练或评测动作包使用。

CuboiLeo 的[转换器](https://github.com/CuboiLeo/SuperMimic-Reproduced/blob/d9be385b3eeb13a638fb33fb200d3bfd9be9839f/src/supermimic/data/motion_convert.py)输出包含 `fps`、`joint_pos`、`joint_vel`、`body_pos_w`、`body_quat_w`、`body_lin_vel_w`、`body_ang_vel_w`、`joint_names` 和 `body_names`。其 G1 转换器使用 29 个关节、30 个刚体、`wxyz` 刚体四元数，默认重采样至 50 Hz。后续转换必须基于匹配的 G1 模型补齐速度和刚体运动学，核对名称顺序，并明确源时间戳与首帧时刻；不能仅重命名 NPZ 字段。

vibed 的[动作加载器](https://github.com/zita-ch/supermimic_vibed/blob/a1508d42c9d1699a52e8233ab16d08c488441ab9/supermimic/motion.py)读取无表头 CSV：每行依次为根位置 3 维、根四元数 `xyzw` 4 维和关节角 29 维，默认源帧率为 30 Hz，再按 50 Hz 控制时钟重采样。关节序必须与它自己的 G1 运动学模型匹配。

当前入口不会执行这些转换，也不会验证数组字段。即使 `motion_data_present` 通过，已有 GMR NPZ 或其他同扩展名文件也不能据此判定兼容。拿到授权数据后的下一步是单独实现和验证转换器，再开展策略评测。

## 后续推理与评测的验收条件

获得对应来源授权的模型与完整导出说明后，单独实现适配器，并先以来源项目自己的 evaluator 为对照验证固定输入的动作输出。随后校验 G1 资产、步长、历史缓冲、归一化、关节映射和 PD 控制，再进行固定动作集、多种子、逐片段的仿真评测。

最终报告应包含来源与权重哈希、数据集清单及许可证、SDK/资产版本、种子、初始化与终止规则、失败片段和耗时。只有同一数据划分和观测条件下的结果才能并列比较。官方模型、CuboiLeo 和 vibed 使用不同来源标签；当前预检记录没有行为评测指标。
