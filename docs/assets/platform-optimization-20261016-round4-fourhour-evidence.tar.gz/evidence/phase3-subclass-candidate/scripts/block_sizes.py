"""Exploratory long-field block target tradeoffs; sustained probes stay active."""
import hashlib,importlib.util,json,statistics,time,tracemalloc
from pathlib import Path
from embodiedforge import motion as current
from motion_fixture import assert_reports,pair
ROOT=Path(__file__).resolve().parents[1];directory=ROOT/'block-size-experiment';directory.mkdir(exist_ok=True);source=Path(current.__file__).read_text();modules={'64Ki':current}
for target in (8,16,32,128,256):
    path=directory/f'motion_{target}.py';changed=source.replace('block = max(1, 64 * 1024 // width)',f'block = max(1, {target} * 1024 // width)');assert changed!=source;path.write_text(changed)
    spec=importlib.util.spec_from_file_location(f'embodiedforge.blocksize_{target}',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);modules[f'{target}Ki']=module
rows=[]
for frames,layout in [(8192,'contiguous'),(65536,'contiguous'),(8192,'fortran'),(8192,'strided')]:
    ref,roll=pair(frames,bodies=16,joints=29,layout=layout);expected=current.compare_clips(ref,roll)
    for m in modules.values():assert_reports(m.compare_clips(ref,roll),expected)
    samples={name:[] for name in modules}
    for i in range(11):
        order=list(modules);shift=i%len(order);order=order[shift:]+order[:shift]
        if i%2:order.reverse()
        for name in order:
            started=time.perf_counter();modules[name].compare_clips(ref,roll);samples[name].append(time.perf_counter()-started)
    peaks={}
    for name,m in modules.items():
        tracemalloc.start();m.compare_clips(ref,roll);peaks[name]=tracemalloc.get_traced_memory()[1];tracemalloc.stop()
    row=dict(frames=frames,layout=layout,samples=samples,median_seconds={name:statistics.median(values) for name,values in samples.items()},peak_traced_bytes=peaks);rows.append(row);print(json.dumps({k:v for k,v in row.items() if k!='samples'}),flush=True)
report=dict(status='passed',scope='Exploratory rotated target order on Python3.12/NumPy2.5.4 while three task-owned sustained probes remain active. Exact same per-field squared-error formula, small-field cutoff stays65536 scalars, only long-field chunk target differs. These are not quiet primary benchmarks and do not replace adopted-source evidence.',source_sha256={name:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for name,m in modules.items()},cases=rows)
(ROOT/'block-size-experiment.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
