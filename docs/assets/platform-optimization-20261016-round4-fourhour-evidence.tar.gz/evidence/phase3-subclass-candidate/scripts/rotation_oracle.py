"""Independent Hamilton-product rotation errors on arbitrary reference poses."""
import hashlib,importlib.util,itertools,json,math,platform,time
from pathlib import Path
import numpy as np
from embodiedforge import motion as candidate
from motion_fixture import arrange,assert_reports,pair
ROOT=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('embodiedforge.rotation_baseline',ROOT/'baseline/embodiedforge/motion.py');baseline=importlib.util.module_from_spec(s);s.loader.exec_module(baseline)
started=time.time();rows=[]


def angle(qa,qb):
    a,b=tuple(map(float,qa)),tuple(map(float,qb))
    w=math.fsum(x*y for x,y in zip(a,b,strict=True))
    x=math.fsum((a[0]*b[1],-a[1]*b[0],-a[2]*b[3],a[3]*b[2]))
    y=math.fsum((a[0]*b[2],a[1]*b[3],-a[2]*b[0],-a[3]*b[1]))
    z=math.fsum((a[0]*b[3],-a[1]*b[2],a[2]*b[1],-a[3]*b[0]))
    return 2*math.atan2(math.hypot(x,y,z),abs(w))


for i,(frames,dtype,layout,kind) in enumerate(itertools.product((4097,16385),('float32','float64','>f8'),('contiguous','fortran','reversed','strided','unaligned'),('mixed','tiny'))):
    rng=np.random.default_rng(81000+i);ref,roll=pair(frames,bodies=4,joints=17,dtype=dtype,layout=layout);expected={}
    for field,label in [('body_quat_w','body_rotation_rmse_rad'),('object_quat_w','object_rotation_rmse_rad')]:
        shape=ref.arrays[field].shape;qa=rng.normal(size=shape);qa/=np.linalg.norm(qa,axis=-1,keepdims=True)
        axis=rng.normal(size=(*shape[:-1],3));axis/=np.linalg.norm(axis,axis=-1,keepdims=True)
        theta=np.full(shape[:-1],1e-12) if kind=='tiny' else rng.uniform(0,np.pi,shape[:-1])
        w=np.cos(theta/2)[...,None];v=axis*np.sin(theta/2)[...,None]
        qb=np.concatenate((qa[...,:1]*w-(qa[...,1:]*v).sum(-1,keepdims=True),qa[...,:1]*v+w*qa[...,1:]+np.cross(qa[...,1:],v)),axis=-1)
        qb[::3]*=-1
        qa=arrange((qa*1.00025).astype(dtype),layout);qb=arrange((qb*0.99975).astype(dtype),layout)
        ref.arrays[field]=qa;roll.arrays[field]=qb
        expected[label]=math.sqrt(math.fsum(angle(a,b)**2 for a,b in zip(qa.reshape(-1,4),qb.reshape(-1,4),strict=True))/int(np.prod(shape[:-1])))
    old=baseline.compare_clips(ref,roll);new=candidate.compare_clips(ref,roll);diff=assert_reports(new,old)
    deviations={name:abs(new['metrics_all'][name]-value) for name,value in expected.items()}
    for name,value in expected.items():
        assert math.isclose(new['metrics_all'][name],value,rel_tol=3e-14,abs_tol=5e-16),(i,name,value,new['metrics_all'][name])
    rows.append(dict(frames=frames,dtype=dtype,layout=layout,kind=kind,max_baseline_difference=diff,hamilton_absolute_errors=deviations,expected=expected,actual={name:new['metrics_all'][name] for name in expected}))
    if len(rows)%10==0:print(json.dumps(dict(cases=len(rows),elapsed_seconds=time.time()-started)),flush=True)
report=dict(status='passed',scope='Independent scalar compensated Hamilton-product geodesic (2 atan2(vector norm, absolute scalar)) versus adopted normalized chord formula. Arbitrary reference orientations, arbitrary rotation axes, equivalent signs, near-unit scales, mixed [0,pi] and all1e-12 rotations, readonly layouts. Tolerance relative3e-14 absolute5e-16 radians accounts for binary input and cancellation; separate CI tests retain strict relative tiny-angle checks for identity references.',python=platform.python_version(),numpy=np.__version__,started_epoch=started,ended_epoch=time.time(),cases=len(rows),source_sha256={name:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for name,m in [('baseline',baseline),('candidate',candidate)]},max_hamilton_absolute_error=max(v for r in rows for v in r['hamilton_absolute_errors'].values()),rows=rows)
(ROOT/f'rotation-oracle-{platform.python_version()}-numpy{np.__version__}.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps({k:report[k] for k in ('status','cases','max_hamilton_absolute_error')}),flush=True)
