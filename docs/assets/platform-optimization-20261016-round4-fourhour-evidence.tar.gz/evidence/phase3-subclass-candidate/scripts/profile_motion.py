import cProfile
import importlib.util
import json
import pstats
import time
import tracemalloc
from pathlib import Path
from types import SimpleNamespace

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('embodiedforge.baseline_motion', ROOT / 'baseline/embodiedforge/motion.py')
# Relative import resolves to the current, unchanged MotionClips implementation.
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def make(frames, bodies, joints=29, dtype='float32', seed=4):
    rng = np.random.default_rng(seed)
    shapes = {'joint_pos': (frames, joints), 'body_pos_w': (frames, bodies, 3), 'object_pos_w': (frames, 3), 'body_quat_w': (frames, bodies, 4), 'object_quat_w': (frames, 4)}
    aa, bb = {}, {}
    for key, shape in shapes.items():
        aa[key] = rng.normal(size=shape).astype(dtype)
        bb[key] = (aa[key] + rng.normal(scale=0.05, size=shape)).astype(dtype)
        if 'quat' in key:
            aa[key] /= np.linalg.norm(aa[key], axis=-1, keepdims=True)
            bb[key] /= np.linalg.norm(bb[key], axis=-1, keepdims=True)
            bb[key][::3] *= -1
    for name in ('terminated', 'truncated', 'clip_end'):
        bb[name] = np.zeros(frames, bool)
    bb['clip_end'][-1] = True
    meta = dict(robot='profile', joint_names=[str(i) for i in range(joints)], body_names=[str(i) for i in range(bodies)], coordinate_frame='world', quaternion_order='wxyz')
    common = dict(fps=50, names=['clip'], objects=['box'], lengths=np.array([frames]), starts=np.array([0, frames]))
    return SimpleNamespace(**common, metadata=meta, arrays=aa, sha256='ref'), SimpleNamespace(**common, metadata={**meta, 'reference_sha256': 'ref'}, arrays=bb, sha256='rollout')


if __name__ == '__main__':
    results = []
    for frames, bodies in ((128, 16), (8192, 16), (65536, 16)):
        a, b = make(frames, bodies)
        module.compare_clips(a, b)
        start = time.perf_counter()
        for _ in range(3):
            report = module.compare_clips(a, b)
        seconds = (time.perf_counter() - start) / 3
        tracemalloc.start()
        module.compare_clips(a, b)
        peak = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
        results.append(dict(frames=frames, bodies=bodies, seconds=seconds, peak_traced_bytes=peak, metrics=report['metrics_all']))
        print(json.dumps(results[-1]), flush=True)
    profiler = cProfile.Profile()
    profiler.runcall(module.compare_clips, a, b)
    profiler.dump_stats(ROOT / 'motion-baseline-profile.pstats')
    with (ROOT / 'motion-baseline-profile.txt').open('w') as stream:
        pstats.Stats(profiler, stream=stream).sort_stats('cumulative').print_stats(25)
    (ROOT / 'motion-baseline-profile.json').write_text(json.dumps(results, indent=2) + '\n')
