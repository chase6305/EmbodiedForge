import importlib.util
import json
import statistics
import time
import tracemalloc
from pathlib import Path
from profile_motion import make, module as baseline

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('embodiedforge.motion_candidate', ROOT / 'motion_candidate.py')
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
rows = []
for frames, bodies in ((128, 16), (1024, 16), (8192, 16), (65536, 16), (8192, 32)):
    a, b = make(frames, bodies)
    metrics = {}
    for name, module in [('baseline', baseline), ('candidate', candidate)]:
        metrics[name] = module.compare_clips(a, b)['metrics_all']
    for key in metrics['baseline']:
        import numpy as np
        np.testing.assert_allclose(metrics['candidate'][key], metrics['baseline'][key], rtol=2e-14, atol=0)
    times = {'baseline': [], 'candidate': []}
    for pair in range(11):
        for name, module in ([('baseline', baseline), ('candidate', candidate)] if pair % 2 == 0 else [('candidate', candidate), ('baseline', baseline)]):
            start = time.perf_counter()
            module.compare_clips(a, b)
            times[name].append(time.perf_counter() - start)
    peak = {}
    for name, module in [('baseline', baseline), ('candidate', candidate)]:
        tracemalloc.start()
        module.compare_clips(a, b)
        peak[name] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    row = dict(frames=frames, bodies=bodies, times=times, medians={name: statistics.median(v) for name,v in times.items()}, peak_traced_bytes=peak, metrics=metrics)
    rows.append(row)
    print(json.dumps({k:v for k,v in row.items() if k not in ('times', 'metrics')}), flush=True)
(ROOT / 'motion-prototype-comparison.json').write_text(json.dumps(rows, indent=2) + '\n')
