import hashlib,importlib.util,json,statistics,time
from pathlib import Path
from motion_fixture import pair,assert_reports
from embodiedforge import motion as first
root=Path(__file__).resolve().parents[1]
modules={'first':first}
for name,path in [('baseline',root/'baseline/embodiedforge/motion.py'),('tuned',root/'motion_blocks.py')]:
 s=importlib.util.spec_from_file_location('embodiedforge.motion_'+name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);modules[name]=m
rows=[]
for frames,clips in [(128,1),(128,32),(1024,1),(8192,1),(65536,1)]:
 a,b=pair(frames,clips=clips,reorder=True,prefixes=True)
 results={name:m.compare_clips(a,b) for name,m in modules.items()}
 for r in results.values():assert_reports(r,results['baseline'])
 times={name:[] for name in modules};calls=100 if frames==128 and clips==1 else 20 if frames<=1024 else 1
 for i in range(21):
  names=list(modules);names=names[i%3:]+names[:i%3]
  if i%2:names.reverse()
  for name in names:
   start=time.perf_counter()
   for _ in range(calls):modules[name].compare_clips(a,b)
   times[name].append((time.perf_counter()-start)/calls)
 row=dict(frames=frames,clips=clips,seconds=times,medians={name:statistics.median(v) for name,v in times.items()});rows.append(row);print(json.dumps({k:v for k,v in row.items() if k!='seconds'}),flush=True)
(root/('motion-blocks-tuning-numpy'+__import__('numpy').__version__+'.json')).write_text(json.dumps(dict(status='passed',sources={name:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for name,m in modules.items()},cases=rows),indent=2)+'\n')
