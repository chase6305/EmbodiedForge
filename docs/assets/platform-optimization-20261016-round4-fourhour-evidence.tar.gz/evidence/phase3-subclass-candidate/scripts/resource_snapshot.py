"""Summarize actual sustained-probe resource samples without a leak claim."""
import json,statistics,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];rows=[]
for label in ('py312','numpy124','rotations-py310'):
    data=json.loads((ROOT/f'motion-{label}-progress.json').read_text());samples=data['samples'];assert samples
    assert all(s['fd']==data['fd_baseline'] and s['threads']==data['threads_baseline'] for s in samples)
    rss=[s['rss_bytes'] for s in samples];quarter=max(1,len(rss)//4)
    rows.append(dict(label=label,cases=data['cases'],sample_count=len(samples),rss_min_bytes=min(rss),rss_max_bytes=max(rss),rss_first_quarter_median_bytes=statistics.median(rss[:quarter]),rss_last_quarter_median_bytes=statistics.median(rss[-quarter:]),fd_values=sorted({s['fd'] for s in samples}),python_thread_values=sorted({s['threads'] for s in samples})))
report=dict(status='passed',observed_epoch=time.time(),scope='FD and Python-thread equality verified in every recorded sample and asserted after every case by the probe. RSS ranges/quarter medians are diagnostic samples across varying fixture shapes and allocator histories; they are not proof of no memory leak or a process memory bound. Probe weakrefs independently verify tested input object release after each case.',probes=rows)
path=ROOT/f'resource-snapshot-{int(time.time())}.json';path.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
