from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'phase1/motion.py').read_text()
start=s.index('def _position_rmse(');end=s.index('def compare_clips(',start)
helpers='''def _position_squared(reference, rollout):
    error = rollout.astype(np.float64) - reference
    return np.square(error)


def _rotation_squared(reference, rollout):
    qa, qb = (value.astype(np.float64) for value in (reference, rollout))
    qa /= np.linalg.norm(qa, axis=-1, keepdims=True)
    qb /= np.linalg.norm(qb, axis=-1, keepdims=True)
    # q and -q encode the same rotation. Chords retain small-angle precision.
    qb *= np.where((qa * qb).sum(axis=-1, keepdims=True) < 0, -1.0, 1.0)
    angle = 4 * np.arctan2(
        np.linalg.norm(qa - qb, axis=-1),
        np.linalg.norm(qa + qb, axis=-1),
    )
    return np.square(angle)


def _tracking_rmse(reference, rollout, squared_error, *, vector=False):
    """Score small fields directly; limit large trajectory scratch to frame blocks."""
    if reference.size <= 64 * 1024:
        squared = squared_error(reference, rollout)
        if vector:
            squared = squared.sum(axis=-1)
        return float(np.sqrt(squared.mean()))
    width = reference.size // len(reference)
    block = max(1, 64 * 1024 // width)
    total = 0.0
    count = 0
    for start in range(0, len(reference), block):
        squared = squared_error(
            reference[start : start + block], rollout[start : start + block]
        )
        if vector:
            squared = squared.sum(axis=-1)
        total += squared.sum()
        count += squared.size
        del squared
    return float(np.sqrt(total / count))


'''
s=s[:start]+helpers+s[end:]
s=s.replace('metrics[label] = _position_rmse(', 'metrics[label] = _tracking_rmse(').replace('                vector=field != "joint_pos",','                _position_squared,\n                vector=field != "joint_pos",')
s=s.replace('metrics[label] = _rotation_rmse(\n                reference.arrays[field][a], rollout.arrays[field][b]\n            )','metrics[label] = _tracking_rmse(\n                reference.arrays[field][a], rollout.arrays[field][b], _rotation_squared\n            )')
(root/'motion_tuned.py').write_text(s)
