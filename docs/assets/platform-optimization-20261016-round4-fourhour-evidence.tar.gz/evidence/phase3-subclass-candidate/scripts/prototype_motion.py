from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / 'baseline/embodiedforge/motion.py').read_text()
start = source.index('        metrics = {}\n')
end = source.index('        if not all(np.isfinite(value)', start)
replacement = '''        metrics = {}
        for field, label in (
            ("joint_pos", "joint_rmse_rad"),
            ("body_pos_w", "body_position_rmse_m"),
            ("object_pos_w", "object_position_rmse_m"),
        ):
            metrics[label] = _position_rmse(
                reference.arrays[field][a],
                rollout.arrays[field][b],
                vector=field != "joint_pos",
            )
        for field, label in (
            ("body_quat_w", "body_rotation_rmse_rad"),
            ("object_quat_w", "object_rotation_rmse_rad"),
        ):
            metrics[label] = _rotation_rmse(
                reference.arrays[field][a], rollout.arrays[field][b]
            )
'''
helpers = '''def _position_rmse(reference, rollout, *, vector):
    """Reduce long trajectories in blocks, keeping input arrays untouched."""
    width = int(np.prod(reference.shape[1:]))
    block = max(1, 64 * 1024 // width)
    total = 0.0
    count = 0
    for start in range(0, len(reference), block):
        error = rollout[start : start + block].astype(np.float64) - reference[
            start : start + block
        ]
        squared = np.square(error)
        if vector:
            squared = squared.sum(axis=-1)
        if len(reference) <= block:
            return float(np.sqrt(squared.mean()))
        total += squared.sum()
        count += squared.size
    return float(np.sqrt(total / count))


def _rotation_rmse(reference, rollout):
    """Use normalized quaternion chords, with bounded frame-block scratch."""
    width = int(np.prod(reference.shape[1:]))
    block = max(1, 64 * 1024 // width)
    total = 0.0
    count = 0
    for start in range(0, len(reference), block):
        qa, qb = (
            value[start : start + block].astype(np.float64)
            for value in (reference, rollout)
        )
        qa /= np.linalg.norm(qa, axis=-1, keepdims=True)
        qb /= np.linalg.norm(qb, axis=-1, keepdims=True)
        # q and -q encode the same rotation. Chords retain small-angle precision.
        qb *= np.where((qa * qb).sum(axis=-1, keepdims=True) < 0, -1.0, 1.0)
        angle = 4 * np.arctan2(
            np.linalg.norm(qa - qb, axis=-1),
            np.linalg.norm(qa + qb, axis=-1),
        )
        squared = np.square(angle)
        if len(reference) <= block:
            return float(np.sqrt(squared.mean()))
        total += squared.sum()
        count += squared.size
    return float(np.sqrt(total / count))


'''
source = source[:start] + replacement + source[end:]
source = source.replace('def compare_clips(reference, rollout):', helpers + 'def compare_clips(reference, rollout):')
(ROOT / 'motion_candidate.py').write_text(source)
