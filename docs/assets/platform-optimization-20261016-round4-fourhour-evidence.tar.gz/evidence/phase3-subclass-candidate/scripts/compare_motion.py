"""Alternating baseline/final full compare_clips; inputs and audits untimed."""
import argparse
import hashlib
import importlib.util
import json
import platform
import statistics
import time
import tracemalloc
from pathlib import Path

import numpy as np

from embodiedforge import motion as candidate
from motion_fixture import assert_reports, pair

ROOT = Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('embodiedforge.motion_baseline',ROOT/'baseline/embodiedforge/motion.py')
baseline=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline)
p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--pairs',type=int,default=15);args=p.parse_args()
assert args.pairs > 0
source={name:hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest() for name,module in [('baseline',baseline),('candidate',candidate)]}
cases=[dict(frames=n,layout='contiguous') for n in (128,1024,8192,65536)]
cases += [dict(frames=8192,layout=layout) for layout in ('fortran','reversed','strided','unaligned')]
cases += [dict(frames=8192,layout='contiguous',dtype=dtype) for dtype in ('float64','>f4')]
cases += [dict(frames=128,layout='contiguous',clips=32,reorder=True,prefixes=True),dict(frames=8192,layout='contiguous',clips=8,reorder=True,prefixes=True)]
rows=[]
for config in cases:
    reference,rollout=pair(**config)
    reports={name:module.compare_clips(reference,rollout) for name,module in [('baseline',baseline),('candidate',candidate)]}
    max_error=assert_reports(reports['candidate'],reports['baseline'])
    calls=50 if config['frames']==128 and config.get('clips',1)==1 else 8 if config['frames']<=1024 else 1
    runs={'baseline':[],'candidate':[]}
    for index in range(args.pairs):
        order=[('baseline',baseline),('candidate',candidate)]
        if index%2:order.reverse()
        for name,module in order:
            start=time.perf_counter()
            for _ in range(calls):module.compare_clips(reference,rollout)
            runs[name].append((time.perf_counter()-start)/calls)
    peaks={}
    for name,module in [('baseline',baseline),('candidate',candidate)]:
        tracemalloc.start();module.compare_clips(reference,rollout)
        peaks[name]=tracemalloc.get_traced_memory()[1];tracemalloc.stop()
    after={name:module.compare_clips(reference,rollout) for name,module in [('baseline',baseline),('candidate',candidate)]}
    for name in reports:assert after[name] == reports[name]
    medians={name:statistics.median(values) for name,values in runs.items()}
    row=dict(**config,bodies=16,joints=29,calls_per_sample=calls,pairs=args.pairs,reference_frames=int(reference.starts[-1]),rollout_frames=int(rollout.starts[-1]),input_sha256=dict(reference=reference.sha256,rollout=rollout.sha256),seconds=runs,median_seconds=medians,peak_traced_bytes=peaks,seconds_reduction_pct=100*(1-medians['candidate']/medians['baseline']),peak_reduction_pct=100*(1-peaks['candidate']/peaks['baseline']),max_absolute_metric_difference=max_error,results=reports)
    rows.append(row)
    print(json.dumps({k:row[k] for k in ('frames','layout','median_seconds','peak_traced_bytes','seconds_reduction_pct','peak_reduction_pct')}),flush=True)
    del reference,rollout
report=dict(status='passed',scope='Full CPU compare_clips with predecoded validated immutable synthetic full-format motions, including status/name alignment, all five metrics and per-clip aggregation. One warmup then alternating measured pairs; separate tracing and correctness passes. Shared unpinned host; no task-owned long stress active. No NPZ decode, generation, hash, simulation, or training in timing. Peak is traced temporary allocation, not input memory or RSS.',python=platform.python_version(),numpy=np.__version__,source_sha256=source,metric_tolerance=dict(relative=3e-14,absolute=1e-25),cases=rows)
assert source['candidate']==hashlib.sha256(Path(candidate.__file__).read_bytes()).hexdigest()
(ROOT/args.output).write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
