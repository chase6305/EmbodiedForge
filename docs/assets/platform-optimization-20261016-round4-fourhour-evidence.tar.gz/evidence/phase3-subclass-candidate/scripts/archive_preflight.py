"""Audit an in-memory active snapshot; final artifacts remain time gated."""
import gzip,hashlib,io,json,tarfile,time
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parents[1];repo=Path.cwd();allowed={'.py','.json','.log','.txt','.patch','.pstats','.svg','.html','.js','.xml'}
files=[f for f in ROOT.rglob('*') if f.is_file() and '__pycache__' not in f.parts and 'datasets' not in f.relative_to(ROOT).parts and f.name!='report-preview.json' and (f.suffix in allowed or f.name.startswith(('LICENSE','NOTICE')))]
final=list(json.loads((ROOT/'final-file-hashes.json').read_text())['sha256'])+['pyproject.toml'];blobs={}
for f in sorted(files):blobs[str(Path('evidence')/f.relative_to(ROOT))]=f.read_bytes()
for f in final:blobs[str(Path('final')/f)]=(repo/f).read_bytes()
assert all(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts for name in blobs)
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w:gz') as archive:
    # Progress files are atomically replaced by active workers. Header sizes
    # come from the same bytes snapshot, avoiding a stat/open replacement race.
    for name,data in blobs.items():
        info=tarfile.TarInfo(name);info.size=len(data);archive.addfile(info,io.BytesIO(data))
payload=buffer.getvalue();gzip.decompress(payload)
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as archive:
    names=archive.getnames();assert len(set(names))==len(names)==len(blobs)
    for member in archive:
        assert member.isfile() and archive.extractfile(member).read()==blobs[member.name]
state=json.loads((ROOT/'progress-state.json').read_text())
for f,h in state['initial_runtime_sha256'].items():assert hashlib.sha256(blobs[str(Path('evidence/baseline')/Path(f).relative_to('src'))]).hexdigest()==h
for f,h in json.loads(blobs['evidence/final-file-hashes.json'])['sha256'].items():assert hashlib.sha256(blobs['final/'+f]).hexdigest()==h
assert not (repo/'docs/platform-optimization-20261016-round4-fourhour.json').exists()
assert not (repo/'docs/assets/platform-optimization-20261016-round4-fourhour-evidence.tar.gz').exists()
report=dict(status='passed',observed_epoch=time.time(),scope='In-memory active snapshot of the final archive file-selection rules. Every byte/member, safe unique path, all105initial Python sources and final changed-file hashes verified. Active progress is not a completed endurance result; this does not create the final report or archive.',members=len(blobs),compressed_bytes=len(payload),snapshot_sha256=hashlib.sha256(payload).hexdigest(),all_initial_python_sources_verified=True,all_final_changed_file_hashes_verified=True,gzip_crc_checked=True,final_artifacts_created=False)
(ROOT/'archive-preflight.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
