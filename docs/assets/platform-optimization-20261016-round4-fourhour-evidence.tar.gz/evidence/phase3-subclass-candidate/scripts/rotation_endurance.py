"""Sustained independent Hamilton rotation oracle over arbitrary reference poses."""
import argparse,gc,hashlib,importlib.util,itertools,json,math,os,platform,threading,time,traceback,weakref
from pathlib import Path
import numpy as np
from embodiedforge import motion as candidate
from embodiedforge._motion_clips import MotionClips
from motion_fixture import arrange,assert_reports,pair
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--until',type=float,default=1792159871);p.add_argument('--cases',type=int,default=0);p.add_argument('--label',default='rotations-py310');args=p.parse_args()
s=importlib.util.spec_from_file_location('embodiedforge.rotation_endurance_baseline',ROOT/'baseline/embodiedforge/motion.py');baseline=importlib.util.module_from_spec(s);s.loader.exec_module(baseline)
source={name:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for name,m in [('baseline',baseline),('candidate',candidate)]}
configs=list(itertools.product((1,7,1023,1024,1025,4095,4096,4097,16383,16384,16385),(1,4,16),('float32','float64','>f8'),('contiguous','fortran','reversed','strided','unaligned'),('mixed','tiny','zero','nearpi')))
progress=ROOT/f'motion-{args.label}-progress.json';final=ROOT/f'motion-{args.label}.json';failure=ROOT/f'motion-{args.label}-failure.json';assert not final.exists() and not failure.exists()
started=last_report=time.time();fd=len(list(Path('/proc/self/fd').iterdir()));threads=len(threading.enumerate());cases=frames_seen=quaternions=0;max_difference=max_oracle=0.0;coverage=set();samples=[]


def distance(qa,qb):
    a,b=tuple(map(float,qa)),tuple(map(float,qb))
    w=math.fsum(x*y for x,y in zip(a,b,strict=True))
    x=math.fsum((a[0]*b[1],-a[1]*b[0],-a[2]*b[3],a[3]*b[2]))
    y=math.fsum((a[0]*b[2],a[1]*b[3],-a[2]*b[0],-a[3]*b[1]))
    z=math.fsum((a[0]*b[3],-a[1]*b[2],a[2]*b[1],-a[3]*b[0]))
    return 2*math.atan2(math.hypot(x,y,z),abs(w))


def inputs(frames,bodies,dtype,layout,kind,seed):
    rng=np.random.default_rng(seed);ref,roll=pair(frames,bodies=bodies,joints=17,dtype=dtype,layout=layout,seed=seed)
    for field in ('body_quat_w','object_quat_w'):
        shape=ref.arrays[field].shape;qa=rng.normal(size=shape);qa/=np.linalg.norm(qa,axis=-1,keepdims=True)
        axis=rng.normal(size=(*shape[:-1],3));axis/=np.linalg.norm(axis,axis=-1,keepdims=True)
        if kind=='tiny':theta=np.full(shape[:-1],1e-12)
        elif kind=='zero':theta=np.zeros(shape[:-1])
        elif kind=='nearpi':theta=np.full(shape[:-1],np.pi-1e-12)
        else:theta=rng.uniform(0,np.pi,shape[:-1])
        w=np.cos(theta/2)[...,None];v=axis*np.sin(theta/2)[...,None]
        qb=np.concatenate((qa[...,:1]*w-(qa[...,1:]*v).sum(-1,keepdims=True),qa[...,:1]*v+w*qa[...,1:]+np.cross(qa[...,1:],v)),axis=-1)
        qa=(qa*1.00025).astype(dtype);qb=qa.copy() if kind=='zero' else (qb*0.99975).astype(dtype)
        qb[::3]*=-1;ref.arrays[field]=arrange(qa,layout);roll.arrays[field]=arrange(qb,layout)
    ref=MotionClips(ref.arrays,ref.metadata);ref.sha256='rotation-reference'
    roll.metadata['reference_sha256']=ref.sha256;roll=MotionClips(roll.arrays,roll.metadata);roll.sha256='rotation-rollout'
    return ref,roll


def fingerprint(ref,roll):
    h=hashlib.sha256()
    for m in (ref,roll):
        for key in ('joint_pos','body_pos_w','object_pos_w','body_quat_w','object_quat_w'):
            value=m.arrays[key];h.update(str((key,value.shape,value.dtype.str,value.strides,value.flags.writeable)).encode())
            with np.nditer(value,flags=['external_loop','buffered'],op_flags=['readonly'],buffersize=65536,order='C') as blocks:
                for block in blocks:h.update(block.tobytes())
    return h.hexdigest()


def independent(ref,roll,report):
    worst=0.0;count=0
    for field,label in [('body_quat_w','body_rotation_rmse_rad'),('object_quat_w','object_rotation_rmse_rad')]:
        aa,bb=(m.arrays[field].reshape(-1,4) for m in (ref,roll));n=len(aa)
        expected=math.sqrt(math.fsum(distance(a,b)**2 for a,b in zip(aa,bb,strict=True))/n)
        value=report['metrics_all'][label];error=abs(value-expected)
        assert math.isclose(value,expected,rel_tol=3e-14,abs_tol=5e-16),(label,value,expected,error)
        worst=max(worst,error);count+=n
    return worst,count


def snapshot(status):
    report=dict(status=status,label=args.label,pid=os.getpid(),scope='Sustained arbitrary normalized reference quaternion/axis rotation tests on actual fully validated MotionClips; independent scalar compensated Hamilton-product geodesic every case (rel3e-14,abs5e-16rad), initial/final chord-score parity (rel3e-14,abs1e-25), readonly byte fingerprints, weakref release, FD/thread checks. Mixed,1e-12,exact equivalent-sign,nearpi rotations; C/F/reversed/interval/unaligned arrays. Sampled RSS is not leak proof; includes generation/oracle overhead, not a speed benchmark.',python=platform.python_version(),numpy=np.__version__,started_epoch=started,observed_epoch=time.time(),until_epoch=args.until,cases=cases,reference_frames=frames_seen,quaternion_pairs_checked=quaternions,unique_configurations=len(coverage),total_configurations=len(configs),analytic_cases=cases,max_absolute_metric_difference=max_difference,max_hamilton_absolute_error=max_oracle,fault_counts={},fd_baseline=fd,threads_baseline=threads,source_sha256=source,samples=samples)
    temp=progress.with_suffix('.tmp');temp.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');temp.replace(progress)
    if status=='passed':final.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({key:report[key] for key in ('status','label','cases','quaternion_pairs_checked','unique_configurations','observed_epoch')}),flush=True)
    return report


try:
    while time.time()<args.until and (not args.cases or cases<args.cases):
        index=cases%len(configs);frames,bodies,dtype,layout,kind=configs[index]
        ref,roll=inputs(frames,bodies,dtype,layout,kind,91046+cases);before=fingerprint(ref,roll)
        old=baseline.compare_clips(ref,roll);new=candidate.compare_clips(ref,roll);max_difference=max(max_difference,assert_reports(new,old))
        error,count=independent(ref,roll,new);max_oracle=max(max_oracle,error);quaternions+=count
        assert fingerprint(ref,roll)==before
        refs=[weakref.ref(m) for m in (ref,roll)]+[weakref.ref(m.arrays[field]) for m in (ref,roll) for field in ('body_quat_w','object_quat_w')]
        del ref,roll,old,new;gc.collect();assert all(v() is None for v in refs)
        assert len(list(Path('/proc/self/fd').iterdir()))==fd and len(threading.enumerate())==threads
        cases+=1;frames_seen+=frames;coverage.add(index)
        if cases%25==0 or time.time()-last_report>=15:
            rss=int(next(line.split()[1] for line in Path('/proc/self/status').read_text().splitlines() if line.startswith('VmRSS:')))*1024
            samples.append(dict(cases=cases,observed_epoch=time.time(),rss_bytes=rss,fd=fd,threads=threads,last_config=dict(frames=frames,bodies=bodies,dtype=dtype,layout=layout,kind=kind)))
            assert all(hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()==source[name] for name,m in [('baseline',baseline),('candidate',candidate)])
            snapshot('active');last_report=time.time()
    assert cases>0;snapshot('passed')
except BaseException as error:
    report=snapshot('failed');report.update(error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc(),failed_index=cases,last_config=dict(frames=frames,bodies=bodies,dtype=dtype,layout=layout,kind=kind));failure.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');raise
