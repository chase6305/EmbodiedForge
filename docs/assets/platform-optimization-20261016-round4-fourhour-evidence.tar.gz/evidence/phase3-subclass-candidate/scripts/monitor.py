"""Read progress and verify frozen source plus owned probe harnesses."""
import hashlib,json,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];state=json.loads((ROOT/'progress-state.json').read_text());now=time.time()
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in state['final_runtime_sha256'].items())
assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in json.loads((ROOT/'stress-script-hashes.json').read_text())['sha256'].items())
assert not list(ROOT.glob('*failure.json')),list(ROOT.glob('*failure.json'))
rows=[]
for label in ('py312','numpy124','rotations-py310'):
    value=json.loads((ROOT/f'motion-{label}-progress.json').read_text());age=now-value['observed_epoch']
    assert value['status'] in ('active','passed'),value
    assert value['status']=='passed' or age<90,(label,age)
    assert value['source_sha256']['candidate']==state['final_runtime_sha256']['src/embodiedforge/motion.py']
    rows.append({key:value[key] for key in ('label','status','pid','cases','reference_frames','unique_configurations','total_configurations','analytic_cases','max_absolute_metric_difference','fault_counts')}|dict(quaternion_pairs_checked=value.get('quaternion_pairs_checked'),max_hamilton_absolute_error=value.get('max_hamilton_absolute_error'),progress_age_seconds=age,last_sample=value['samples'][-1] if value['samples'] else None))
report=dict(status='passed',observed_epoch=now,elapsed_seconds=now-state['start_epoch'],remaining_seconds=max(0,state['deadline_epoch']-now),frozen_runtime_files=len(state['final_runtime_sha256']),source_sha256=state['final_runtime_sha256']['src/embodiedforge/motion.py'],probes=rows)
path=ROOT/'monitor-audit.json';old=json.loads(path.read_text()) if path.exists() else [];old.append(report);temp=path.with_suffix('.tmp');temp.write_text(json.dumps(old,indent=2,allow_nan=False)+'\n');temp.replace(path)
print(json.dumps(report,allow_nan=False))
