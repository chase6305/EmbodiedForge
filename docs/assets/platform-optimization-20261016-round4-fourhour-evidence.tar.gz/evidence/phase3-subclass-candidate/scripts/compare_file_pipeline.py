"""Full file open/NPZ decode/validation/SHA256/scoring in isolated packages."""
import hashlib,json,os,select,statistics,subprocess,time
from pathlib import Path
from motion_fixture import assert_reports

ROOT=Path(__file__).resolve().parents[1];started=time.time();workers={};rows=[]
try:
    for name,path in [('baseline',ROOT/'baseline'),('candidate',Path.cwd()/'src')]:
        env=dict(os.environ,PYTHONPATH=str(path),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
        workers[name]=subprocess.Popen(['/tmp/ef-ci312-20261014/bin/python',str(ROOT/'scripts/motion_file_worker.py')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env)
    def run(name,data,mode):
        worker=workers[name];worker.stdin.write(json.dumps(dict(reference=data['reference'],rollout=data['rollout'],mode=mode))+'\n');worker.stdin.flush()
        if not select.select([worker.stdout],[],[],60)[0]:raise TimeoutError((name,data['frames'],mode))
        line=worker.stdout.readline()
        if not line:raise RuntimeError((name,worker.stderr.read()))
        return json.loads(line)
    for data in json.loads((ROOT/'motion-datasets.json').read_text()):
        expected={name:run(name,data,'warmup') for name in workers}
        error=assert_reports(expected['candidate']['result'],expected['baseline']['result'])
        samples={name:[] for name in workers}
        for i in range(9):
            names=list(workers)
            if i%2:names.reverse()
            for name in names:
                measured=run(name,data,'time');assert measured['result']==expected[name]['result'];samples[name].append(measured['seconds'])
        allocation={name:run(name,data,'allocation') for name in workers}
        for name in workers:assert allocation[name]['result']==expected[name]['result']
        medians={name:statistics.median(values) for name,values in samples.items()};peaks={name:allocation[name]['peak_traced_bytes'] for name in workers}
        row=dict(**data,seconds=samples,median_seconds=medians,peak_traced_bytes=peaks,seconds_reduction_pct=100*(1-medians['candidate']/medians['baseline']),peak_reduction_pct=100*(1-peaks['candidate']/peaks['baseline']),max_absolute_metric_difference=error,source_sha256={name:expected[name]['source_sha256'] for name in workers},result=expected['candidate']['result']);rows.append(row)
        print(json.dumps({k:row[k] for k in ('frames','median_seconds','peak_traced_bytes','seconds_reduction_pct','peak_reduction_pct')}),flush=True)
finally:
    for name,worker in workers.items():
        worker.stdin.close()
        try:worker.wait(timeout=20)
        except subprocess.TimeoutExpired:worker.terminate();worker.wait(timeout=10);raise
        error=worker.stderr.read();assert worker.returncode==0,(name,worker.returncode,error)
report=dict(status='passed',scope='Whole isolated initial/final packages, full file open + cached-filesystem NPZ decode + MotionClips validation + file SHA256 + compare_clips. No simulation/training or imports/startup in timing. One warmup plus nine alternating pairs; temporary allocation traced separately including decoded inputs and scoring scratch, not process RSS. Task-owned sustained probes inactive; shared unpinned host.',started_epoch=started,ended_epoch=time.time(),cases=rows)
(ROOT/'motion-file-pipeline.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
