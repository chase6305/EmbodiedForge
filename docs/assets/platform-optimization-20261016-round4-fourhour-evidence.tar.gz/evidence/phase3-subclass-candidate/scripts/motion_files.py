"""Generate reproducible benchmark archives; never include payloads in evidence."""
import argparse
import hashlib
import json
from pathlib import Path

from embodiedforge._motion_clips import MotionClips
from motion_fixture import pair

ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--frames',type=int,nargs='+',default=[128,8192,65536]);args=p.parse_args();rows=[]
for frames in args.frames:
    directory=ROOT/'datasets'/f'frames{frames}';directory.mkdir(parents=True,exist_ok=False)
    reference,rollout=pair(frames,bodies=16,joints=29)
    reference_path=directory/'reference.npz';rollout_path=directory/'rollout.npz'
    reference.save(reference_path);loaded=MotionClips.load(reference_path)
    rollout.metadata['reference_sha256']=loaded.sha256;rollout.save(rollout_path)
    decoded=MotionClips.load(rollout_path)
    rows.append(dict(frames=frames,reference=str(reference_path),rollout=str(rollout_path),reference_sha256=loaded.sha256,rollout_sha256=decoded.sha256,reference_bytes=reference_path.stat().st_size,rollout_bytes=rollout_path.stat().st_size))
    print(json.dumps(rows[-1]),flush=True)
(ROOT/'motion-datasets.json').write_text(json.dumps(rows,indent=2)+'\n')
