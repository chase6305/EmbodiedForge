"""Actual early invocation must refuse final report/archive creation."""
import hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];repo=Path.cwd();script=ROOT/'scripts/report.py'
paths=[repo/'docs/platform-optimization-20261016-round4-fourhour.json',repo/'docs/assets/platform-optimization-20261016-round4-fourhour-evidence.tar.gz']
assert not any(path.exists() for path in paths)
started=time.time();assert started<1792160111
result=subprocess.run(['python',str(script)],capture_output=True,text=True,timeout=15)
assert result.returncode!=0 and 'Actual four-hour requirement is not yet met' in result.stderr
assert not any(path.exists() for path in paths)
report=dict(status='passed',observed_epoch=time.time(),elapsed_seconds=started-1792145711,returncode=result.returncode,reporter_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),final_artifacts_created=False,scope='Actual final reporter invocation before the original four-hour deadline failed at its real-time assertion before final writes. No simulated clock.',stderr=result.stderr)
(ROOT/'duration-gate-negative-control.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ('status','elapsed_seconds','returncode','final_artifacts_created')}))
