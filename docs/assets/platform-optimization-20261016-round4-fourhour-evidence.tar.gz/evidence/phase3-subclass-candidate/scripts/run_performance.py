"""Run primary benchmarks sequentially before starting sustained probes."""
import hashlib,json,os,platform,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];rows=[]
steps=[('score-py312','/tmp/ef-ci312-20261014/bin/python','compare_motion.py',['--output','motion-performance-py312.json']),('score-numpy124','/tmp/ef-numpy124-20261014/bin/python','compare_motion.py',['--output','motion-performance-numpy124.json']),('datasets','/tmp/ef-ci312-20261014/bin/python','motion_files.py',[]),('file-pipeline','/tmp/ef-ci312-20261014/bin/python','compare_file_pipeline.py',[])]
for label,python,script,args in steps:
    log=ROOT/f'performance-{label}.log';command=[python,str(ROOT/'scripts'/script),*args];started=time.time()
    print(json.dumps(dict(status='starting',label=label,observed_epoch=started)),flush=True)
    with log.open('w') as stream:
        result=subprocess.run(command,env=dict(os.environ,PYTHONPATH=str(Path.cwd()/'src'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),stdout=stream,stderr=subprocess.STDOUT,timeout=600)
    row=dict(label=label,command=command,started_epoch=started,ended_epoch=time.time(),returncode=result.returncode,log=str(log),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest());rows.append(row)
    print(json.dumps(row),flush=True)
    assert result.returncode==0,(label,log.read_text()[-4000:])
(ROOT/'performance-runs.json').write_text(json.dumps(dict(status='passed',scope='Sequential primary scoring and full-file benchmarks before sustained probes. Full test workers have exited; no task-owned long stress active. Shared host remains unpinned.',results=rows),indent=2)+'\n')
