import hashlib,json,os,subprocess,time
from pathlib import Path
from embodiedforge.motion import MotionClips,compare_clips
from motion_fixture import assert_reports
ROOT=Path(__file__).resolve().parents[1];directory=ROOT/'benchmark-smoke';directory.mkdir(exist_ok=True);rows=[]
interpreters=['/tmp/ef-ci312-20261014/bin/python','/tmp/ef-ci310-20261014/bin/python','/tmp/ef-numpy124-20261014/bin/python']
data=json.loads((ROOT/'motion-datasets.json').read_text())
for index,python in enumerate(interpreters):
    env=dict(os.environ,PYTHONPATH=str(Path.cwd()/'src'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    for case in data:
        output=directory/f'valid-{index}-{case["frames"]}.json';command=[python,'benchmarks/motion_compare.py','--reference',case['reference'],'--rollout',case['rollout'],'--calls','2','--repeats','2','--output',str(output)]
        result=subprocess.run(command,env=env,capture_output=True,text=True,timeout=60);assert result.returncode==0,(command,result.stderr)
        report=json.loads(output.read_text());expected=compare_clips(MotionClips.load(case['reference']),MotionClips.load(case['rollout']));assert_reports(report['result'],expected)
        assert len(report['seconds_per_call'])==2 and all(t>0 for t in report['seconds_per_call']) and report['peak_traced_bytes']>0
        assert report['result_sha256']==hashlib.sha256(json.dumps(report['result'],sort_keys=True,allow_nan=False).encode()).hexdigest()
        rows.append(dict(kind='valid',interpreter=python,frames=case['frames'],returncode=0,output=str(output),result_sha256=report['result_sha256']))
    for flag,value in [('--calls','0'),('--calls','-1'),('--repeats','0'),('--repeats','-1')]:
        output=directory/f'invalid-{index}-{flag[2:]}-{value}.json';command=[python,'benchmarks/motion_compare.py','--reference',data[0]['reference'],'--rollout',data[0]['rollout'],flag,value,'--output',str(output)]
        result=subprocess.run(command,env=env,capture_output=True,text=True,timeout=10);assert result.returncode==2 and 'must be positive' in result.stderr and not output.exists()
        rows.append(dict(kind='invalid-argument',interpreter=python,flag=flag,value=value,returncode=result.returncode))
    existing=directory/f'valid-{index}-{data[0]["frames"]}.json';before=existing.read_bytes()
    command=[python,'benchmarks/motion_compare.py','--reference',data[0]['reference'],'--rollout',data[0]['rollout'],'--calls','1','--repeats','1','--output',str(existing)]
    result=subprocess.run(command,env=env,capture_output=True,text=True,timeout=15);assert result.returncode!=0 and 'FileExistsError' in result.stderr and existing.read_bytes()==before
    rows.append(dict(kind='existing-output-preserved',interpreter=python,returncode=result.returncode))
report=dict(status='passed',scope='Benchmark CLI validation and output ownership; times from this smoke run overlap sustained probes and are not used for performance conclusions.',observed_epoch=time.time(),benchmark_sha256=hashlib.sha256(Path('benchmarks/motion_compare.py').read_bytes()).hexdigest(),rows=rows)
(ROOT/'benchmark-smoke.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(status='passed',cases=len(rows))))
