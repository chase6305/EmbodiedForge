"""Deterministic public-score parity and independent analytic numeric checks."""
import hashlib
import importlib.util
import itertools
import json
import platform
import time
from pathlib import Path

import numpy as np

from embodiedforge import motion as candidate
from motion_fixture import analytic_oracle, assert_reports, pair

ROOT=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('embodiedforge.oracle_baseline',ROOT/'baseline/embodiedforge/motion.py');baseline=importlib.util.module_from_spec(s);s.loader.exec_module(baseline)
started=time.time();rows=[];max_error=0
# Different field widths put each metric's block boundary at a different frame.
for i,(frames,bodies,dtype,layout) in enumerate(itertools.product((1,7,1023,1024,1025,3855,3856,4095,4096,4097,16383,16384,16385),(1,4),('float32','float64','>f4'),('contiguous','fortran','reversed','strided','unaligned'))):
    joints=(1,17,29)[i%3]
    ref,roll=pair(frames,bodies=bodies,joints=joints,clips=1+i%4,dtype=dtype,layout=layout,seed=61046+i,reorder=True,prefixes=True)
    old=baseline.compare_clips(ref,roll);new=candidate.compare_clips(ref,roll)
    max_error=max(max_error,assert_reports(new,old))
    if i%13==0:analytic_oracle(ref,roll,new)
    rows.append(dict(frames=frames,bodies=bodies,joints=joints,dtype=dtype,layout=layout,clips=len(ref.names),reference_frames=int(ref.starts[-1]),rollout_frames=int(roll.starts[-1]),input_sha256=dict(reference=ref.sha256,rollout=roll.sha256)))
    if len(rows)%50==0:print(json.dumps(dict(cases=len(rows),elapsed_seconds=time.time()-started)),flush=True)
extra=[]
# Values representable in extended precision must not be prematurely downcast
# while accumulating position errors. Quaternion arithmetic remains float64.
for dtype in ('int8','uint64','>i8','longdouble'):
    for frames in (1,4097,16385):
        ref,roll=pair(frames,bodies=1,joints=17,dtype='float64')
        for obj in (ref,roll):
            for field in ('joint_pos','body_pos_w','object_pos_w'):
                values=np.zeros_like(obj.arrays[field],dtype=dtype)
                if obj is roll:values[:]=3 if dtype!='uint64' else 2**63+123
                if dtype=='longdouble' and obj is ref:values[:]=np.longdouble('1e200')
                values.flags.writeable=False;obj.arrays[field]=values
        with np.errstate(over='ignore',invalid='ignore'):
            old=baseline.compare_clips(ref,roll);new=candidate.compare_clips(ref,roll)
        max_error=max(max_error,assert_reports(new,old));extra.append(dict(dtype=dtype,frames=frames,metrics=new['metrics_all']))
report=dict(status='passed',scope='Actual MotionClips instances, full compare_clips baseline/final numeric parity (relative3e-14 absolute1e-25), independently compensated scalar/axis-angle oracle every13cases; 13 frame lengths around field-specific block thresholds, 5 layouts including unaligned readonly arrays, three float dtypes, unequal reordered/prefix clips/statuses. Extra integer/endian/long-double positions. Not a speed benchmark.',python=platform.python_version(),numpy=np.__version__,started_epoch=started,ended_epoch=time.time(),cases=len(rows),analytic_cases=sum(i%13==0 for i in range(len(rows))),max_absolute_metric_difference=max_error,source_sha256={name:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for name,m in [('baseline',baseline),('candidate',candidate)]},rows=rows,extra=extra)
path=ROOT/f'motion-oracle-{platform.python_version()}-numpy{np.__version__}.json';path.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps({k:report[k] for k in ('status','cases','analytic_cases','max_absolute_metric_difference')}),flush=True)
