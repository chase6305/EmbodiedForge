"""Verify complete compressed evidence and source/duration links after closing."""
import gzip
import hashlib
import json
import tarfile
import time
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parents[1];repo=Path.cwd();path=repo/'docs/platform-optimization-20261016-round4-fourhour.json';report=json.loads(path.read_text());state=json.loads((ROOT/'progress-state.json').read_text())
archive=repo/report['evidence_archive']['path']
assert hashlib.sha256(archive.read_bytes()).hexdigest()==report['evidence_archive']['sha256']
assert archive.stat().st_size==report['evidence_archive']['bytes']
with gzip.open(archive,'rb') as stream:
    while stream.read(1024*1024):pass
with tarfile.open(archive,'r:gz') as stream:
    members=stream.getmembers();names=[m.name for m in members]
    assert len(set(names))==len(names)
    assert all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members)
    blobs={}
    for member in members:
        with stream.extractfile(member) as source:data=source.read()
        assert len(data)==member.size
        blobs[member.name]=data
for filename,digest in state['initial_runtime_sha256'].items():
    name=str(Path('evidence/baseline')/Path(filename).relative_to('src'))
    assert hashlib.sha256(blobs[name]).hexdigest()==digest,filename
final=json.loads(blobs['evidence/final-file-hashes.json'])['sha256']
for filename,digest in final.items():
    assert hashlib.sha256(blobs['final/'+filename]).hexdigest()==digest
    assert hashlib.sha256((repo/filename).read_bytes()).hexdigest()==digest
assert json.loads(blobs['evidence/duration-gate.json'])==report['duration']
duration=report['duration'];assert duration['required_seconds']==14400 and duration['elapsed_seconds']>=14400 and duration['requirement_met']
assert duration['started_epoch']==1792145711 and duration['deadline_epoch']==1792160111 and duration['observed_epoch']>=duration['deadline_epoch']
assert abs(duration['elapsed_seconds']-(duration['observed_epoch']-duration['started_epoch']))<1e-9
negative=json.loads(blobs['evidence/duration-gate-negative-control.json'])
assert negative['status']=='passed' and not negative['final_artifacts_created'] and negative['observed_epoch']<duration['deadline_epoch']
assert negative['reporter_sha256']==hashlib.sha256(blobs['evidence/scripts/report.py']).hexdigest()
checks=json.loads(blobs['evidence/final-checks.json']);assert checks['status']=='passed' and all(v['returncode']==0 for v in checks['results'])
for row in checks['results']:
    name='evidence/'+Path(row['log']).name;assert hashlib.sha256(blobs[name]).hexdigest()==row['log_sha256']
for filename,digest in json.loads(blobs['evidence/stress-script-hashes.json'])['sha256'].items():assert hashlib.sha256(blobs['evidence/'+filename]).hexdigest()==digest
for label in ('py312','numpy124','rotations-py310'):
    proof=json.loads(blobs[f'evidence/motion-{label}.json']);assert proof['status']=='passed' and proof['cases']>proof['total_configurations'] and proof['unique_configurations']==proof['total_configurations']
    assert proof['source_sha256']['candidate']==final['src/embodiedforge/motion.py']
for filename,digest in state['final_runtime_sha256'].items():assert hashlib.sha256((repo/filename).read_bytes()).hexdigest()==digest
verification=dict(status='passed',observed_epoch=time.time(),archive_sha256=report['evidence_archive']['sha256'],archive_bytes=archive.stat().st_size,members=len(members),gzip_crc_checked=True,all_tar_members_read=True,unique_safe_regular_paths=True,initial_runtime_python_files_verified=len(state['initial_runtime_sha256']),final_changed_source_test_benchmark_doc_figure_verified=True,full_test_log_hashes_verified=True,stress_final_reports_and_harness_hashes_verified=True,duration_gate_and_early_rejection_reporter_hash_verified=True)
report['artifact_verification']=verification;path.write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n');(ROOT/'artifact-verification.json').write_text(json.dumps(verification,indent=2)+'\n');print(json.dumps(verification))
