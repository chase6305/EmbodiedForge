"""Publication-style exported plot of paired CPU measurements, with IQR."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parents[1];repo=Path.cwd()
matplotlib.rcParams.update({'font.size':10,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(3,2,figsize=(12.8,12.0))
colors={'baseline':'#8192a8','candidate':'#127c72'}
for row,(name,title) in enumerate([('motion-performance-py312.json','Decoded scoring · Python 3.12 / NumPy 2.5.4'),('motion-performance-numpy124.json','Decoded scoring · Python 3.10 / NumPy 1.24.4'),('motion-file-pipeline.json','Load + validate + SHA256 + score · Python 3.12 / NumPy 2.5.4')]):
    data=json.loads((ROOT/name).read_text())
    if row<2:
        cases=[r for r in data['cases'] if r['layout']=='contiguous' and r.get('dtype','float32')=='float32' and (r.get('clips',1)==1 or r.get('clips')==32)]
        labels=[f'{r["frames"]:,} frames' if r.get('clips',1)==1 else '32 short clips' for r in cases]
    else:
        cases=data['cases'];labels=[f'{r["frames"]:,} frames' for r in cases]
    x=np.arange(len(cases));width=.36
    for col in range(2):
        ax=axes[row,col]
        for offset,group in [(-width/2,'baseline'),(width/2,'candidate')]:
            values=[r['median_seconds'][group]*1000 if col==0 else r['peak_traced_bytes'][group]/1024**2 for r in cases]
            error=None
            if col==0:
                lo=[v-np.percentile(r['seconds'][group],25)*1000 for v,r in zip(values,cases,strict=True)]
                hi=[np.percentile(r['seconds'][group],75)*1000-v for v,r in zip(values,cases,strict=True)]
                error=[lo,hi]
            ax.bar(x+offset,values,width,color=colors[group],label='Initial' if group=='baseline' else 'Final',yerr=error,capsize=3,error_kw={'linewidth':.8,'ecolor':'#304050'})
        ax.set_xticks(x,labels,rotation=15,ha='right');ax.set_yscale('log');ax.set_ylabel('Time per call (ms, log)' if col==0 else 'Traced peak (MiB, log)')
        ax.grid(axis='y',which='major',alpha=.22);ax.set_axisbelow(True)
        ax.set_title(title+('\nMedian and interquartile range' if col==0 else '\nSeparate allocation pass'),fontsize=10.5,loc='left',pad=12)
        if row==0 and col==0:ax.legend(frameon=False,loc='upper left')
fig.suptitle('Motion evaluation: bounded scoring scratch for long clips',x=.065,y=.985,ha='left',fontsize=17,fontweight='bold')
fig.text(.065,.951,'16 bodies, 29 joints, float32 contiguous inputs. Compare initial/final within each panel.',fontsize=10.5)
fig.text(.065,.018,'Scoring: 15 alternating pairs after warmup; file pipeline: 9 pairs on a cached filesystem. Shared unpinned CPU host.\nDecoded inputs are excluded from scoring trace and included in full-file trace. Traced peak is not process RSS.\nOther layouts/dtypes and all positive/negative results are in the JSON report. No simulation or training throughput claim.',fontsize=9,color='#394856',linespacing=1.5)
fig.tight_layout(rect=(.04,.085,.99,.93),h_pad=3,w_pad=3)
path=repo/'docs/platform-optimization-20261016-round4-fourhour-performance.svg';fig.savefig(path)
fig.savefig('/tmp/ef-round4-performance.png',dpi=130);print(path)
