import hashlib,json,sys,time,tracemalloc
from pathlib import Path
from embodiedforge import motion
from embodiedforge._motion_clips import MotionClips


def score(reference,rollout):
    return motion.compare_clips(MotionClips.load(reference),MotionClips.load(rollout))


for line in sys.stdin:
    request=json.loads(line);reference=request['reference'];rollout=request['rollout']
    if request['mode']=='time':
        started=time.perf_counter();result=score(reference,rollout);row=dict(seconds=time.perf_counter()-started)
    elif request['mode']=='allocation':
        tracemalloc.start();result=score(reference,rollout);row=dict(peak_traced_bytes=tracemalloc.get_traced_memory()[1]);tracemalloc.stop()
    else:
        result=score(reference,rollout);row={}
    row['result']=result;row['source_sha256']=hashlib.sha256(Path(motion.__file__).read_bytes()).hexdigest()
    print(json.dumps(row,allow_nan=False),flush=True)
