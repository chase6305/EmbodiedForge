"""Fourth-round evidence report; actual four-hour gate precedes final writes."""
import argparse
import hashlib
import json
import os
import tarfile
import time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];repo=Path.cwd()
p=argparse.ArgumentParser();p.add_argument('--preview',action='store_true');args=p.parse_args()


def load(name):return json.loads((ROOT/name).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def compact(report):return {k:v for k,v in report.items() if k not in ('samples','rows')}|dict(sample_count=len(report.get('samples',[])),detail_count=len(report.get('rows',[])))
def processes():
    found=[]
    for directory in Path('/proc').iterdir():
        if not directory.name.isdigit() or int(directory.name)==os.getpid():continue
        try:
            command=[v.decode() for v in (directory/'cmdline').read_bytes().split(b'\0') if v]
            if command and Path(command[0]).name.startswith('python') and any(str(ROOT) in v or 'runs/platform-optimization-20261016-round4-fourhour/' in v for v in command):found.append(dict(pid=int(directory.name),command=command))
        except (FileNotFoundError,PermissionError):continue
    return found


state=load('progress-state.json');observed=time.time();elapsed=observed-state['start_epoch']
assert state['start_epoch']==1792145711 and state['deadline_epoch']==1792160111 and state['required_seconds']==14400
if not args.preview:assert elapsed>=14400,('Actual four-hour requirement is not yet met',elapsed,14400)
assert all(sha(ROOT/'baseline'/Path(f).relative_to('src'))==h for f,h in state['initial_runtime_sha256'].items())
assert all(sha(repo/f)==h for f,h in state['final_runtime_sha256'].items())
source=sha(repo/'src/embodiedforge/motion.py');checks=load('final-checks.json');diff=load('runtime-diff-summary.json')
assert diff['changed_runtime_files']==['src/embodiedforge/motion.py']
assert checks['status']=='passed' and checks['source_hashes']==state['final_runtime_sha256']
assert all(sha(repo/f)==h for f,h in load('final-file-hashes.json')['sha256'].items())
assert load('style-checks.json')['status']=='passed'
scoring=[load(name) for name in ['motion-performance-py312.json','motion-performance-numpy124.json']];pipeline=load('motion-file-pipeline.json')
assert load('performance-runs.json')['status']=='passed'
for value in scoring:
    assert value['status']=='passed' and value['source_sha256']['candidate']==source
    assert value['source_sha256']['baseline']==state['initial_runtime_sha256']['src/embodiedforge/motion.py']
assert pipeline['status']=='passed' and all(c['source_sha256']['candidate']==source for c in pipeline['cases'])
oracles=[json.loads(f.read_text()) for f in sorted(ROOT.glob('motion-oracle-*.json'))]+[json.loads(f.read_text()) for f in sorted(ROOT.glob('rotation-oracle-*.json'))]
assert len(oracles)==4 and all(v['status']=='passed' and v['source_sha256']['candidate']==source for v in oracles)
smoke=load('benchmark-smoke.json');assert smoke['status']=='passed' and smoke['benchmark_sha256']==sha(repo/'benchmarks/motion_compare.py')
assert all(sha(ROOT/f)==h for f,h in load('stress-script-hashes.json')['sha256'].items())
assert not list(ROOT.glob('*failure.json'))
probes=[load(f'motion-{label}-progress.json' if args.preview else f'motion-{label}.json') for label in ('py312','numpy124','rotations-py310')]
assert all(v['source_sha256']['candidate']==source for v in probes)
if not args.preview:
    assert all(v['status']=='passed' and v['unique_configurations']==v['total_configurations'] and v['cases']>v['total_configurations'] for v in probes)
    active=processes();assert not active,active
    assert load('duration-gate-negative-control.json')['status']=='passed'
    assert load('duration-gate-negative-control.json')['reporter_sha256']==sha(__file__)
duration=dict(started_epoch=state['start_epoch'],deadline_epoch=state['deadline_epoch'],observed_epoch=observed,elapsed_seconds=elapsed,required_seconds=14400,requirement_met=elapsed>=14400,started_utc=datetime.fromtimestamp(state['start_epoch'],timezone.utc).isoformat(),observed_utc=datetime.fromtimestamp(observed,timezone.utc).isoformat(),scope='Actual elapsed wall time from this round start. Parallel test, benchmark and endurance durations are not summed.')
selected=[c for report in scoring for c in report['cases'] if c['frames'] in (8192,65536) and c['layout']=='contiguous' and c.get('dtype','float32')=='float32' and c.get('clips',1)==1]
full=[c for c in pipeline['cases'] if c['frames']>=8192]
report=dict(schema_version=1,date='2026-10-16',round='fourth-round-four-actual-hours',status='active' if args.preview else 'complete',preview_only=args.preview,duration=duration,baseline_revision=state['head'],initial_worktree_status=(ROOT/'initial-status.txt').read_text(),environment=load('environment.json'),runtime_diff=diff,changes=[dict(paths=['src/embodiedforge/motion.py'],behavior='Bound long-clip linear and normalized quaternion squared-error scratch by per-field frame blocks targeting65536 input scalars, at least one frame. Keep small fields direct, preserve float64 quaternion chord/atan2 accuracy, accumulate entire per-clip squared sums before RMSE and equal-clip aggregation. Inputs remain untouched. Different reduction order can change last bits.'),dict(paths=['tests/test_motion_compare_blocks.py','benchmarks/motion_compare.py','docs/weave-reference.md'],behavior='52 new analytic/readonly/layout/threshold/precision/wide-frame tests; a separate decoded-motion benchmark that excludes loading and tracing from timing; documented scope and memory limits.')],validation=dict(full_suites=[{k:v for k,v in row.items() if k!='tail'}|dict(result=row['tail'][-1]) for row in checks['results']],source_hashes=checks['source_hashes'],new_tests=52,oracles=[compact(v) for v in oracles],benchmark_cli=smoke,style=load('style-checks.json')),performance=dict(serial_execution=load('performance-runs.json'),scoring=scoring,full_file_pipeline=pipeline),key_findings=dict(scope='Contiguous float32 one-clip inputs,16bodies29joints,8192and65536frames; compare initial/final within each interpreter/environment.',scoring_seconds_reduction_pct_range=[min(c['seconds_reduction_pct'] for c in selected),max(c['seconds_reduction_pct'] for c in selected)],scoring_traced_peak_reduction_pct_range=[min(c['peak_reduction_pct'] for c in selected),max(c['peak_reduction_pct'] for c in selected)],full_file_seconds_reduction_pct_range=[min(c['seconds_reduction_pct'] for c in full),max(c['seconds_reduction_pct'] for c in full)],small_short_clip_regression_retained=True,uniform_training_or_general_pipeline_gain_established=False),stress=[compact(v) for v in probes],intermediate_experiments=[dict(path='phase1/',scope='Initial per-field blocking; then remove extra small-field slices/loops by sharing squared-error math and adding a direct small-field path. Raw prototype/tuning measurements are exploratory, final conclusions use motion-performance-*.json.'),dict(path='phase2/',scope='An initially overstrict new wide-frame test asserted exact pi; all environments measured pi plus one ULP. Corrected numeric tolerance, all final suites passed; runtime unchanged by this test correction.'),load('rejected-blocks-experiment.json'),load('block-size-decision.json')],figure='platform-optimization-20261016-round4-fourhour-performance.svg',reproduction=dict(cwd='Repository checkout matching final hashes; evidence scripts resolve their initial baseline snapshot relative to themselves. Current source/benchmarks resolve from checkout src. Installed environments and generated NPZ files are not archived.',decoded='OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONPATH=src python benchmarks/motion_compare.py --reference reference.npz --rollout rollout.npz --output /tmp/motion-score.json',paired='Run evidence/scripts/compare_motion.py --output new-name.json under each recorded Python/NumPy environment. Fixture generation is deterministic and outside timing.',files='Run motion_files.py once in a fresh evidence directory, then compare_file_pipeline.py; the pipeline script records the exact original Python3.12 interpreter path, which must be adjusted if reproducing on another host.',stress='Run motion_endurance.py --label new-label --until FUTURE_UNIX_EPOCH. Optional --cases gives a finite audit. The default stop epoch records this original round.'),limits=['Scoring measurements exclude full NPZ loading, constructor validation, source/file hashing, fixture generation, simulation and training; the separate full-file pipeline explicitly includes loading/validation/hash. All timings are on a shared unpinned CPU host.','Different sizes, strides, dtypes and NumPy versions have different results. A many-short-clips NumPy1.24 case slowed about6.4%; small full-file timing was essentially flat. All raw positive and negative measurements are retained.','Memory tracing is temporary Python/NumPy allocation, not process RSS or native/GPU memory. Reference and rollout arrays remain fully decoded in memory. A frame wider than65536 scalars is processed as one frame, so this is not a hard byte limit.','Metrics preserve definitions, units, shortest quaternion rotations and equal per-clip aggregation. Summation order can change final floating-point bits; tested numeric tolerances and independent analytic/Hamilton oracles are recorded.','Sampled RSS, stable FD/Python-thread counts and weakref release apply to tested workloads and are not a general leak proof. Rejection controls mutate already validated fixture objects intentionally to check score-side validation parity.','No GPU, physics, learning, real robot, network viewer delivery or general training throughput benefit is established. Optional integration test skips and warnings remain in the logs.'])
if not args.preview:
    report['final_process_audit']=dict(status='passed',observed_epoch=time.time(),matching_processes=active)
    (ROOT/'duration-gate.json').write_text(json.dumps(duration,indent=2)+'\n')
    archive=repo/'docs/assets/platform-optimization-20261016-round4-fourhour-evidence.tar.gz'
    allowed={'.py','.json','.log','.txt','.patch','.pstats','.svg','.html','.js','.xml'}
    files=[f for f in ROOT.rglob('*') if f.is_file() and '__pycache__' not in f.parts and 'datasets' not in f.relative_to(ROOT).parts and f.name!='report-preview.json' and (f.suffix in allowed or f.name.startswith(('LICENSE','NOTICE')))]
    final=list(load('final-file-hashes.json')['sha256'])+['pyproject.toml']
    with tarfile.open(archive,'w:gz') as stream:
        for f in sorted(files):stream.add(f,arcname=str(Path('evidence')/f.relative_to(ROOT)),recursive=False)
        for f in final:stream.add(repo/f,arcname=str(Path('final')/f),recursive=False)
    report['evidence_archive']=dict(path=str(archive.relative_to(repo)),sha256=sha(archive),bytes=archive.stat().st_size,scope='Exact initial Python package source snapshot, adopted source/test/benchmark/doc/figure, all raw comparisons, scripts, tests, oracles, sustained samples, diagnostic experiments and actual duration proof. Generated NPZ payloads and installed binary environments are excluded; fixtures regenerate from scripts.')
    report['duration_gate_negative_control']=load('duration-gate-negative-control.json')
output=ROOT/'report-preview.json' if args.preview else repo/'docs/platform-optimization-20261016-round4-fourhour.json'
output.write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n');print(json.dumps(dict(path=str(output),status=report['status'],elapsed_seconds=elapsed,requirement_met=duration['requirement_met'])))
