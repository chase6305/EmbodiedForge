"""Deterministic full-format motion inputs, independent of the scoring module."""
import hashlib
import json
import math
from pathlib import Path

import numpy as np

from embodiedforge._motion_clips import MotionClips

METRICS = ('joint_rmse_rad', 'body_position_rmse_m', 'object_position_rmse_m', 'body_rotation_rmse_rad', 'object_rotation_rmse_rad')


def arrange(value, layout):
    if layout == 'fortran':
        value = np.asfortranarray(value)
    elif layout == 'reversed':
        value = value[::-1].copy()[::-1]
    elif layout == 'strided':
        value = np.repeat(value, 2, axis=0)[::2]
    elif layout == 'unaligned':
        destination = np.ndarray(value.shape, dtype=value.dtype, buffer=bytearray(value.nbytes + 1), offset=1)
        destination[:] = value
        value = destination
    value.flags.writeable = False
    return value


def library(lengths, *, bodies, joints, dtype, rng, reference=None, order=None, layout='contiguous', seed_angles=False):
    total = sum(lengths)
    count = len(lengths)
    names = [f'clip-{i}' for i in range(count)] if order is None else [f'clip-{i}' for i in order]
    metadata = dict(schema='ef-motion-v1', robot='benchmark-fixture', joint_names=[f'joint-{i}' for i in range(joints)], body_names=[f'body-{i}' for i in range(bodies)], coordinate_frame='world', quaternion_order='wxyz')
    if reference is not None:
        metadata['reference_sha256'] = reference.sha256
    arrays = dict(fps=np.array(50.0), motion_lengths=np.asarray(lengths, dtype=np.int64), motion_names=np.asarray(names), object_names=np.asarray(['box' if int(name[5:]) % 2 == 0 else 'chair' for name in names]))
    shapes = dict(joint_pos=(total,joints), joint_vel=(total,joints), body_pos_w=(total,bodies,3), body_quat_w=(total,bodies,4), body_lin_vel_w=(total,bodies,3), body_ang_vel_w=(total,bodies,3), object_pos_w=(total,3), object_quat_w=(total,4), object_lin_vel_w=(total,3), object_ang_vel_w=(total,3), contact_label=(total,bodies))
    expected = {name: {} for name in names}
    for key, shape in shapes.items():
        if key in ('joint_pos','body_pos_w','object_pos_w'):
            value = rng.normal(scale=0.1, size=shape).astype(dtype) if reference is not None else np.zeros(shape,dtype=dtype)
        elif 'quat' in key:
            value = np.zeros(shape, dtype=dtype)
            if reference is None:
                value[...,0] = 1.00025
            else:
                angles = rng.uniform(0,np.pi,shape[:-1])
                if seed_angles:
                    angles.flat[::7] = 1e-12
                    angles.flat[::11] = np.pi
                value[...,0] = np.cos(angles/2)*0.99975
                value[...,3] = np.sin(angles/2)*0.99975
                value[::3] *= -1
        else:
            # These validated fields are irrelevant to compare_clips. Broadcast
            # zeros avoid allocating unused full arrays in a scoring benchmark.
            value = np.broadcast_to(np.zeros((),dtype=dtype),shape)
        arrays[key] = arrange(value,layout) if value.flags.writeable else value
    if reference is not None:
        for key in ('terminated','truncated','clip_end'):
            arrays[key] = np.zeros(total,dtype=bool)
        offset = 0
        for name,length in zip(names,lengths,strict=True):
            index = int(name[5:])
            status = index % 4
            endpoint = offset + length - 1
            target = int(reference.lengths[index])
            arrays['terminated'][endpoint] = status == 1
            arrays['truncated'][endpoint] = status == 2
            arrays['clip_end'][endpoint] = status == 0 and length == target
            offset += length
    result = MotionClips(arrays,metadata)
    digest = hashlib.sha256()
    digest.update(json.dumps(metadata,sort_keys=True).encode())
    for key in sorted(arrays):
        value = arrays[key]
        digest.update(key.encode());digest.update(str((value.shape,value.dtype.str)).encode())
        # Digest only scored fields and descriptors. Unused broadcast fields are
        # guaranteed zero by construction and independently validated above.
        if key in ('joint_pos','body_pos_w','object_pos_w','body_quat_w','object_quat_w') or key not in shapes:
            digest.update(value.tobytes(order='C'))
    result.sha256 = digest.hexdigest()
    return result


def pair(frames, *, bodies=16, joints=29, clips=1, dtype='float32', layout='contiguous', seed=61046, reorder=False, prefixes=False):
    rng = np.random.default_rng(seed)
    lengths = [max(1,frames//(i+1)) for i in range(clips)]
    reference = library(lengths,bodies=bodies,joints=joints,dtype=dtype,rng=rng,layout=layout)
    order = list(reversed(range(clips))) if reorder else list(range(clips))
    recorded = [max(1,lengths[i] - (i % 3 if prefixes and i % 4 != 0 else 0)) for i in order]
    rollout = library(recorded,bodies=bodies,joints=joints,dtype=dtype,rng=rng,reference=reference,order=order,layout=layout,seed_angles=True)
    return reference,rollout


def assert_reports(actual, expected):
    assert actual.keys() == expected.keys()
    for key in actual.keys()-{'metrics_all','metrics_success','clips'}:
        assert actual[key] == expected[key], (key,actual[key],expected[key])
    largest = 0.0
    for aa,bb in [(actual['metrics_all'],expected['metrics_all']),(actual['metrics_success'],expected['metrics_success']),*zip(actual['clips'],expected['clips'],strict=True)]:
        assert aa.keys() == bb.keys()
        for key in aa:
            if key in METRICS and aa[key] is not None:
                error = abs(aa[key]-bb[key])
                assert math.isclose(aa[key],bb[key],rel_tol=3e-14,abs_tol=1e-25),(key,aa[key],bb[key])
                largest = max(largest,error)
            else:
                assert aa[key] == bb[key],(key,aa[key],bb[key])
    return largest


def analytic_oracle(reference, rollout, report):
    """Independent compensated sums and axis-angle recovery, no block algorithm."""
    lookup = dict(zip(rollout.names,range(len(rollout.names)),strict=True))
    for index,name in enumerate(reference.names):
        other = lookup[name]
        a,b = int(rollout.starts[other]),int(rollout.starts[other+1])
        metrics = report['clips'][index]
        for field,label in zip(('joint_pos','body_pos_w','object_pos_w'),METRICS[:3],strict=True):
            values = rollout.arrays[field][a:b]
            total = math.fsum(float(x)**2 for x in values.flat)
            denom = values.size if field == 'joint_pos' else values.size//3
            expected = math.sqrt(total/denom)
            assert math.isclose(metrics[label],expected,rel_tol=3e-14,abs_tol=1e-25),(label,metrics[label],expected)
        for field,label in zip(('body_quat_w','object_quat_w'),METRICS[3:],strict=True):
            values = rollout.arrays[field][a:b].reshape(-1,4)
            expected = math.sqrt(math.fsum((2*math.atan2(abs(float(q[3])),abs(float(q[0]))))**2 for q in values)/len(values))
            assert math.isclose(metrics[label],expected,rel_tol=3e-14,abs_tol=1e-25),(label,metrics[label],expected)
