"""Sustained whole-score parity, input ownership and resource checks."""
import argparse
import gc
import hashlib
import importlib.util
import itertools
import json
import os
import platform
import threading
import time
import traceback
import weakref
from pathlib import Path

import numpy as np

from embodiedforge import motion as candidate
from motion_fixture import analytic_oracle, assert_reports, pair

ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--until',type=float,default=1792159871);p.add_argument('--label',required=True);p.add_argument('--cases',type=int,default=0);args=p.parse_args()
s=importlib.util.spec_from_file_location('embodiedforge.endurance_baseline',ROOT/'baseline/embodiedforge/motion.py');baseline=importlib.util.module_from_spec(s);s.loader.exec_module(baseline)
source={name:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for name,m in [('baseline',baseline),('candidate',candidate)]}
scored=('joint_pos','body_pos_w','object_pos_w','body_quat_w','object_quat_w')
configs=list(itertools.product((1,7,64,1023,1024,1025,3855,3856,4095,4096,4097,16383,16384,16385,65536),('contiguous','fortran','reversed','strided','unaligned'),('float32','float64','>f4'),(1,4,16)))
progress=ROOT/f'motion-{args.label}-progress.json';final=ROOT/f'motion-{args.label}.json';failure=ROOT/f'motion-{args.label}-failure.json'
assert not final.exists() and not failure.exists()
started=time.time();fd=len(list(Path('/proc/self/fd').iterdir()));threads=len(threading.enumerate());coverage=set();faults={};samples=[];cases=frames_seen=analytic=0;largest=0.0;last_report=started


def fingerprint(ref,roll):
    digest=hashlib.sha256()
    for motion in (ref,roll):
        for key in scored:
            value=motion.arrays[key]
            digest.update(str((value.shape,value.dtype.str,value.strides,value.flags.writeable)).encode())
            with np.nditer(value,flags=['external_loop','buffered','zerosize_ok'],op_flags=['readonly'],buffersize=65536,order='C') as chunks:
                for chunk in chunks:digest.update(chunk.tobytes())
    return digest.hexdigest()


def rss():
    values=Path('/proc/self/status').read_text().splitlines()
    return int(next(line.split()[1] for line in values if line.startswith('VmRSS:')))*1024


def snapshot(status):
    result=dict(status=status,label=args.label,scope='Sustained full-format MotionClips construction, readonly C/F/reversed/interval-strided/unaligned scoring inputs; exact baseline/final metadata/status parity, metric tolerance3e-14/1e-25, periodic independent scalar/axis-angle checks, numeric/identity rejection controls, byte fingerprints and weakref release. FD/Python thread counts checked after each case; sampled RSS is not a leak proof. Includes fixture generation/audits and is not a throughput benchmark.',python=platform.python_version(),numpy=np.__version__,pid=os.getpid(),started_epoch=started,observed_epoch=time.time(),until_epoch=args.until,cases=cases,reference_frames=frames_seen,unique_configurations=len(coverage),total_configurations=len(configs),fault_counts=faults,analytic_cases=analytic,max_absolute_metric_difference=largest,fd_baseline=fd,threads_baseline=threads,source_sha256=source,samples=samples)
    temp=progress.with_suffix('.tmp');temp.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');temp.replace(progress)
    if status=='passed':final.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:result[k] for k in ('status','label','cases','reference_frames','unique_configurations','analytic_cases','observed_epoch')}),flush=True)
    return result


try:
    while time.time()<args.until and (not args.cases or cases<args.cases):
        index=cases%len(configs);frames,layout,dtype,bodies=configs[index]
        clips=1+(cases//3)%4;joints=(1,17,29,64)[(cases//7)%4]
        # Keep largest fixtures below a few hundred MiB on the shared host.
        if frames==65536:clips=1
        ref,roll=pair(frames,bodies=bodies,joints=joints,clips=clips,dtype=dtype,layout=layout,seed=61046+cases,reorder=True,prefixes=True)
        reference_frames=int(ref.starts[-1]);kinds=('valid',)*8+('robot','fps','reference','names','object','length','flags','nan','overflow');kind=kinds[cases%len(kinds)]
        if kind=='robot':roll.metadata['robot']='different-robot'
        elif kind=='fps':roll.fps=25
        elif kind=='reference':roll.metadata['reference_sha256']='wrong-reference'
        elif kind=='names':roll.names[0]='unknown-clip'
        elif kind=='object':roll.objects[0]='different-object'
        elif kind=='length':roll.lengths=roll.lengths.copy();roll.lengths[0]=int(ref.lengths[int(roll.names[0][5:])])+1
        elif kind=='flags':del roll.arrays['terminated']
        elif kind in ('nan','overflow'):
            field='joint_pos' if cases%2 else 'body_pos_w';value=roll.arrays[field].astype(np.float64)
            value.flat[-1]=np.nan if kind=='nan' else 1e200;value.flags.writeable=False;roll.arrays[field]=value;del value
        before=fingerprint(ref,roll);results={};errors={}
        with np.errstate(over='ignore',invalid='ignore'):
            for name,module in [('baseline',baseline),('candidate',candidate)]:
                try:results[name]=module.compare_clips(ref,roll)
                except ValueError as error:errors[name]=(type(error).__name__,str(error))
        if kind=='valid':
            assert not errors,errors
            largest=max(largest,assert_reports(results['candidate'],results['baseline']))
            if cases%37==0:
                analytic_oracle(ref,roll,results['candidate']);analytic+=1
        else:
            assert errors.keys()=={'baseline','candidate'} and errors['baseline']==errors['candidate'],(kind,errors)
        assert fingerprint(ref,roll)==before
        refs=[weakref.ref(m) for m in (ref,roll)]+[weakref.ref(m.arrays[key]) for m in (ref,roll) for key in scored]
        del ref,roll,results,errors
        gc.collect()
        assert all(v() is None for v in refs)
        assert len(list(Path('/proc/self/fd').iterdir()))==fd
        assert len(threading.enumerate())==threads
        cases+=1;frames_seen+=reference_frames;coverage.add(index);faults[kind]=faults.get(kind,0)+1
        if cases%25==0 or time.time()-last_report>=15:
            samples.append(dict(cases=cases,observed_epoch=time.time(),rss_bytes=rss(),fd=fd,threads=threads,last_config=dict(frames=frames,bodies=bodies,joints=joints,clips=clips,dtype=dtype,layout=layout),last_kind=kind))
            assert all(hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()==source[name] for name,m in [('baseline',baseline),('candidate',candidate)])
            snapshot('active');last_report=time.time()
    assert cases>0
    snapshot('passed')
except BaseException as error:
    report=snapshot('failed');report.update(error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc(),failed_index=cases,last_config=dict(frames=frames,bodies=bodies,joints=joints,clips=clips,dtype=dtype,layout=layout),kind=kind)
    failure.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');raise
