import concurrent.futures,json,os,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def run(label,python):
    for script in ['motion_oracle.py','rotation_oracle.py']:
        log=ROOT/f'{script[:-3]}-{label}.log'
        with log.open('w') as stream:
            result=subprocess.run([python,str(ROOT/'scripts'/script)],env=dict(os.environ,PYTHONPATH=str(Path.cwd()/'src'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),stdout=stream,stderr=subprocess.STDOUT,timeout=180)
        assert result.returncode==0,(label,script,log.read_text()[-3000:])
    return label
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    result=list(pool.map(lambda p:run(*p),[('py312','/tmp/ef-ci312-20261014/bin/python'),('numpy124','/tmp/ef-numpy124-20261014/bin/python')]))
print(json.dumps(dict(status='passed',environments=result,ended_epoch=time.time())))
