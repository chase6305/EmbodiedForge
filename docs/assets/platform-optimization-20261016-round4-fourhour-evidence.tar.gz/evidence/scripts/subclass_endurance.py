"""Sustained public ndarray subclass compatibility against the initial scorer."""
import argparse,gc,hashlib,importlib.util,itertools,json,os,platform,threading,time,traceback,weakref
from pathlib import Path
import numpy as np
from embodiedforge import motion as candidate
from embodiedforge._motion_clips import MotionClips
from motion_fixture import arrange,assert_reports,pair
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--until',type=float,default=1792159871);p.add_argument('--cases',type=int,default=0);p.add_argument('--label',default='subclasses-py312');args=p.parse_args()
s=importlib.util.spec_from_file_location('embodiedforge.subclass_baseline',ROOT/'baseline/embodiedforge/motion.py');baseline=importlib.util.module_from_spec(s);s.loader.exec_module(baseline)
source={name:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for name,m in [('baseline',baseline),('candidate',candidate)]}
fields=('joint_pos','body_pos_w','object_pos_w','body_quat_w','object_quat_w')
configs=list(itertools.product((7,1023,1024,4095,4096,4097,21845,21846,32769),fields,('reference','rollout','both'),('contiguous','fortran','strided'),('float32','float64','>f4'),('masked-partial','masked-tail','offset-mean')))
progress=ROOT/f'motion-{args.label}-progress.json';final=ROOT/f'motion-{args.label}.json';failure=ROOT/f'motion-{args.label}-failure.json';assert not final.exists() and not failure.exists()
started=last_report=time.time();fd=len(list(Path('/proc/self/fd').iterdir()));threads=len(threading.enumerate());cases=frames_seen=0;largest=0.0;coverage=set();samples=[]
class OffsetMean(np.ndarray):
    def mean(self,*args,**kwargs):return super().mean(*args,**kwargs)+0.25


def prepare(config,seed):
    frames,field,side,layout,dtype,kind=config;ref,roll=pair(frames,bodies=4,joints=17,dtype=dtype,layout=layout,seed=seed)
    for name,motion in [('reference',ref),('rollout',roll)]:
        if side not in ('both',name):continue
        if kind=='offset-mean':value=motion.arrays[field].view(OffsetMean)
        else:
            data=motion.arrays[field].copy();mask=np.zeros(data.shape,bool)
            if kind=='masked-partial':mask[::3]=True
            else:mask[-min(4097,frames-1):]=True
            if 'quat' not in field:data[mask]=np.nan
            value=np.ma.array(arrange(data,layout),mask=arrange(mask,layout),copy=False)
        motion.arrays[field]=value;MotionClips(motion.arrays,motion.metadata)
    return ref,roll


def fingerprint(ref,roll):
    digest=hashlib.sha256()
    for motion in (ref,roll):
        for field in fields:
            value=motion.arrays[field];digest.update(str((type(value).__name__,value.shape,value.dtype.str,value.strides,value.flags.writeable)).encode());digest.update(np.asarray(value).tobytes())
            if np.ma.isMaskedArray(value):digest.update(str(value.mask.flags.writeable).encode());digest.update(value.mask.tobytes())
    return digest.hexdigest()


def snapshot(status):
    report=dict(status=status,label=args.label,pid=os.getpid(),scope='Sustained actual public MotionClips constructor + initial/final whole-report parity for readonly MaskedArray (including hidden NaNs and fully masked tails) and custom ndarray mean overrides. All five scoring fields, either/both operands, native/foreign float dtypes and C/F/interval layouts; byte fingerprints, weakref release, per-case FD/thread checks. Baseline semantic parity, not a speed benchmark or a general memory-leak proof.',python=platform.python_version(),numpy=np.__version__,started_epoch=started,observed_epoch=time.time(),until_epoch=args.until,cases=cases,reference_frames=frames_seen,unique_configurations=len(coverage),total_configurations=len(configs),analytic_cases=0,max_absolute_metric_difference=largest,fault_counts={},fd_baseline=fd,threads_baseline=threads,source_sha256=source,samples=samples)
    temp=progress.with_suffix('.tmp');temp.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');temp.replace(progress)
    if status=='passed':final.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({key:report[key] for key in ('status','label','cases','unique_configurations','observed_epoch')}),flush=True);return report


try:
    while time.time()<args.until and (not args.cases or cases<args.cases):
        index=cases%len(configs);config=configs[index];ref,roll=prepare(config,151046+cases);before=fingerprint(ref,roll)
        with np.errstate(over='ignore',invalid='ignore'):
            old=baseline.compare_clips(ref,roll);new=candidate.compare_clips(ref,roll)
        largest=max(largest,assert_reports(new,old));assert fingerprint(ref,roll)==before
        refs=[weakref.ref(m) for m in (ref,roll)]+[weakref.ref(m.arrays[field]) for m in (ref,roll) for field in fields]
        del ref,roll,old,new;gc.collect();assert all(v() is None for v in refs)
        assert len(list(Path('/proc/self/fd').iterdir()))==fd and len(threading.enumerate())==threads
        cases+=1;frames_seen+=config[0];coverage.add(index)
        if cases%25==0 or time.time()-last_report>=15:
            rss=int(next(line.split()[1] for line in Path('/proc/self/status').read_text().splitlines() if line.startswith('VmRSS:')))*1024
            samples.append(dict(cases=cases,observed_epoch=time.time(),rss_bytes=rss,fd=fd,threads=threads,last_config=dict(zip(('frames','field','side','layout','dtype','kind'),config,strict=True))))
            assert all(hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()==source[name] for name,m in [('baseline',baseline),('candidate',candidate)])
            snapshot('active');last_report=time.time()
    assert cases>0;snapshot('passed')
except BaseException as error:
    report=snapshot('failed');report.update(error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc(),failed_index=cases,last_config=config);failure.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');raise
