"""Preserve public ndarray subclass semantics; retain intermediate negative controls."""
import hashlib,importlib.util,itertools,json,platform,warnings
from pathlib import Path
import numpy as np
from embodiedforge import motion as candidate
from embodiedforge._motion_clips import MotionClips
from motion_fixture import arrange,assert_reports,pair
ROOT=Path(__file__).resolve().parents[1];modules={'candidate':candidate}
for name,path in [('baseline',ROOT/'baseline/embodiedforge/motion.py'),('intermediate',ROOT/'phase3-subclass-candidate/motion.py')]:
    spec=importlib.util.spec_from_file_location('embodiedforge.masked_'+name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);modules[name]=m
rows=[];negative=0
for i,(field,side,layout,mask_kind) in enumerate(itertools.product(('joint_pos','body_pos_w','object_pos_w','body_quat_w','object_quat_w'),('reference','rollout','both'),('contiguous','fortran','strided'),('partial','tail'))):
    ref,roll=pair(21846,bodies=4,joints=17,dtype='float64',layout=layout,seed=71046+i)
    held=[]
    for name,lib in [('reference',ref),('rollout',roll)]:
        if side not in ('both',name):continue
        data=lib.arrays[field].copy();mask=np.zeros(data.shape,bool)
        if mask_kind=='partial':mask[::3]=True
        else:mask[-4097:]=True
        if 'quat' not in field:data[mask]=np.nan
        value=np.ma.array(arrange(data,layout),mask=arrange(mask,layout),copy=False)
        lib.arrays[field]=value;MotionClips(lib.arrays,lib.metadata)
        held.append((value,value.data.tobytes(),value.mask.tobytes()))
    with warnings.catch_warnings(),np.errstate(over='ignore',invalid='ignore'):
        warnings.simplefilter('ignore',UserWarning)
        old=modules['baseline'].compare_clips(ref,roll);new=candidate.compare_clips(ref,roll);difference=assert_reports(new,old)
        error=None
        try:
            intermediate=modules['intermediate'].compare_clips(ref,roll)
            try:assert_reports(intermediate,old);different=False
            except AssertionError:different=True
        except (ValueError,FloatingPointError) as caught:different=True;error=(type(caught).__name__,str(caught))
    negative+=different
    assert all(v.data.tobytes()==data and v.mask.tobytes()==mask and not v.flags.writeable and not v.mask.flags.writeable for v,data,mask in held)
    rows.append(dict(field=field,side=side,layout=layout,mask_kind=mask_kind,max_final_metric_difference=difference,intermediate_regression_detected=different,intermediate_error=error))
class OffsetMean(np.ndarray):
    def mean(self,*args,**kwargs):return super().mean(*args,**kwargs)+0.25
for field,side in itertools.product(('joint_pos','body_pos_w','object_pos_w'),('reference','rollout')):
    ref,roll=pair(21846,bodies=4,joints=17);target=ref if side=='reference' else roll
    value=target.arrays[field].view(OffsetMean);target.arrays[field]=value;MotionClips(target.arrays,target.metadata)
    old=modules['baseline'].compare_clips(ref,roll);new=candidate.compare_clips(ref,roll);difference=assert_reports(new,old)
    intermediate=modules['intermediate'].compare_clips(ref,roll)
    try:assert_reports(intermediate,old);different=False
    except AssertionError:different=True
    assert different;negative+=1;rows.append(dict(field=field,side=side,subclass='OffsetMean',max_final_metric_difference=difference,intermediate_regression_detected=True))
assert negative>0
report=dict(status='passed',scope='Actual public constructor accepts these readonly subclasses. Compare final versus exact initial whole-field implementation; relative3e-14/absolute1e-25 for whole reports. Masked numeric payloads include hidden NaNs, whole masked tails, all five fields, both operands, C/F/interval strides. Independent OffsetMean override verifies generic dispatch preservation. Intermediate e74a834 negative controls must expose differences; they are not adopted final failures.',python=platform.python_version(),numpy=np.__version__,cases=len(rows),intermediate_regressions_detected=negative,source_sha256={name:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for name,m in modules.items()},rows=rows)
(ROOT/f'masked-array-oracle-{platform.python_version()}-numpy{np.__version__}.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps({k:report[k] for k in ('status','cases','intermediate_regressions_detected')}))
