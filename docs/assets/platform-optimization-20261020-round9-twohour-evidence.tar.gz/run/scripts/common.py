"""Initial/current environment implementations and immutable round evidence."""
import hashlib,importlib.util,json,os
from pathlib import Path
import numpy as np
from embodiedforge import Config,VectorEnv
from embodiedforge.env import _executed_action
from embodiedforge.tasks import make_task
ROOT=Path(__file__).resolve().parents[1];WORKSPACE=ROOT.parents[1];RAM_ROOT=Path('/dev/shm')/ROOT.name;RAM_ROOT.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(p,d):
 p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n');t.replace(p)
def source_map():return {str(p.relative_to(WORKSPACE)):sha(p) for p in sorted((WORKSPACE/'src').rglob('*.py'))}
def guard():
 assert source_map()==read(ROOT/'frozen-runtime.json')['sha256'],'Runtime source drift'
 for p,h in read(ROOT/'frozen-harness.json')['sha256'].items():assert sha(ROOT/p)==h,p
def pin(cpu):assert cpu in os.sched_getaffinity(0);os.sched_setaffinity(0,{cpu})
spec=importlib.util.spec_from_file_location('embodiedforge._round9_initial_env',ROOT/'initial/src/embodiedforge/env.py');initial=importlib.util.module_from_spec(spec);spec.loader.exec_module(initial)
ENVS={'initial':initial.VectorEnv,'current':VectorEnv}
def executed(version,a,m):return np.where(m[:,None],a,0).astype(np.float32) if version=='initial' else _executed_action(a,m)
def environment(version,task,count,substeps=4,channels=(),seed=81):
 env=ENVS[version](Config(task=task,num_envs=count,physics_hz=50*substeps,max_steps=1000000,render='raster' if channels else 'null',channels=channels,image_size=32,seed=seed));env.physics.position[:]=.5;env.physics.velocity[:]=0
 if task=='reach':env.task.target[:]=1
 return env
def fields(result):return {**{'obs/'+k:v for k,v in result.observation.items()},'reward':result.reward,'terminated':result.terminated,'truncated':result.truncated,**{'info/'+k:v for k,v in result.info.items()}}
def equal(a,b):
 assert a.keys()==b.keys()
 for k in a:
  x,y=a[k],b[k];assert type(x) is type(y) and x.dtype==y.dtype and x.shape==y.shape and x.tobytes()==y.tobytes(),k

def fingerprint(d):
 h=hashlib.sha256()
 for k,v in sorted(d.items()):h.update(k.encode());h.update(str((v.shape,v.dtype.str)).encode());h.update(v.tobytes())
 return h.hexdigest()
