"""Reap all four real sessions and retain their final RAM mirrors."""
import json,os,shutil,time
from pathlib import Path
from report import ROOT,REPORT,ARCHIVE,PROBES,START,preservation,read,sha
state=read(ROOT/'state.json');assert time.time()>=state['probe_stop_epoch'] and not REPORT.exists() and not ARCHIVE.exists()
operator=read(ROOT/'operator-state.json');results=read(ROOT/'tool-session-results.json');assert set(results)==set(operator['active_sessions'])==set(PROBES)
ram=Path('/dev/shm')/ROOT.name;assert ram.exists();shutil.copytree(ram,ROOT/'ram-mirror');completed={}
for n in PROBES:
 s=operator['active_sessions'][n];r=results[n];p=ram/(n+'.json');d=read(p)
 assert r['session_id']==s['session_id'] and r['reaped'] is True and r['tool_result']['exit_code']==0
 assert d['pid']==s['pid'] and d['status']=='passed' and d['configuration_count']==d['base_configurations_expected']
 assert not (Path('/proc')/str(s['pid'])).exists();(ROOT/(n+'.json')).write_bytes(p.read_bytes());completed[n]={**s,'status':'passed','exit_code':0,'reaped':True,'cases':d['cases'],'elapsed_seconds':d['elapsed_seconds']}
assert not (ROOT/'session-completions.json').exists();(ROOT/'session-completions.json').write_text(json.dumps(completed,indent=2)+'\n')
operator.update(status='closing',active_sessions={},completed_sessions=completed,updated_epoch=time.time());state.update(status='closing',updated_epoch=time.time())
for n,d in [('operator-state.json',operator),('state.json',state)]:(ROOT/n).write_text(json.dumps(d,indent=2)+'\n')
for n,h in read(ROOT/'validation.json')['sha256'].items():assert sha(ROOT.parents[1]/n)==h,n
assert not list(ROOT.glob('*-failure.json'))
live=[]
for p in Path('/proc').iterdir():
 if not p.name.isdecimal() or int(p.name)==os.getpid():continue
 try:args=(p/'cmdline').read_bytes().split(b'\0')
 except (FileNotFoundError,ProcessLookupError,PermissionError):continue
 if args and Path(os.fsdecode(args[0])).name.startswith('python') and any(ROOT.name.encode() in a for a in args[1:]):live.append(int(p.name))
assert not live,live
d=dict(status='passed',epoch=time.time(),actual_elapsed_seconds=time.time()-START,preservation=preservation(),owned_python_processes_remaining=live,all_four_final_sessions_actually_reaped=True,formal_outputs_created=False);(ROOT/'closing-preflight.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
