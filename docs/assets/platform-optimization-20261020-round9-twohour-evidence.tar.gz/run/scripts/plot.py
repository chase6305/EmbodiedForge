"""Separately show uniform metadata and full-step transient peaks."""
import hashlib,json,statistics
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parents[1];WORKSPACE=ROOT.parents[1];paths=sorted(ROOT.glob('performance-*.json'));assert len(paths)==3
plt.rcParams.update({'svg.fonttype':'none','font.size':10})
fig,axes=plt.subplots(3,2,figsize=(12,10))
for row,path in enumerate(paths):
 d=json.loads(path.read_text())
 for col,scope in enumerate(('action','environment')):
  cases=[]
  for task in (('hold',) if scope=='action' else ('reach','hold')):
   for fraction in (0.,1.):cases.append(next(c for c in d['cases'] if c['scope']==scope and c['num_envs']==8192 and c['action_dim']==2 and c['layout']=='C' and c['task']==task and c['active_fraction']==fraction))
  ax=axes[row,col];x=np.arange(len(cases));width=.34
  for offset,version,label,color in ((-.5,'initial','Initial','#7e8b97'),(.5,'current','Current','#18877f')):
   values=[statistics.median(c['traced_peak_bytes'][version])/2**20 for c in cases];bars=ax.bar(x+offset*width,values,width,label=label,color=color);ax.bar_label(bars,labels=[f'{v:.3f}' for v in values],padding=3,fontsize=8)
  labels=['Frozen','Active'] if scope=='action' else ['Reach\nFrozen','Reach\nActive','Hold\nFrozen','Hold\nActive'];ax.set_xticks(x,labels,fontsize=9);ax.set_ylabel('Peak traced allocation (MiB)');ax.set_title(f"Python {d['python']} / NumPy {d['numpy']}",fontsize=11);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True);ax.set_ylim(0,ax.get_ylim()[1]*1.18)
  if row==0 and col==0:ax.legend(loc='upper right',fontsize=9)
fig.suptitle('Executed-action buffers: uniform activity cases',fontsize=15,y=.98)
fig.text(.29,.935,'Executed-action metadata',ha='center',fontsize=12);fig.text(.77,.935,'Complete step without cameras',ha='center',fontsize=12)
fig.subplots_adjust(top=.89,bottom=.18,left=.09,right=.98,hspace=.47,wspace=.26)
fig.text(.09,.055,'8192 environments, two action dimensions, C layout. Medians of three independent tracemalloc peaks.\nWarm fixtures and input arrays exist before tracing. Peaks are not process RSS or training throughput.\nMixed activity and small batches remain signed controls in all 78 raw scenarios per version.\nComponent savings are not overall memory savings; complete-step time is measured separately.',fontsize=10)
p=WORKSPACE/'docs/platform-optimization-20261020-round9-twohour-allocations.svg';fig.savefig(p);fig.savefig('/tmp/ef-round9-allocations.png',dpi=120)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=dict(status='passed',figure_sha256=sha(p),script_sha256=sha(Path(__file__)),reports_sha256={p.name:sha(p) for p in paths},latency_claim=False,scope='Separate metadata/full-step peaks for all-active/all-frozen batches. Raw mixed and small controls retained.')
(ROOT/'figure-provenance.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
