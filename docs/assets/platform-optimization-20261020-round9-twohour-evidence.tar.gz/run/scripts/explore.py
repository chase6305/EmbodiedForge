import itertools,json,time,statistics,tracemalloc
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parents[1]
def original(a,m):return np.where(m[:,None],a,0).astype(np.float32)
def candidate(a,m):
 out=np.zeros_like(a,dtype=np.float32);np.copyto(out,a,where=m[:,None],casting='unsafe');return out
rows=[]
for n,d,layout,fraction in itertools.product((1,128,1024,8192,65536),(2,12),('C','F','reverse'),(0.,.25,1.)):
 rng=np.random.default_rng(19);a=rng.uniform(-1,1,(n,d));a[::5,0]=-0.;m=rng.random(n)<fraction
 if layout=='F':a=np.asfortranarray(a)
 elif layout=='reverse':a=a[::-1,::-1]
 a.flags.writeable=False;old,new=original(a,m),candidate(a,m);assert old.tobytes()==new.tobytes() and old.strides==new.strides,(n,d,layout,fraction,old.strides,new.strides)
 samples={v:[] for v in ('initial','candidate')};peaks={}
 for pair in range(11):
  for name,fn in ([('initial',original),('candidate',candidate)] if pair%2==0 else [('candidate',candidate),('initial',original)]):
   tick=time.perf_counter()
   for _ in range(16):fn(a,m)
   samples[name].append((time.perf_counter()-tick)/16)
 for name,fn in [('initial',original),('candidate',candidate)]:
  tracemalloc.start();fn(a,m);peaks[name]=tracemalloc.get_traced_memory()[1];tracemalloc.stop()
 med={v:statistics.median(x) for v,x in samples.items()};rows.append(dict(n=n,dim=d,layout=layout,active_fraction=fraction,seconds=med,peaks=peaks,time_reduction_percent=100*(1-med['candidate']/med['initial']),peak_reduction_percent=100*(1-peaks['candidate']/peaks['initial'])))
(root/'exploration.json').write_text(json.dumps(dict(status='passed',scope='Prototype only, validated clipped native float64 actions; not final-source evidence',rows=rows),indent=2)+'\n');print(json.dumps([r for r in rows if r['n']==8192 and r['dim']==2 and r['layout']=='C'],indent=2))
