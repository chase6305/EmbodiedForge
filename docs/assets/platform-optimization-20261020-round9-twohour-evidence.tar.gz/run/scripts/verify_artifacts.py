"""Re-read the exported file and verify its complete provenance and timing links."""
import hashlib,io,json,time
from pathlib import Path
import numpy as np
from report import ROOT,WORKSPACE,REPORT,ARCHIVE,FIGURE,CORE,PROBES,START,DURATION,read,sha,unpack
report=read(REPORT);assert report['actual_elapsed_seconds']>=DURATION and report['duration_gate']['actual_elapsed_seconds']>=DURATION
payload=ARCHIVE.read_bytes();assert len(payload)==report['evidence_archive']['bytes'] and hashlib.sha256(payload).hexdigest()==report['evidence_archive']['sha256'];data=unpack(payload);assert len(data)==report['evidence_archive']['regular_members']
def digest(n):return hashlib.sha256(data[n]).hexdigest()
def raw(n):return json.loads(data[n])
initial=raw('run/initial-hashes.json');runtime_initial={p:h for p,h in initial.items() if p.startswith('src/') and p.endswith('.py')};assert len(runtime_initial)==105
for p,h in runtime_initial.items():assert digest('run/initial/'+p)==h
for p,h in report['review_files_sha256'].items():assert digest('final/'+p)==sha(WORKSPACE/p)==h
assert digest('final/'+str(FIGURE.relative_to(WORKSPACE)))==sha(FIGURE)==report['figure']['figure_sha256'];assert b'<text' in data['final/'+str(FIGURE.relative_to(WORKSPACE))]
assert digest('run/scripts/plot.py')==report['figure']['script_sha256'] and report['figure']['latency_claim'] is False
root_rel=ROOT.relative_to(WORKSPACE)
for p,h in report['validation']['sha256'].items():
 assert sha(WORKSPACE/p)==h
 n='run/'+str((WORKSPACE/p).relative_to(ROOT)) if p.startswith(str(root_rel)+'/') else 'final/'+p if p in CORE else 'run/initial/'+p
 assert digest(n)==h,n
assert report['validation']['new_regression_cases']==183
assert digest('run/actual-regression-results.json')==report['actual_regression_results_sha256'];ci=raw('run/actual-regression-results.json');assert ci['validation_sha256']==digest('run/validation.json')
for d in ci['actual_results'].values():assert d['exit_code']==0 and d['reaped'] is True
frozen=raw('run/frozen-runtime.json')['sha256'];assert frozen=={str(p.relative_to(WORKSPACE)):sha(p) for p in (WORKSPACE/'src').rglob('*.py')}
for n in PROBES:
 p='run/'+n+'.json';d=raw(p);assert digest(p)==report['probe_results'][n]['raw_report_sha256'];assert d['status']=='passed' and d['runtime_source_sha256']==frozen and d['configuration_count']==d['base_configurations_expected'] and d['cases']==report['probe_results'][n]['cases']
 for p,h in d['script_sha256'].items():assert digest('run/'+p)==h
 assert data['run/'+n+'.json']==data['run/ram-mirror/'+n+'.json']
for n,d in report['performance'].items():
 assert digest('run/'+n)==d['sha256'];a=raw('run/'+n);assert a['status']=='passed' and len(a['cases'])==78 and a['pairs']==21 and a['runtime_source_sha256']==frozen and a['initial_env_sha256']==digest('run/initial/src/embodiedforge/env.py')
 for p,h in a['script_sha256'].items():assert digest('run/'+p)==h
 assert report['figure']['reports_sha256'][n]==d['sha256']
gate=raw('run/duration-gate.json');assert gate==report['duration_gate'];early=gate['early_control'];assert early['real_clock_used'] and not early['clock_simulated'] and early['actual_elapsed_seconds']<DURATION and early['actual_rejection_exit']==1 and not early['final_outputs_created']
assert digest('run/scripts/report.py')==sha(ROOT/'scripts/report.py')==early['reporter_sha256']
completed=raw('run/session-completions.json');assert set(completed)==set(PROBES)
for n,d in completed.items():assert d['exit_code']==0 and d['reaped'] is True
assert raw('run/closing-preflight.json')['status']=='passed' and not raw('run/closing-preflight.json')['owned_python_processes_remaining']
capture=report['capture_control'];p='run/controls/capture-control-failure-input.npz';assert digest(p)==capture['capture_sha256'];assert digest('run/controls/capture-control-failure.json')==capture['failed_report_sha256'] and raw('run/controls/capture-control-failure.json')['status']=='failed'
assert digest('run/scripts/endurance.py')==capture['harness_sha256'] and digest('run/scripts/common.py')==capture['common_sha256']
with np.load(io.BytesIO(data[p]),allow_pickle=False) as f:
 assert f['initial/action'].tobytes()!=f['current/action'].tobytes()
 for k in ('action','active'):assert f['before/'+k].tobytes()==f['after/'+k].tobytes()
persistence=report['persistence_control'];assert digest('run/controls/root-write-failure-ram.json')==persistence['ram_report_sha256'] and digest('run/scripts/endurance.py')==persistence['harness_sha256'];d=raw('run/controls/root-write-failure-ram.json');assert d['status']=='passed' and d['cases']==20 and all(e['errno']==28 for e in d['persistence_events'])
for p,h in report['inherited_diagnostics']['files_sha256'].items():assert digest('run/'+p)==h
assert raw('run/inherited-diagnostics/motion/subclasses-py312-failure.json')['status']=='failed' and raw('run/inherited-diagnostics/round7/diagnostic.json')['status']=='unclassified_persistence_interruption'
assert raw('run/inherited-diagnostics/round8/diagnostic.json')['status']=='unclassified_process_termination'
for p,h in report['rejected_prototype']['files_sha256'].items():assert digest('run/'+p)==h
assert 'run/ram-mirror/action-numpy124-signals.log' in data
report['artifact_verification']=dict(status='passed',epoch=time.time(),actual_elapsed_seconds=time.time()-START,regular_archive_members=len(data),gzip_crc_and_all_manifest_hashes_verified=True,source_tests_logs_performance_harness_and_figure_links_verified=True,real_duration_and_actual_reaping_verified=True,injected_output_difference_and_unchanged_inputs_verified=True,mirrored_ENOSPC_control_verified=True,inherited_unclassified_records_and_rejected_prototype_preserved=True,claims_scoped_to_measured_components=True);report['status']='complete_with_unclassified_diagnostics';tmp=REPORT.with_suffix('.json.tmp');tmp.write_text(json.dumps(report,indent=2)+'\n');tmp.replace(REPORT);print(json.dumps(report['artifact_verification'],indent=2))
