"""Mirrored differential endurance for executed actions and full trajectories."""
import argparse,errno,itertools,json,os,sys,threading,time,traceback,warnings,weakref
from pathlib import Path
import numpy as np
from common import ROOT,RAM_ROOT,atomic,read,sha,pin,guard,source_map,environment,fields,equal,executed,fingerprint
p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('--scope',choices=('action','environment','large'),required=True);p.add_argument('--cpu',type=int,required=True);p.add_argument('--smoke',type=int,default=0);p.add_argument('--inject-failure',action='store_true');p.add_argument('--inject-write-failure',action='store_true');args=p.parse_args();assert not (args.inject_failure or args.inject_write_failure) or args.smoke
pin(args.cpu);started=time.time();stop=read(ROOT/'state.json')['probe_stop_epoch'];cases=0;covered=set();resources=[];events=[];last_progress=last_guard=0;context={}
def persist(path,d):
 mirror=RAM_ROOT/path.relative_to(ROOT);atomic(mirror,d)
 try:
  if args.inject_write_failure:raise OSError(errno.ENOSPC,'Injected root write failure')
  atomic(path,d)
 except OSError as e:
  if e.errno not in (errno.ENOSPC,errno.EDQUOT,errno.EIO):raise
  events.append(dict(epoch=time.time(),errno=e.errno,path=str(path),error=str(e)));atomic(mirror,d);print(json.dumps(dict(persistence_interruption=events[-1],ram_mirror=str(mirror))),file=sys.stderr,flush=True)

def action_case(index,config):
 n,dim,layout,activity,kind,mode=config;rng=np.random.default_rng(920000+index);a=rng.uniform(-1,1,(n,dim));a[::3,0]=-0.
 if kind=='special':a=np.resize(np.array([0,2**63,1,0x7fefffffffffffff,0x7ff0000000000081,0x7ff8000000000081],np.uint64),(n,dim)).view(np.float64)
 else:a=a.astype(kind)
 if layout=='F':a=np.asfortranarray(a)
 elif layout=='reverse':a=a[::-1,::-1]
 m=np.ones(n,bool) if activity=='all' else np.zeros(n,bool)
 if activity=='mixed':m[::3]=True
 a.flags.writeable=m.flags.writeable=False;inputs=dict(action=a,active=m);before=fingerprint(inputs);global context;context={**{'before/'+k:v.copy() for k,v in inputs.items()},'configuration':np.array(json.dumps(config)),'case':np.array(index)};results={};outputs={}
 for v in ('initial','current'):
  with warnings.catch_warnings(record=True) as caught,np.errstate(all=mode):
   warnings.simplefilter('always')
   try:
    out=executed(v,a,m)
    if v=='current' and args.inject_failure:out[0,0]+=1
    results[v]=dict(status='passed',dtype=out.dtype.str,shape=out.shape,strides=out.strides,owned=bool(out.flags.owndata),bytes=out.tobytes());outputs[v]=out;context[v+'/action']=out
   except FloatingPointError as e:results[v]=dict(status='floating_point_error',message=str(e))
   results[v]['warnings']=[(w.category.__name__,str(w.message)) for w in caught]
  assert fingerprint(inputs)==before,(v,'input changed')
 context.update({'after/'+k:v.copy() for k,v in inputs.items()});assert results['initial']==results['current'],(config,'different output/FP diagnostics')
 for out in outputs.values():
  assert out.flags.owndata and not np.shares_memory(out,a) and not np.shares_memory(out,m);out[:]=99
 refs=[weakref.ref(v) for v in (*inputs.values(),*outputs.values())];context={};return refs

def environment_case(index,config):
 task,n,substeps,channels=config;pair=[environment(v,task,n,substeps,channels,930000+index) for v in ('initial','current')];rng=np.random.default_rng(940000+index);global context
 for step in range(10):
  if step in (1,6):
   for env in pair:env.terminated[:]=True
  if step in (2,7):
   ids=np.arange(n)[::3][::-1];obs=[env.reset(ids) for env in pair];equal(obs[0],obs[1])
  if step==4:
   obs=[env.reset() for env in pair];equal(obs[0],obs[1])
  a=rng.uniform(-.1,.1,(n,2));a[::5,0]=-0.;a.flags.writeable=False;before=a.tobytes();context={'action':a,'configuration':np.array(json.dumps(config)),'case':np.array(index),'step':np.array(step)}
  results=[env.step(a) for env in pair];x,y=map(fields,results);context.update({'initial/'+k:v for k,v in x.items()});context.update({'current/'+k:v for k,v in y.items()});equal(x,y);assert a.tobytes()==before
  for r in results:
   for v in fields(r).values():assert v.flags.owndata
  equal(pair[0].observe(),pair[1].observe())
 refs=[weakref.ref(env) for env in pair]+[weakref.ref(v) for r in results for v in fields(r).values()]
 for env in pair:env.close()
 context={};return refs

if args.scope=='action':configs=list(itertools.product((0,1,1023,1024,8192),(1,2,12),('C','F','reverse'),('all','none','mixed'),('float64','float32','>f8','special'),('ignore','warn','raise')))
elif args.scope=='environment':configs=list(itertools.product(('reach','hold'),(1,16,128,1024),(1,4,16),((),('depth',),('rgb','depth','instance_id','semantic_id'))))
else:configs=list(itertools.product(('reach','hold'),(8192,),(1,4,16),((),)))
np.random.default_rng(921).shuffle(configs)
report=dict(status='running',name=args.name,scope=args.scope,pid=os.getpid(),started_epoch=started,python=__import__('platform').python_version(),numpy=np.__version__,cpu_affinity=sorted(os.sched_getaffinity(0)),base_configurations_expected=len(configs),runtime_source_sha256=source_map(),script_sha256={f'scripts/{n}':sha(ROOT/'scripts'/n) for n in ('endurance.py','common.py')},resources=resources,persistence_events=events,ram_evidence_directory=str(RAM_ROOT))
def progress(status='running'):
 global last_progress
 now=time.time();resources.append(dict(epoch=now,fds=len(list(Path('/proc/self/fd').iterdir())),python_threads=threading.active_count(),os_threads=len(list(Path('/proc/self/task').iterdir()))))
 for k in ('fds','python_threads','os_threads'):assert len({r[k] for r in resources})==1,k
 report.update(status=status,updated_epoch=now,elapsed_seconds=now-started,cases=cases,configuration_count=len(covered));persist(ROOT/(args.name+'-progress.json'),report);last_progress=now
try:
 guard();progress()
 while (cases<args.smoke if args.smoke else time.time()<stop):
  config=(1024,2,'C','all','float64','ignore') if args.inject_failure else configs[cases%len(configs)];refs=(action_case if args.scope=='action' else environment_case)(cases,config);assert all(ref() is None for ref in refs),'Retained completed case objects';covered.add(cases%len(configs));cases+=1;now=time.time()
  if now-last_guard>60:guard();last_guard=now
  if now-last_progress>20:progress()
 guard();progress('passed');report['finished_epoch']=time.time();persist(ROOT/(args.name+'.json'),report)
except BaseException:
 trace=traceback.format_exc();print(trace,file=sys.stderr,flush=True)
 if context:
  capture=RAM_ROOT/(args.name+'-failure-input.npz');capture.parent.mkdir(parents=True,exist_ok=True);np.savez_compressed(capture,**context)
  try:
   target=ROOT/(args.name+'-failure-input.npz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(capture.read_bytes())
  except OSError as e:print(repr(e),file=sys.stderr,flush=True)
 report.update(status='failed',cases=cases,configuration_count=len(covered),traceback=trace,finished_epoch=time.time());persist(ROOT/(args.name+'-failure.json'),report);raise
