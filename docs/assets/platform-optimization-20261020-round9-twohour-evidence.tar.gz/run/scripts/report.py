"""Export only after two real elapsed hours, clean reaping and linked evidence."""
import argparse,gzip,hashlib,io,json,tarfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];WORKSPACE=ROOT.parents[1]
START=1792426276;DEADLINE=1792433476;DURATION=7200
STEM='platform-optimization-20261020-round9-twohour';REPORT=WORKSPACE/'docs'/(STEM+'.json');ARCHIVE=WORKSPACE/'docs/assets'/(STEM+'-evidence.tar.gz');FIGURE=WORKSPACE/'docs'/(STEM+'-allocations.svg')
CORE=('src/embodiedforge/env.py','tests/test_executed_action_buffers.py','benchmarks/executed_actions.py','docs/interfaces.md')
PROBES=('action-py312','action-numpy124','environment-py312','environment-large-py312')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def preservation():
 initial=read(ROOT/'initial-hashes.json');changed=[]
 for p,h in initial.items():
  assert sha(ROOT/'initial'/p)==h,('Snapshot drift',p)
  if sha(WORKSPACE/p)!=h:changed.append(p)
 assert set(changed)=={'src/embodiedforge/env.py','docs/interfaces.md'},changed
 current={str(p.relative_to(WORKSPACE)):sha(p) for p in sorted((WORKSPACE/'src').rglob('*.py'))};assert current==read(ROOT/'frozen-runtime.json')['sha256']
 return dict(initial_files_verified=len(initial),runtime_sources_verified=len(current),changed_initial_files=changed,prior_changes_preserved=True)
def members():
 data={}
 for p in sorted(ROOT.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(ROOT)
  if '__pycache__' in rel.parts or p.suffix in ('.pyc','.tmp') or (len(rel.parts)==1 and p.name in ('preview-report.json','archive-preflight.json')):continue
  if rel.parts[0]=='initial' and p.suffix not in ('.py','.md','.json','.toml','.txt','.xml','.svg','.html','.js') and not p.name.startswith(('LICENSE','NOTICE')):continue
  data['run/'+str(rel)]=p.read_bytes()
 for p in CORE:data['final/'+p]=(WORKSPACE/p).read_bytes()
 data['final/'+str(FIGURE.relative_to(WORKSPACE))]=FIGURE.read_bytes()
 manifest={n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in data.items()};data['manifest.json']=(json.dumps(dict(manifest_excludes_itself=True,members=manifest),indent=2)+'\n').encode();return data

def pack(data):
 target=io.BytesIO()
 with tarfile.open(fileobj=target,mode='w:gz') as tar:
  for n,b in data.items():
   p=Path(n);assert not p.is_absolute() and '..' not in p.parts;t=tarfile.TarInfo(n);t.size=len(b);t.mode=0o644;t.mtime=START;tar.addfile(t,io.BytesIO(b))
 return target.getvalue()
def unpack(payload):
 gzip.decompress(payload)
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tar:
  entries=tar.getmembers();assert len(entries)==len({p.name for p in entries});data={}
  for p in entries:
   path=Path(p.name);assert p.isfile() and not path.is_absolute() and '..' not in path.parts;data[p.name]=tar.extractfile(p).read()
 manifest=json.loads(data['manifest.json'])['members'];assert set(data)==set(manifest)|{'manifest.json'}
 for n,d in manifest.items():assert len(data[n])==d['bytes'] and hashlib.sha256(data[n]).hexdigest()==d['sha256'],n
 return data
def verify_archive(payload):return len(unpack(payload))
def main():
 p=argparse.ArgumentParser();p.add_argument('--preview',action='store_true');args=p.parse_args();now=time.time();state=read(ROOT/'state.json')
 assert state['start_epoch']==START and state['deadline_epoch']==DEADLINE and state['required_elapsed_seconds']==DURATION==DEADLINE-START
 if not args.preview:
  assert now-START>=DURATION,'Two-hour elapsed-time gate: actual elapsed time must reach 7200 seconds'
  assert not REPORT.exists() and not ARCHIVE.exists()
 preserved=preservation();frozen=read(ROOT/'frozen-runtime.json')['sha256'];validation=read(ROOT/'validation.json');assert validation['status']=='passed' and validation['new_regression_cases']==183
 for n,h in validation['sha256'].items():assert sha(WORKSPACE/n)==h,n
 actual=read(ROOT/'actual-regression-results.json');assert actual['status']=='passed' and actual['validation_sha256']==sha(ROOT/'validation.json') and actual['runtime_source_sha256']==frozen[CORE[0]]
 for d in actual['actual_results'].values():assert d['exit_code']==0 and d['reaped'] is True
 performance={}
 for path in sorted(ROOT.glob('performance-*.json')):
  d=read(path);assert d['status']=='passed' and len(d['cases'])==78 and d['pairs']==21 and d['runtime_source_sha256']==frozen and d['initial_env_sha256']==sha(ROOT/'initial'/CORE[0])
  for n,h in d['script_sha256'].items():assert sha(ROOT/n)==h,n
  performance[path.name]=dict(sha256=sha(path),python=d['python'],numpy=d['numpy'],cpu_affinity=d['cpu_affinity'],cases=len(d['cases']),pairs=d['pairs'],selected_8192_dim2_C=[c for c in d['cases'] if c['num_envs']==8192 and c['action_dim']==2 and c['layout']=='C'],controls=[{k:v for k,v in c.items() if k not in ('seconds','traced_peak_bytes')} for c in d['cases'] if c['num_envs']<1024 or c['active_fraction']==.25])
 assert len(performance)==3
 figure=read(ROOT/'figure-provenance.json');assert figure['status']=='passed' and figure['figure_sha256']==sha(FIGURE) and figure['script_sha256']==sha(ROOT/'scripts/plot.py')
 for n,h in figure['reports_sha256'].items():assert sha(ROOT/n)==h,n
 probes={}
 for n in PROBES:
  path=ROOT/(n+('-progress' if args.preview else '')+'.json');d=read(path);assert d['runtime_source_sha256']==frozen
  for f,h in d['script_sha256'].items():assert sha(ROOT/f)==h,f
  if not args.preview:assert d['status']=='passed' and d['configuration_count']==d['base_configurations_expected']
  probes[n]={k:d[k] for k in ('status','scope','started_epoch','elapsed_seconds','cases','configuration_count','base_configurations_expected','persistence_events')};probes[n]['raw_report_sha256']=sha(path)
  for k in ('fds','python_threads','os_threads'):
   values=sorted({s[k] for s in d['resources']});assert len(values)==1;probes[n]['observed_'+k]=values
 assert not list(ROOT.glob('*-failure.json'))
 capture=read(ROOT/'capture-control.json');assert capture['status']=='passed' and capture['actual_process_exit']==1 and capture['before_after_inputs_verified'] and capture['injected_output_difference_verified']
 assert capture['capture_sha256']==sha(ROOT/'controls/capture-control-failure-input.npz') and capture['failed_report_sha256']==sha(ROOT/'controls/capture-control-failure.json') and capture['harness_sha256']==sha(ROOT/'scripts/endurance.py') and capture['common_sha256']==sha(ROOT/'scripts/common.py')
 persistence=read(ROOT/'persistence-control.json');assert persistence['status']=='passed' and persistence['actual_process_exit']==0 and persistence['completed_cases']==20 and persistence['simulated_errno']==28 and persistence['ram_report_sha256']==sha(ROOT/'controls/root-write-failure-ram.json') and persistence['harness_sha256']==sha(ROOT/'scripts/endurance.py')
 inherited={str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'inherited-diagnostics').rglob('*')) if p.is_file()};assert read(ROOT/'inherited-diagnostics/round8/diagnostic.json')['status']=='unclassified_process_termination'
 rejected={n:sha(ROOT/n) for n in ('scripts/explore.py','exploration.json','scripts/explore_activity.py','exploration-activity-shortcut.json')}
 report=dict(status='active_preview' if args.preview else 'closing_after_elapsed_gate',objective='持续优化 EmbodiedForge 两个实际小时，保留既有工作，完成实现、回归、测量、持续验证和可审查证据。',start_epoch=START,deadline_epoch=DEADLINE,required_elapsed_seconds=DURATION,actual_elapsed_seconds=now-START,parallel_durations_added=False,preservation=preserved,review_files_sha256={n:sha(WORKSPACE/n) for n in CORE},changes=['Executed-action metadata with at least 2048 native float64 elements avoids a float64 mask result for uniform activity: all-active casts directly to an independently owned float32 output; all-frozen allocates owned positive-zero float32 output.','Mixed masks, small batches, nonnative/mixed dtypes and subclasses retain the original where-then-cast path. Physics control input masking, clipping, reward computation and reset behavior remain unchanged.','183 new regression cases cover boundaries, zero signs, native/nonnative dtypes, layouts, ownership, later step/reset independence, subclass dispatch and strict floating-point diagnostics. A public benchmark CLI exposes activity fraction and separate metadata/full-step scopes.'],performance=performance,performance_claims=dict(primary='Measured transient allocation peaks for large uniform executed-action metadata; no propagation to total memory.',latency='All signed paired measurements retained, including small and mixed controls. Shared host timings and component gains are not general step/training speedups.',full_step='Complete camera-free step time and peaks are separately measured for Reach/Hold and all/mixed/frozen activity.'),scope='Synthetic CPU reference environment and executed-action metadata. No GPU, process RSS bound or training-throughput inference.',validation=validation,actual_regression_results_sha256=sha(ROOT/'actual-regression-results.json'),figure=figure,probe_results=probes,capture_control=capture,persistence_control=persistence,rejected_prototype=dict(files_sha256=rejected,interpretation='The first masked copyto prototype reduced component allocation but was slower, so it was rejected. Prototype measurements are separate from final-source performance proof.'),inherited_diagnostics=dict(status='unclassified',files_sha256=inherited,interpretation='Prior MotionClips fingerprint, round-7 exit-120 persistence interruption and round-8 exit-143 process termination remain unclassified. Their original files are retained. This round changes only executed-action metadata and does not infer those historical causes from passing replays or isolated ENOSPC controls.'),signal_followup='The NumPy 1.24 action cohort runs under its own parent strace restricted to SIGTERM. Final trace is preserved after actual reaping; it does not identify the earlier sender.',round_scope='Two actual wall-clock hours include analysis, implementation, measurements, regression, sustained validation and export. Cohort starts/durations are separate; parallel durations are never added.',evidence_selection='Raw reports, scripts, controls, inherited diagnostics, initial text files and final review files/figure. Initial binaries/old compressed archives excluded; original hashes for all snapshot files retained.')
 if args.preview:
  (ROOT/'preview-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],actual_elapsed_seconds=now-START)));return
 early=read(ROOT/'duration-gate-control.json');assert early['status']=='passed' and early['real_clock_used'] and not early['clock_simulated'] and early['actual_elapsed_seconds']<DURATION and early['reporter_sha256']==sha(Path(__file__))
 completed=read(ROOT/'session-completions.json');assert set(completed)==set(PROBES)
 for n,d in completed.items():assert d['exit_code']==0 and d['reaped'] is True and not (Path('/proc')/str(d['pid'])).exists()
 assert not read(ROOT/'operator-state.json')['active_sessions'] and read(ROOT/'closing-preflight.json')['status']=='passed'
 gate=dict(status='passed',real_clock_used=True,actual_elapsed_seconds=now-START,required_elapsed_seconds=DURATION,parallel_durations_added=False,early_control=early);(ROOT/'duration-gate.json').write_text(json.dumps(gate,indent=2)+'\n');report['duration_gate']=gate
 payload=pack(members());count=verify_archive(payload)
 with ARCHIVE.open('xb') as f:f.write(payload)
 report['evidence_archive']=dict(path=str(ARCHIVE.relative_to(WORKSPACE)),bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest(),regular_members=count)
 with REPORT.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
 print(json.dumps(dict(status=report['status'],actual_elapsed_seconds=now-START,archive_members=count,archive_bytes=len(payload))))
if __name__=='__main__':main()
