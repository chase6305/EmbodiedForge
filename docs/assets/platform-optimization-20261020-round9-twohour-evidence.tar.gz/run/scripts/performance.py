"""Paired executed-action and full-step measurements; all signed controls retained."""
import itertools,json,os,platform,statistics,time,tracemalloc
import numpy as np
from common import ROOT,environment,executed,fields,equal,fingerprint,pin,guard,sha,source_map
pin(0);guard();start=time.time();pairs=21;rows=[]
cases=[('action',n,d,l,f,'hold') for n,d,l,f in itertools.product((1,128,1024,8192,65536),(2,12),('C','F'),(0.,.25,1.))]
cases += [('environment',n,2,'C',f,t) for n,f,t in itertools.product((128,1024,8192),(0.,.25,1.),('reach','hold'))]
for scope,n,dim,layout,fraction,task in cases:
 rng=np.random.default_rng(91);a=rng.uniform(-.5,.5,(n,dim)) if scope=='action' else np.zeros((n,dim));m=np.zeros(n,bool);m[:int(n*fraction)]=True
 if layout=='F':a=np.asfortranarray(a)
 a.flags.writeable=False;objects={};calls={}
 for version in ('initial','current'):
  if scope=='action':calls[version]=lambda v=version:{'action':executed(v,a,m)}
  else:
   env=environment(version,task,n);env.terminated[:]=~m;objects[version]=env;calls[version]=lambda e=env:fields(e.step(a))
 try:
  for call in calls.values():
   for _ in range(4):call()
  samples={v:[] for v in calls};last={};loops=8 if scope=='environment' else 16 if n>=65536 else 64
  for pair in range(pairs):
   for v in (('initial','current') if pair%2==0 else ('current','initial')):
    tick=time.perf_counter()
    for _ in range(loops):value=calls[v]();del value
    samples[v].append((time.perf_counter()-tick)/loops);last[v]=calls[v]()
   equal(last['initial'],last['current'])
  peaks={}
  for v in calls:
   peaks[v]=[]
   for _ in range(3):
    tracemalloc.start();value=calls[v]();del value;peaks[v].append(tracemalloc.get_traced_memory()[1]);tracemalloc.stop()
  med={v:statistics.median(s) for v,s in samples.items()};row=dict(scope=scope,num_envs=n,action_dim=dim,layout=layout,active_fraction=fraction,task=task,seconds=samples,median_seconds=med,traced_peak_bytes=peaks,elapsed_reduction_percent=100*(1-med['current']/med['initial']),peak_reduction_percent=100*(1-statistics.median(peaks['current'])/statistics.median(peaks['initial'])),output_sha256=fingerprint(last['current']));rows.append(row);print(scope,n,dim,layout,fraction,task,round(row['elapsed_reduction_percent'],2),round(row['peak_reduction_percent'],2),flush=True)
 finally:
  for env in objects.values():env.close()
 guard()
d=dict(status='passed',python=platform.python_version(),numpy=np.__version__,started_epoch=start,finished_epoch=time.time(),cpu_affinity=sorted(os.sched_getaffinity(0)),pairs=pairs,cases=rows,runtime_source_sha256=source_map(),initial_env_sha256=sha(ROOT/'initial/src/embodiedforge/env.py'),script_sha256={f'scripts/{n}':sha(ROOT/'scripts'/n) for n in ('common.py','performance.py')},scope='Synthetic CPU executed-action metadata and complete camera-free step. Reused warm fixtures; construction, warmup, tracing and byte comparisons excluded from timing. Separate three-sample tracemalloc peaks exclude prebuilt inputs/caches and are not process RSS. Pinned CPU on shared host; all mixed/small/signed controls retained. No training-throughput inference.')
p=ROOT/('performance-py'+d['python']+'-numpy'+d['numpy']+'.json');p.write_text(json.dumps(d,indent=2)+'\n');print(p.name)
