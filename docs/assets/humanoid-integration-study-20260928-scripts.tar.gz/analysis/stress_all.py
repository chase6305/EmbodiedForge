import os,json,time,hashlib,random
from pathlib import Path
from embodiedforge._microduck_process import run_process
from embodiedforge._sonic_worker import episode_result
root=Path('/home/ubuntu/workspace/chase/EmbodiedForge');study=root/'runs/humanoid-integration-20260928';out=study/'stress';out.mkdir()
base=[r for r in json.loads((study/'sonic-matrix.json').read_text())['runs'] if r['threads']==2 and r['init_frame']==0]
plan=[]
for row in base:
 for idx,clip in enumerate(row['result']['clips']):
  for storage in ['fp32','fp16','int8']:
   for strength in [200,400]:
    for direction,unit in [('x+',[1,0,0]),('x-',[-1,0,0]),('y+',[0,1,0]),('y-',[0,-1,0])]:
     cmd=clip['command'].copy()
     if storage!='fp32':cmd[cmd.index('--onnx')+1]=str(study/f"compressed/{row['model']}-{storage}.onnx")
     label=f"{row['model']}-{row['motion']}-{idx}-f{row['init_frame']}-{storage}-{strength}-{direction}"
     plan.append({'label':label,'model':row['model'],'motion':row['motion'],'clip':clip['name'],'init_frame':row['init_frame'],'storage':storage,'force_magnitude_N':strength,'direction':direction,'force_N':[strength*x for x in unit],'start_seconds':1.0,'duration_seconds':0.2,'command':cmd,'telemetry':str(out/f'{label}.telemetry.json')})
random.Random(20260929).shuffle(plan)
protocol={'description':'Exploratory second stage, selected after observing no falls in the first 665 of 864 pre-specified 20/60/100 N cases. World-frame pelvis pushes at 1.0s for 0.2s; init frame 0 only; original model-specific controls. No new motions or training seeds.','new_episodes':len(plan),'source_baseline_episodes':24,'forces_N':[200,400],'directions':['x+','x-','y+','y-'],'init_frames':[0],'storage':['fp32','fp16','int8'],'threads':2,'execution_order_seed':20260929,'entries':plan}
(study/'stress-protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
env=os.environ.copy();env.pop('DISPLAY',None);env['OMP_NUM_THREADS']='1';env['ORT_NUM_THREADS']='2'
rows=[]
started=time.monotonic()
for i,case in enumerate(plan):
 label=case['label'];request=out/f'{label}.request.json';request.write_text(json.dumps(case,indent=2)+'\n');log=out/f'{label}.log'
 command=[str(root/'.cache/humanoid-motion-venv/bin/python'),str(study/'analysis/perturb_sonic.py'),str(request)]
 run_process(command,cwd=root,env=env,log_path=log,echo=False,timeout=180)
 report=episode_result(log.read_text());telemetry=json.loads(Path(case['telemetry']).read_text())
 rows.append({'case':case,'result':report,'telemetry':telemetry,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 if (i+1)%12==0 or i+1==len(plan):(study/'stress.partial.json').write_text(json.dumps(rows,indent=2)+'\n')
 elapsed=time.monotonic()-started
 print(f"{i+1}/{len(plan)} {label} {report['status']} {report['simulated_seconds']}s elapsed={elapsed:.1f}s eta={elapsed/(i+1)*(len(plan)-i-1):.1f}s",flush=True)
(study/'stress.json').write_text(json.dumps({'protocol':protocol,'episodes':rows},indent=2)+'\n')
