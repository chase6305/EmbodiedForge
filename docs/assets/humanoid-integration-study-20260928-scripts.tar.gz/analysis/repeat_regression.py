"""Check the observed INT8 fall against FP32/FP16 with two fresh processes each."""
import hashlib
import json
import os
from pathlib import Path

import numpy as np

from embodiedforge._microduck_process import run_process
from embodiedforge._sonic_worker import episode_result

study = Path(__file__).resolve().parents[1]
root = study.parents[1]
output = study / "regression-repeats"
output.mkdir()
cases = [r for r in json.loads((study / "stress.json").read_text())["episodes"]
         if r["case"]["model"] == "incumbent-14000" and r["case"]["motion"] == "idle"
         and r["case"]["force_magnitude_N"] == 400 and r["case"]["direction"] == "y-"]
assert len(cases) == 3
env = os.environ.copy()
env.pop("DISPLAY", None)
env.update(OMP_NUM_THREADS="1", ORT_NUM_THREADS="2")
results = []
for source in cases:
    captures = []
    reports = []
    for repeat in range(2):
        case = source["case"].copy()
        label = f"{case['storage']}-repeat{repeat}"
        capture = output / f"{label}.npz"
        case.update(telemetry=str(output / f"{label}.telemetry.json"), capture=str(capture))
        request = output / f"{label}.request.json"
        request.write_text(json.dumps(case, indent=2) + "\n")
        log = output / f"{label}.log"
        run_process([case["command"][0], str(study / "analysis/perturb_sonic.py"), str(request)],
                    cwd=root, env=env, log_path=log, echo=False, timeout=180)
        parsed = episode_result(log.read_text())
        assert parsed == source["result"]
        with np.load(capture, allow_pickle=False) as z:
            captures.append({name: z[name].copy() for name in z.files})
        reports.append({"log": str(log), "result": parsed,
                        "capture": str(capture), "sha256": hashlib.sha256(capture.read_bytes()).hexdigest()})
        print(label, parsed, flush=True)
    equal = {name: bool(np.array_equal(captures[0][name], captures[1][name])) for name in captures[0]}
    assert all(equal.values())
    results.append({"storage": source["case"]["storage"], "original_label": source["case"]["label"],
                    "matches_original_rounded_metrics": True, "repeat_arrays_bitwise_equal": equal,
                    "control_steps": len(captures[0]["actions"]), "repeats": reports})
report = {"status": "passed", "new_repeat_episodes": 6, "counted_in_unique_comparison_matrix": False,
          "purpose": "Confirm a discovered failure difference; exploratory repeats, no new training seeds.",
          "cases": results}
(study / "regression-repeats.json").write_text(json.dumps(report, indent=2) + "\n")
