from pathlib import Path
import subprocess,os,json
root=Path('/home/ubuntu/workspace/chase/EmbodiedForge');study=root/'runs/humanoid-integration-20260928'
env=os.environ.copy();env.pop('DISPLAY',None);env['OMP_NUM_THREADS']='1';env['ORT_NUM_THREADS']='2'
for model in ['transfer-v2','incumbent-14000']:
 for motion in ['walk','idle','dance']:
  result=study/f'sonic-matrix/{model}-{motion}-f0-t2/result.json'
  if not result.exists(): continue
  data=json.loads(result.read_text())
  if data['status']!='complete':continue
  out=study/f'captures/{model}-{motion}'
  if out.exists():continue
  with (study/f'capture-{model}-{motion}.log').open('x') as log:
   subprocess.run([str(root/'.cache/humanoid-motion-venv/bin/python'),str(study/'analysis/capture_sonic.py'),str(result),str(out)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  print(out.name,flush=True)
