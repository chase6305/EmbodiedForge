import os,json,random,subprocess
from pathlib import Path
root=Path('/home/ubuntu/workspace/chase/EmbodiedForge');study=root/'runs/humanoid-integration-20260928';out=study/'cpu-benchmark';out.mkdir()
plan=[]
for block in range(6):
 variants=[(m,t) for m in ['transfer-v2','incumbent-14000'] for t in [1,2,4]]
 random.Random(20260928+block).shuffle(variants)
 plan += [{'block':block,'model':m,'threads':t} for m,t in variants]
(study/'cpu-benchmark-protocol.json').write_text(json.dumps({'entries':plan,'ordering':'randomized blocks, seed 20260928+block','samples':512,'warmup':64,'affinity_pinned':False,'shared_cpu':True},indent=2)+'\n')
env=os.environ.copy();env.pop('DISPLAY',None);env['OMP_NUM_THREADS']='1'
for i,item in enumerate(plan):
 m,t,b=item['model'],item['threads'],item['block']
 captures=sorted(study.glob(f'captures/{m}-*/clip_*.npz'));assert len(captures)==4
 model=study/f'sonic-matrix/{m}-walk-f0-t2/inputs/policy.onnx'
 target=out/f'{m}-t{t}-b{b}.json'
 cmd=[str(root/'.cache/humanoid-motion-venv/bin/python'),str(study/'analysis/benchmark_sonic.py'),'--model',str(model),'--captures',*map(str,captures),'--threads',str(t),'--seed',str(9000+b),'--output',str(target)]
 subprocess.run(cmd,cwd=root,env=env,check=True,stdout=subprocess.DEVNULL)
 print(i+1,len(plan),target.name,flush=True)
