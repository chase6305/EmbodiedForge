import json,sys
from pathlib import Path
import numpy as np
import onnx
import onnxruntime as ort
root=Path('/home/ubuntu/workspace/chase/EmbodiedForge');study=root/'runs/humanoid-integration-20260928'
reports=[]
for model in ['transfer-v2','incumbent-14000']:
 obs=[];expected=[]
 for src in sorted(study.glob(f'captures/{model}-*/clip_*.npz')):
  with np.load(src,allow_pickle=False) as z:obs.append(z['observations']);expected.append(z['actions'])
 obs=np.concatenate(obs);expected=np.concatenate(expected)
 opts=ort.SessionOptions();opts.intra_op_num_threads=2;opts.inter_op_num_threads=1;opts.add_session_config_entry('session.intra_op.allow_spinning','0')
 baseline=study/f'sonic-matrix/{model}-walk-f0-t2/inputs/policy.onnx'
 reference=None;codes=None
 for storage in ['fp32','fp16','int8']:
  path=baseline if storage=='fp32' else study/f'compressed/{model}-{storage}.onnx'
  plain=ort.InferenceSession(str(path),opts,providers=['CPUExecutionProvider'])
  graph=onnx.shape_inference.infer_shapes(onnx.load(path));info={v.name:v for v in graph.graph.value_info};rounds=[n for n in graph.graph.node if n.op_type=='Round'];assert len(rounds)==1
  graph.graph.output.append(info[rounds[0].output[0]])
  debug=ort.InferenceSession(graph.SerializeToString(),opts,providers=['CPUExecutionProvider'])
  values=[];code=[];debug_error=0.
  for row in obs:
   kwargs={plain.get_inputs()[0].name:row[None]}
   action=plain.run(None,kwargs)[0]
   dbg=debug.run(None,kwargs)
   debug_error=max(debug_error,float(np.max(np.abs(action-dbg[0]))))
   values.append(action[0]);code.append(dbg[1].reshape(-1))
  values=np.stack(values);code=np.stack(code)
  if storage=='fp32':reference=values;codes=code
  error=values-reference
  changed=code!=codes
  reports.append({'versions':{'python':sys.version.split()[0],'numpy':np.__version__,'onnxruntime':ort.__version__,'onnx':onnx.__version__},'model':model,'storage':storage,'states':len(obs),'bytes':path.stat().st_size,'rmse_vs_fp32':float(np.sqrt(np.mean(error.astype(float)**2))),'max_absolute_error_vs_fp32':float(np.max(np.abs(error))),'p99_absolute_error_vs_fp32':float(np.percentile(np.abs(error),99)),'original_capture_max_error':float(np.max(np.abs(values-expected))),'debug_output_max_error':debug_error,'code_elements_per_state':code.shape[1],'fraction_states_any_fsq_code_change':float(np.mean(np.any(changed,axis=1))),'fraction_fsq_code_elements_changed':float(np.mean(changed))})
  print(reports[-1],flush=True)
  (study/'storage-offline.partial.json').write_text(json.dumps(reports,indent=2)+'\n')
(study/'storage-offline.json').write_text(json.dumps(reports,indent=2)+'\n')
