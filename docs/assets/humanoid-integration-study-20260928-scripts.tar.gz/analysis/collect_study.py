"""Collect complete, traceable experiment results into a compact public dataset."""
import argparse,json,hashlib,platform,statistics,collections,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--draft',action='store_true');a=p.parse_args()
root=Path('/home/ubuntu/workspace/chase/EmbodiedForge');study=root/'runs/humanoid-integration-20260928'
def load(name):return json.loads((study/name).read_text())
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
keys=['status','reason','simulated_seconds','joint_mae_rad','max_joint_error_rad','pelvis_z_mae_m']
def metrics(row):return {k:row[k] for k in keys}
data={'schema':'ef-humanoid-integration-study-v1','status':'draft' if a.draft else 'complete','protocol':load('protocol.json'),'models':load('model-analysis.json'),'motions':load('motion-analysis.json'),'gmr':[load(x+'/result.json') for x in ['wheel-gmr-g1','gmr-h1-2-final']],'gmr_replay_validation':load('replay-validation.json'),'gmr_model_coverage':load('gmr-model-coverage.json'),'vendor_assets':load('vendor-assets.json'),'storage_models':load('storage-models.json'),'storage_offline':load('storage-offline.json'),'storage_optimization':load('storage-optimization.json'),'perturbation_parity':load('perturb-parity.json'),'interruption_validation':load('interrupt-validation.json')}
matrix=load('sonic-matrix.json');assert len(matrix['runs'])==72
data['engineering_validation']=load('engineering-validation.json')
data['packaging_validation']=load('packaging-validation.json')
data['gmr_replication']=load('gmr-replication.json')
data['gmr_reference_derivatives']=load('gmr-reference-derivatives.json')
data['sonic_interruption_validation']=load('sonic-interrupt-validation.json')
data['regression_repeats']=load('regression-repeats.json')
if (study/'script-bundle.json').exists():data['research_script_bundle']=load('script-bundle.json')
basic=[]
for row in matrix['runs']:
 for clip in row['result']['clips']:
  basic.append({**{k:row[k] for k in ['model','motion','init_frame','threads']},'clip':clip['name'],**metrics(clip),'report':str(Path(row['run']).relative_to(root)/'result.json')})
assert len(basic)==96
data['basic_episodes']=basic
data['cpu_benchmark_protocol']=load('cpu-benchmark-protocol.json')
data['cpu_benchmarks']=[{k:v for k,v in json.loads(path.read_text()).items() if k!='timings_ns'} for path in sorted((study/'cpu-benchmark').glob('*.json'))]
assert len(data['cpu_benchmarks'])==36
for field,file,variant in [('control_episodes','control-ablation.json','preset'),('storage_episodes','storage-closed-loop.json','storage')]:
 raw=load(file);data[field+'_protocol']=raw['protocol'];data[field]=[]
 for r in raw['episodes']:
  row={k:r[k] for k in ['model','motion','clip','init_frame',variant]}
  row.update(metrics(r['result']));row['reused_baseline']=r.get('reused_baseline',False)
  row['log']=str(Path(r['result']['log']).relative_to(root))
  data[field].append(row)
assert len(data['control_episodes'])==96 and len(data['storage_episodes'])==64
if a.draft:
 partial=study/'perturbation.partial.json';raw=json.loads(partial.read_text()) if partial.exists() else []
else:
 raw=load('perturbation.json')['episodes'];assert len(raw)==864
protocol=load('perturbation-protocol.json');data['perturbation_protocol']={k:v for k,v in protocol.items() if k!='entries'}
data['perturbed_episodes']=[]
for row in raw:
 case=row['case'];r={k:case[k] for k in ['label','model','motion','clip','init_frame','storage','force_magnitude_N','direction','force_N']}
 r.update(metrics(row['result']));r['telemetry']=row['telemetry'];r['log']=str(Path(row['log']).relative_to(root));data['perturbed_episodes'].append(r)
if a.draft:
 partial=study/'stress.partial.json';stress=json.loads(partial.read_text()) if partial.exists() else []
else:
 stress=load('stress.json')['episodes'];assert len(stress)==192
protocol=load('stress-protocol.json');data['stress_protocol']={k:v for k,v in protocol.items() if k!='entries'}
data['stress_episodes']=[]
for row in stress:
 case=row['case'];r={k:case[k] for k in ['label','model','motion','clip','init_frame','storage','force_magnitude_N','direction','force_N']}
 r.update(metrics(row['result']));r['telemetry']=row['telemetry'];r['log']=str(Path(row['log']).relative_to(root));data['stress_episodes'].append(r)
if a.draft:
 partial=study/'stress-controls.partial.json';strong_controls=json.loads(partial.read_text()) if partial.exists() else []
else:
 strong_controls=load('stress-controls.json')['episodes'];assert len(strong_controls)==96
data['stress_control_protocol']=load('stress-controls-protocol.json')
data['stress_control_episodes']=[]
for row in strong_controls:
 case=row['case'];r={k:case[k] for k in ['label','model','motion','clip','init_frame','storage','force_magnitude_N','direction','force_N']}
 r.update(metrics(row['result']));r['preset']=row['preset'];r['reused_baseline']=row['reused_baseline'];r['telemetry']=row['telemetry'];r['log']=str(Path(row['log']).relative_to(root));data['stress_control_episodes'].append(r)
new_controls=sum(not r['reused_baseline'] for r in strong_controls)
data['counts']={'basic':96,'control_new':64,'storage_new':64,'perturbed_new':len(raw),'exploratory_stress_new':len(stress),'exploratory_stress_control_new':new_controls,'unique_comparison_episodes':224+len(raw)+len(stress)+new_controls,'regression_repeats_excluded':6,'baseline_reuse_note':'32 basic t2 cases reused in the 96-row control comparison; 32 strong-force FP32 cases reused in the 96-row exploratory control comparison; force-zero baselines selected separately from basic/storage cases'}
cpu=next(line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name'))
data['host']={'cpu':cpu,'platform':platform.platform(),'logical_cpus':__import__('os').cpu_count(),'shared_machine':True,'affinity_pinned':False}
artifacts=[]
for path in sorted(study.rglob('*')):
 if not path.is_file() or path.is_symlink():continue
 rel=path.relative_to(study)
 if any(x in rel.parts for x in ['python','__pycache__','inputs','optimized-graphs','wheel']):continue
 if path.suffix not in ['.json','.py','.log','.npz','.onnx']:continue
 if path.name.endswith('.partial.json') or path.name in ['study-draft.json','artifact-manifest.json','final-audit.json','completion.json','delivery-manifest.json'] or 'ort124' in path.name:continue
 artifacts.append({'path':str(path.relative_to(root)),'bytes':path.stat().st_size,'sha256':digest(path)})
data['artifacts']=artifacts
source_files=['_motion_sdk.py','gmr.py','_gmr_worker.py','sonic.py','_sonic_worker.py','_h1_motion.py','robot_replay.py','cli.py','viewers/robot.py']
data['implementation']=[{'path':str((Path('src/embodiedforge')/name)),'sha256':digest(root/'src/embodiedforge'/name)} for name in source_files]
if a.draft:target=study/'study-draft.json'
else:target=root/'docs/humanoid-integration-study-20260928.json'
target.write_text(json.dumps(data,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print(target,len(artifacts),data['counts'])
