import os,json,subprocess,time,pathlib,itertools,datetime
root=pathlib.Path('/home/ubuntu/workspace/chase/EmbodiedForge')
out=root/'runs/humanoid-integration-20260928'
plan=[dict(model=m,motion=c,init_frame=f,threads=t) for m,c,f,t in itertools.product(['transfer-v2','incumbent-14000'],['walk','idle','dance'],[0,50,100,200],[1,2,4])]
protocol={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Full bundled-clip closed-loop evaluation across fixed RSI frames and CPU thread counts; deterministic cases, not independent training seeds.','entries':plan,'expected_runs':72,'expected_episodes':96,'control_settings':'model-specific presets from the public CLI','display':None}
(out/'sonic-matrix-protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
rows=[]
env=os.environ.copy();env.pop('DISPLAY',None);env['PYTHONNOUSERSITE']='1'
for i,item in enumerate(plan):
 name=f"sonic-matrix/{item['model']}-{item['motion']}-f{item['init_frame']}-t{item['threads']}"
 run=out/name
 cmd=['/home/ubuntu/miniconda3/envs/ef/bin/python','-m','embodiedforge','sonic','evaluate','--sonic-root','/home/ubuntu/workspace/3rdparty/sonic-x2','--python',str(root/'.cache/humanoid-motion-venv/bin/python'),'--output',str(run),'--model',item['model'],'--motion',item['motion'],'--init-frame',str(item['init_frame']),'--threads',str(item['threads'])]
 start=time.monotonic()
 r=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True,timeout=180)
 if r.returncode: raise RuntimeError(f'{name}\n{r.stdout}\n{r.stderr}')
 result=json.loads((run/'result.json').read_text())
 rows.append({**item,'run':str(run),'wall_seconds':time.monotonic()-start,'result':result})
 (out/'sonic-matrix.partial.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(f"{i+1}/72 {name}: {result['success_rate']} {[c['joint_mae_rad'] for c in result['clips']]}",flush=True)
(out/'sonic-matrix.json').write_text(json.dumps({'protocol':protocol,'runs':rows},indent=2)+'\n')
print('complete',flush=True)
