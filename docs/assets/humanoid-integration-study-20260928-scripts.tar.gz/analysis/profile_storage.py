from pathlib import Path
import onnx,onnxruntime as ort,numpy as np,json,collections
root=Path('/home/ubuntu/workspace/chase/EmbodiedForge');study=root/'runs/humanoid-integration-20260928';out=study/'optimized-graphs';out.mkdir()
rows=[]
for model in ['transfer-v2','incumbent-14000']:
 with np.load(study/f'captures/{model}-walk/clip_000.npz') as z:x=z['observations'][0:1]
 for storage in ['fp32','fp16','int8']:
  path=study/f'sonic-matrix/{model}-walk-f0-t2/inputs/policy.onnx' if storage=='fp32' else study/f'compressed/{model}-{storage}.onnx'
  dest=out/f'{model}-{storage}.onnx'
  options=ort.SessionOptions();options.intra_op_num_threads=2;options.inter_op_num_threads=1;options.optimized_model_filepath=str(dest)
  session=ort.InferenceSession(str(path),options,providers=['CPUExecutionProvider']);session.run(None,{session.get_inputs()[0].name:x})
  graph=onnx.load(dest)
  retained=[node.name for node in graph.graph.node if any(n.startswith('ef_storage_') for n in list(node.input)+list(node.output))]
  counts=collections.Counter()
  for t in graph.graph.initializer:counts[onnx.TensorProto.DataType.Name(t.data_type)]+=int(np.prod(t.dims))
  rows.append({'model':model,'storage':storage,'onnxruntime':ort.__version__,'optimized_bytes':dest.stat().st_size,'optimized_operators':dict(collections.Counter(n.op_type for n in graph.graph.node)),'initializer_elements_by_dtype':dict(counts),'storage_decode_nodes_retained':retained})
  assert not retained
(study/'storage-optimization.json').write_text(json.dumps(rows,indent=2)+'\n')
print('all storage decode nodes folded in 6 optimized graphs')
