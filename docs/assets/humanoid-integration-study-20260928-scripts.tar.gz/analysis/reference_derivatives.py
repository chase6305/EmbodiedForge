"""Describe the stored IK reference without claiming dynamic feasibility."""
import json
from pathlib import Path

import numpy as np

study = Path(__file__).resolve().parents[1]
rows = []
for run in ["wheel-gmr-g1", "gmr-h1-2-final"]:
    with np.load(study / run / "motion.npz", allow_pickle=False) as z:
        meta = json.loads(str(z["metadata"]))
        dt = np.diff(z["time"].astype(np.float64))
        q = z["joints"].astype(np.float64)
        velocity = np.diff(q, axis=0) / dt[:, None]
        index = np.unravel_index(np.argmax(np.abs(velocity)), velocity.shape)
        root_velocity = np.diff(z["positions"][:, 0].astype(np.float64), axis=0) / dt[:, None]
        rows.append({
            "run": run, "robot": meta["robot"],
            "method": "adjacent-frame finite differences of stored joint angles and root body world position; no smoothing, no cyclic angle unwrap, no velocity feasibility threshold",
            "samples": int(velocity.size),
            "joint_abs_velocity_p95_rad_s": float(np.percentile(np.abs(velocity), 95)),
            "joint_abs_velocity_max_rad_s": float(np.abs(velocity[index])),
            "peak_joint": meta["joint_names"][index[1]],
            "peak_source_frame_pair": [int(index[0]), int(index[0] + 1)],
            "peak_root_linear_speed_m_s": float(np.linalg.norm(root_velocity, axis=1).max()),
            "peak_after_source_frame_10_rad_s": float(np.abs(velocity[10:]).max()),
        })
(study / "gmr-reference-derivatives.json").write_text(json.dumps(rows, indent=2) + "\n")
print(json.dumps(rows, indent=2))
