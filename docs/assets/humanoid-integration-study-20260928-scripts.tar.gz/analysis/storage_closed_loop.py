import json,os,time,hashlib
from pathlib import Path
from embodiedforge._microduck_process import run_process
from embodiedforge._sonic_worker import episode_result
root=Path('/home/ubuntu/workspace/chase/EmbodiedForge');study=root/'runs/humanoid-integration-20260928';out=study/'storage-evaluation';out.mkdir()
cases=[r for r in json.loads((study/'sonic-matrix.json').read_text())['runs'] if r['threads']==2]
protocol={'formats':['fp16','int8'],'models':['transfer-v2','incumbent-14000'],'motions':['walk','idle','dance+mirror'],'init_frames':[0,50,100,200],'threads':2,'new_episodes':64,'baseline_episodes':32,'presets':'same model-specific settings as the public CLI','storage':'matrix weights only, FP32 computation unchanged','scope':'bundled motions; no OOD inference'}
(study/'storage-closed-loop-protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
env=os.environ.copy();env.pop('DISPLAY',None);env['OMP_NUM_THREADS']='1';env['ORT_NUM_THREADS']='2'
rows=[]
for case in cases:
 for index,clip in enumerate(case['result']['clips']):
  for storage in ['fp16','int8']:
   model=study/f"compressed/{case['model']}-{storage}.onnx"
   label=f"{case['model']}-{case['motion']}-{index}-f{case['init_frame']}-{storage}"
   cmd=clip['command'].copy();cmd[cmd.index('--onnx')+1]=str(model)
   log=out/f'{label}.log';start=time.monotonic()
   run_process(cmd,cwd=root,env=env,log_path=log,echo=False,timeout=180)
   result=episode_result(log.read_text());result.update(command=cmd,wall_seconds=time.monotonic()-start,log=str(log),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
   rows.append({'model':case['model'],'motion':case['motion'],'clip':clip['name'],'init_frame':case['init_frame'],'storage':storage,'model_sha256':hashlib.sha256(model.read_bytes()).hexdigest(),'result':result})
   (study/'storage-closed-loop.partial.json').write_text(json.dumps(rows,indent=2)+'\n')
   print(len(rows),64,label,result['status'],result['joint_mae_rad'],flush=True)
(study/'storage-closed-loop.json').write_text(json.dumps({'protocol':protocol,'episodes':rows},indent=2)+'\n')
