"""Archive unchanged research scripts without weights, motions or vendor code."""
import gzip
import io
import json
import tarfile
from hashlib import sha256
from pathlib import Path

folder = Path(__file__).resolve().parent
root = folder.parents[2]
target = root / "docs/assets/humanoid-integration-study-20260928-scripts.tar.gz"
buffer = io.BytesIO()
manifest = []
with tarfile.open(fileobj=buffer, mode="w") as archive:
    for path in sorted([*folder.glob("*.py"), folder / "README.md"]):
        content = path.read_bytes()
        member = tarfile.TarInfo("analysis/" + path.name)
        member.size = len(content)
        member.mode = 0o644
        member.mtime = 0
        archive.addfile(member, io.BytesIO(content))
        manifest.append({"name": member.name, "sha256": sha256(content).hexdigest()})
target.write_bytes(gzip.compress(buffer.getvalue(), mtime=0))
result = {"path": str(target.relative_to(root)), "bytes": target.stat().st_size,
          "sha256": sha256(target.read_bytes()).hexdigest(), "files": manifest}
(folder.parent / "script-bundle.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: value for key, value in result.items() if key != "files"}, indent=2))
