"""Research-only constant weight storage transforms; FP32 computation unchanged."""
from pathlib import Path
import json,hashlib
import numpy as np
import onnx
from onnx import helper,numpy_helper,TensorProto
root=Path('/home/ubuntu/workspace/chase/EmbodiedForge');study=root/'runs/humanoid-integration-20260928';out=study/'compressed';out.mkdir(exist_ok=True)
protocol={'created_before_evaluation':True,'formats':['fp16','int8'],'selector':'all rank-2 FLOAT initializers','fp16':'IEEE float16 rounding; Cast to float32 before consumers','int8':'symmetric [-127,127], independent scale per matrix row, nearest-even rounding, Cast and Mul to float32; no activation quantization','purpose':'Assess artifact storage and closed-loop effects only; no model training or claim of FP16/INT8 computation.'}
(study/'storage-protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
rows=[]
for model in ['transfer-v2','incumbent-14000']:
 src=study/f'sonic-matrix/{model}-walk-f0-t2/inputs/policy.onnx'
 for kind in ['fp16','int8']:
  graph=onnx.load(src);keep=[];nodes=[];converted=[]
  for t in graph.graph.initializer:
   if t.data_type!=TensorProto.FLOAT or len(t.dims)!=2:
    keep.append(t);continue
   a=numpy_helper.to_array(t);prefix=f'ef_storage_{len(converted)}';converted.append({'name':t.name,'shape':list(t.dims)})
   if kind=='fp16':
    q=a.astype(np.float16);assert np.isfinite(q).all()
    keep.append(numpy_helper.from_array(q,prefix+'_half'))
    nodes.append(helper.make_node('Cast',[prefix+'_half'],[t.name],to=TensorProto.FLOAT))
   else:
    maximum=np.max(np.abs(a),axis=1,keepdims=True)
    scale=np.where(maximum>0,maximum/127,np.float32(1)).astype(np.float32)
    q=np.clip(np.rint(a/scale),-127,127).astype(np.int8)
    keep.extend([numpy_helper.from_array(q,prefix+'_int8'),numpy_helper.from_array(scale,prefix+'_scale')])
    nodes.extend([helper.make_node('Cast',[prefix+'_int8'],[prefix+'_float'],to=TensorProto.FLOAT),helper.make_node('Mul',[prefix+'_float',prefix+'_scale'],[t.name])])
  old=list(graph.graph.node);del graph.graph.node[:];graph.graph.node.extend(nodes+old)
  del graph.graph.initializer[:];graph.graph.initializer.extend(keep)
  onnx.checker.check_model(graph)
  target=out/f'{model}-{kind}.onnx';onnx.save(graph,target)
  rows.append({'model':model,'format':kind,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'path':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'converted':converted})
  print(model,kind,target.stat().st_size,flush=True)
(study/'storage-models.json').write_text(json.dumps(rows,indent=2)+'\n')
