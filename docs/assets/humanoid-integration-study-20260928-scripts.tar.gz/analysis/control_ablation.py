"""Paired control-preset ablation, without modifying upstream sources or CLI defaults."""
import json,os,time,hashlib
from pathlib import Path
from embodiedforge._microduck_process import run_process
from embodiedforge._sonic_worker import episode_result
root=Path('/home/ubuntu/workspace/chase/EmbodiedForge');study=root/'runs/humanoid-integration-20260928';out=study/'control-ablation';out.mkdir()
baselines=[r for r in json.loads((study/'sonic-matrix.json').read_text())['runs'] if r['threads']==2]
tuning=study/'sonic-matrix/incumbent-14000-walk-f0-t2/inputs/tuning.yaml'
presets={'bigrun':['--tuning',str(tuning)],'raw_frozen':['--tuning','','--action-clip','20','--freeze-wrist'],'raw_free':['--tuning','','--action-clip','20']}
protocol={'presets':presets,'models':['transfer-v2','incumbent-14000'],'frames':[0,50,100,200],'threads':2,'expected_episodes':96,'reuse_baseline_episodes':32,'new_episodes':64,'intent':'Paired bundled-preset comparison; raw_frozen vs raw_free isolates wrist freezing, bigrun vs raw changes multiple controller settings.'}
(study/'control-ablation-protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
env=os.environ.copy();env.pop('DISPLAY',None);env['OMP_NUM_THREADS']='1';env['ORT_NUM_THREADS']='2'
rows=[]
for case in baselines:
 default='raw_frozen' if case['model']=='transfer-v2' else 'bigrun'
 for index,clip in enumerate(case['result']['clips']):
  for preset,args in presets.items():
   label=f"{case['model']}-{case['motion']}-{index}-f{case['init_frame']}-{preset}"
   if preset==default:
    result=clip;reused=True
   else:
    cmd=clip['command'][:clip['command'].index('--tuning')]+args
    log=out/f'{label}.log';start=time.monotonic()
    run_process(cmd,cwd=root,env=env,log_path=log,echo=False,timeout=180)
    result={**episode_result(log.read_text()),'command':cmd,'wall_seconds':time.monotonic()-start,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};reused=False
   rows.append({'model':case['model'],'motion':case['motion'],'clip':clip['name'],'init_frame':case['init_frame'],'preset':preset,'reused_baseline':reused,'result':result})
   (study/'control-ablation.partial.json').write_text(json.dumps(rows,indent=2)+'\n')
   print(len(rows),96,label,result['status'],result['simulated_seconds'],flush=True)
(study/'control-ablation.json').write_text(json.dumps({'protocol':protocol,'episodes':rows},indent=2)+'\n')
