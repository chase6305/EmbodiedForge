"""Independent-process CPU ORT timing on captured, real control observations."""
import argparse,json,time,os,platform
from pathlib import Path
import numpy as np
import onnxruntime as ort
p=argparse.ArgumentParser();p.add_argument('--model',required=True);p.add_argument('--captures',nargs='+',required=True);p.add_argument('--threads',type=int,required=True);p.add_argument('--output',required=True);p.add_argument('--seed',type=int,required=True);a=p.parse_args()
obs=[];expected=[]
for src in a.captures:
 with np.load(src,allow_pickle=False) as z:obs.append(z['observations']);expected.append(z['actions'])
obs=np.concatenate(obs);expected=np.concatenate(expected)
rng=np.random.default_rng(a.seed);rows=rng.choice(len(obs),512,replace=False);obs=obs[rows];expected=expected[rows]
opts=ort.SessionOptions();opts.intra_op_num_threads=a.threads;opts.inter_op_num_threads=1;opts.add_session_config_entry('session.intra_op.allow_spinning','0')
load_start=time.perf_counter();session=ort.InferenceSession(a.model,opts,providers=['CPUExecutionProvider']);load_seconds=time.perf_counter()-load_start
name=session.get_inputs()[0].name
for row in obs[:64]: session.run(None,{name:row[None]})
ns=[];outputs=[]
for row in obs:
 start=time.perf_counter_ns();out=session.run(None,{name:row[None]})[0];ns.append(time.perf_counter_ns()-start);outputs.append(out[0])
diff=np.stack(outputs)-expected
report={'model':a.model,'threads':a.threads,'samples':len(obs),'seed':a.seed,'load_seconds':load_seconds,'timing_scope':'onnxruntime.session.run on real captured batch-1 observations; 64 warmup calls excluded; no simulation or transfers','mean_us':float(np.mean(ns)/1e3),'p50_us':float(np.percentile(ns,50)/1e3),'p95_us':float(np.percentile(ns,95)/1e3),'max_absolute_error_vs_capture':float(np.abs(diff).max()),'rmse_vs_capture':float(np.sqrt(np.mean(diff.astype(float)**2))),'versions':{'numpy':np.__version__,'onnxruntime':ort.__version__,'python':platform.python_version()},'timings_ns':ns}
Path(a.output).write_text(json.dumps(report,indent=2)+'\n')
print({k:v for k,v in report.items() if k!='timings_ns'},flush=True)
