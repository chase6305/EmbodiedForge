"""Audit coverage, raw terminal reports, physical impulses and artifact hashes."""

import hashlib
import itertools
import json
import math
from collections import Counter
from pathlib import Path

from embodiedforge._sonic_worker import episode_result

root = Path(__file__).resolve().parents[3]
study = root / "runs/humanoid-integration-20260928"
data = json.loads((root / "docs/humanoid-integration-study-20260928.json").read_text())


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


models = ["incumbent-14000", "transfer-v2"]
clips = [clip["name"] for bank in data["motions"] for clip in bank["clips"]]
assert len(clips) == len(set(clips)) == 4
assert data["status"] == "complete"
basic = data["basic_episodes"]
assert Counter((r["model"], r["clip"], r["init_frame"], r["threads"]) for r in basic) == Counter(
    itertools.product(models, clips, [0, 50, 100, 200], [1, 2, 4])
)
controls = data["control_episodes"]
assert Counter((r["model"], r["clip"], r["init_frame"], r["preset"]) for r in controls) == Counter(
    itertools.product(models, clips, [0, 50, 100, 200], ["bigrun", "raw_frozen", "raw_free"])
)
assert sum(r["reused_baseline"] for r in controls) == 32
storage = data["storage_episodes"]
assert Counter((r["model"], r["clip"], r["init_frame"], r["storage"]) for r in storage) == Counter(
    itertools.product(models, clips, [0, 50, 100, 200], ["fp16", "int8"])
)
pushes = data["perturbed_episodes"]
assert Counter(
    (r["model"], r["clip"], r["init_frame"], r["storage"], r["force_magnitude_N"], r["direction"])
    for r in pushes
) == Counter(itertools.product(models, clips, [0, 100, 200], ["fp32", "fp16", "int8"], [20, 60, 100], ["x+", "x-", "y+", "y-"]))

stress = data["stress_episodes"]
assert Counter(
    (r["model"], r["clip"], r["init_frame"], r["storage"], r["force_magnitude_N"], r["direction"])
    for r in stress
) == Counter(itertools.product(models, clips, [0], ["fp32", "fp16", "int8"], [200, 400], ["x+", "x-", "y+", "y-"]))
metric_names = ["status", "reason", "simulated_seconds", "joint_mae_rad", "max_joint_error_rad", "pelvis_z_mae_m"]
strong_controls = data["stress_control_episodes"]
assert Counter((r["model"], r["clip"], r["preset"], r["direction"]) for r in strong_controls) == Counter(
    itertools.product(models, clips, ["bigrun", "raw_frozen", "raw_free"], ["x+", "x-", "y+", "y-"])
)
assert sum(r["reused_baseline"] for r in strong_controls) == 32
assert all(r["storage"] == "fp32" and r["force_magnitude_N"] == 400 and r["init_frame"] == 0 for r in strong_controls)
for row in basic + controls + storage + pushes + stress + strong_controls:
    if "log" in row:
        parsed = episode_result((root / row["log"]).read_text())
    else:
        report = json.loads((root / row["report"]).read_text())
        entry = next(r for r in report["clips"] if r["name"] == row["clip"])
        parsed = episode_result(Path(entry["log"]).read_text())
    assert parsed == {key: row[key] for key in metric_names}
    assert all(math.isfinite(row[key]) and row[key] >= 0 for key in metric_names[2:])

directions = {"x+": [1, 0, 0], "x-": [-1, 0, 0], "y+": [0, 1, 0], "y-": [0, -1, 0]}
for row in pushes + stress + strong_controls:
    telemetry = row["telemetry"]
    force = [row["force_magnitude_N"] * component for component in directions[row["direction"]]]
    assert force == row["force_N"] == telemetry["force_N"]
    assert telemetry["force_frame"] == "world" and telemetry["target_body"] == "pelvis"
    assert telemetry["initial_simulator_time"] == 0
    dt = telemetry["physics_dt"]
    start = round(telemetry["start_seconds"] / dt)
    duration = round(telemetry["duration_seconds"] / dt)
    expected_steps = max(0, min(duration, telemetry["steps"] - start))
    assert telemetry["force_steps"] == expected_steps
    assert all(
        math.isclose(actual, component * dt * expected_steps, rel_tol=1e-12, abs_tol=1e-12)
        for actual, component in zip(telemetry["actual_impulse_N_s"], force, strict=True)
    )

# Check that stored labels describe the models, clips and controls actually run.
baseline_commands = {}
for run in json.loads((study / "sonic-matrix.json").read_text())["runs"]:
    if run["threads"] != 2:
        continue
    for clip in run["result"]["clips"]:
        key = run["model"], clip["name"], run["init_frame"]
        baseline_commands[key] = clip["command"]
        motion_path = Path(clip["command"][clip["command"].index("--motion") + 1])
        assert digest(motion_path) == clip["motion_sha256"]
storage_hashes = {(row["model"], row["format"]): row["sha256"] for row in data["storage_models"]}
for model, filename in [("incumbent-14000", "x2_sonic_14000_g1.onnx"), ("transfer-v2", "x2_sonic_frozen_g1core_lora_v2.onnx")]:
    storage_hashes[model, "fp32"] = next(row["sha256"] for row in data["models"] if row["name"] == filename)
hash_cache = {}
command_count = 0
for name in ["storage-closed-loop.json", "perturbation.json", "stress.json"]:
    for raw in json.loads((study / name).read_text())["episodes"]:
        row = raw.get("case", raw)
        command = (raw["case"]["command"] if "case" in raw else raw["result"]["command"]).copy()
        baseline = baseline_commands[row["model"], row["clip"], row["init_frame"]]
        model_index = command.index("--onnx") + 1
        model_path = command[model_index]
        if model_path not in hash_cache:
            hash_cache[model_path] = digest(Path(model_path))
        assert hash_cache[model_path] == storage_hashes[row["model"], row["storage"]]
        command[model_index] = baseline[model_index]
        assert command == baseline, row
        command_count += 1

for raw in json.loads((study / "stress-controls.json").read_text())["episodes"]:
    row = raw["case"]
    command = row["command"].copy()
    baseline = baseline_commands[row["model"], row["clip"], row["init_frame"]]
    expected = baseline[:baseline.index("--tuning")] + data["stress_control_protocol"]["presets"][raw["preset"]]
    if raw["reused_baseline"]:
        assert command == baseline
    else:
        assert command == expected
    assert digest(Path(command[command.index("--onnx") + 1])) == storage_hashes[row["model"], "fp32"]
    command_count += 1

for row in data["artifacts"]:
    path = root / row["path"]
    assert path.stat().st_size == row["bytes"] and digest(path) == row["sha256"], path
for row in data["implementation"]:
    assert digest(root / row["path"]) == row["sha256"], row["path"]
engineering = json.loads((study / "engineering-validation.json").read_text())
for row in engineering["files"]:
    assert digest(root / row["path"]) == row["sha256"], row["path"]
snapshots = json.loads((study / "model-snapshot-deduplication.json").read_text())
for row in snapshots["files"]:
    assert digest(Path(row["path"])) == digest(Path(row["canonical"])) == row["sha256"]

report = {
    "status": "passed",
    "coverage": data["counts"],
    "raw_terminal_reports_matched": len(basic + controls + storage + pushes + stress + strong_controls),
    "physical_impulses_checked": len(pushes + stress + strong_controls),
    "variant_commands_and_model_hashes_checked": command_count,
    "artifact_hashes_checked": len(data["artifacts"]),
    "engineering_test_source_hashes_checked": len(engineering["files"]),
    "deduplicated_snapshot_hashes_checked": len(snapshots["files"]),
    "perturbation_statuses": dict(Counter(row["status"] for row in pushes)),
    "exploratory_stress_statuses": dict(Counter(row["status"] for row in stress)),
    "control_statuses": dict(Counter(row["status"] for row in controls)),
    "exploratory_stress_control_statuses": dict(Counter(row["status"] for row in strong_controls)),
}
destination = study / "final-audit.json"
destination.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
