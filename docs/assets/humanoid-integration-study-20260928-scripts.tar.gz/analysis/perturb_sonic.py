"""Research-only world-frame pelvis push around the unchanged pinned control loop."""
import json,sys
from pathlib import Path
import numpy as np
case=json.loads(Path(sys.argv[1]).read_text())
command=case['command'];sys.path.insert(0,str(Path(command[1]).parent))
import eval_x2_mujoco_onnx as player
import mujoco
step=mujoco.mj_step
count=0;applied=0;physics_dt=None;mass=None;first_time=None
force=np.asarray(case['force_N'],dtype=float)
def forced_step(model,data,*args,**kwargs):
 global count,applied,physics_dt,mass,first_time
 if physics_dt is None:
  physics_dt=float(model.opt.timestep);mass=float(np.sum(model.body_mass));first_time=float(data.time)
  assert abs(first_time)<1e-12
 start=round(case['start_seconds']/physics_dt);duration=round(case['duration_seconds']/physics_dt)
 enabled=start<=count<start+duration
 data.xfrc_applied[model.body('pelvis').id,:3]=force if enabled else 0.
 if enabled:applied+=1
 step(model,data,*args,**kwargs);count+=1
mujoco.mj_step=forced_step
observations=[];actions=[]
if case.get('capture'):
 original=player.OnnxActor
 class Capture(original):
  def __call__(self,prop,tok):
   action=super().__call__(prop,tok)
   observations.append(np.concatenate([tok.astype(np.float32),prop.astype(np.float32)]).copy());actions.append(action.copy())
   return action
 player.OnnxActor=Capture
sys.argv=command[1:]
player.main()
report={'force_N':force.tolist(),'start_seconds':case['start_seconds'],'duration_seconds':case['duration_seconds'],'physics_dt':physics_dt,'steps':count,'force_steps':applied,'actual_impulse_N_s':(force*applied*physics_dt).tolist(),'total_mass_kg':mass,'initial_simulator_time':first_time,'target_body':'pelvis','force_frame':'world'}
Path(case['telemetry']).write_text(json.dumps(report,indent=2)+'\n')
if case.get('capture'):np.savez_compressed(case['capture'],observations=np.stack(observations),actions=np.stack(actions))
