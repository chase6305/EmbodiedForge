"""Exploratory control comparison prompted by the 400 N model/preset confound."""
import hashlib
import json
import os
import random
import time
from pathlib import Path

from embodiedforge._microduck_process import run_process
from embodiedforge._sonic_worker import episode_result

study = Path(__file__).resolve().parents[1]
root = study.parents[1]
output = study / "stress-controls"
output.mkdir()
base = [r for r in json.loads((study / "stress.json").read_text())["episodes"]
        if r["case"]["storage"] == "fp32" and r["case"]["force_magnitude_N"] == 400]
assert len(base) == 32
tuning = study / "sonic-matrix/incumbent-14000-walk-f0-t2/inputs/tuning.yaml"
presets = {"bigrun": ["--tuning", str(tuning)],
           "raw_frozen": ["--tuning", "", "--action-clip", "20", "--freeze-wrist"],
           "raw_free": ["--tuning", "", "--action-clip", "20"]}
protocol = {"description": "Exploratory extension chosen after the 400 N study showed different outcomes for models using different presets; FP32 only, paired conditions, no new training seeds.",
            "presets": presets, "force_N": 400, "directions": ["x+", "x-", "y+", "y-"],
            "init_frame": 0, "new_episodes": 64, "reused_baseline_episodes": 32,
            "total_comparison_rows": 96, "execution_order_seed": 20260930}
(study / "stress-controls-protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
plan = [(row, preset) for row in base for preset in presets]
random.Random(20260930).shuffle(plan)
env = os.environ.copy()
env.pop("DISPLAY", None)
env.update(OMP_NUM_THREADS="1", ORT_NUM_THREADS="2")
rows = []
started = time.monotonic()
for index, (source, preset) in enumerate(plan):
    case = source["case"].copy()
    default = "bigrun" if case["model"] == "incumbent-14000" else "raw_frozen"
    reused = preset == default
    if reused:
        result, telemetry, log = source["result"], source["telemetry"], Path(source["log"])
    else:
        case["command"] = case["command"][:case["command"].index("--tuning")] + presets[preset]
        case["label"] += "-" + preset
        case["telemetry"] = str(output / f"{case['label']}.telemetry.json")
        request = output / f"{case['label']}.request.json"
        request.write_text(json.dumps(case, indent=2) + "\n")
        log = output / f"{case['label']}.log"
        run_process([case["command"][0], str(study / "analysis/perturb_sonic.py"), str(request)],
                    cwd=root, env=env, log_path=log, echo=False, timeout=180)
        result = episode_result(log.read_text())
        telemetry = json.loads(Path(case["telemetry"]).read_text())
    rows.append({"case": case, "preset": preset, "reused_baseline": reused,
                 "result": result, "telemetry": telemetry, "log": str(log),
                 "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest()})
    (study / "stress-controls.partial.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(index + 1, 96, case["model"], case["motion"], case["direction"], preset,
          result["status"], f"elapsed={time.monotonic() - started:.1f}s", flush=True)
(study / "stress-controls.json").write_text(json.dumps({"protocol": protocol, "episodes": rows}, indent=2) + "\n")
