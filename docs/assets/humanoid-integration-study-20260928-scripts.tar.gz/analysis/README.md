# Research script snapshot — 2026-09-28

These are the original local research scripts behind
`docs/humanoid-integration-study-20260928.md`. They are provided for inspection and
adaptation, not as another supported training or deployment API. The public
`gmr retarget` and `sonic evaluate` commands are documented separately.

The scripts retain the machine's absolute paths and interpreter locations. Before
reusing them elsewhere, adjust the repository root, external checkout paths,
interpreter paths and output directory. Start from a new output directory:
several scripts deliberately reject an existing destination. Do not run these
scripts over the archived measurements.

External prerequisites and commits are recorded in the article and guide. No
models, motion data, upstream code or robot meshes are included in this archive.
CPU SDK versions for the primary comparisons are MuJoCo 3.3.7, ORT 1.23.2,
NumPy 1.26.4 and SciPy 1.15.3. Storage conversion and the final offline diagnostics
use ONNX 1.20.1; the initial ORT 1.24.4 offline run is excluded from the primary
dataset. GMR additionally uses Mink 0.0.13, qpsolvers 4.8.1 and DAQP 0.10.1.

The experiment dependencies are:

1. `basic_matrix.py`: full public SONIC evaluations, producing the original-model
   snapshots, selected single-clip inputs, commands and baseline reports.
2. `capture_all.py` calls `capture_sonic.py` to collect each actor's actual
   observations and actions. `benchmark_all.py` then calls `benchmark_sonic.py`
   for independent CPU latency processes.
3. `control_ablation.py`: model/control-preset comparisons with explicit reuse
   of matching baseline results.
4. `storage_sonic.py`: the two constant-weight storage transforms.
   `storage_closed_loop.py`, `storage_offline.py` and `profile_storage.py` use
   those graphs to evaluate closed loops, FSQ/action differences and ORT folding.
5. `perturb_all.py` calls `perturb_sonic.py` for the originally specified force
   matrix. `stress_all.py` is a separately identified exploratory second stage.
   The latter protocol was chosen after the first 665 mild-force cases had
   completed without a fall.
6. `repeat_regression.py` reruns the observed INT8 failure condition twice for
   each storage format, checking the full observation/action sequences.
   `stress_controls.py` separates the observed model/preset difference with a
   further exploratory 400 N control comparison. Both were selected after
   observing the preceding results and are identified as such in the article.
7. `reference_derivatives.py` describes adjacent-frame velocities in the GMR
   outputs without setting a physical feasibility threshold.
8. `collect_study.py` and `publish_study.py` assemble the local records and article.
   They also expect separately recorded GMR, packaging, source-hash and replay
   validations, so they are archival publication scripts, not stand-alone
   reproductions of the whole engineering task. `audit_study.py` checks the
   resulting coverage, raw logs, impulses and hashes against the local artifacts.

The plotting script is published separately and only needs the public JSON,
NumPy and Matplotlib. Baselines are reused rather than counted as additional
episodes. All simulation evaluations cover the complete first episode up to
motion completion or a physical failure; no short startup/training mode is used.
