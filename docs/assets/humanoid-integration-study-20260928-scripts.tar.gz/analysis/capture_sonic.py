"""Research-only observation capture around the unchanged pinned SONIC player."""
import argparse,json,sys,hashlib
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser();p.add_argument('result');p.add_argument('output');args=p.parse_args()
result=json.loads(Path(args.result).read_text());out=Path(args.output);out.mkdir(parents=True)
for index,clip in enumerate(result['clips']):
 cmd=clip['command'];sys.path.insert(0,str(Path(cmd[1]).parent))
 import eval_x2_mujoco_onnx as player
 original=player.OnnxActor
 obs=[];actions=[]
 class CapturingActor(original):
  def __call__(self,proprioception,tokenizer_obs):
   action=super().__call__(proprioception,tokenizer_obs)
   obs.append(np.concatenate([tokenizer_obs.astype(np.float32),proprioception.astype(np.float32)]).copy())
   actions.append(action.copy())
   return action
 player.OnnxActor=CapturingActor
 sys.argv=cmd[1:]
 try: player.main()
 finally: player.OnnxActor=original
 obs=np.stack(obs);actions=np.stack(actions)
 assert obs.shape[1]==1670 and actions.shape==(len(obs),31)
 assert np.isfinite(obs).all() and np.isfinite(actions).all()
 dest=out/f'clip_{index:03d}.npz'
 np.savez_compressed(dest,observations=obs,actions=actions)
 report={'clip':clip['name'],'frames':len(obs),'data':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'model':result['model'],'policy':result['policy'],'command':cmd,'instrumentation':'captures input/output arrays around upstream OnnxActor.__call__; original control loop unchanged'}
 (out/f'clip_{index:03d}.json').write_text(json.dumps(report,indent=2)+'\n')
