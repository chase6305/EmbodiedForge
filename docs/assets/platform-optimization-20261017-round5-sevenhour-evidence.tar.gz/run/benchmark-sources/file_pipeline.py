"""Cached file open/decode/hash/validation and a complete NumPy adapter loop."""
import hashlib
import json
import sys
import time

import numpy as np

from fixture import ROOT, fingerprint, make_input, source_hashes, versions
from benchmark_support import paired


def no_sustained_probes():
    for directory in ROOT.__class__("/proc").iterdir():
        if not directory.name.isdecimal():
            continue
        try:
            arguments=(directory/"cmdline").read_bytes().split(b"\0")
        except (FileNotFoundError,PermissionError,ProcessLookupError):
            continue
        for argument in arguments:
            if b"platform-optimization-20261017-round5-sevenhour/scripts/" in argument and argument.endswith(b"_endurance.py"):
                raise AssertionError((directory.name,arguments))


def dataset(name, lengths, *, bodies, joints, objects):
    directory=ROOT/"datasets"
    directory.mkdir(exist_ok=True)
    path=directory/f"{name}.npz"
    arrays,metadata=make_input(lengths,bodies=bodies,joints=joints,objects=objects)
    content_sha256=fingerprint(arrays,metadata)
    if not path.exists():
        with path.open("xb") as stream:
            np.savez_compressed(stream,metadata=np.array(json.dumps(metadata,allow_nan=False)),**arrays)
    loaded=original.MotionClips.load(path)
    assert fingerprint(loaded.arrays,loaded.metadata)==content_sha256
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    assert loaded.sha256==digest
    row=dict(path=str(path),sha256=digest,content_sha256=content_sha256,bytes=path.stat().st_size,frames=sum(lengths),clips=len(lengths),bodies=bodies,joints=joints,objects=objects,dtype="float32",layout="contiguous",generator_script="scripts/fixture.py",seed=170513)
    del arrays,metadata,loaded
    return path,row


def adapter(cls,path,*,audit=False):
    library=cls.load(path)
    requests=[f"object-{i%64}" for i in range(128)]
    rng=np.random.default_rng(1741)
    digest=hashlib.sha256() if audit else None
    for _ in range(16):
        ids,steps=library.sample(requests,rng)
        frames=library.frames(ids,steps,offsets=[0,1,3,7])
        if audit:
            digest.update(ids.tobytes());digest.update(steps.tobytes())
            for name,value in sorted(frames.items()):
                assert value.flags.owndata
                digest.update(name.encode());digest.update(value.tobytes())
    if audit:
        digest.update(json.dumps(rng.bit_generator.state,sort_keys=True).encode())
        digest.update(library.sha256.encode())
        return digest.hexdigest()


no_sustained_probes()
started=time.time()
original,current=versions()
report=dict(status="running",started_epoch=started,python=sys.version,numpy=np.__version__,source_sha256=source_hashes(),scope="Actual CPU file open, cached compressed NPZ decode, SHA256 and full constructor validation. Adapter additionally performs 16 batches of 128 object-conditioned samples and 4 future-frame offsets across all 11 owned gathered fields. Alternating timing pairs exclude imports, generation, audits and tracing. Traced peak includes newly decoded input arrays, not RSS. No task-owned sustained probes active; shared unpinned host. This is the NumPy reference API, not upstream Weave/Torch training.",load=[],adapter=[],datasets=[])
for count in (128,8192,65536,131072):
    path,description=dataset(f"frames-{count}",[count],bodies=16,joints=29,objects=1)
    expected=original.MotionClips.load(path)
    actual=current.MotionClips.load(path)
    assert expected.sha256==actual.sha256
    assert fingerprint(expected.arrays,expected.metadata)==fingerprint(actual.arrays,actual.metadata)
    del expected,actual
    result=paired({"initial":lambda:original.MotionClips.load(path),"current":lambda:current.MotionClips.load(path)},calls=1,pairs=9)
    report["load"].append({**description,"pairs":9,**result})
    report["datasets"].append(description)
    print(json.dumps({"kind":"load","frames":count,"time_percent":result["elapsed_reduction_percent"],"peak_percent":result["peak_reduction_percent"]}),flush=True)
path,description=dataset("adapter-65536-clips",[1+i%7 for i in range(65536)],bodies=4,joints=17,objects=64)
assert adapter(original.MotionClips,path,audit=True)==adapter(current.MotionClips,path,audit=True)
result=paired({"initial":lambda:adapter(original.MotionClips,path),"current":lambda:adapter(current.MotionClips,path)},calls=1,pairs=9)
report["adapter"].append({**description,"pairs":9,"batches":16,"batch_size":128,"future_offsets":[0,1,3,7],**result})
report["datasets"].append(description)
print(json.dumps({"kind":"adapter","time_percent":result["elapsed_reduction_percent"],"peak_percent":result["peak_reduction_percent"]}),flush=True)
assert report["source_sha256"]==source_hashes()
no_sustained_probes()
report.update(status="passed",finished_epoch=time.time(),elapsed_seconds=time.time()-started)
output=ROOT/f"file-pipeline-{sys.version_info.major}.{sys.version_info.minor}-numpy{np.__version__}.json"
with output.open("x") as stream:
    json.dump(report,stream,indent=2,allow_nan=False);stream.write("\n")
