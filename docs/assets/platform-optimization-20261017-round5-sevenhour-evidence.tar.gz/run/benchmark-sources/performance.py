"""Alternating original/current full-constructor and sampling measurements."""
import gc
import json
import platform
import statistics
import sys
import time
import tracemalloc

import numpy as np

from fixture import ROOT, assert_equal, fingerprint, make_input, source_hashes, versions


def paired(functions, *, calls, pairs=15):
    for function in functions.values():
        function()
    samples = {name: [] for name in functions}
    for index in range(pairs):
        names = list(functions)
        if index % 2:
            names.reverse()
        for name in names:
            start = time.perf_counter()
            for _ in range(calls):
                functions[name]()
            samples[name].append((time.perf_counter() - start) / calls)
    result = {}
    for name, function in functions.items():
        gc.collect()
        tracemalloc.start()
        function()
        peak = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
        result[name] = {"seconds": samples[name], "median_seconds": statistics.median(samples[name]), "q25_seconds": float(np.quantile(samples[name],0.25)), "q75_seconds": float(np.quantile(samples[name],0.75)), "peak_traced_bytes": peak}
    result["elapsed_reduction_percent"] = 100*(1-result["current"]["median_seconds"]/result["initial"]["median_seconds"])
    result["peak_reduction_percent"] = 100*(1-result["current"]["peak_traced_bytes"]/result["initial"]["peak_traced_bytes"])
    return result


started=time.time()
original,current=versions()
report={"status":"running","started_epoch":started,"python":sys.version,"numpy":np.__version__,"platform":platform.platform(),"source_sha256":source_hashes(),"scope":"CPU synthetic complete MotionClips inputs, owned readonly numeric arrays. Timing excludes input construction, tracing, checksumming and imports. Sampling includes per-call candidate grouping and frame sampling, excludes creation of the NumPy generator. Traced peak is temporary Python/NumPy allocation, not input arrays or RSS. Shared unpinned host; no simulator/training claim.","validation":[],"sampling":[]}
cases=[dict(frames=n,dtype="float32",layout="contiguous") for n in (128,4096,8192,65536,131072)]
cases += [dict(frames=8192,dtype="float32",layout=layout) for layout in ("fortran","reversed","strided","unaligned")]
cases += [dict(frames=8192,dtype=dtype,layout="contiguous") for dtype in ("float64",">f4")]
for config in cases:
    arrays,metadata=make_input([config["frames"]],bodies=16,joints=29,dtype=config["dtype"],layout=config["layout"])
    before=fingerprint(arrays,metadata)
    initial=original.MotionClips(arrays,metadata)
    final=current.MotionClips(arrays,metadata)
    assert_equal(initial,final,arrays,metadata)
    functions={"initial":lambda: original.MotionClips(arrays,metadata),"current":lambda: current.MotionClips(arrays,metadata)}
    result=paired(functions,calls=50 if config["frames"]==128 else 3)
    assert before==fingerprint(arrays,metadata)
    row={**config,"bodies":16,"joints":29,"input_sha256":before,"pairs":15,"calls_per_sample":50 if config["frames"]==128 else 3,**result}
    report["validation"].append(row)
    print(json.dumps({"kind":"validation",**config,"time_percent":result["elapsed_reduction_percent"],"peak_percent":result["peak_reduction_percent"]}),flush=True)
    del arrays,metadata,initial,final,functions
for clips in (64,4096,65536):
    for objects in (1,4,16,64):
        lengths=[1+i%7 for i in range(clips)]
        arrays,metadata=make_input(lengths,bodies=1,joints=1,objects=objects)
        initial=original.MotionClips(arrays,metadata)
        final=current.MotionClips(arrays,metadata)
        requested=[f"object-{i % objects}" for i in range(128)]
        before=fingerprint(arrays,metadata)
        old_rng=np.random.default_rng(473)
        new_rng=np.random.default_rng(473)
        expected=initial.sample(iter(requested),old_rng)
        actual=final.sample(iter(requested),new_rng)
        assert all(np.array_equal(a,b) for a,b in zip(actual,expected,strict=True))
        assert old_rng.bit_generator.state==new_rng.bit_generator.state
        functions={"initial":lambda: initial.sample(requested,old_rng),"current":lambda: final.sample(requested,new_rng)}
        calls=10 if clips<65536 else 1
        result=paired(functions,calls=calls)
        assert old_rng.bit_generator.state==new_rng.bit_generator.state
        assert before==fingerprint(arrays,metadata)
        row={"clips":clips,"objects":objects,"requested_objects":objects,"batch_size":128,"frames":sum(lengths),"pairs":15,"calls_per_sample":calls,"input_sha256":before,**result}
        report["sampling"].append(row)
        print(json.dumps({"kind":"sampling","clips":clips,"objects":objects,"time_percent":result["elapsed_reduction_percent"],"peak_percent":result["peak_reduction_percent"]}),flush=True)
        del arrays,metadata,initial,final,functions
assert report["source_sha256"]==source_hashes()
report.update(status="passed",finished_epoch=time.time(),elapsed_seconds=time.time()-started)
output=ROOT/f"motion-inputs-performance-{sys.version_info.major}.{sys.version_info.minor}-numpy{np.__version__}.json"
with output.open("x") as stream:
    json.dump(report,stream,indent=2,allow_nan=False)
    stream.write("\n")
