"""Alternating original/current full-constructor and sampling measurements."""
import gc
import statistics
import time
import tracemalloc

import numpy as np



def paired(functions, *, calls, pairs=15):
    for function in functions.values():
        function()
    samples = {name: [] for name in functions}
    for index in range(pairs):
        names = list(functions)
        if index % 2:
            names.reverse()
        for name in names:
            start = time.perf_counter()
            for _ in range(calls):
                functions[name]()
            samples[name].append((time.perf_counter() - start) / calls)
    result = {}
    for name, function in functions.items():
        gc.collect()
        tracemalloc.start()
        function()
        peak = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
        result[name] = {"seconds": samples[name], "median_seconds": statistics.median(samples[name]), "q25_seconds": float(np.quantile(samples[name],0.25)), "q75_seconds": float(np.quantile(samples[name],0.75)), "peak_traced_bytes": peak}
    result["elapsed_reduction_percent"] = 100*(1-result["current"]["median_seconds"]/result["initial"]["median_seconds"])
    result["peak_reduction_percent"] = 100*(1-result["current"]["peak_traced_bytes"]/result["initial"]["peak_traced_bytes"])
    return result


