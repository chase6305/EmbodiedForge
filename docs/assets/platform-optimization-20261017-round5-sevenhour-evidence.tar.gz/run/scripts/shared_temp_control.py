"""Prove that the unchanged global-temp assertion can flag an unrelated owner."""

import importlib.util
import json
import tempfile
from pathlib import Path

import pytest

from embodiedforge import go1_live

ROOT = Path(__file__).resolve().parents[1]
phase = ROOT / "phase8-shared-test-temp"
spec = importlib.util.spec_from_file_location(
    "initial_live_cleanup_test", ROOT / "initial/tests/test_live_cleanup.py"
)
tests = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tests)
original_class = go1_live.LivePolicyProcess
foreign = []
owners = []
try:
    with tempfile.TemporaryDirectory(prefix="ef-r5-temp-control-") as directory:
        with pytest.MonkeyPatch.context() as patch:

            def create_foreign_then_construct(*args, **kwargs):
                # This occurs after the test's 'before' glob, while preserving
                # a separately owned live directory outside the constructor.
                foreign.append(
                    tempfile.TemporaryDirectory(prefix="embodiedforge-go1-live-")
                )
                owner = object.__new__(original_class)
                owners.append(owner)
                original_class.__init__(owner, *args, **kwargs)
                return owner

            patch.setattr(go1_live, "LivePolicyProcess", create_foreign_then_construct)
            failed = False
            try:
                tests.test_startup_preserves_launch_error_when_child_socket_close_also_fails(
                    Path(directory), patch, OSError
                )
            except AssertionError:
                failed = True
            assert failed and len(owners) == len(foreign) == 1
            assert not Path(owners[0].directory.name).exists(), (
                "The actual owned directory must be cleaned"
            )
            assert Path(foreign[0].name).exists(), (
                "The independent directory must still exist"
            )
            report = {
                "status": "passed",
                "unchanged_initial_test_assertion_failed_for_unrelated_directory": True,
                "actual_constructor_owned_directory_cleaned": True,
                "independently_owned_directory_alive_until_control_cleanup": True,
                "scope": "Deterministically demonstrates the global /tmp glob assertion mechanism. Attribution of the earlier suite's specific directory to the overlapping interpreter remains an inference; the directory had disappeared before investigation. The actual Go1 runtime and test source were unchanged.",
            }
            (phase / "controlled-mechanism.json").write_text(
                json.dumps(report, indent=2) + "\n"
            )
            print(json.dumps(report, indent=2))
finally:
    for directory in foreign:
        directory.cleanup()
