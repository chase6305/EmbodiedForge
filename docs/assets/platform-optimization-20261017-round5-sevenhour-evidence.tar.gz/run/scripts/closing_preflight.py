"""Run after all owned probe sessions are complete and reaped."""

import json
import os
import time
from pathlib import Path

from report import (
    ARCHIVE_PATH,
    PROBES,
    REPORT_PATH,
    ROOT,
    START,
    WORKSPACE,
    check_preservation,
    sha256,
)

assert not REPORT_PATH.exists() and not ARCHIVE_PATH.exists()
preservation = check_preservation()
validation = json.loads((ROOT / "validation-results.json").read_text())
for relative, expected in validation["sha256"].items():
    assert sha256(WORKSPACE / relative) == expected, relative
completions = json.loads((ROOT / "session-completions.json").read_text())
for name in PROBES:
    result = completions[name]
    assert result["exit_code"] == 0 and result["reaped"] is True
    assert not (Path("/proc") / str(result["pid"])).exists()
    report = json.loads((ROOT / f"{name}.json").read_text())
    assert report["status"] == "passed"
    assert report["configuration_count"] == report["base_configurations_expected"]
supplemental = json.loads((ROOT / "supplemental-sessions.json").read_text())
for name, result in supplemental["sessions"].items():
    assert result["exit_code"] == 0 and result["reaped"] is True
    assert not (Path("/proc") / str(result["pid"])).exists()
    assert json.loads((ROOT / f"{name}.json").read_text())["status"] == "passed"
assert not json.loads((ROOT / "operator-state.json").read_text())["active_sessions"]
diagnostic_sessions = json.loads((ROOT / "diagnostic-sessions.json").read_text())
for name, result in diagnostic_sessions["sessions"].items():
    assert result["status"] == "passed" and result["exit_code"] == 0
    assert result["reaped"] is True
    assert not (Path("/proc") / str(result["pid"])).exists(), name
operator = json.loads((ROOT / "operator-state.json").read_text())
for name, result in operator.get("failed_sessions", {}).items():
    assert result["status"] == "failed" and result["exit_code"] == 1
    assert result["reaped"] is True
    assert not (Path("/proc") / str(result["pid"])).exists(), name
assert not list(ROOT.glob("*-failure.json"))
live = []
for directory in Path("/proc").iterdir():
    if not directory.name.isdecimal() or int(directory.name) == os.getpid():
        continue
    try:
        arguments = (directory / "cmdline").read_bytes().split(b"\0")
    except (FileNotFoundError, PermissionError, ProcessLookupError):
        continue
    if not arguments or not Path(os.fsdecode(arguments[0])).name.startswith("python"):
        continue
    if any(ROOT.name.encode() in argument for argument in arguments[1:]):
        live.append(
            {
                "pid": int(directory.name),
                "argv": [os.fsdecode(argument) for argument in arguments if argument],
            }
        )
assert not live, live
report = {
    "status": "passed",
    "actual_epoch": time.time(),
    "actual_elapsed_seconds": time.time() - START,
    "preservation": preservation,
    "validated_source_and_test_log_links": len(validation["sha256"]),
    "all_owned_probe_sessions_complete_and_reaped": True,
    "diagnostic_sessions_complete_and_reaped": True,
    "historical_failed_session_preserved_and_reaped": True,
    "owned_python_processes_remaining": live,
    "final_outputs_created": False,
}
(ROOT / "closing-preflight.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
