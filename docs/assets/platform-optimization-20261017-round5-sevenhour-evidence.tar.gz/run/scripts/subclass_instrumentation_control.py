"""Prove the added recorder distinguishes byte mutation from digest mismatch."""

import hashlib
import json
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
script = ROOT / "scripts/subclass_endurance_instrumented.py"
prefix = script.read_text().rsplit("\nrun = Run(__doc__)", 1)[0]
results = []
for mode in ("changed-bytes", "digest-only"):
    namespace = {"__file__": str(script), "__name__": "recorder_control"}
    exec(compile(prefix, str(script), "exec"), namespace)
    destination = ROOT / "phase9-subclass-fingerprint" / ("control-" + mode)
    destination.mkdir(exist_ok=False)
    namespace["ROOT"] = destination
    namespace["snapshot"]["index"] = -1
    value = np.arange(8, dtype=np.float32)
    arrays = {"value": value}
    metadata = {"control": mode}
    before = namespace["fingerprint"](arrays, metadata)
    if mode == "changed-bytes":
        value[3] = 99
    else:
        namespace["base_fingerprint"] = lambda arrays, metadata: "0" * 64
    try:
        namespace["verify"]("controlled-stage", arrays, metadata)
    except AssertionError:
        recorded = json.loads((destination / "subclass-instrumented-difference.json").read_text())
    else:
        raise AssertionError("Recorder did not detect controlled mismatch")
    assert recorded["stage"] == "controlled-stage" and recorded["before"] == before
    if mode == "changed-bytes":
        assert len(recorded["changes"]) == 1
        assert recorded["changes"][0]["field"] == "value:data"
        assert (destination / "subclass-instrumented-value-data-before.bin").read_bytes() != (destination / "subclass-instrumented-value-data-after.bin").read_bytes()
    else:
        assert recorded["changes"] == []
    results.append(dict(mode=mode, status="passed", recorded=recorded))
report = dict(status="passed", epoch=time.time(), script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), instrumented_harness_sha256=hashlib.sha256(script.read_bytes()).hexdigest(), results=results, scope="Controlled recorder verification only; does not classify the earlier observed failure.")
(ROOT / "subclass-instrumentation-control.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"status": report["status"], "controls": len(results)}))
