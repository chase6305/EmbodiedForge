"""Record completed cohorts only from successful, actually reaped tool sessions."""

import json
import time
from pathlib import Path

from report import PROBES, ROOT

operator = json.loads((ROOT / "operator-state.json").read_text())
state = json.loads((ROOT / "state.json").read_text())
results = json.loads((ROOT / "tool-session-results.json").read_text())
assert state["start_epoch"] == 1792206355 and state["deadline_epoch"] == 1792231555
assert state["required_elapsed_seconds"] == 25200
assert time.time() >= state["probe_stop_epoch"]
assert set(results) == set(operator["active_sessions"]) == set(PROBES)
assert not (ROOT / "session-completions.json").exists()
completed = {}
for name in PROBES:
    session = operator["active_sessions"][name]
    result = results[name]
    assert result["session_id"] == session["session_id"]
    assert result["tool_result"]["exit_code"] == 0
    assert result["reaped"] is True
    probe = json.loads((ROOT / f"{name}.json").read_text())
    assert probe["status"] == "passed" and probe["pid"] == session["pid"]
    assert probe["configuration_count"] == probe["base_configurations_expected"]
    assert probe["source_sha256"]["current"] == session["source_sha256"]
    assert probe["argv"][0].endswith(session["script"])
    assert not (Path("/proc") / str(session["pid"])).exists()
    completed[name] = {
        **session,
        "status": "passed",
        "exit_code": 0,
        "reaped": True,
        "cases": probe["cases"],
        "started_epoch": probe["started_epoch"],
        "finished_epoch": probe["finished_epoch"],
        "elapsed_seconds": probe["elapsed_seconds"],
        "configuration_count": probe["configuration_count"],
    }
with (ROOT / "session-completions.json").open("x") as stream:
    json.dump(completed, stream, indent=2)
    stream.write("\n")
operator.update(status="closing", stage="all_final_probe_sessions_reaped", active_sessions={}, updated_epoch=time.time())
operator["completed_sessions"] = completed
state.update(active_sessions={}, status="closing", updated_epoch=time.time())
for name, value in (("operator-state.json", operator), ("state.json", state)):
    temporary = ROOT / (name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(ROOT / name)
print(json.dumps({"status": "closing", "all_four_sessions_actually_reaped": True, "cases": {name: data["cases"] for name, data in completed.items()}}))
