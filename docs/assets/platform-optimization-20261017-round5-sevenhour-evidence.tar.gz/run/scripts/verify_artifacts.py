"""Re-read the exported archive and cross-check every evidence link on disk."""

import hashlib
import io
import json
import tarfile
import time
from pathlib import Path

from report import (
    ARCHIVE_PATH,
    CORE_FILES,
    DURATION,
    FIGURE_PATH,
    PROBES,
    REPORT_PATH,
    ROOT,
    START,
    WORKSPACE,
    sha256,
    verify_archive,
)

report = json.loads(REPORT_PATH.read_text())
assert report["actual_elapsed_seconds"] >= DURATION
assert report["duration_gate"]["status"] == "passed"
assert report["duration_gate"]["actual_elapsed_seconds"] >= DURATION
assert report["parallel_durations_added"] is False
archive_data = ARCHIVE_PATH.read_bytes()
assert hashlib.sha256(archive_data).hexdigest() == report["evidence_archive"]["sha256"]
assert len(archive_data) == report["evidence_archive"]["bytes"]
count = verify_archive(archive_data)
assert count == report["evidence_archive"]["regular_members"]
with tarfile.open(fileobj=io.BytesIO(archive_data), mode="r:gz") as archive:

    def archived(name):
        return archive.extractfile(name).read()

    initial = json.loads(archived("run/initial-hashes.json"))
    initial_sources = 0
    for name, expected in initial.items():
        if name.startswith("src/") and name.endswith(".py"):
            assert (
                hashlib.sha256(archived("run/initial/" + name)).hexdigest() == expected
            )
            initial_sources += 1
    assert initial_sources == 105
    for name in CORE_FILES:
        expected = report["review_files_sha256"][name]
        assert sha256(WORKSPACE / name) == expected
        assert hashlib.sha256(archived("final/" + name)).hexdigest() == expected
    figure_name = str(FIGURE_PATH.relative_to(WORKSPACE))
    assert sha256(FIGURE_PATH) == report["figure"]["sha256"]
    assert (
        hashlib.sha256(archived("final/" + figure_name)).hexdigest()
        == report["figure"]["sha256"]
    )
    assert b"<text" in archived("final/" + figure_name)
    for path, expected in report["validation"]["sha256"].items():
        assert sha256(WORKSPACE / path) == expected, path
        if path.startswith(str(ROOT.relative_to(WORKSPACE)) + "/"):
            inside = str(Path(path).relative_to(ROOT.relative_to(WORKSPACE)))
            assert hashlib.sha256(archived("run/" + inside)).hexdigest() == expected
        else:
            inside = "final/" + path if path in CORE_FILES else "run/initial/" + path
            assert hashlib.sha256(archived(inside)).hexdigest() == expected, inside
    frozen = json.loads(archived("run/frozen-runtime.json"))["sha256"]
    actual = {
        str(path.relative_to(WORKSPACE)): sha256(path)
        for path in sorted((WORKSPACE / "src").rglob("*.py"))
    }
    assert actual == frozen
    for name in PROBES:
        probe = json.loads(archived("run/" + name + ".json"))
        assert probe["status"] == "passed"
        assert probe["configuration_count"] == probe["base_configurations_expected"]
        assert report["sustained_probes"][name]["cases"] == probe["cases"]
        assert probe["runtime_source_sha256"] == frozen
        for relative, expected in probe["script_sha256"].items():
            assert hashlib.sha256(archived("run/" + relative)).hexdigest() == expected
    gate = json.loads(archived("run/duration-gate.json"))
    assert gate == report["duration_gate"]
    control = gate["early_control"]
    assert (
        control["status"] == "passed" and control["actual_elapsed_seconds"] < DURATION
    )
    assert control["real_clock_used"] is True and control["clock_simulated"] is False
    assert control["final_outputs_created"] is False
    reporter_sha = hashlib.sha256(archived("run/scripts/report.py")).hexdigest()
    assert (
        reporter_sha == control["reporter_sha256"] == sha256(ROOT / "scripts/report.py")
    )
    for relative, expected in {
        **report["benchmark_provenance"]["reports_sha256"],
        **report["benchmark_provenance"]["executed_harness_sha256"],
    }.items():
        assert hashlib.sha256(archived("run/" + relative)).hexdigest() == expected
    for relative, expected in report["dtype_provenance"]["reports_sha256"].items():
        assert hashlib.sha256(archived("run/" + relative)).hexdigest() == expected
    for relative, expected in report["precision_provenance"]["reports_sha256"].items():
        assert hashlib.sha256(archived("run/" + relative)).hexdigest() == expected
    for relative, data in report["secondary_sampling_boundary_controls"].items():
        assert hashlib.sha256(archived("run/" + relative)).hexdigest() == data["sha256"]
        assert json.loads(archived("run/" + relative)) == data["data"]
    for name, data in report["fixed_library_retained_allocation_checks"].items():
        assert data["status"] == "passed"
        assert (
            hashlib.sha256(archived("run/" + name + ".json")).hexdigest()
            == data["raw_report_sha256"]
        )
    historical = report["historical_subclass_diagnostic"]
    diagnostic_root = "run/phase9-subclass-fingerprint/"
    for name, expected in historical["preserved_files_sha256"].items():
        assert hashlib.sha256(archived(diagnostic_root + name)).hexdigest() == expected
    original_failure = archived(diagnostic_root + "subclasses-py312-failure.json")
    assert hashlib.sha256(original_failure).hexdigest() == report["historical_subclass_failure_sha256"]
    assert json.loads(original_failure)["status"] == "failed"
    for relative, data in report["subclass_diagnostic_followup"].items():
        payload = archived("run/" + relative)
        assert hashlib.sha256(payload).hexdigest() == data["sha256"]
        assert json.loads(payload) == data["data"]
    assert report["verification_qualification"]
verification = {
    "status": "passed",
    "verified_epoch": time.time(),
    "actual_elapsed_seconds": time.time() - START,
    "regular_archive_members_verified": count,
    "initial_runtime_sources_verified": initial_sources,
    "final_changed_files_and_figure_verified": len(CORE_FILES) + 1,
    "test_log_and_source_links_verified": True,
    "all_four_completed_probe_and_harness_links_verified": True,
    "gzip_crc_all_manifest_hashes_unique_safe_paths_verified": True,
    "duration_gate_and_real_early_rejection_verified": True,
    "performance_source_links_verified": True,
    "dtype_boundary_and_retained_allocation_links_verified": True,
    "historical_failed_probe_preserved_and_qualified": True,
}
report["artifact_verification"] = verification
report["status"] = "complete_with_unclassified_diagnostic" if report["historical_subclass_diagnostic"]["status"] == "unclassified" else "complete"
temporary = REPORT_PATH.with_suffix(".json.tmp")
temporary.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
temporary.replace(REPORT_PATH)
print(json.dumps(verification, indent=2))
