"""Full-constructor unit-boundary parity over precision, layout and tail sizes."""

import hashlib
import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np

from endurance_support import invoke
from fixture import ROOT, assert_equal, fingerprint, make_input, source_hashes, versions

started = time.time()
original, current = versions()
expected_sources = source_hashes()
rng = np.random.default_rng(170521)
rows = []
configurations = list(
    itertools.product(
        (65535, 65536, 65537),
        ("float16", ">f2", "float32", ">f4", "float64", ">f8", "longdouble"),
        (
            "contiguous",
            "fortran",
            "fortran-strided",
            "fortran-reversed",
            "component-strided",
            "component-reversed",
        ),
        ("body_quat_w", "object_quat_w"),
    )
)
for configuration_index, (frames, dtype, layout, field) in enumerate(configurations):
    scalar = np.dtype(dtype).type
    payloads = [
        np.frombuffer(bytes.fromhex(value), dtype="<f2").astype(dtype)
        for value in ("ecb567a834b949b9", "d5a61339d02f1fba")
    ]
    for sign, delta in itertools.product((-1, 1), (-2, 0, 2)):
        q = rng.normal(size=4).astype(scalar)
        q /= np.sqrt(np.square(q).sum())
        q *= scalar(1) + scalar(sign * 1e-3) + scalar(delta) * np.finfo(scalar).eps
        payloads.append(q.astype(dtype))
    for payload_index, payload in enumerate(payloads):
        arrays, metadata = make_input(
            [frames], bodies=1, joints=1, dtype=dtype, flags=False, owned=False
        )
        value = arrays[field].copy()
        value[-1] = payload
        if layout == "fortran":
            value = np.array(value, order="F", copy=True)
        elif layout == "fortran-strided":
            storage = np.empty((2 * frames, *value.shape[1:]), dtype=dtype, order="F")
            storage[::2] = value
            value = storage[::2]
        elif layout == "fortran-reversed":
            value = np.array(value[::-1], order="F", copy=True)[::-1]
        elif layout == "component-strided":
            storage = np.empty((*value.shape[:-1], 8), dtype=dtype)
            storage[..., ::2] = value
            value = storage[..., ::2]
        elif layout == "component-reversed":
            value = value[..., ::-1].copy()[..., ::-1]
        value.flags.writeable = False
        arrays[field] = value
        expected_acceptance = bool(
            np.allclose(np.linalg.norm(value, axis=-1), 1, atol=1e-3, rtol=0)
        )
        before = fingerprint(arrays, metadata)
        old, old_error = invoke(original.MotionClips, arrays, metadata)
        new, new_error = invoke(current.MotionClips, arrays, metadata)
        assert old_error == new_error, (
            configuration_index,
            payload_index,
            old_error,
            new_error,
        )
        assert (old_error is None) == expected_acceptance, (
            configuration_index,
            payload_index,
            old_error,
        )
        if expected_acceptance:
            assert_equal(old, new, arrays, metadata)
        else:
            assert old_error == ("ValueError", f"{field} must contain unit quaternions")
        assert before == fingerprint(arrays, metadata)
        assert all(not v.flags.writeable for v in arrays.values())
        rows.append(
            dict(
                frames=frames,
                dtype=dtype,
                layout=layout,
                field=field,
                payload_index=payload_index,
                payload_bytes_hex=payload.tobytes().hex(),
                accepted=expected_acceptance,
            )
        )
        del arrays, metadata, value, old, new
    if configuration_index % 25 == 0:
        print(
            json.dumps(
                {
                    "completed_base_configurations": configuration_index + 1,
                    "cases": len(rows),
                }
            ),
            flush=True,
        )
assert source_hashes() == expected_sources
report = dict(
    status="passed",
    python=sys.version,
    numpy=np.__version__,
    started_epoch=started,
    finished_epoch=time.time(),
    elapsed_seconds=time.time() - started,
    source_sha256=expected_sources,
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    base_configurations=len(configurations),
    cases=len(rows),
    accepted=sum(row["accepted"] for row in rows),
    rejected=sum(not row["accepted"] for row in rows),
    observations=rows,
    scope="Actual original and final public constructors, plus the installed NumPy whole-field norm tolerance predicate. Native/non-native float16/32/64 and extended precision, frame counts at the quaternion block boundary, Fortran/negative/component-strided layouts, and both acceptance/rejection edges. This preserves existing computational tolerance semantics; it does not claim improved half-precision accuracy. Readonly input bytes are checked. No performance conclusion.",
)
path = (
    ROOT
    / f"precision-oracle-{sys.version_info.major}.{sys.version_info.minor}-numpy{np.__version__}.json"
)
with path.open("x") as stream:
    json.dump(report, stream, indent=2, allow_nan=False)
    stream.write("\n")
print(
    json.dumps(
        {
            key: report[key]
            for key in (
                "status",
                "numpy",
                "base_configurations",
                "cases",
                "accepted",
                "rejected",
                "elapsed_seconds",
            )
        }
    )
)
