"""Additional low-object controls; explicitly exploratory under sustained load."""

import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np

from benchmark_support import paired
from endurance_support import state_digest
from fixture import ROOT, fingerprint, make_input, source_hashes, versions

started = time.time()
original, current = versions()
rows = []
configurations = [
    (clips, objects, objects) for clips in (64, 4096, 65536) for objects in (2, 3)
]
configurations += [(65536, 64, requested) for requested in (2, 3)]
for clips, objects, requested in configurations:
    lengths = [1 + i % 7 for i in range(clips)]
    arrays, metadata = make_input(lengths, bodies=1, joints=1, objects=objects)
    old = original.MotionClips(arrays, metadata)
    new = current.MotionClips(arrays, metadata)
    before = fingerprint(arrays, metadata)
    requests = [f"object-{i % requested}" for i in range(128)]
    old_rng = np.random.default_rng(7153)
    new_rng = np.random.default_rng(7153)
    a = old.sample(requests, old_rng)
    b = new.sample(requests, new_rng)
    assert all(np.array_equal(x, y) for x, y in zip(a, b, strict=True))
    assert state_digest(old_rng) == state_digest(new_rng)
    functions = {
        "initial": lambda: old.sample(requests, old_rng),
        "current": lambda: new.sample(requests, new_rng),
    }
    result = paired(functions, calls=25 if clips < 65536 else 5, pairs=15)
    assert state_digest(old_rng) == state_digest(new_rng)
    assert before == fingerprint(arrays, metadata)
    row = {
        "clips": clips,
        "library_objects": objects,
        "requested_objects": requested,
        "batch_size": 128,
        "pairs": 15,
        **result,
    }
    rows.append(row)
    print(
        json.dumps(
            {
                "clips": clips,
                "objects": objects,
                "requested": requested,
                "time_percent": result["elapsed_reduction_percent"],
                "peak_percent": result["peak_reduction_percent"],
            }
        ),
        flush=True,
    )
report = {
    "status": "passed",
    "python": sys.version,
    "numpy": np.__version__,
    "started_epoch": started,
    "finished_epoch": time.time(),
    "source_sha256": source_hashes(),
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "cases": rows,
    "scope": "Exploratory 2/3-requested-object boundary and sparse-request controls. Four task-owned sustained probes remained active throughout. Timing is not isolated and is excluded from primary performance conclusions; alternating medians, raw signed results, separate traced allocation measurements, exact output/RNG parity and readonly bytes retained. No runtime tuning was applied from these exploratory measurements.",
}
path = (
    ROOT
    / f"sampling-boundaries-{sys.version_info.major}.{sys.version_info.minor}-numpy{np.__version__}.json"
)
with path.open("x") as stream:
    json.dump(report, stream, indent=2, allow_nan=False)
    stream.write("\n")
