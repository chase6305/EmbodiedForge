"""Use the real clock to prove that premature final export is rejected."""

import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parents[1]
START = 1792206355
reporter = ROOT / "scripts/report.py"
targets = [
    WORKSPACE / "docs/platform-optimization-20261017-round5-sevenhour.json",
    WORKSPACE / "docs/assets/platform-optimization-20261017-round5-sevenhour-evidence.tar.gz",
]
before = time.time()
assert before - START < 25200, "Early control must run before the real deadline"
assert not any(path.exists() for path in targets)
result = subprocess.run([sys.executable, str(reporter)], capture_output=True, text=True)
assert result.returncode == 1, result
assert "Seven-hour elapsed-time gate: actual elapsed time must reach 25200 seconds" in result.stderr
assert not any(path.exists() for path in targets)
report = {
    "status": "passed",
    "actual_epoch": before,
    "actual_elapsed_seconds": before - START,
    "required_elapsed_seconds": 25200,
    "reporter_sha256": hashlib.sha256(reporter.read_bytes()).hexdigest(),
    "real_clock_used": True,
    "clock_simulated": False,
    "final_outputs_created": False,
    "exit_code": result.returncode,
    "stderr": result.stderr,
}
(ROOT / "duration-gate-control.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({key: report[key] for key in ("status", "actual_elapsed_seconds", "final_outputs_created")}))
