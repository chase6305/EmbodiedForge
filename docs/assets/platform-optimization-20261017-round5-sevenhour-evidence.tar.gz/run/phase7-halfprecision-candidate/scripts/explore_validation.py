"""Exploratory measurements only; no source edits, timing excludes setup."""

import cProfile
import importlib.util
import io
import json
import pstats
import time
import tracemalloc
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location(
    "initial_motion_clips", ROOT / "initial/src/embodiedforge/_motion_clips.py"
)
initial = importlib.util.module_from_spec(spec)
spec.loader.exec_module(initial)
fixture = importlib.util.spec_from_file_location(
    "motion_fixture", ROOT / "initial/tests/test_motion_compare_blocks.py"
)
fixture_module = importlib.util.module_from_spec(fixture)
fixture.loader.exec_module(fixture_module)


def chunks(value, target):
    width = value.size // len(value)
    block = max(1, target // width)
    for start in range(0, len(value), block):
        yield value[start : start + block]


def finite(value, target):
    if value.size <= target:
        return np.isfinite(value).all()
    return all(np.isfinite(part).all() for part in chunks(value, target))


def unit(value, target):
    if value.size <= target:
        return np.allclose(np.linalg.norm(value, axis=-1), 1, atol=1e-3, rtol=0)
    return all(
        np.allclose(np.linalg.norm(part, axis=-1), 1, atol=1e-3, rtol=0)
        for part in chunks(value, target)
    )


def contact(value, target):
    if value.size <= target:
        return np.isin(value, [-1, 0, 1]).all()
    return all(np.isin(part, [-1, 0, 1]).all() for part in chunks(value, target))


def candidate(arrays, target):
    for key, value in arrays.items():
        if value.ndim < 2:
            continue
        assert finite(value, target)
        if "quat" in key:
            assert unit(value, target)
    assert contact(arrays["contact_label"], target)


def measure(fn, repeats):
    fn()
    samples = []
    for _ in range(repeats):
        started = time.perf_counter()
        fn()
        samples.append(time.perf_counter() - started)
    tracemalloc.start()
    fn()
    peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    return {"seconds": samples, "median_seconds": float(np.median(samples)), "peak_traced_bytes": peak}


rows = []
for frames in (128, 8192, 65536):
    motion = fixture_module.library([frames], dtype="float32", bodies=16, joints=29)
    row = {"frames": frames, "initial": measure(lambda: initial.MotionClips(motion.arrays, motion.metadata), 5)}
    for target in (16384, 65536, 262144, 1048576):
        row[str(target)] = measure(lambda: candidate(motion.arrays, target), 5)
    rows.append(row)
    print(json.dumps(row), flush=True)
    if frames == 65536:
        profiler = cProfile.Profile()
        profiler.runcall(initial.MotionClips, motion.arrays, motion.metadata)
        output = io.StringIO()
        pstats.Stats(profiler, stream=output).sort_stats("cumulative").print_stats(28)
        (ROOT / "initial-constructor-profile.txt").write_text(output.getvalue())
(ROOT / "exploratory-validation.json").write_text(json.dumps(rows, indent=2) + "\n")
