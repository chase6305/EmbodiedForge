"""Exercise all public benchmark scopes and its CLI/output contracts."""

import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parents[1]
PYTHONS = (
    "/tmp/ef-ci310-20261014/bin/python",
    "/tmp/ef-ci312-20261014/bin/python",
    "/tmp/ef-numpy124-20261014/bin/python",
)
environment = dict(
    os.environ, PYTHONPATH="src", OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1"
)
directory = ROOT / "benchmark-smoke"
directory.mkdir()
started = time.time()
checks = []
for index, python in enumerate(PYTHONS):
    prefix = [
        python,
        "benchmarks/motion_inputs.py",
        "--input",
        str(ROOT / "datasets/frames-128.npz"),
        "--calls",
        "1",
        "--repeats",
        "2",
    ]
    reports = {}
    for scope in ("load", "validate", "sample"):
        output = directory / f"{index}-{scope}.json"
        command = [*prefix, "--scope", scope, "--output", str(output)]
        if scope == "sample":
            command.extend(["--objects", "object-0", "--batch-size", "17"])
        result = subprocess.run(
            command, cwd=WORKSPACE, env=environment, capture_output=True, text=True
        )
        assert result.returncode == 0, result.stderr
        report = json.loads(output.read_text())
        assert len(report["seconds_per_call"]) == 2
        assert report["median_seconds_per_call"] > 0
        assert report["peak_traced_bytes"] > 0
        assert (
            report["input_sha256"]
            == hashlib.sha256(
                (ROOT / "datasets/frames-128.npz").read_bytes()
            ).hexdigest()
        )
        reports[scope] = report
        checks.append(
            dict(
                python=python,
                kind="valid_scope",
                scope=scope,
                output=str(output),
                exit_code=0,
            )
        )
    assert reports["load"]["result_sha256"] == reports["validate"]["result_sha256"]
    for arguments in (
        ["--calls", "0"],
        ["--repeats", "0"],
        ["--batch-size", "0"],
        ["--seed", "-1"],
        ["--objects", "object-0"],
    ):
        output = directory / f"{index}-invalid-{len(checks)}.json"
        result = subprocess.run(
            [*prefix, "--scope", "validate", "--output", str(output), *arguments],
            cwd=WORKSPACE,
            env=environment,
            capture_output=True,
            text=True,
        )
        assert result.returncode == 2 and not output.exists(), result.stderr
        checks.append(
            dict(
                python=python,
                kind="invalid_arguments",
                arguments=arguments,
                exit_code=2,
            )
        )
    output = directory / f"{index}-existing.json"
    sentinel = b"caller-owned output\n"
    output.write_bytes(sentinel)
    result = subprocess.run(
        [*prefix, "--scope", "validate", "--output", str(output)],
        cwd=WORKSPACE,
        env=environment,
        capture_output=True,
        text=True,
    )
    assert result.returncode != 0 and "FileExistsError" in result.stderr
    assert output.read_bytes() == sentinel
    checks.append(
        dict(
            python=python, kind="existing_output_preserved", exit_code=result.returncode
        )
    )
report = dict(
    status="passed",
    started_epoch=started,
    finished_epoch=time.time(),
    checks=len(checks),
    observations=checks,
    benchmark_sha256=hashlib.sha256(
        (WORKSPACE / "benchmarks/motion_inputs.py").read_bytes()
    ).hexdigest(),
    scope="CLI/result/output checks only; these smoke timings overlap sustained probes and are excluded from performance conclusions.",
)
(ROOT / "benchmark-smoke.json").write_text(json.dumps(report, indent=2) + "\n")
print(
    json.dumps({key: report[key] for key in ("status", "checks", "benchmark_sha256")})
)
