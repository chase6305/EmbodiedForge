"""Frame-field dtype extremes and actual readonly memmap compatibility."""

import gc
import hashlib
import itertools
import json
import os
import sys
import tempfile
import time
import weakref
from pathlib import Path

import numpy as np

from endurance_support import invoke
from fixture import (
    ROOT,
    arrange,
    assert_equal,
    fingerprint,
    make_input,
    source_hashes,
    versions,
)

started = time.time()
original, current = versions()
rows = []
dtype_names = (
    "int8",
    "uint8",
    "int64",
    "uint64",
    ">i8",
    ">u8",
    "float16",
    "float32",
    "float64",
    ">f8",
    "longdouble",
)
for frames, dtype, layout in itertools.product(
    (1, 65535, 65536, 65537, 262145),
    dtype_names,
    ("contiguous", "fortran", "reversed", "strided", "unaligned"),
):
    arrays, metadata = make_input(
        [frames], bodies=1, joints=1, dtype=dtype, layout=layout
    )
    # Isolate frame-field dtype behavior from the separately documented uint64
    # contact-label defect. Integer contact labels remain fully validated.
    arrays["contact_label"] = np.asarray(arrays["contact_label"], dtype=np.int8)
    arrays["contact_label"].flags.writeable = False
    values = arrays["joint_pos"].copy()
    if np.dtype(dtype).kind in "iu":
        values[-1] = np.iinfo(dtype).max
    else:
        values[-1] = np.finfo(dtype).max
    if dtype == "longdouble":
        values[0] = np.longdouble("1e4000")
    arrays["joint_pos"] = arrange(values, layout)
    before = fingerprint(arrays, metadata)
    with np.errstate(all="ignore"):
        old, old_error = invoke(original.MotionClips, arrays, metadata)
        new, new_error = invoke(current.MotionClips, arrays, metadata)
    assert old_error == new_error, (frames, dtype, layout, old_error, new_error)
    assert old_error is None, (frames, dtype, layout, old_error)
    assert_equal(old, new, arrays, metadata)
    assert before == fingerprint(arrays, metadata)
    assert all(not value.flags.writeable for value in arrays.values())
    rows.append(
        dict(
            frames=frames,
            dtype=dtype,
            layout=layout,
            accepted=True,
            readonly_bytes_preserved=True,
        )
    )
    del arrays, metadata, values, old, new
memmaps = []
base_fds = len(os.listdir("/proc/self/fd"))
for frames, dtype, field, order in itertools.product(
    (1, 65537),
    ("float32", "float64", ">f8", "int64"),
    ("joint_pos", "body_quat_w", "contact_label"),
    ("C", "F"),
):
    arrays, metadata = make_input([frames], bodies=1, joints=1, dtype=dtype)
    with tempfile.TemporaryDirectory(prefix="ef-r5-memmap-") as directory:
        path = Path(directory) / "field.dat"
        writable = np.memmap(
            path, mode="w+", dtype=dtype, shape=arrays[field].shape, order=order
        )
        writable[:] = arrays[field]
        writable.flush()
        del writable
        gc.collect()
        value = np.memmap(
            path, mode="r", dtype=dtype, shape=arrays[field].shape, order=order
        )
        ref = weakref.ref(value)
        arrays[field] = value
        file_before = hashlib.sha256(path.read_bytes()).hexdigest()
        before = fingerprint(arrays, metadata)
        old, old_error = invoke(original.MotionClips, arrays, metadata)
        new, new_error = invoke(current.MotionClips, arrays, metadata)
        assert old_error == new_error == None, (
            frames,
            dtype,
            field,
            order,
            old_error,
            new_error,
        )
        assert_equal(old, new, arrays, metadata)
        assert not value.flags.writeable
        assert before == fingerprint(arrays, metadata)
        assert hashlib.sha256(path.read_bytes()).hexdigest() == file_before
        del arrays, metadata, value, old, new
        gc.collect()
        assert ref() is None
    assert len(os.listdir("/proc/self/fd")) == base_fds
    memmaps.append(
        dict(
            frames=frames,
            dtype=dtype,
            field=field,
            order=order,
            accepted=True,
            file_sha256=file_before,
            mapping_released=True,
        )
    )
report = dict(
    status="passed",
    python=sys.version,
    numpy=np.__version__,
    started_epoch=started,
    finished_epoch=time.time(),
    elapsed_seconds=time.time() - started,
    source_sha256=source_hashes(),
    frame_dtype_cases=len(rows),
    readonly_memmap_cases=len(memmaps),
    observations=rows,
    memmaps=memmaps,
    scope="Actual full public constructors over numeric frame fields, native/non-native arrays, maximum finite/integer payloads and extended-range longdouble positions. Contact dtype is int8 in the general dtype corpus to isolate the separate uint64 defect. Actual read-only file mappings, byte preservation, weak-reference release and FD restoration are checked. FPS remains the ordinary 50-Hz scalar; no performance claim.",
)
path = (
    ROOT
    / f"dtype-oracle-{sys.version_info.major}.{sys.version_info.minor}-numpy{np.__version__}.json"
)
with path.open("x") as stream:
    json.dump(report, stream, indent=2, allow_nan=False)
    stream.write("\n")
print(
    json.dumps(
        {
            key: report[key]
            for key in (
                "status",
                "numpy",
                "frame_dtype_cases",
                "readonly_memmap_cases",
                "elapsed_seconds",
            )
        }
    )
)
