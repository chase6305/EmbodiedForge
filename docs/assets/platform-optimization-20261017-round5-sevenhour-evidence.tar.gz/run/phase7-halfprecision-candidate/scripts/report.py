"""Export reviewable evidence only after seven actual elapsed hours."""

import argparse
import datetime
import gzip
import hashlib
import io
import json
import tarfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parents[1]
START = 1792206355
DEADLINE = 1792231555
DURATION = 25200
STEM = "platform-optimization-20261017-round5-sevenhour"
REPORT_PATH = WORKSPACE / "docs" / f"{STEM}.json"
FIGURE_PATH = WORKSPACE / "docs" / f"{STEM}-performance.svg"
ARCHIVE_PATH = WORKSPACE / "docs/assets" / f"{STEM}-evidence.tar.gz"
PROBES = (
    "validation-py312",
    "validation-numpy124",
    "sampling-py310",
    "subclasses-py312",
)
CORE_FILES = (
    "src/embodiedforge/_motion_clips.py",
    "tests/test_motion_clips.py",
    "tests/test_motion_validation.py",
    "benchmarks/motion_inputs.py",
    "docs/weave-reference.md",
)


def read_json(path):
    return json.loads(path.read_text())


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def utc(epoch):
    return datetime.datetime.fromtimestamp(epoch, datetime.timezone.utc).isoformat()


def check_preservation():
    initial = read_json(ROOT / "initial-hashes.json")
    changed = []
    for name, expected in initial.items():
        assert sha256(ROOT / "initial" / name) == expected, (
            "Initial snapshot changed",
            name,
        )
        if sha256(WORKSPACE / name) != expected:
            changed.append(name)
    assert set(changed) == {
        "src/embodiedforge/_motion_clips.py",
        "tests/test_motion_clips.py",
        "docs/weave-reference.md",
    }, changed
    frozen = read_json(ROOT / "frozen-runtime.json")["sha256"]
    actual = {
        str(path.relative_to(WORKSPACE)): sha256(path)
        for path in sorted((WORKSPACE / "src").rglob("*.py"))
    }
    assert frozen == actual, "Runtime source differs from tested frozen source"
    return {
        "initial_files_verified": len(initial),
        "runtime_sources_verified": len(frozen),
        "changed_initial_files": changed,
        "only_runtime_change": "src/embodiedforge/_motion_clips.py",
        "prior_runtime_optimizations_preserved": True,
    }


def collect_members():
    """Read bytes before building TarInfo, including atomically replaced progress."""
    members = {}
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if "__pycache__" in relative.parts or path.suffix in (".pyc", ".tmp"):
            continue
        if relative.parts[0] in ("datasets", "final"):
            continue
        if path.name in ("preview-report.json", "archive-preflight.json"):
            continue
        if relative.parts[0] == "initial":
            inside = Path(*relative.parts[1:])
            allowed = inside.suffix in {
                ".py",
                ".md",
                ".toml",
                ".html",
                ".js",
                ".xml",
                ".json",
                ".txt",
                ".svg",
            } or inside.name.startswith(("LICENSE", "NOTICE"))
            if not allowed:
                continue
        name = str(Path("run") / relative)
        assert name not in members
        members[name] = path.read_bytes()
    for name in CORE_FILES:
        members[str(Path("final") / name)] = (WORKSPACE / name).read_bytes()
    for path in sorted(WORKSPACE.glob("LICENSE*")):
        if path.is_file():
            members[str(Path("project") / path.name)] = path.read_bytes()
    if FIGURE_PATH.exists():
        members[str(Path("final") / FIGURE_PATH.relative_to(WORKSPACE))] = (
            FIGURE_PATH.read_bytes()
        )
    manifest = {
        name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
        for name, data in members.items()
    }
    members["manifest.json"] = (
        json.dumps(
            {"status": "passed", "manifest_excludes_itself": True, "members": manifest},
            indent=2,
        )
        + "\n"
    ).encode()
    return members


def archive_bytes(members):
    output = io.BytesIO()
    with tarfile.open(fileobj=output, mode="w:gz") as archive:
        for name, data in members.items():
            path = Path(name)
            assert not path.is_absolute() and ".." not in path.parts
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = START
            archive.addfile(info, io.BytesIO(data))
    return output.getvalue()


def verify_archive(data):
    gzip.decompress(data)  # Read through the gzip CRC and trailer.
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
        members = archive.getmembers()
        assert len({member.name for member in members}) == len(members)
        manifest = json.load(archive.extractfile("manifest.json"))["members"]
        assert {member.name for member in members} == set(manifest) | {"manifest.json"}
        for member in members:
            path = Path(member.name)
            assert member.isfile() and not path.is_absolute() and ".." not in path.parts
            payload = archive.extractfile(member).read()
            if member.name != "manifest.json":
                assert len(payload) == manifest[member.name]["bytes"]
                assert (
                    hashlib.sha256(payload).hexdigest()
                    == manifest[member.name]["sha256"]
                )
    return len(members)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preview", action="store_true")
    args = parser.parse_args()
    now = time.time()
    state = read_json(ROOT / "state.json")
    assert state["start_epoch"] == START and state["deadline_epoch"] == DEADLINE
    assert DEADLINE - START == DURATION == state["required_elapsed_seconds"]
    if not args.preview:
        # This is deliberately before any final artifact write or closing check.
        assert now - START >= DURATION, (
            "Seven-hour elapsed-time gate: actual elapsed time must reach 25200 seconds"
        )
        assert not REPORT_PATH.exists() and not ARCHIVE_PATH.exists(), (
            "Final output already exists"
        )
    preservation = check_preservation()
    validation = read_json(ROOT / "validation-results.json")
    assert validation["status"] == "passed"
    for path, expected in validation["sha256"].items():
        assert sha256(WORKSPACE / path) == expected, path
    performances = {}
    for pattern in ("motion-inputs-performance-*.json", "file-pipeline-*.json"):
        for path in sorted(ROOT.glob(pattern)):
            data = read_json(path)
            assert data["status"] == "passed"
            assert data["source_sha256"]["current"] == sha256(WORKSPACE / CORE_FILES[0])
            performances[path.name] = data
    assert len(performances) == 4
    provenance = read_json(ROOT / "benchmark-provenance.json")
    for name, expected in {
        **provenance["reports_sha256"],
        **provenance["executed_harness_sha256"],
    }.items():
        assert sha256(ROOT / name) == expected, name
    uint64 = []
    for path in sorted(ROOT.glob("uint64-oracle-*.json")):
        data = read_json(path)
        assert (
            data["status"] == "passed"
            and data["cases"] == 80
            and data["file_load_checks"] == 16
        )
        assert data["source_sha256"]["current"] == sha256(WORKSPACE / CORE_FILES[0])
        uint64.append(
            {
                key: data[key]
                for key in (
                    "numpy",
                    "cases",
                    "file_load_checks",
                    "known_original_defect_cases",
                )
            }
        )
    assert len(uint64) == 3
    dtype_provenance = read_json(ROOT / "dtype-provenance.json")
    assert dtype_provenance["status"] == "passed"
    assert dtype_provenance["script_sha256"] == sha256(ROOT / "scripts/dtype_oracle.py")
    dtype_oracles = []
    for name, expected in dtype_provenance["reports_sha256"].items():
        assert sha256(ROOT / name) == expected, name
        data = read_json(ROOT / name)
        assert data["status"] == "passed"
        assert data["frame_dtype_cases"] == 275 and data["readonly_memmap_cases"] == 48
        assert data["source_sha256"]["current"] == sha256(WORKSPACE / CORE_FILES[0])
        dtype_oracles.append(
            {
                key: data[key]
                for key in (
                    "numpy",
                    "frame_dtype_cases",
                    "readonly_memmap_cases",
                    "scope",
                )
            }
        )
    assert len(dtype_oracles) == 3
    boundary_controls = {}
    for path in sorted(ROOT.glob("sampling-boundaries-*.json")):
        data = read_json(path)
        assert data["status"] == "passed" and len(data["cases"]) == 8
        assert data["source_sha256"]["current"] == sha256(WORKSPACE / CORE_FILES[0])
        assert data["script_sha256"] == sha256(ROOT / "scripts/sampling_boundaries.py")
        boundary_controls[path.name] = {"sha256": sha256(path), "data": data}
    assert len(boundary_controls) == 2
    retained = {}
    for name in ("retained-py312", "retained-numpy124"):
        path = ROOT / f"{name}.json"
        if path.exists():
            data = read_json(path)
            assert data["status"] == "passed" and len(data["cases"]) == 3
            assert all(case["traced_calls"] == 5000 for case in data["cases"])
            assert data["source_sha256"]["current"] == sha256(WORKSPACE / CORE_FILES[0])
            assert data["script_sha256"] == sha256(
                ROOT / "scripts/retained_allocations.py"
            )
            retained[name] = {
                "status": "passed",
                "raw_report_sha256": sha256(path),
                "numpy": data["numpy"],
                "traced_calls": sum(case["traced_calls"] for case in data["cases"]),
                "live_ranges_bytes_after_explicit_gc": [
                    case["live_range_bytes"] for case in data["cases"]
                ],
                "scope": data["scope"],
            }
        else:
            assert args.preview, ("Retained allocation check incomplete", name)
            retained[name] = read_json(ROOT / f"{name}-progress.json")
    probes = {}
    for name in PROBES:
        path = ROOT / f"{name}{'-progress' if args.preview else ''}.json"
        data = read_json(path)
        assert data["source_sha256"]["current"] == sha256(WORKSPACE / CORE_FILES[0])
        for relative, expected in data["script_sha256"].items():
            assert sha256(ROOT / relative) == expected, relative
        if not args.preview:
            assert data["status"] == "passed"
            assert data["configuration_count"] == data["base_configurations_expected"]
        resources = data["resources"]
        probes[name] = {
            key: data[key]
            for key in (
                "status",
                "started_epoch",
                "elapsed_seconds",
                "cases",
                "reference_input_frames",
                "configuration_count",
                "base_configurations_expected",
                "outcomes",
            )
        }
        probes[name]["resource_samples"] = len(resources)
        probes[name]["observed_fds"] = sorted({row["fds"] for row in resources})
        probes[name]["observed_python_threads"] = sorted(
            {row["python_threads"] for row in resources}
        )
        probes[name]["observed_os_threads"] = sorted(
            {row["os_threads"] for row in resources}
        )
        probes[name]["observed_rss_range_bytes"] = [
            min(row["rss_bytes"] for row in resources),
            max(row["rss_bytes"] for row in resources),
        ]
        if "independent_gather_element_checks" in data:
            probes[name]["independent_gather_element_checks"] = data[
                "independent_gather_element_checks"
            ]
    assert not list(ROOT.glob("*-failure.json"))
    earliest_probe = min(data["started_epoch"] for data in probes.values())
    assert all(
        data["finished_epoch"] < earliest_probe for data in performances.values()
    )
    report = {
        "status": "active_preview" if args.preview else "closing_after_elapsed_gate",
        "objective": "持续优化 EmbodiedForge 七个实际小时，保留已有工作区改动并提供可审查证据。",
        "started_utc": utc(START),
        "required_deadline_utc": utc(DEADLINE),
        "generated_utc": utc(now),
        "actual_elapsed_seconds": now - START,
        "required_elapsed_seconds": DURATION,
        "parallel_durations_added": False,
        "scope": "CPU motion input loading/validation and NumPy object-conditioned sampling; shared unpinned host. Weave's upstream Torch sampler, simulation, GPU performance and training throughput were not measured.",
        "changes": [
            "Large exact ndarray fields validate in frame blocks targeting 262144 input scalars; small fields and ndarray subclasses retain whole-field behavior. A frame wider than the target is processed whole; this is not a byte cap or file streaming.",
            "Exact ndarray contact labels use equality membership, fixing NumPy 1.24 uint64 signed-table IndexError for ordinary arrays and NPZ-decoded inputs. Array subclasses retain existing isin dispatch.",
            "Multiple requested objects share one per-call library scan and compact signed integer candidate buffers. Candidate order, RNG call order, output order, errors and later public object-list edits are preserved. Single-object calls retain the existing scan.",
        ],
        "tradeoffs": [
            "Multi-object candidate grouping may need additional transient memory. The 65536-clip/64-object/128-request cases used about 0.56-0.57 MB instead of 0.08-0.10 MB. All raw signed memory and timing results are retained.",
            "Whole-file loading remains dominated by NPZ decoding; small inputs can be flat or slightly slower. Selected synthetic reference-API gains do not establish training speedups.",
            "Readonly byte fingerprints and weak-reference release checks run per case. File descriptor/thread/RSS checks are periodic observations, not general leak proofs or process memory limits.",
        ],
        "preservation": preservation,
        "review_files_sha256": {name: sha256(WORKSPACE / name) for name in CORE_FILES},
        "validation": validation,
        "uint64_integer_oracles": uint64,
        "frame_dtype_and_memmap_oracles": dtype_oracles,
        "dtype_provenance": dtype_provenance,
        "secondary_sampling_boundary_controls": boundary_controls,
        "fixed_library_retained_allocation_checks": retained,
        "sustained_probes": probes,
        "primary_performance_collected_before_sustained_probes": True,
        "performance": performances,
        "benchmark_provenance": provenance,
        "diagnostics": [
            {
                "path": "phase1-test-fixture",
                "classification": "New test fixture construction errors: readonly Fortran copies and transient masked views; 34 failed/144 passed before fixture correction, no runtime defect inferred.",
            },
            {
                "path": "phase2-uint64-contact",
                "classification": "New old-NumPy test exposed original unsigned isin IndexError; independently reproduced in initial source and fixed with ordinary-array domain comparisons.",
            },
            {
                "path": "phase3-list-candidates",
                "classification": "Intermediate Python-list grouping used more transient memory; replaced by compact integer buffers. Its earlier performance report is not final evidence.",
            },
            {
                "path": "phase4-harness-smoke",
                "classification": "Passed preliminary 50-case harness, exact script bytes preserved and hashed; final smoke/probes use the later guarded, shuffled harness.",
            },
            {
                "path": "phase5-dtype-corpus",
                "classification": "Passed initial 220-case dtype/48-case memmap corpus; final corpus adds the 262145-frame finite-reduction boundary and preserves the extreme-value replacement layout, with 275 dtype cases per environment.",
            },
            {
                "path": "phase6-rng-test-strengthening",
                "classification": "Earlier 200-new-case full suites passed. Strengthened the late-unknown RNG guard to use two candidate clips and added a captured-PCG64 ids/steps/next-draw compatibility test; final suites include 201 new cases. Runtime source remained frozen throughout.",
            },
        ],
        "evidence_selection": "Archive includes raw JSON/logs, executed scripts, original text source/test/benchmark/documentation snapshots and notices, final changed files and the figure. Generated NPZ datasets, caches, original binary robot/image assets and prior compressed evidence archives are excluded; initial hashes retain their identities. Dataset generators and file hashes are retained.",
    }
    if FIGURE_PATH.exists():
        figure_provenance = read_json(ROOT / "figure-provenance.json")
        assert figure_provenance["status"] == "passed"
        assert figure_provenance["figure_sha256"] == sha256(FIGURE_PATH)
        assert figure_provenance["script_sha256"] == sha256(ROOT / "scripts/plot.py")
        for name, expected in figure_provenance["input_reports_sha256"].items():
            assert sha256(ROOT / name) == expected, name
        report["figure"] = {
            "path": str(FIGURE_PATH.relative_to(WORKSPACE)),
            "sha256": sha256(FIGURE_PATH),
        }
        report["figure_provenance"] = figure_provenance
    smoke_path = ROOT / "benchmark-smoke.json"
    if smoke_path.exists():
        report["benchmark_smoke"] = read_json(smoke_path)
        assert report["benchmark_smoke"]["status"] == "passed"
        assert report["benchmark_smoke"]["benchmark_sha256"] == sha256(
            WORKSPACE / "benchmarks/motion_inputs.py"
        )
    if args.preview:
        (ROOT / "preview-report.json").write_text(
            json.dumps(report, indent=2, allow_nan=False) + "\n"
        )
        print(
            json.dumps(
                {
                    "status": report["status"],
                    "actual_elapsed_seconds": report["actual_elapsed_seconds"],
                    "path": str(ROOT / "preview-report.json"),
                }
            )
        )
        return
    assert FIGURE_PATH.exists() and smoke_path.exists()
    control = read_json(ROOT / "duration-gate-control.json")
    assert (
        control["status"] == "passed" and control["actual_elapsed_seconds"] < DURATION
    )
    assert control["reporter_sha256"] == sha256(Path(__file__))
    completions = read_json(ROOT / "session-completions.json")
    for name in PROBES:
        result = completions[name]
        assert result["exit_code"] == 0 and result["reaped"] is True
        assert not (Path("/proc") / str(result["pid"])).exists(), (
            "Owned probe still alive",
            name,
        )
    operator = read_json(ROOT / "operator-state.json")
    assert not operator["active_sessions"]
    gate = {
        "status": "passed",
        "required_elapsed_seconds": DURATION,
        "actual_elapsed_seconds": now - START,
        "start_utc": utc(START),
        "actual_utc": utc(now),
        "parallel_durations_added": False,
        "early_control": control,
    }
    (ROOT / "duration-gate.json").write_text(json.dumps(gate, indent=2) + "\n")
    members = collect_members()
    data = archive_bytes(members)
    count = verify_archive(data)
    with ARCHIVE_PATH.open("xb") as stream:
        stream.write(data)
    report["duration_gate"] = gate
    report["evidence_archive"] = {
        "path": str(ARCHIVE_PATH.relative_to(WORKSPACE)),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "regular_members": count,
    }
    with REPORT_PATH.open("x") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(
        json.dumps(
            {
                "status": report["status"],
                "actual_elapsed_seconds": now - START,
                "report": str(REPORT_PATH),
                "archive_members": count,
                "archive_bytes": len(data),
            }
        )
    )


if __name__ == "__main__":
    main()
