"""Fixed-library, long-lived-generator retained allocation checks after GC."""

import argparse
import gc
import hashlib
import json
import os
import sys
import time
import tracemalloc
import traceback
from pathlib import Path

import numpy as np

from endurance_support import atomic_json, resource_snapshot
from fixture import ROOT, fingerprint, make_input, source_hashes, versions

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--name", required=True)
parser.add_argument("--calls", type=int, default=5000)
args = parser.parse_args()
assert args.calls > 0 and args.calls % 100 == 0
started = time.time()
expected_source = source_hashes()
_, current = versions()
report = dict(
    name=args.name,
    status="running",
    pid=os.getpid(),
    python=sys.version,
    numpy=np.__version__,
    source_sha256=expected_source,
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    started_epoch=started,
    cases=[],
)


def progress(case_index, calls):
    atomic_json(
        ROOT / f"{args.name}-progress.json",
        {
            "status": "running",
            "pid": os.getpid(),
            "case_index": case_index,
            "completed_calls": calls,
            "updated_epoch": time.time(),
            "source_sha256": expected_source,
        },
    )


try:
    for case_index, (clips, objects, kind) in enumerate(
        ((4096, 2, "valid"), (65536, 64, "valid"), (65536, 2, "unknown-after-known"))
    ):
        arrays, metadata = make_input(
            [1 + i % 7 for i in range(clips)], bodies=1, joints=1, objects=objects
        )
        library = current.MotionClips(arrays, metadata)
        rng = np.random.default_rng(170517)
        requests = (
            [f"object-{i % objects}" for i in range(128)]
            if kind == "valid"
            else ["object-0", "missing", "object-0"]
        )
        before = fingerprint(arrays, metadata)

        def operation():
            try:
                result = library.sample(requests, rng)
            except ValueError as error:
                assert (
                    kind == "unknown-after-known"
                    and str(error) == "Unknown object: missing"
                )
            else:
                assert kind == "valid"
                assert result[0].shape == result[1].shape == (128,)

        for _ in range(100):
            operation()
        checkpoints = args.calls // 100
        live = np.empty(checkpoints, dtype=np.int64)
        peaks = np.empty(checkpoints, dtype=np.int64)
        rss = np.empty(checkpoints, dtype=np.int64)
        fds = np.empty(checkpoints, dtype=np.int64)
        threads = np.empty(checkpoints, dtype=np.int64)
        initial_resources = resource_snapshot()
        gc.collect()
        progress(case_index, 0)
        tracemalloc.start()
        try:
            for checkpoint in range(checkpoints):
                for _ in range(100):
                    operation()
                gc.collect()
                allocated, peak = tracemalloc.get_traced_memory()
                live[checkpoint] = allocated
                peaks[checkpoint] = peak
                resources = resource_snapshot()
                rss[checkpoint] = resources["rss_bytes"]
                fds[checkpoint] = resources["fds"]
                threads[checkpoint] = resources["python_threads"]
                assert resources["fds"] == initial_resources["fds"]
                assert (
                    resources["python_threads"] == initial_resources["python_threads"]
                )
                assert source_hashes() == expected_source
                progress(case_index, (checkpoint + 1) * 100)
                tracemalloc.reset_peak()
        finally:
            tracemalloc.stop()
        assert before == fingerprint(arrays, metadata)
        live_range = int(live.max() - live.min())
        assert live_range <= 64 * 1024, (case_index, live.tolist())
        report["cases"].append(
            dict(
                clips=clips,
                objects=objects,
                kind=kind,
                warmup_calls=100,
                traced_calls=args.calls,
                checkpoint_every_calls=100,
                live_traced_bytes_after_gc=live.tolist(),
                per_checkpoint_traced_peak_bytes=peaks.tolist(),
                live_range_bytes=live_range,
                net_live_change_bytes=int(live[-1] - live[0]),
                observed_rss_bytes=rss.tolist(),
                observed_fds=fds.tolist(),
                observed_python_threads=threads.tolist(),
                trace_growth_guard_bytes=64 * 1024,
                readonly_input_sha256=before,
            )
        )
        progress(case_index, args.calls)
        del operation, library, arrays, metadata, rng
        gc.collect()
    report.update(
        status="passed",
        finished_epoch=time.time(),
        elapsed_seconds=time.time() - started,
        scope="Fixed actual public libraries and long-lived NumPy generators; successful and late-error sample calls repeated under tracing. Inputs, generator and preallocated measurement arrays exist before tracing. Retained Python/NumPy allocations measured after explicit GC every 100 calls; progress/audit overhead is included. A 64-KiB live-range guard checks these finite runs. This does not establish a general leak proof or RSS/process memory cap. Four sustained probes remain active; tracing/work duration is not performance evidence.",
    )
    atomic_json(ROOT / f"{args.name}.json", report)
    atomic_json(
        ROOT / f"{args.name}-progress.json",
        {
            "status": "passed",
            "pid": os.getpid(),
            "updated_epoch": time.time(),
            "cases": len(report["cases"]),
            "traced_calls": sum(case["traced_calls"] for case in report["cases"]),
            "source_sha256": expected_source,
        },
    )
    print(
        json.dumps(
            {
                "name": args.name,
                "status": "passed",
                "elapsed_seconds": report["elapsed_seconds"],
                "live_ranges_bytes": [
                    case["live_range_bytes"] for case in report["cases"]
                ],
            }
        ),
        flush=True,
    )
except BaseException:
    report.update(
        status="failed", finished_epoch=time.time(), traceback=traceback.format_exc()
    )
    atomic_json(ROOT / f"{args.name}-failure.json", report)
    raise
