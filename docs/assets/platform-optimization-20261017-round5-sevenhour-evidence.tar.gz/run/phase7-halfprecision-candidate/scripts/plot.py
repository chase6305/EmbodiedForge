"""Standalone scientific SVG with all displayed values tied to raw reports."""

import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parents[1]
STEM = "platform-optimization-20261017-round5-sevenhour"
COLORS = {"initial": "#657389", "current": "#008c83"}
LABELS = {"initial": "Initial workspace", "current": "Optimized"}
plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "svg.fonttype": "none",
        "axes.spines.top": False,
        "axes.spines.right": False,
    }
)
fig, axes = plt.subplots(4, 2, figsize=(15, 15))
inputs = []
pipeline_values = []
for index, (python, numpy) in enumerate((("3.12", "2.5.4"), ("3.10", "1.24.4"))):
    path = ROOT / f"motion-inputs-performance-{python}-numpy{numpy}.json"
    data = json.loads(path.read_text())
    inputs.append(path)
    validation = [
        row
        for row in data["validation"]
        if row["dtype"] == "float32" and row["layout"] == "contiguous"
    ]
    sampling = [row for row in data["sampling"] if row["clips"] == 65536]
    for row, cases, xkey, title in (
        (
            index,
            validation,
            "frames",
            f"Validation | Python {python}, NumPy {numpy} | 16 bodies, 29 joints",
        ),
        (
            index + 2,
            sampling,
            "objects",
            f"Sampling | Python {python}, NumPy {numpy} | 65,536 clips, 128 requests",
        ),
    ):
        x = np.asarray([case[xkey] for case in cases])
        for column in (0, 1):
            ax = axes[row, column]
            for version in ("initial", "current"):
                y = np.asarray(
                    [
                        case[version]["median_seconds"] * 1000
                        if column == 0
                        else case[version]["peak_traced_bytes"] / 1024**2
                        for case in cases
                    ]
                )
                ax.plot(
                    x,
                    y,
                    "o-",
                    linewidth=2,
                    markersize=5,
                    color=COLORS[version],
                    label=LABELS[version],
                )
                if column == 0:
                    low = np.asarray(
                        [case[version]["q25_seconds"] * 1000 for case in cases]
                    )
                    high = np.asarray(
                        [case[version]["q75_seconds"] * 1000 for case in cases]
                    )
                    ax.fill_between(x, low, high, color=COLORS[version], alpha=0.12)
            ax.set_xscale("log", base=2)
            ax.set_yscale("log")
            ax.set_xticks(x)
            ax.set_xticklabels(
                [f"{value:,}" for value in x], rotation=20 if xkey == "frames" else 0
            )
            ax.set_xlabel(
                "Input frames" if xkey == "frames" else "Requested object kinds"
            )
            ax.set_ylabel(
                "Median time per call (ms)"
                if column == 0
                else "Temporary traced peak (MiB)"
            )
            ax.set_title(title, loc="left", fontsize=10, pad=12)
            ax.grid(True, which="major", color="#d7dde5", alpha=0.65)
            ax.set_axisbelow(True)
            if row == 0:
                ax.legend(loc="upper left", frameon=False)
            if xkey == "objects" and column == 1:
                ax.text(
                    0.98,
                    0.90,
                    "Multi-object indexing can use more scratch",
                    transform=ax.transAxes,
                    ha="right",
                    fontsize=9,
                    color="#4e5764",
                )
    pipeline_path = ROOT / f"file-pipeline-{python}-numpy{numpy}.json"
    pipeline = json.loads(pipeline_path.read_text())
    inputs.append(pipeline_path)
    pipeline_values.append(
        f"Python {python} / NumPy {numpy}: {pipeline['adapter'][0]['elapsed_reduction_percent']:.1f}%"
    )
fig.suptitle(
    "Motion inputs: CPU time and temporary allocations",
    x=0.07,
    y=0.985,
    ha="left",
    fontsize=20,
    fontweight="bold",
    color="#172c45",
)
fig.text(
    0.07,
    0.956,
    "Captured dirty workspace vs optimized source; 15 alternating pairs, median and time IQR. Shared, unpinned CPU host.",
    fontsize=10,
    color="#4e5764",
)
fig.text(
    0.07,
    0.055,
    "Validation/sampling exclude file loading, setup, result auditing and allocation tracing. Peaks exclude preloaded input arrays and are not RSS.",
    fontsize=9,
    color="#4e5764",
)
fig.text(
    0.07,
    0.037,
    "Separate cached file -> 16 sample/frame batches: time reduction "
    + "; ".join(pipeline_values)
    + ".",
    fontsize=9,
    color="#4e5764",
)
fig.text(
    0.07,
    0.019,
    "Selected synthetic NumPy reference API cases; whole-file load gains are small. No simulation or training throughput claim. Raw signed results are in the JSON report.",
    fontsize=9,
    color="#4e5764",
)
fig.subplots_adjust(
    left=0.07, right=0.98, top=0.92, bottom=0.11, hspace=0.64, wspace=0.24
)
output = WORKSPACE / "docs" / f"{STEM}-performance.svg"
fig.savefig(output, metadata={"Creator": "Matplotlib", "Date": None})
fig.savefig("/tmp/ef-round5-performance.png", dpi=100)
plt.close(fig)
assert b"<text" in output.read_bytes(), "SVG text must remain selectable"
report = {
    "status": "passed",
    "matplotlib_version": matplotlib.__version__,
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "input_reports_sha256": {
        str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in inputs
    },
    "figure": str(output.relative_to(WORKSPACE)),
    "figure_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
    "svg_text_selectable": True,
    "scope": "Scientific standalone SVG of selected CPU validation and sampling cases. Different Python/NumPy rows are separate measurements; compare initial/current within a row.",
}
(ROOT / "figure-provenance.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
