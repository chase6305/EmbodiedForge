"""Read-only process/source/progress audit with a compact append-only journal."""

import hashlib
import json
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parents[1]


def main():
    now = time.time()
    state = json.loads((ROOT / "state.json").read_text())
    assert state["start_epoch"] == 1792206355
    assert state["deadline_epoch"] == 1792231555
    assert state["required_elapsed_seconds"] == 25200
    assert not list(ROOT.glob("*-failure.json")), "A probe recorded a failure"
    frozen = json.loads((ROOT / "frozen-runtime.json").read_text())["sha256"]
    current = {
        str(path.relative_to(WORKSPACE)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted((WORKSPACE / "src").rglob("*.py"))
    }
    assert current == frozen, "Runtime source set or bytes changed"
    for name, digest in json.loads((ROOT / "frozen-harness.json").read_text())[
        "sha256"
    ].items():
        assert hashlib.sha256((WORKSPACE / name).read_bytes()).hexdigest() == digest, (
            name
        )
    operator = json.loads((ROOT / "operator-state.json").read_text())
    rows = {}
    for name, session in operator["active_sessions"].items():
        report = json.loads((ROOT / f"{name}-progress.json").read_text())
        assert report["status"] in ("running", "passed"), (name, report["status"])
        assert report["pid"] == session["pid"]
        assert report["source_sha256"]["current"] == session["source_sha256"]
        age = now - report["updated_epoch"]
        if report["status"] == "running":
            assert age < 90, (name, "progress stale", age)
            arguments = (
                (Path("/proc") / str(session["pid"]) / "cmdline")
                .read_bytes()
                .split(b"\0")
            )
            assert any(
                argument.endswith(session["script"].encode()) for argument in arguments
            ), arguments
            assert name.encode() in arguments, arguments
        resources = report["resources"]
        assert all(row["fds"] == resources[0]["fds"] for row in resources)
        assert all(
            row["python_threads"] == resources[0]["python_threads"] for row in resources
        )
        rows[name] = {
            "status": report["status"],
            "cases": report["cases"],
            "base_configurations": report["configuration_count"],
            "expected_base_configurations": report["base_configurations_expected"],
            "reference_input_frames": report["reference_input_frames"],
            "progress_age_seconds": age,
            "resources": resources[-1],
        }
    event = {
        "status": "passed",
        "epoch": now,
        "round_elapsed_seconds": now - state["start_epoch"],
        "remaining_to_deadline_seconds": max(0, state["deadline_epoch"] - now),
        "frozen_runtime_sources": len(frozen),
        "probes": rows,
    }
    encoded = json.dumps(event, separators=(",", ":"), allow_nan=False)
    with (ROOT / "monitor-audit.jsonl").open("a") as stream:
        stream.write(encoded + "\n")
    (ROOT / "monitor-latest.json").write_text(json.dumps(event, indent=2) + "\n")
    print(
        json.dumps(
            {
                "elapsed_seconds": event["round_elapsed_seconds"],
                "remaining_seconds": event["remaining_to_deadline_seconds"],
                "probes": {
                    name: {
                        key: row[key]
                        for key in (
                            "status",
                            "cases",
                            "base_configurations",
                            "expected_base_configurations",
                        )
                    }
                    for name, row in rows.items()
                },
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
