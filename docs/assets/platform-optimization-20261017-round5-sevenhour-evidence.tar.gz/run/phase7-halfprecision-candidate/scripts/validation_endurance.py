"""Exercise accepted and rejected full-format inputs across block boundaries."""

import itertools
import math
import random
import weakref

import numpy as np
from endurance_support import Run, invoke
from fixture import assert_equal, fingerprint, make_input, versions

FRAMES = (
    1,
    4095,
    4096,
    4097,
    8191,
    8192,
    8193,
    16383,
    16384,
    16385,
    65535,
    65536,
    65537,
    87383,
)
LAYOUTS = ("contiguous", "fortran", "reversed", "strided", "unaligned")
DTYPES = ("float32", "float64", ">f4")
CONFIGURATIONS = list(itertools.product(FRAMES, (1, 4, 16), LAYOUTS, DTYPES))
CONFIGURATIONS += [
    (262145, 1, layout, dtype) for layout, dtype in itertools.product(LAYOUTS, DTYPES)
]
random.Random(170517).shuffle(CONFIGURATIONS)
KINDS = (
    "valid",
    "valid",
    "valid",
    "valid",
    "tail-nan",
    "tail-inf",
    "bad-unit",
    "bad-contact",
    "fractional-contact",
    "wrong-shape",
    "wrong-dtype",
    "missing-field",
    "bad-fps",
    "bad-metadata",
    "bad-flags",
    "post-terminal",
    "length-overflow",
    "empty-object",
)
original, current = versions()


def case(index):
    frames, bodies, layout, dtype = CONFIGURATIONS[index % len(CONFIGURATIONS)]
    joints = (1, 17, 29)[(index // 7 + index // len(CONFIGURATIONS)) % 3]
    if frames == 262145:
        joints = 1
    clips = min(frames, 1 + index % 4)
    lengths = [frames // clips + (i < frames % clips) for i in range(clips)]
    arrays, metadata = make_input(
        lengths,
        bodies=bodies,
        joints=joints,
        dtype=dtype,
        layout=layout,
        seed=170517 + index,
    )
    kind = KINDS[(index // len(CONFIGURATIONS) + index) % len(KINDS)]
    if kind in ("tail-nan", "tail-inf"):
        field = ("joint_pos", "body_quat_w", "object_pos_w", "contact_label")[
            (index // 3) % 4
        ]
        value = arrays[field].copy()
        value.flat[-1] = np.nan if kind == "tail-nan" else np.inf
        value.flags.writeable = False
        arrays[field] = value
    elif kind == "bad-unit":
        field = "body_quat_w" if index % 2 else "object_quat_w"
        value = arrays[field].copy()
        value[-1] = 0
        value.flags.writeable = False
        arrays[field] = value
    elif kind in ("bad-contact", "fractional-contact"):
        value = arrays["contact_label"].copy()
        value.flat[-1] = 2 if kind == "bad-contact" else 0.5
        value.flags.writeable = False
        arrays["contact_label"] = value
    elif kind == "wrong-shape":
        arrays["joint_vel"] = arrays["joint_vel"][:-1]
    elif kind == "wrong-dtype":
        arrays["object_pos_w"] = arrays["object_pos_w"].astype(bool)
        arrays["object_pos_w"].flags.writeable = False
    elif kind == "missing-field":
        del arrays["object_ang_vel_w"]
    elif kind == "bad-fps":
        arrays["fps"] = np.array(float("nan") if index % 2 else 0)
        arrays["fps"].flags.writeable = False
    elif kind == "bad-metadata":
        metadata["quaternion_order"] = "xyzw"
    elif kind == "bad-flags":
        del arrays["terminated"]
    elif kind == "post-terminal":
        if max(lengths) > 1:
            value = arrays["terminated"].copy()
            value[0] = True
            value.flags.writeable = False
            arrays["terminated"] = value
        else:
            kind = "valid"
    elif kind == "length-overflow":
        value = arrays["motion_lengths"].astype(np.uint64)
        value[0] = 2**63
        value.flags.writeable = False
        arrays["motion_lengths"] = value
    elif kind == "empty-object":
        value = arrays["object_names"].copy()
        value[-1] = " "
        value.flags.writeable = False
        arrays["object_names"] = value
    refs = [weakref.ref(value) for value in arrays.values()]
    before = fingerprint(arrays, metadata)
    with np.errstate(all="ignore"):
        old, old_error = invoke(original.MotionClips, arrays, metadata)
        new, new_error = invoke(current.MotionClips, arrays, metadata)
    assert old_error == new_error, (index, kind, old_error, new_error)
    if kind == "valid":
        assert old_error is None, (index, old_error)
        assert_equal(old, new, arrays, metadata)
        assert new.starts.tolist() == [0, *itertools.accumulate(lengths)]
        # Independent scalar norms: random normalized quaternions should remain
        # well inside the tolerance; validation's last-axis reduction is not used.
        for field in ("body_quat_w", "object_quat_w"):
            for row in arrays[field][[0, -1]].reshape(-1, 4):
                norm = math.sqrt(math.fsum(float(x) ** 2 for x in row))
                assert abs(norm - 1) < 1e-3, (index, field, norm)
    else:
        assert old_error is not None, (index, kind)
    assert before == fingerprint(arrays, metadata), (index, "input modified")
    assert all(not value.flags.writeable for value in arrays.values())
    configuration = dict(frames=frames, bodies=bodies, layout=layout, dtype=dtype)
    return frames, configuration, kind, refs


run = Run(__doc__)
run.report["base_configurations_expected"] = len(CONFIGURATIONS)
run.report["negative_kinds"] = list(dict.fromkeys(KINDS))
try:
    while run.active():
        frames, configuration, kind, refs = case(run.report["cases"])
        assert all(ref() is None for ref in refs), (
            "Input array retained after completed case"
        )
        run.record(frames=frames, configuration=configuration, outcome=kind)
    if run.args.cases is None:
        assert len(run.report["configurations"]) == len(CONFIGURATIONS)
        assert set(KINDS) <= run.report["outcomes"].keys()
    run.finish()
except BaseException:
    if run.report["status"] != "stopped":
        run.failed()
    raise
