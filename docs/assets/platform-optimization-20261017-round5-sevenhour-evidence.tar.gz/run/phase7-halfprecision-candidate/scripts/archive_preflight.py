"""Validate an in-memory active evidence snapshot without final export."""

import hashlib
import json
import time

from report import (
    CORE_FILES,
    FIGURE_PATH,
    PROBES,
    ROOT,
    START,
    WORKSPACE,
    archive_bytes,
    collect_members,
    verify_archive,
)

members = collect_members()
payload = archive_bytes(members)
count = verify_archive(payload)
initial = json.loads((ROOT / "initial-hashes.json").read_text())
source_count = 0
for name, expected in initial.items():
    if name.startswith("src/") and name.endswith(".py"):
        assert hashlib.sha256(members["run/initial/" + name]).hexdigest() == expected
        source_count += 1
assert source_count == 105
validation = json.loads((ROOT / "validation-results.json").read_text())
for path, expected in validation["sha256"].items():
    if path.startswith(str(ROOT.relative_to(WORKSPACE)) + "/"):
        inside = "run/" + str(
            ROOT.__class__(path).relative_to(ROOT.relative_to(WORKSPACE))
        )
    else:
        inside = "final/" + path if path in CORE_FILES else "run/initial/" + path
    assert hashlib.sha256(members[inside]).hexdigest() == expected, inside
for name in PROBES:
    data = json.loads(members["run/" + name + "-progress.json"])
    for relative, expected in data["script_sha256"].items():
        assert hashlib.sha256(members["run/" + relative]).hexdigest() == expected
figure = json.loads((ROOT / "figure-provenance.json").read_text())
assert (
    hashlib.sha256(
        members["final/" + str(FIGURE_PATH.relative_to(WORKSPACE))]
    ).hexdigest()
    == figure["figure_sha256"]
)
report = {
    "status": "passed",
    "actual_epoch": time.time(),
    "actual_elapsed_seconds": time.time() - START,
    "archive_regular_members": count,
    "compressed_bytes": len(payload),
    "initial_runtime_sources_verified": source_count,
    "test_source_log_links_verified": len(validation["sha256"]),
    "all_four_progress_harnesses_verified": True,
    "figure_hash_verified": True,
    "gzip_crc_and_all_member_hashes_verified": True,
    "final_archive_created": False,
    "scope": "In-memory active snapshot; final archive will be built only after the real seven-hour gate and completed probes.",
}
(ROOT / "archive-preflight.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report))
