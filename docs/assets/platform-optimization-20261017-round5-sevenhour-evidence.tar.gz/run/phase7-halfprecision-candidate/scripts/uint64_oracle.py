"""Python integer domain oracle, original defect and real file-load checks."""
import hashlib
import itertools
import json
import sys
import time

import numpy as np

from fixture import ROOT, arrange, fingerprint, make_input, source_hashes, versions


def outcome(function,*args):
    try:
        result=function(*args)
    except Exception as error:
        return None,(type(error).__name__,str(error))
    return result,None


started=time.time()
original,current=versions()
rows=[]
files=[]
cases=list(itertools.product(("uint64",">u8"),(1,65538),("contiguous","fortran","reversed","strided"),(0,1,2,2**63,2**64-1)))
directory=ROOT/"datasets"/f"uint64-numpy{np.__version__}"
directory.mkdir(parents=True,exist_ok=True)
for index,(dtype,frames,layout,last) in enumerate(cases):
    arrays,metadata=make_input([frames],bodies=4,joints=17,owned=False,flags=False)
    labels=np.zeros((frames,4),dtype=dtype)
    labels[::2]=1
    labels[-1,-1]=last
    labels=arrange(labels,layout)
    arrays["contact_label"]=labels
    expected=all(int(value) in {-1,0,1} for value in labels.flat)
    before=fingerprint(arrays,metadata)
    old,old_error=outcome(original.MotionClips,arrays,metadata)
    new,new_error=outcome(current.MotionClips,arrays,metadata)
    assert (new_error is None)==expected,(index,new_error,expected)
    if not expected:
        assert new_error[0]=="ValueError" and new_error[1].startswith("contact_label must use"),new_error
    known_original_defect=old_error is not None and old_error[0]=="IndexError" and old_error[1]=="arrays used as indices must be of integer (or boolean) type"
    if not known_original_defect:
        assert old_error==new_error,(index,old_error,new_error)
    assert before==fingerprint(arrays,metadata)
    rows.append(dict(dtype=dtype,frames=frames,layout=layout,last=last,python_integer_oracle_accepted=expected,initial_error=old_error,current_error=new_error,known_original_unsigned_table_defect=known_original_defect))
    if expected and layout in ("contiguous","reversed"):
        path=directory/f"case-{index}.npz"
        with path.open("xb") as stream:
            np.savez_compressed(stream,metadata=np.array(json.dumps(metadata)),**arrays)
        result=current.MotionClips.load(path)
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        assert result.sha256==digest
        assert fingerprint(result.arrays,result.metadata)==before
        _,load_error=outcome(original.MotionClips.load,path)
        assert load_error==old_error,(index,load_error,old_error)
        files.append(dict(path=str(path),sha256=digest,bytes=path.stat().st_size,frames=frames,layout=layout,dtype=dtype,initial_error=load_error,current_accepted=True))
report=dict(status="passed",python=sys.version,numpy=np.__version__,source_sha256=source_hashes(),started_epoch=started,finished_epoch=time.time(),elapsed_seconds=time.time()-started,cases=len(rows),file_load_checks=len(files),known_original_defect_cases=sum(row["known_original_unsigned_table_defect"] for row in rows),observations=rows,files=files,scope="Independent Python int membership checks for readonly native/non-native uint64 labels including 2**63 and 2**64-1. Existing NumPy 1.24 isin signed-table IndexError is an intentional difference; all other original/current outcomes must match. Actual save/decode/hash validation checks included; no performance conclusion.")
path=ROOT/f"uint64-oracle-{sys.version_info.major}.{sys.version_info.minor}-numpy{np.__version__}.json"
with path.open("x") as stream:
    json.dump(report,stream,indent=2,allow_nan=False);stream.write("\n")
print(json.dumps({key:report[key] for key in ("status","numpy","cases","file_load_checks","known_original_defect_cases","elapsed_seconds")}),flush=True)
