"""Freeze identities of completed tests after checking actual tool exits."""

import hashlib
import json
import re
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parents[1]
records = []
for name, environment, session, expected in (
    ("full-tests-py310.log", "3.10 / NumPy 2.2.6", 42508, 2189),
    ("full-tests-py312.log", "3.12 / NumPy 2.5.4", 83175, 2251),
    ("focused-tests-numpy124.log", "3.10 / NumPy 1.24.4", 78961, 317),
):
    log = ROOT / name
    text = log.read_text()
    match = re.search(
        r"(\d+) passed, (\d+) skipped(?:, (\d+) warnings)? in ([0-9.]+)s", text
    )
    assert match and int(match[1]) == expected, (name, text[-1000:])
    records.append(
        {
            "environment": environment,
            "log": str(log.relative_to(WORKSPACE)),
            "passed": int(match[1]),
            "skipped": int(match[2]),
            "warnings": int(match[3] or 0),
            "pytest_seconds": float(match[4]),
            "session_id": session,
            "exit_code": 0,
            "reaped": True,
        }
    )
paths = list((WORKSPACE / "src").rglob("*.py")) + list(
    (WORKSPACE / "tests").glob("*.py")
)
paths.append(WORKSPACE / "benchmarks/motion_inputs.py")
paths.extend(WORKSPACE / record["log"] for record in records)
paths.extend(
    ROOT / name for name in ("ruff-check.log", "ruff-format.log", "diff-check.log")
)
assert (ROOT / "ruff-check.log").read_text().strip() == "All checks passed!"
assert "218 files already formatted" in (ROOT / "ruff-format.log").read_text()
assert not (ROOT / "diff-check.log").read_text()
hashes = {
    str(path.relative_to(WORKSPACE)): hashlib.sha256(path.read_bytes()).hexdigest()
    for path in sorted(paths)
}
report = {
    "status": "passed",
    "recorded_epoch": time.time(),
    "tests": records,
    "new_regression_cases": 201,
    "checks": [
        "ruff check src tests benchmarks examples",
        "ruff format --check src tests benchmarks examples",
        "git diff --check",
    ],
    "sha256": hashes,
}
(ROOT / "validation-results.json").write_text(json.dumps(report, indent=2) + "\n")
print(
    json.dumps(
        {"status": "passed", "tests": records, "hashed_files": len(hashes)}, indent=2
    )
)
