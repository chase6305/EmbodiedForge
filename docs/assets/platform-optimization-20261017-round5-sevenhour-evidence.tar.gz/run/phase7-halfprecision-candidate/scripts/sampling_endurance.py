"""Exact original/current samples and RNG states, plus independent clip bounds."""

import itertools
import random
import weakref

import numpy as np
from endurance_support import Run, state_digest
from fixture import fingerprint, make_input, versions

BIT_GENERATORS = (np.random.PCG64, np.random.MT19937, np.random.Philox, np.random.SFC64)
LIBRARIES = [(1, 1)] + list(itertools.product((64, 4096, 65536), (1, 4, 16, 64)))
CONFIGURATIONS = [
    (*library, batch, bit_generator)
    for library, batch, bit_generator in itertools.product(
        LIBRARIES, (0, 1, 7, 128, 4096), BIT_GENERATORS
    )
]
random.Random(170518).shuffle(CONFIGURATIONS)
KINDS = (
    "valid",
    "valid",
    "valid",
    "rotate-objects",
    "numpy-requests",
    "unknown-first",
    "unknown-after-known",
    "unhashable",
    "iterator-failure",
    "empty",
)
original, current = versions()


def sample(library, requests, rng):
    try:
        result = library.sample(requests(), rng)
    except Exception as error:
        return None, (type(error).__name__, str(error))
    return result, None


def case(index):
    clips, objects, batch, bit_generator = CONFIGURATIONS[index % len(CONFIGURATIONS)]
    lengths = [1 + (i * 3 + index) % 7 for i in range(clips)]
    arrays, metadata = make_input(
        lengths, bodies=1, joints=1, objects=objects, seed=171507 + index
    )
    old = original.MotionClips(arrays, metadata)
    new = current.MotionClips(arrays, metadata)
    requests = [f"object-{(i * 7 + index) % objects}" for i in range(batch)]
    kind = KINDS[(index // len(CONFIGURATIONS) + index) % len(KINDS)]
    old_rng = np.random.Generator(bit_generator(17513 + index))
    new_rng = np.random.Generator(bit_generator(17513 + index))
    if kind == "rotate-objects":
        # A successful earlier call must not leave a stale candidate cache.
        a = old.sample(requests, old_rng)
        b = new.sample(requests, new_rng)
        assert all(np.array_equal(x, y) for x, y in zip(a, b, strict=True))
        old.objects.reverse()
        new.objects.reverse()
    elif kind == "unknown-first":
        requests = ["missing", *requests]
    elif kind == "unknown-after-known":
        requests = ["object-0", "missing", "object-0", *requests]
    elif kind == "unhashable":
        requests = ["object-0", []]
    elif kind == "empty":
        requests = []
    before = fingerprint(arrays, metadata)
    refs = [weakref.ref(value) for value in arrays.values()]

    def request_factory():
        if kind == "numpy-requests":
            return np.asarray(requests, dtype=str)
        return iter(requests)

    if kind == "iterator-failure":

        def request_factory():
            yield "object-0"
            raise RuntimeError("request iterator failed")

    old_result, old_error = sample(old, request_factory, old_rng)
    new_result, new_error = sample(new, request_factory, new_rng)
    assert old_error == new_error, (index, old_error, new_error)
    assert state_digest(old_rng) == state_digest(new_rng), (index, "RNG state changed")
    checks = 0
    if kind in (
        "unknown-first",
        "unknown-after-known",
        "unhashable",
        "iterator-failure",
    ):
        assert old_error is not None, (index, kind)
    else:
        assert old_error is None, (index, kind, old_error)
        assert all(
            np.array_equal(x, y) for x, y in zip(old_result, new_result, strict=True)
        ), index
        ids, steps = new_result
        refs.extend(weakref.ref(value) for value in new_result)
        refs.extend(weakref.ref(value) for value in old_result)
        assert ids.shape == steps.shape == (len(requests),)
        assert ids.dtype == steps.dtype == np.dtype("int64")
        assert ids.flags.owndata and steps.flags.owndata
        assert [new.objects[int(i)] for i in ids] == requests
        assert ((steps >= 0) & (steps < new.lengths[ids])).all()
        if index % 7 == 0:
            offsets = np.array([0, 1, 7, 2**63 - 1], dtype=np.int64)
            a = old.frames(*old_result, offsets=offsets)
            b = new.frames(*new_result, offsets=offsets)
            for field in old.frame_fields:
                assert np.array_equal(a[field], b[field]), (index, field)
                assert b[field].flags.owndata
                refs.append(weakref.ref(a[field]))
                refs.append(weakref.ref(b[field]))
                for row in range(min(5, len(ids))):
                    clip = int(ids[row])
                    for future, offset in enumerate(offsets):
                        local = min(
                            int(steps[row]) + int(offset), int(new.lengths[clip]) - 1
                        )
                        global_index = int(new.starts[clip]) + local
                        assert np.array_equal(
                            b[field][row, future], arrays[field][global_index]
                        ), (index, field, clip, local)
                        checks += 1
    assert before == fingerprint(arrays, metadata), (index, "input modified")
    assert all(not value.flags.writeable for value in arrays.values())
    configuration = dict(
        clips=clips,
        objects=objects,
        batch_size=batch,
        bit_generator=bit_generator.__name__,
    )
    return sum(lengths), configuration, kind, refs, checks


run = Run(__doc__)
run.report["base_configurations_expected"] = len(CONFIGURATIONS)
run.report["independent_gather_element_checks"] = 0
try:
    while run.active():
        frames, configuration, kind, refs, checks = case(run.report["cases"])
        assert all(ref() is None for ref in refs), "Array retained after completed case"
        run.report["independent_gather_element_checks"] += checks
        run.record(frames=frames, configuration=configuration, outcome=kind)
    if run.args.cases is None:
        assert len(run.report["configurations"]) == len(CONFIGURATIONS)
        assert set(KINDS) <= run.report["outcomes"].keys()
    run.finish()
except BaseException:
    if run.report["status"] != "stopped":
        run.failed()
    raise
