"""Explore per-call candidate grouping, preserving the existing RNG schedule."""
import importlib.util
import json
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("fixture", ROOT / "initial/tests/test_motion_compare_blocks.py")
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)


def candidate(self, object_names, rng):
    requests = {}
    count = 0
    for index, name in enumerate(object_names):
        requests.setdefault(name, []).append(index)
        count += 1
    ids = np.empty(count, dtype=np.int64)
    groups = None
    if len(requests) > 1:
        groups = {}
        for index, name in enumerate(self.objects):
            groups.setdefault(name, []).append(index)
    for name, rows in requests.items():
        candidates = groups.get(name, []) if groups is not None else [i for i, obj in enumerate(self.objects) if obj == name]
        if not candidates:
            raise ValueError(f"Unknown object: {name}")
        ids[rows] = rng.choice(candidates, size=len(rows))
    return ids, rng.integers(self.lengths[ids])


rows = []
for clips in (64, 4096, 65536):
    motion = fixture.library([1] * clips, dtype="float32", bodies=1, joints=1)
    for groups in (1, 4, 16, 64):
        motion.objects[:] = [f"object-{i % groups}" for i in range(clips)]
        requested = [f"object-{i % groups}" for i in range(128)]
        a = np.random.default_rng(33)
        b = np.random.default_rng(33)
        expected = motion.sample(iter(requested), a)
        actual = candidate(motion, iter(requested), b)
        assert all(np.array_equal(x, y) for x, y in zip(actual, expected, strict=True))
        assert a.bit_generator.state == b.bit_generator.state
        samples = {"initial": [], "candidate": []}
        for pair in range(9):
            for name in (("initial", "candidate") if pair % 2 == 0 else ("candidate", "initial")):
                rng = np.random.default_rng(47)
                start = time.perf_counter()
                for _ in range(3):
                    if name == "initial":
                        motion.sample(iter(requested), rng)
                    else:
                        candidate(motion, iter(requested), rng)
                samples[name].append((time.perf_counter() - start) / 3)
        row = {"clips": clips, "objects": groups, "samples_seconds": samples, "medians_seconds": {name: float(np.median(values)) for name, values in samples.items()}}
        rows.append(row)
        print(json.dumps(row), flush=True)
(ROOT / "exploratory-sampling.json").write_text(json.dumps(rows, indent=2) + "\n")
