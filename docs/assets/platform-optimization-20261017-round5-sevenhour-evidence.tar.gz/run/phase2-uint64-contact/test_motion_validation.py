"""Large reference inputs keep field validation and caller ownership intact."""

import numpy as np
import pytest

from embodiedforge._motion_clips import MotionClips

FIELDS = {
    "joint_pos": (17,),
    "joint_vel": (17,),
    "body_pos_w": (4, 3),
    "body_quat_w": (4, 4),
    "body_lin_vel_w": (4, 3),
    "body_ang_vel_w": (4, 3),
    "object_pos_w": (3,),
    "object_quat_w": (4,),
    "object_lin_vel_w": (3,),
    "object_ang_vel_w": (3,),
    "contact_label": (4,),
}


def motion_arrays(frames, dtype="float32"):
    metadata = {
        "schema": "ef-motion-v1",
        "robot": "validation-fixture",
        "joint_names": [f"joint-{i}" for i in range(17)],
        "body_names": [f"body-{i}" for i in range(4)],
        "quaternion_order": "wxyz",
        "coordinate_frame": "world",
    }
    arrays = {
        "fps": np.array(50.0),
        "motion_lengths": np.array([frames]),
        "motion_names": np.array(["clip"]),
        "object_names": np.array(["box"]),
    }
    for field, tail in FIELDS.items():
        seed = [1, 0, 0, 0] if "quat" in field else 0
        arrays[field] = np.broadcast_to(np.array(seed, dtype=dtype), (frames, *tail))
    return arrays, metadata


def arrange(value, order):
    if order == "fortran":
        return np.array(value, order="F", copy=True)
    if order == "reversed":
        return value[::-1].copy()[::-1]
    if order == "strided":
        return np.repeat(value, 2, axis=0)[::2]
    return value.copy()


@pytest.mark.parametrize("field", FIELDS)
@pytest.mark.parametrize("dtype", ["float32", "float64", ">f4"])
@pytest.mark.parametrize("order", ["contiguous", "fortran", "reversed", "strided"])
def test_large_fields_reject_nonfinite_tail_without_mutating_inputs(
    field, dtype, order
):
    frames = 262144 // int(np.prod(FIELDS[field])) + 2
    arrays, metadata = motion_arrays(frames, dtype)
    value = arrange(arrays[field], order)
    value.flags.writeable = False
    arrays[field] = value
    before = value.tobytes()
    result = MotionClips(arrays, metadata)
    assert result.arrays is arrays and result.metadata is metadata
    assert result.starts.tolist() == [0, frames]
    assert value.tobytes() == before and not value.flags.writeable
    for invalid in (np.nan, np.inf, -np.inf):
        bad = arrange(value, order)
        bad.flat[-1] = invalid
        bad.flags.writeable = False
        arrays[field] = bad
        before = bad.tobytes()
        with pytest.raises(ValueError, match=f"{field} must be finite numeric"):
            MotionClips(arrays, metadata)
        assert bad.tobytes() == before and not bad.flags.writeable


@pytest.mark.parametrize(
    "dtype", ["float16", "float32", "float64", ">f8", "longdouble"]
)
@pytest.mark.parametrize("order", ["contiguous", "fortran", "reversed", "strided"])
@pytest.mark.parametrize("field", ["body_quat_w", "object_quat_w"])
def test_large_unit_quaternion_tolerance_keeps_boundary_decisions(dtype, order, field):
    frames = 262144 // int(np.prod(FIELDS[field])) + 2
    arrays, metadata = motion_arrays(frames, dtype)
    scalar = np.dtype(dtype).type
    tolerance = np.longdouble(1e-3)
    for edge in (scalar(0.999), scalar(1.001)):
        for target in (scalar(0), scalar(1), scalar(2)):
            scale = np.nextafter(edge, target)
            value = arrange(arrays[field], order)
            value[-1] = 0
            value[-1, ..., 0] = scale
            value.flags.writeable = False
            candidate = {**arrays, field: value}
            expected = abs(np.longdouble(scale) - 1) <= tolerance
            if expected:
                MotionClips(candidate, metadata)
            else:
                with pytest.raises(ValueError, match=f"{field} must contain unit"):
                    MotionClips(candidate, metadata)
            assert not value.flags.writeable


@pytest.mark.parametrize("dtype", ["int8", "uint64", ">i8", "float32"])
def test_large_contact_domain_checks_the_final_element(dtype):
    arrays, metadata = motion_arrays(65538, dtype)
    value = arrays["contact_label"].copy()
    value[::2] = 1
    MotionClips({**arrays, "contact_label": value}, metadata)
    if np.dtype(dtype).kind != "u":
        value[::3] = -1
        MotionClips({**arrays, "contact_label": value}, metadata)
    value[-1, -1] = 2
    value.flags.writeable = False
    with pytest.raises(ValueError, match="contact_label must use"):
        MotionClips({**arrays, "contact_label": value}, metadata)


def test_large_masked_finite_reduction_preserves_hidden_payload_semantics():
    arrays, metadata = motion_arrays(16386)
    value = arrays["joint_pos"].copy()
    mask = np.zeros(value.shape, dtype=bool)
    value[-1] = np.nan
    mask[-1] = True
    value.flags.writeable = False
    mask.flags.writeable = False
    masked = np.ma.array(value, mask=mask, copy=False)
    masked.flags.writeable = False
    arrays["joint_pos"] = masked
    MotionClips(arrays, metadata)
    assert np.isnan(masked.data[-1]).all() and masked.mask[-1].all()
    assert not masked.data.flags.writeable and not masked.mask.flags.writeable


def test_large_subclass_all_reduction_is_not_replaced():
    class RejectAll(np.ndarray):
        def all(self, *args, **kwargs):
            return False

    arrays, metadata = motion_arrays(16386)
    arrays["joint_pos"] = arrays["joint_pos"].view(RejectAll)
    with pytest.raises(ValueError, match="joint_pos must be finite"):
        MotionClips(arrays, metadata)
