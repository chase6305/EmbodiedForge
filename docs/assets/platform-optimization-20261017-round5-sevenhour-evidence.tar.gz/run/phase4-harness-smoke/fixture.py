"""Full-format owned motion fixtures; independent of either validator."""
import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def versions():
    return (
        load_module("initial_clips", ROOT / "initial/src/embodiedforge/_motion_clips.py"),
        load_module("current_clips", ROOT.parents[1] / "src/embodiedforge/_motion_clips.py"),
    )


def arrange(value, layout):
    if layout == "fortran":
        value = np.array(value, order="F", copy=True)
    elif layout == "reversed":
        value = value[::-1].copy()[::-1]
    elif layout == "strided":
        value = np.repeat(value, 2, axis=0)[::2]
    elif layout == "unaligned":
        destination = np.ndarray(value.shape, dtype=value.dtype, buffer=bytearray(value.nbytes + 1), offset=1)
        destination[:] = value
        value = destination
    else:
        value = value.copy()
    value.flags.writeable = False
    return value


def make_input(lengths, *, bodies=16, joints=29, dtype="float32", layout="contiguous", objects=4, seed=170513, flags=True, owned=True):
    rng = np.random.default_rng(seed)
    total = sum(lengths)
    count = len(lengths)
    metadata = dict(schema="ef-motion-v1", robot="input-fixture", joint_names=[f"joint-{i}" for i in range(joints)], body_names=[f"body-{i}" for i in range(bodies)], coordinate_frame="world", quaternion_order="wxyz")
    arrays = dict(fps=np.array(50.0), motion_lengths=np.asarray(lengths, dtype=np.int64), motion_names=np.asarray([f"clip-{i}" for i in range(count)]), object_names=np.asarray([f"object-{i % objects}" for i in range(count)]))
    shapes = dict(joint_pos=(total,joints), joint_vel=(total,joints), body_pos_w=(total,bodies,3), body_quat_w=(total,bodies,4), body_lin_vel_w=(total,bodies,3), body_ang_vel_w=(total,bodies,3), object_pos_w=(total,3), object_quat_w=(total,4), object_lin_vel_w=(total,3), object_ang_vel_w=(total,3), contact_label=(total,bodies))
    for key, shape in shapes.items():
        kind = np.dtype(dtype).kind
        if not owned:
            seed_value = [1,0,0,0] if "quat" in key else 0
            value = np.broadcast_to(np.asarray(seed_value,dtype=dtype),shape)
            arrays[key] = value
            continue
        if "quat" in key:
            if kind in "iu":
                value = np.zeros(shape, dtype=dtype)
                value[...,0] = 1
            else:
                value = rng.normal(size=shape)
                value /= np.linalg.norm(value,axis=-1,keepdims=True)
                value = value.astype(dtype)
        elif key == "contact_label":
            value = rng.integers(0 if kind == "u" else -1,2,size=shape).astype(dtype)
        elif kind in "iu":
            value = rng.integers(0,7,size=shape).astype(dtype)
        else:
            value = rng.normal(scale=0.2,size=shape).astype(dtype)
        arrays[key] = arrange(value, layout)
    if flags:
        for key in ("terminated","truncated","clip_end"):
            arrays[key] = np.zeros(total,dtype=bool)
        arrays["clip_end"][np.cumsum(lengths)-1] = True
        for key in ("terminated","truncated","clip_end"):
            arrays[key].flags.writeable = False
    for value in arrays.values():
        value.flags.writeable = False
    return arrays,metadata


def fingerprint(arrays,metadata):
    digest = hashlib.sha256(json.dumps(metadata,sort_keys=True).encode())
    for key,value in sorted(arrays.items()):
        digest.update(key.encode())
        digest.update(str((value.shape,value.dtype.str)).encode())
        if isinstance(value,np.ma.MaskedArray):
            digest.update(value.data.tobytes())
            digest.update(np.ma.getmaskarray(value).tobytes())
        else:
            digest.update(value.tobytes())
    return digest.hexdigest()


def assert_equal(old,new,arrays,metadata):
    assert old.arrays is new.arrays is arrays
    assert old.metadata is new.metadata is metadata
    assert old.names == new.names and old.objects == new.objects
    assert old.fps == new.fps
    assert np.array_equal(old.lengths,new.lengths)
    assert np.array_equal(old.starts,new.starts)
    assert old.frame_fields == new.frame_fields


def source_hashes():
    paths = {"initial":ROOT / "initial/src/embodiedforge/_motion_clips.py", "current":ROOT.parents[1] / "src/embodiedforge/_motion_clips.py"}
    return {name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in paths.items()}
