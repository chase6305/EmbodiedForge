"""Isolate input changes around the original and current constructors."""

import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts/subclass_endurance.py"
namespace = {"__file__": str(SCRIPT), "__name__": "subclass_diagnostic"}
exec(compile(SCRIPT.read_text().split("run = Run(__doc__)")[0], str(SCRIPT), "exec"), namespace)
fingerprint = namespace["fingerprint"]
invoke = namespace["invoke"]
capture = {}
checks = 0


def contents(arrays, metadata):
    result = {"metadata": json.dumps(metadata, sort_keys=True).encode()}
    for key, value in sorted(arrays.items()):
        result[key + ":description"] = str((value.shape, value.dtype.str)).encode()
        if isinstance(value, np.ma.MaskedArray):
            result[key + ":data"] = value.data.tobytes()
            result[key + ":mask"] = np.ma.getmaskarray(value).tobytes()
        else:
            result[key + ":data"] = value.tobytes()
    return result


def verify(stage, arrays, metadata):
    global checks
    actual = contents(arrays, metadata)
    changes = []
    for key in sorted(capture["bytes"].keys() | actual.keys()):
        previous = capture["bytes"].get(key, b"")
        following = actual.get(key, b"")
        if previous != following:
            offsets = [i for i, (a, b) in enumerate(zip(previous, following)) if a != b]
            changes.append(dict(field=key, offsets=offsets[:64], before_length=len(previous), after_length=len(following)))
            name = key.replace(":", "-")
            (ROOT / f"subclass-diagnostic-{name}-before.bin").write_bytes(previous)
            (ROOT / f"subclass-diagnostic-{name}-after.bin").write_bytes(following)
    current_hash = fingerprint(arrays, metadata)
    checks += 1
    if changes or current_hash != capture["hash"]:
        failure = dict(status="failed", epoch=time.time(), index=capture["index"], stage=stage, changes=changes, before=capture["hash"], after=current_hash)
        (ROOT / "subclass-input-diagnostic-failure.json").write_text(json.dumps(failure, indent=2) + "\n")
        raise AssertionError(failure)


def checked_fingerprint(arrays, metadata):
    if "bytes" not in capture:
        capture["bytes"] = contents(arrays, metadata)
        capture["hash"] = fingerprint(arrays, metadata)
    verify("fingerprint", arrays, metadata)
    return fingerprint(arrays, metadata)


def checked_invoke(constructor, arrays, metadata):
    label = "original" if constructor is namespace["original"].MotionClips else "current"
    verify("before-" + label, arrays, metadata)
    result = invoke(constructor, arrays, metadata)
    verify("after-" + label, arrays, metadata)
    return result


namespace["fingerprint"] = checked_fingerprint
namespace["invoke"] = checked_invoke
started = time.time()
indices = [115660] * 1000 + list(range(115000, 116001))
for position, index in enumerate(indices):
    capture.clear()
    capture["index"] = index
    namespace["case"](index)
    if position % 100 == 0:
        print(json.dumps(dict(completed=position + 1, checks=checks, elapsed_seconds=time.time() - started)), flush=True)
report = dict(status="passed", started_epoch=started, finished_epoch=time.time(), cases=len(indices), stage_checks=checks, source_sha256=namespace["current"].__file__, harness_sha256=hashlib.sha256(SCRIPT.read_bytes()).hexdigest(), script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), scope="Direct before/after byte snapshots around each constructor; an unreproduced failure remains unclassified.")
(ROOT / "subclass-input-diagnostic.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report), flush=True)
