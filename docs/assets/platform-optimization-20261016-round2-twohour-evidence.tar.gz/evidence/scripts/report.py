"""Scoped round-two report, gated on the original actual two-hour deadline."""
import argparse,hashlib,json,os,tarfile,time
from datetime import datetime,timezone
from pathlib import Path
root=Path(__file__).resolve().parent.parent;repo=Path.cwd()
p=argparse.ArgumentParser();p.add_argument('--preview',action='store_true');a=p.parse_args()
def load(name):return json.loads((root/name).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def owned_processes():
 result=[]
 for directory in Path('/proc').iterdir():
  if not directory.name.isdigit() or int(directory.name)==os.getpid():continue
  try:
   argv=[v.decode() for v in (directory/'cmdline').read_bytes().split(b'\0') if v]
   if argv and Path(argv[0]).name.startswith('python') and any(str(root) in v or 'runs/platform-optimization-20261016-round2-twohour/scripts/' in v for v in argv):result.append(dict(pid=int(directory.name),command=argv))
  except (FileNotFoundError,PermissionError):continue
 return result
state=load('state.json');observed=time.time();elapsed=observed-state['started_epoch'];checks=load('final-checks.json')
assert checks['status']=='passed'
assert all(sha(root/'baseline'/Path(f).relative_to('src'))==h for f,h in state['initial_source_hashes'].items())
assert all(sha(root/f)==h for f,h in load('stress-script-hashes.json')['sha256'].items())
assert all(sha(repo/f)==h for f,h in checks['source_hashes'].items())
data_hash=sha(repo/'src/embodiedforge/data.py');policy_hash=sha(repo/'src/embodiedforge/policies.py');render_hash=sha(repo/'src/embodiedforge/backends/render.py')
executor=load('executor-comparison.json');sparse=load('sparse-executor-comparison.json');renderer=load('render-comparison.json');replication=load('render-replication.json');pipeline=load('full-pipeline-comparison.json');faults=load('collection-fault-cycles.json');smoke=load('benchmark-smoke.json')
assert executor['source_sha256']['candidate']==sparse['source_sha256']['candidate']==policy_hash
assert executor['source_sha256']['benchmark']==smoke['benchmark_sha256']==sha(repo/'benchmarks/action_executor.py')
assert renderer['source_sha256']['candidate']==replication['source_sha256']['candidate']==sha(root/'scripts/render_prototype.py')==render_hash
assert renderer['source_sha256']['benchmark']==replication['source_sha256']['benchmark']==sha(repo/'benchmarks/raster.py')
assert faults['status']==smoke['status']=='passed' and faults['source_sha256']==data_hash and faults['test_source_sha256']==sha(repo/'tests/test_recorder_collection_atomic.py')
for row in pipeline['cases']:
 for result in row['runs']['candidate']:
  assert result['source_sha256']['data.py']==data_hash and result['source_sha256']['backends/render.py']==render_hash
signals=[load(f'collection-signals-{label}.json') for label in ('py310','py312')];joins=[load(f'real-signals-{label}.json') for label in ('py310','py312')]
large_oracles=[json.loads(f.read_text()) for f in sorted(root.glob('large-executor-oracle-*.json'))]
assert len(large_oracles)==2 and all(r['status']=='passed' and r['source_sha256']['candidate']==policy_hash and r['source_sha256']['integer_oracle']==sha(repo/'tests/test_executor_metadata.py') for r in large_oracles)
mixed_faults=[load(f'mixed-collection-faults-{label}.json') for label in ('py310','py312')]
assert all(r['status']=='passed' and r['source_sha256']==data_hash for r in mixed_faults)
assert all(report['status']=='passed' for report in signals+joins)
assert all(row['source_sha256']==data_hash for report in signals+joins for row in report['rows'])
recording=load('endurance-progress.json' if a.preview else 'endurance.json');actions=load('executor-endurance-progress.json' if a.preview else 'executor-endurance.json');rendering=load('render-endurance-progress.json' if a.preview else 'render-endurance.json')
if not a.preview:
 assert elapsed>=state['required_seconds'],(elapsed,state['required_seconds'])
 assert recording['status']==actions['status']==rendering['status']=='passed'
 assert recording['workers']['candidate']['source']['data.py']==data_hash and recording['workers']['candidate']['source']['backends/render.py']==render_hash
 assert actions['source_sha256']['candidate']==policy_hash and rendering['source_sha256']['candidate']==render_hash
 assert actions['source_sha256']['integer_oracle']==sha(repo/'tests/test_executor_metadata.py')
 assert not list(root.glob('*failure.json'))
 processes=owned_processes();assert not processes,processes

def resources(samples,worker=None):
 values=[s['resources'][worker] if worker else s['resources'] for s in samples]
 return dict(fd_values=sorted({s['fd'] for s in values}),thread_values=sorted({s['threads'] for s in values}),min_sampled_rss_bytes=min(s['rss_bytes'] for s in values),max_sampled_rss_bytes=max(s['rss_bytes'] for s in values),last_sample=values[-1])
def compact_stress(report,kind):
 result={k:v for k,v in report.items() if k not in ('samples','coverage')}
 if isinstance(report.get('coverage'),(int,float)):result['coverage']=report['coverage']
 elif isinstance(report.get('coverage'),list):result['coverage_count']=len(report['coverage'])
 if 'samples' in report:
  result['sample_count']=len(report['samples']);result['resources']=({name:resources(report['samples'],name) for name in ('baseline','candidate')} if kind=='recording' else resources(report['samples']))
 return result

def compact_pairs(report,time_key='seconds'):
 rows=[]
 for row in report['cases']:
  selected={k:v for k,v in row.items() if k!='runs'}
  selected['seconds']={name:[r[time_key] for r in group] for name,group in row['runs'].items()}
  if 'action_sha256' in row['runs']['baseline'][0]:
   selected['action_sha256']=row['runs']['baseline'][0]['action_sha256']
  elif 'sha256' in row['runs']['baseline'][0]:selected['sha256']=row['runs']['baseline'][0]['sha256']
  rows.append(selected)
 return {k:v for k,v in report.items() if k!='cases'}|dict(cases=rows)
duration=dict(started_epoch=state['started_epoch'],deadline_epoch=state['deadline_epoch'],observed_epoch=observed,elapsed_seconds=elapsed,required_seconds=state['required_seconds'],requirement_met=elapsed>=state['required_seconds'],started_utc=datetime.fromtimestamp(state['started_epoch'],timezone.utc).isoformat(),observed_utc=datetime.fromtimestamp(observed,timezone.utc).isoformat(),scope='Actual wall clock from this round start; parallel task durations are not summed.')
report=dict(
 schema_version=1,date='2026-10-16',round='second-two-hour-round',status='active' if a.preview else 'complete',preview_only=a.preview,duration=duration,
 baseline_revision=state['baseline_revision'],initial_worktree_status=state['initial_status'],environment=load('environment.json'),
 changes=[
  dict(component='Completed background-write collection',paths=['src/embodiedforge/data.py','tests/test_recorder_collection_atomic.py'],behavior='Snapshot buffered-byte and completion counts before committing a successful future. If a caller exception interrupts those updates or handle removal, restore this record and counters so append/close retries cannot double-account it. Previously committed records stay committed. Does not resubmit NPZ writes.'),
  dict(component='Trusted internal executor resets',paths=['src/embodiedforge/policies.py','benchmarks/action_executor.py'],behavior='Use a private row-clear operation for internally generated unique, in-range changed-row indices and skip the empty-row call. Public reset retains type/dimension/uniqueness/range validation. Repeated identity benchmark flag and timed policy-call counts expose actual replanning frequency; ownership and tracking behavior remain covered by the integer queue oracle.'),
  dict(component='CPU raster depth conversion',paths=['src/embodiedforge/backends/render.py','tests/test_raster.py'],behavior='Build one boolean validity mask and multiply directly into float32 depth, avoiding float64 intermediate depth and a duplicate validity comparison. All output channels own independent arrays. Prototype source exactly matches the adopted complete render.py file.')],
 validation=dict(full_suites=[{k:v for k,v in row.items() if k!='tail'}|dict(result=row['tail'][-1]) for row in checks['results']],source_hashes=checks['source_hashes'],test_environment=dict(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),new_test_cases=76,new_test_breakdown=dict(collection_interruptions=52,depth_pixels_and_ownership=24),initial_negative_control=dict(failed_cases=6,trigger='One caller interruption immediately before successful future handle removal; two real completed episodes counted as three',log='collection-before.log',test_source='negative-control-test.py'),real_collection_signals=[dict(python=r['python'],passed_cases=r['passed_cases'],baseline_expected_failures=len(r['baseline_negative_controls']),scope=r['scope']) for r in signals],real_join_signals=[dict(python=r['python'],passed_cases=r['passed_cases'],baseline_positive_controls=len(r['baseline_positive_controls']),scope=r['scope']) for r in joins],benchmark_cli=smoke,large_executor_oracles=large_oracles,style=load('style-checks.json')),
 collection_fault_cycles=faults,mixed_collection_faults=mixed_faults,
 performance=dict(executor=compact_pairs(executor),sparse_executor=compact_pairs(sparse),executor_call_profile=load('executor-profile.json'),raster=compact_pairs(renderer),raster_replication=compact_pairs(replication),raster_adoption=dict(prototype_sha256=render_hash,final_source_sha256=render_hash,exact_whole_file_match=True),full_pipeline=compact_pairs(pipeline,'seconds_including_close')),
 stress=dict(recording=compact_stress(recording,'recording'),executor=compact_stress(actions,'executor'),rendering=compact_stress(rendering,'rendering'),earlier_recording_stage=load('phase1/recording-summary.json')),
 reproduction=dict(working_directory='Repository root matching final source hashes; extract the archive elsewhere first. Baseline package and harness paths in evidence/ are self-relative. Optional dependencies/assets are supplied by the checkout, not the archive.',current_executor='OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONPATH=src python benchmarks/action_executor.py --metadata --repeat-every 16 --output /tmp/executor-r2.json',current_raster='OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONPATH=src python benchmarks/raster.py --num-envs 32 --image-size 128 --frames 50 --channels rgb depth --output /tmp/raster-r2.json',paired_experiments='Run executor_compare.py, sparse_executor_compare.py, render_compare.py, render_replicate.py or full_pipeline_compare.py from the extracted evidence/scripts/ using the recorded Python and repository cwd. These rewrite measurements only inside the extracted evidence tree.',endurance='endurance.py, executor_endurance.py and render_endurance.py accept --until with a future Unix UTC epoch. The recorded absolute default is this study stop time.'),
 figure='platform-optimization-20261016-round2-twohour-performance.svg',
 limits=[
  'All measurements are CPU reference workloads on a shared unpinned host; neural inference, GPU training, real robots and web delivery are outside these timings.',
  'Continuous-frame executor measurements are essentially flat. Larger benefits occur with repeated observations and depend on affected-row count, frequency, N and action layout; no uniform executor or training throughput gain is established.',
  'Raster depth-only and RGB/depth cases improve, but four-channel cases and the RGB-only control vary. Traced allocation peaks can remain flat when other channels dominate; they are not process RSS or GPU memory.',
  'Whole-package acquisition timings include positive and negative cases. A uniform end-to-end acquisition gain has not been established; all paired samples and the earlier renderer-stage diagnostic are archived.',
  'Fault tests cover single interruptions of successful collection bookkeeping, selected rollback/removal failures and shutdown waits; they do not establish transactional cancellation at every arbitrary bytecode or interruption during rollback itself.',
  'SIGTERM controllers install a handler raising SystemExit143. Default process-killing SIGTERM cleanup is not claimed.',
  'FD/Python-thread checks and recorder weakref collection apply to tested cases; sampled RSS and payload-size budgets are not general leak proofs or hard process-memory bounds. Optional test skips remain in the recorded environment.'])
if not a.preview:
 report['final_process_audit']=dict(status='passed',observed_epoch=time.time(),matching_processes=processes,scope='Exact-run Python command-path scan; excludes reporter and unrelated jobs. Recording controller waits/reaps both worker processes.')
 (root/'duration-gate.json').write_text(json.dumps(duration,indent=2)+'\n')
 archive=repo/'docs/assets/platform-optimization-20261016-round2-twohour-evidence.tar.gz'
 evidence=[f for f in root.rglob('*') if f.is_file() and '__pycache__' not in f.parts and f.name!='report-preview.json' and (f.suffix in ('.py','.json','.log','.patch','.pstats','.txt','.html','.js') or f.name.startswith(('LICENSE','NOTICE')))]
 paths=['src/embodiedforge/data.py','src/embodiedforge/policies.py','src/embodiedforge/backends/render.py','tests/test_recorder_collection_atomic.py','tests/test_raster.py','tests/test_executor_metadata.py','tests/test_recorder_close.py','tests/test_recorder_duplicates.py','tests/test_ordered_batches.py','benchmarks/action_executor.py','benchmarks/raster.py','benchmarks/recording_pipeline.py','pyproject.toml','docs/interfaces.md','docs/platform-optimization-20261016-round2-twohour-performance.svg']
 paths.extend(name for name in ('LICENSE','LICENSE.md','NOTICE','NOTICE.md') if (repo/name).is_file())
 with tarfile.open(archive,'w:gz') as stream:
  for f in sorted(evidence):stream.add(f,arcname=str(Path('evidence')/f.relative_to(root)),recursive=False)
  for path in paths:stream.add(repo/path,arcname=str(Path('final')/path),recursive=False)
 report['evidence_archive']=dict(path=str(archive.relative_to(repo)),sha256=sha(archive),bytes=archive.stat().st_size,scope='Exact initial package source, final changed source/tests/benchmark excerpts, all harnesses, raw timings/profiles/logs and intentional prior-stage evidence. Synthetic datasets regenerate from scripts; optional external SDK assets and installed dependencies are excluded.')
out=root/'report-preview.json' if a.preview else repo/'docs/platform-optimization-20261016-round2-twohour.json'
out.write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n');print(json.dumps(dict(path=str(out),status=report['status'],elapsed_seconds=elapsed,requirement_met=duration['requirement_met'])))
