import gc
import hashlib
import importlib.util
import json
import statistics
import sys
import tempfile
from pathlib import Path

import numpy as np
import embodiedforge.data as candidate
from embodiedforge import VectorEnv
from embodiedforge.tasks import ReachTask

root=Path(__file__).resolve().parent.parent


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec)
    sys.modules[name]=result
    spec.loader.exec_module(result)
    return result


class TimeoutTask(ReachTask):
    def evaluate(self,state,actions,previous):
        count=len(state.time)
        return np.zeros(count,np.float32),np.zeros(count,bool),np.zeros(count,bool)


baseline=module('embodiedforge._pipeline_baseline_data',root/'baseline/embodiedforge/data.py')
benchmark=module('twohour_pipeline_benchmark',Path.cwd()/'benchmarks/recording_pipeline.py')
benchmark.measure.__globals__['VectorEnv']=lambda config:VectorEnv(config,task=TimeoutTask())
proof=dict(baseline=hashlib.sha256(Path(baseline.__file__).read_bytes()).hexdigest(),candidate=hashlib.sha256(Path(candidate.__file__).read_bytes()).hexdigest())
rows=[]
for noise in (False,True):
    for layout in ('transitions','compact'):
        for workers in (0,1,2):
            runs={name:[] for name in ('baseline','candidate')}
            for repeat in range(6):
                order=[('baseline',baseline),('candidate',candidate)]
                if repeat%2:
                    order.reverse()
                for name,implementation in order:
                    benchmark.measure.__globals__['EpisodeRecorder']=implementation.EpisodeRecorder
                    gc.collect()
                    with tempfile.TemporaryDirectory(prefix='ef-twohour-pipeline-') as temporary:
                        result=benchmark.measure(Path(temporary)/'run',workers=workers,episode_format=layout,num_envs=4,steps=40,cycles=3,image_size=64,budget_mib=12,noise=noise)
                    if repeat:
                        runs[name].append(result)
            assert len({row['sha256'] for group in runs.values() for row in group})==1
            medians={name:statistics.median(row['seconds_including_close'] for row in group) for name,group in runs.items()}
            row=dict(noise=noise,layout=layout,workers=workers,runs=runs,median_seconds_including_close=medians,seconds_reduction_pct=100*(1-medians['candidate']/medians['baseline']))
            rows.append(row)
            print(json.dumps({key:row[key] for key in ('noise','layout','workers','median_seconds_including_close','seconds_reduction_pct')}),flush=True)
assert proof['candidate']==hashlib.sha256(Path(candidate.__file__).read_bytes()).hexdigest()
(root/'pipeline-comparison.json').write_text(json.dumps(dict(source_sha256=proof,scope='Alternating exact baseline/candidate recorder classes using full NumPy physics, raster RGB/depth64px, validation/copies, NPZ writing and final close, N4 T40 three cycles, 12MiB payload budget; synchronous and 1/2 writer threads, legacy/compact. Timeout-only task ensures fixed episode counts; synthetic-noise payload cases separately labelled. One warmup plus five measured pairs per case; public decoded hashes match. Shared host; study stress probes not active; results do not imply general training throughput or RSS limits.',cases=rows),indent=2)+'\n')
