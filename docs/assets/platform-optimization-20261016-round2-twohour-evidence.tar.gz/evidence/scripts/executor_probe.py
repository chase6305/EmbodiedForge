import importlib.util,json,statistics,sys,time
from pathlib import Path
import numpy as np
from embodiedforge.policies import ActionExecutor
root=Path(__file__).resolve().parent.parent
class Trusted(ActionExecutor):
    def reset(self,ids):
        if len(ids):
            self.chunks[ids]=0
            self.cursor[ids]=self.length[ids]=0
            self._episode[ids]=self._step[ids]=-1

def measure(cls,count,mode,steps):
    obs={'env_id':np.arange(count),'episode_id':np.zeros(count,np.int64),'step_id':np.zeros(count,np.int64)}
    chunk=np.zeros((count,16,2),np.float32)
    class Policy:
        def act(self,observation):return chunk[:len(observation['env_id'])]
    obj=cls(count,2,16);pol=Policy()
    for _ in range(32):obj.act(obs,pol)
    start=time.perf_counter()
    for i in range(steps):
        obj.act(obs,pol)
        if mode=='consecutive':obs['step_id']+=1
        elif mode=='partial':obs['step_id']+=1;obs['step_id'][i%count]-=1
    return time.perf_counter()-start
rows=[]
for n,steps in [(1,20000),(128,10000),(8192,500)]:
 for mode in ('consecutive','repeat','partial'):
  vals={'baseline':[],'prototype':[]}
  for pair in range(6):
   order=[('baseline',ActionExecutor),('prototype',Trusted)]
   if pair%2:order.reverse()
   for name,cls in order:
    seconds=measure(cls,n,mode,steps)
    if pair:vals[name].append(seconds)
  med={k:statistics.median(v) for k,v in vals.items()}
  row={'n':n,'mode':mode,'seconds':vals,'median':med,'reduction_pct':100*(1-med['prototype']/med['baseline'])};rows.append(row);print(json.dumps(row),flush=True)
(root/'executor-probe.json').write_text(json.dumps({'scope':'Diagnostic trusted-reset subclass, not a final implementation; precomputed zero action chunks, metadata loop plus increments, warmup and five measured alternating pairs','cases':rows},indent=2)+'\n')
