"""Differential real recording/reader stress in isolated persistent processes."""

import argparse
import gc
import hashlib
import json
import os
import platform
import selectors
import subprocess
import sys
import tempfile
import threading
import time
import traceback
from pathlib import Path

root = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser()
parser.add_argument("--worker", action="store_true")
parser.add_argument("--until", type=float, default=1792137605)
args = parser.parse_args()

if args.worker:
    import numpy as np
    import embodiedforge
    from embodiedforge import Config, VectorEnv
    from embodiedforge.batching import BatchOptions, window_batches
    from embodiedforge.data import EpisodeRecorder, action_windows, read_episodes

    package = Path(embodiedforge.__file__).parent
    source = {name:hashlib.sha256((package/name).read_bytes()).hexdigest() for name in ("data.py","batching.py","env.py","sensors.py","rollout.py","backends/physics.py","backends/render.py")}

    def resources():
        return dict(fd=len(list(Path('/proc/self/fd').iterdir())), threads=threading.active_count(), rss_bytes=int(next(line.split()[1] for line in Path('/proc/self/status').read_text().splitlines() if line.startswith('VmRSS:')))*1024)

    def case(index):
        rng = np.random.default_rng(160000+index)
        case_number=index
        index=(index*104729)%6912
        image_size = (8,32,64,128)[index%4]
        channels = ((),('rgb',),('rgb','depth'))[(index//4)%3]
        num_envs = (1,3,16)[(index//12)%3]
        if channels and image_size==128:
            num_envs=min(3,num_envs)
        max_steps = (1,3,9,25)[(index//36)%4]
        workers = (0,1,2)[(index//144)%3]
        layout = ('transitions','compact')[(index//432)%2]
        task = ('reach','hold')[(index//864)%2]
        metadata_dtype = (None,'>u8','<u8','>i8')[(index//1728)%4]
        offset = 2**63+1 if metadata_dtype in ('>u8','<u8') else 0
        history,horizon=(1,2,3)[index%3],(1,2,4)[(index//3)%3]
        batching=BatchOptions(batch_size=(1,4,17,64)[index%4],shuffle_buffer=(0,4,17)[(index//4)%3],seed=index%23,epoch=index%5)
        config = Config(task=task,num_envs=num_envs,max_steps=max_steps,render='raster' if channels else 'null',channels=channels,image_size=image_size)
        expected,complete={},{}

        def observation(value):
            if metadata_dtype is None:
                return value
            result=dict(value)
            result['env_id']=value['env_id'].astype(metadata_dtype)
            result['step_id']=value['step_id'].astype(metadata_dtype)
            result['episode_id']=np.array([int(x)+offset for x in value['episode_id']],dtype=metadata_dtype)
            return result

        def checksum_episode(arrays):
            digest=hashlib.sha256()
            for name,value in sorted(arrays.items()):
                digest.update(name.encode())
                digest.update(str((value.shape,value.dtype.str)).encode())
                digest.update(np.ascontiguousarray(value).data)
            return digest.hexdigest()

        with tempfile.TemporaryDirectory(prefix='ef-twohour-parity-') as temporary:
            with VectorEnv(config) as env:
                writer=EpisodeRecorder(Path(temporary)/'run',env,episode_format=layout,write_workers=workers)
                with writer:
                    for tick in range(2*max_steps+2):
                        before=observation(env.observe())
                        result=env.step(rng.uniform(-.2,.2,(num_envs,2)))
                        result.observation=observation(result.observation)
                        if tick==0:
                            # A late-row validation fault must not commit earlier
                            # copied rows, poison the writer, or prevent retry.
                            bad=dict(result.observation)
                            bad['step_id']=result.observation['step_id'].copy()
                            bad['step_id'][-1]+=1
                            from dataclasses import replace
                            invalid=replace(result,observation=bad)
                            try:
                                writer.append(before,invalid)
                            except ValueError:
                                pass
                            else:
                                raise AssertionError('Invalid next step accepted')
                            assert not writer.pending and not writer._writes and writer.buffered_bytes==0 and writer.failure is None
                            if case_number%7==0:
                                with EpisodeRecorder(Path(temporary)/'tiny',env,episode_format=layout,write_workers=workers,max_buffer_bytes=1) as tiny:
                                    try:
                                        tiny.append(before,result)
                                    except BufferError:
                                        pass
                                    else:
                                        raise AssertionError('One-byte budget accepted a transition')
                                    assert not tiny.pending and not tiny._writes and tiny.buffered_bytes==0 and tiny.failure is None
                        writer.append(before,result)
                        for row in np.flatnonzero(result.info['active']):
                            key=(int(row),int(before['episode_id'][row]))
                            fields={**{f'obs/{name}':value[row].copy() for name,value in before.items()},**{f'next/{name}':value[row].copy() for name,value in result.observation.items()},'action':result.info['executed_action'][row].copy(),'reward':result.reward[row].copy(),'terminated':result.terminated[row].copy(),'truncated':result.truncated[row].copy()}
                            expected.setdefault(key,[]).append(fields)
                            if result.terminated[row] or result.truncated[row]:
                                complete[key]=expected.pop(key)
                        # Caller mutation must not corrupt queued/incomplete rows.
                        before['proprio'][:]=123
                        done=np.flatnonzero(result.terminated|result.truncated)
                        if len(done):
                            env.reset(done)
                    incomplete=sorted((key,len(rows)) for key,rows in expected.items())
                assert writer.closed and not writer._writes and not writer.pending and writer.buffered_bytes==0
                manifest=json.loads((writer.root/'run.json').read_text())
                assert manifest['completed_episodes']==len(complete)
                assert sorted(((row['env_id'],row['episode_id']),row['steps']) for row in manifest['incomplete_episodes'])==incomplete
                assert manifest['status']=='closed'
                actual=list(read_episodes(writer.root))
                assert len(actual)==len(complete)
                digest=hashlib.sha256()
                for arrays in actual:
                    key=(int(arrays['obs/env_id'][0]),int(arrays['obs/episode_id'][0]))
                    rows=complete.pop(key)
                    reference={name:np.stack([row[name] for row in rows]) for name in rows[0]}
                    assert arrays.keys()==reference.keys()
                    for name in arrays:
                        np.testing.assert_array_equal(arrays[name],reference[name])
                    digest.update(checksum_episode(arrays).encode())
                assert not complete
                windows=list(action_windows(writer.root,history,horizon))
                batches=list(window_batches(writer.root,history,horizon,batching=batching))
                assert sum(len(batch.action) for batch in batches)==len(windows)
                for batch in batches:
                    digest.update(checksum_episode({'action':batch.action,**{f'obs/{name}':value for name,value in batch.observation.items()}}).encode())
                    digest.update(json.dumps(batch.instruction).encode())
                    assert batch.action.flags.owndata and batch.action.flags.c_contiguous
                for window in windows:
                    digest.update(checksum_episode({'action':window['action'],**{f'obs/{name}':value for name,value in window['observation'].items()}}).encode())
                window_count=len(windows)
                episodes=len(actual)
                transitions=sum(len(episode['action']) for episode in actual)
            del arrays,reference,rows,before,result,batches,windows,actual,writer,env,expected,complete
        gc.collect()
        return dict(index=case_number,sha256=digest.hexdigest(),episodes=episodes,transitions=transitions,windows=window_count,configuration=dict(image_size=image_size,channels=channels,num_envs=num_envs,max_steps=max_steps,workers=workers,layout=layout,task=task,metadata_dtype=metadata_dtype,history=history,horizon=horizon,shuffle=batching.shuffle_buffer,batch_size=batching.batch_size),resources=resources())

    initial=resources()
    print(json.dumps(dict(ready=True,source=source,python=platform.python_version(),numpy=np.__version__,resources=initial)),flush=True)
    for line in sys.stdin:
        try:
            index=json.loads(line)['index']
            result=case(index)
            assert result['resources']['fd']==initial['fd'] and result['resources']['threads']==initial['threads'],result
            print(json.dumps(dict(status='passed',**result)),flush=True)
        except BaseException as error:
            print(json.dumps(dict(status='failed',index=index,error=repr(error),traceback=traceback.format_exc())),flush=True)
            raise SystemExit(1)
else:
    processes={}
    logs={}
    started=time.time()
    samples=[]
    count=episodes=transitions=0
    configurations=set()
    try:
        for name,path in [('baseline',root/'baseline'),('candidate',Path.cwd()/'src')]:
            logs[name]=(root/f'endurance-{name}.stderr.log').open('w')
            env=dict(os.environ,PYTHONPATH=str(path.resolve()),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
            process=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--worker'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=logs[name],text=True,env=env,bufsize=1)
            processes[name]=process

        def receive(process):
            with selectors.DefaultSelector() as selector:
                selector.register(process.stdout,selectors.EVENT_READ)
                if not selector.select(45):
                    raise TimeoutError('Endurance worker did not reply in 45 seconds')
            line=process.stdout.readline()
            if not line:
                raise RuntimeError(f'Endurance worker exited with {process.poll()}')
            return json.loads(line)

        info={name:receive(process) for name,process in processes.items()}
        assert all(value['ready'] for value in info.values())
        (root/'endurance-worker-info.json').write_text(json.dumps(info,indent=2)+'\n')
        while time.time()<args.until:
            for process in processes.values():
                process.stdin.write(json.dumps(dict(index=count))+'\n')
                process.stdin.flush()
            results={name:receive(process) for name,process in processes.items()}
            assert all(row['status']=='passed' for row in results.values()),results
            baseline,candidate=results['baseline'],results['candidate']
            assert all(baseline[key]==candidate[key] for key in ('index','sha256','episodes','transitions','configuration')),results
            count+=1
            episodes+=candidate['episodes']
            transitions+=candidate['transitions']
            configurations.add(json.dumps(candidate['configuration'],sort_keys=True))
            if not samples or time.time()-samples[-1]['epoch']>=15:
                sample=dict(epoch=time.time(),cases=count,episodes=episodes,transitions=transitions,unique_configurations=len(configurations),resources={name:row['resources'] for name,row in results.items()})
                samples.append(sample)
                (root/'endurance-progress.json').write_text(json.dumps(dict(status='running',started_epoch=started,elapsed_seconds=time.time()-started,until=args.until,**sample),indent=2)+'\n')
                print(json.dumps(sample),flush=True)
        (root/'endurance.json').write_text(json.dumps(dict(status='passed',started_epoch=started,ended_epoch=time.time(),elapsed_seconds=time.time()-started,cases=count,episodes=episodes,transitions=transitions,unique_configurations=len(configurations),workers=info,samples=samples,scope='Persistent isolated baseline/candidate NumPy VectorEnv recording and full decoded independent reference, byte-identical public data/window/batch hashes, legacy/compact, 0/1/2 background writers, state/RGB/depth, 8..128px, N1/3/16 capped3 for128px, variable episodes/history/horizon/shuffle, high unsigned/non-native identities, late-row invalid-step atomic retry and caller mutation. FD/thread equality checked after each case; sampled RSS is not a leak proof.'),indent=2)+'\n')
    except BaseException as error:
        (root/'endurance-failure.json').write_text(json.dumps(dict(status='failed',epoch=time.time(),cases=count,error=repr(error),traceback=traceback.format_exc()),indent=2)+'\n')
        raise
    finally:
        for process in processes.values():
            process.stdin.close()
        for process in processes.values():
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
        for log in logs.values():
            log.close()
