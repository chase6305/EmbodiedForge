import gc,hashlib,importlib.util,itertools,json,tempfile,threading,time,weakref
from pathlib import Path
import embodiedforge.data as data
root=Path(__file__).resolve().parent.parent;path=Path.cwd()/'tests/test_recorder_collection_atomic.py'
s=importlib.util.spec_from_file_location('collection_fault_cases',path);tests=importlib.util.module_from_spec(s);s.loader.exec_module(tests)
refs=[];created=0
class TrackedRecorder(tests.EpisodeRecorder):
 def __init__(self,*args,**kwargs):
  global created
  super().__init__(*args,**kwargs);created+=1;refs.append(weakref.ref(self))
tests.EpisodeRecorder=TrackedRecorder

def resources():return dict(fd=len(list(Path('/proc/self/fd').iterdir())),threads=threading.active_count(),rss_bytes=int(next(x.split()[1] for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('VmRSS:')))*1024)
configurations=[]
for error,layout,entry,boundary,selected in itertools.product((KeyboardInterrupt,SystemExit,OSError),('transitions','compact'),('close','append'),('count','release'),(0,1)):
 configurations.append((tests.test_close_interrupted_after_completion_accounting_is_not_counted_twice,dict(error_type=error,episode_format=layout,entry=entry,boundary=boundary,interrupt_env=selected)))
for layout,interruptions in itertools.product(('transitions','compact'),(1,2)):
 configurations.append((tests.test_interruption_after_handle_removal_restores_retry_state,dict(episode_format=layout,interruptions=interruptions)))
initial=resources();started=time.time();samples=[]
for index in range(3120):
 function,args=configurations[index%len(configurations)]
 with tempfile.TemporaryDirectory(prefix='ef-r2-fault-cycle-') as tmp:function(tmp_path=Path(tmp),**args)
 gc.collect();assert all(r() is None for r in refs),'Recorder retained after GC';refs.clear()
 state=resources();assert state['fd']==initial['fd'] and state['threads']==initial['threads'],state
 if index%52==0:samples.append(dict(case=index+1,resources=state));print(json.dumps(dict(case=index+1,resources=state)),flush=True)
report=dict(status='passed',started_epoch=started,ended_epoch=time.time(),cases=3120,configurations=len(configurations),recorders_created=created,recorders_released_after_gc=created,initial=initial,final=resources(),samples=samples,source_sha256=hashlib.sha256(Path(data.__file__).read_bytes()).hexdigest(),test_source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),scope='60 cycles of all 52 collection-interruption regression configurations with real background writes/NPZ readback. Tracked subclass preserves inherited collection bytecode; GC/weakrefs verify recorder release after each case, FD/Python threads return to baseline. Sampled RSS and small point-state payloads do not establish a hard memory limit or an arbitrary-bytecode interruption guarantee.')
(root/'collection-fault-cycles.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='samples'}),flush=True)
