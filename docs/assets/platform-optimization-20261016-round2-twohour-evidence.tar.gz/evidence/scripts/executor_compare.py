import gc,hashlib,importlib.util,json,statistics,sys
from pathlib import Path
import embodiedforge.policies as candidate
root=Path(__file__).resolve().parent.parent

def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
baseline=module('embodiedforge._r2_baseline_policies',root/'baseline/embodiedforge/policies.py')
b=module('r2_executor_benchmark',Path.cwd()/'benchmarks/action_executor.py')
proof={k:hashlib.sha256(Path(f).read_bytes()).hexdigest() for k,f in [('baseline',baseline.__file__),('candidate',candidate.__file__),('benchmark',b.__file__)]}
rows=[]
cases=[dict(num_envs=n,action_dim=2,horizon=16,steps=20000 if n==1 else 10000 if n==128 else 500,metadata=metadata,repeat_every=repeat) for n in (1,128,8192) for metadata,repeat in ((False,0),(True,0),(True,16),(True,1))]
cases += [dict(num_envs=128,action_dim=dim,horizon=h,steps=10000,metadata=True,repeat_every=repeat) for dim,h,repeat in [(32,16,16),(2,1,0)]]
for args in cases:
 vals={name:[] for name in ('baseline','candidate')}
 for pair in range(10):
  order=[('baseline',baseline.ActionExecutor),('candidate',candidate.ActionExecutor)]
  if pair%2:order.reverse()
  for name,cls in order:
   b.measure.__globals__['ActionExecutor']=cls;gc.collect();r=b.measure(**args)
   if pair:vals[name].append(r)
 assert len({r['action_sha256'] for v in vals.values() for r in v})==1
 assert len({r['timed_policy_calls'] for v in vals.values() for r in v})==1
 med={name:statistics.median(r['seconds'] for r in v) for name,v in vals.items()}
 row=dict(arguments=args,runs=vals,median_seconds=med,reduction_pct=100*(1-med['candidate']/med['baseline']))
 rows.append(row);print(json.dumps({k:row[k] for k in ('arguments','median_seconds','reduction_pct')}),flush=True)
assert proof['candidate']==hashlib.sha256(Path(candidate.__file__).read_bytes()).hexdigest()
(root/'executor-comparison.json').write_text(json.dumps(dict(scope='Precomputed policy chunks, CPU act plus identity increment/repeat logic; one warmup and nine measured alternating pairs, no stress probes active; shared host, no pinning, no neural inference/physics. Separate consecutive single-act allocation tracing. Every pair matches returned-action hash and timed policy-call count.',source_sha256=proof,cases=rows),indent=2)+'\n')
