"""Supplement large-N performance cases with per-row Python integer queues."""
import gc,hashlib,importlib.util,json,sys,threading,time
from pathlib import Path
import numpy as np
import embodiedforge.policies as current
root=Path(__file__).resolve().parent.parent

def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
old=module('embodiedforge._large_oracle_baseline',root/'baseline/embodiedforge/policies.py');oracle=module('large_integer_queues',Path.cwd()/'tests/test_executor_metadata.py')
class Plan:
 def __init__(self,count,horizon):self.calls=np.zeros(count,np.int64);self.horizon=horizon
 def act(self,observation):
  ids=observation['env_id'];self.calls[ids]+=1
  return ((self.calls[ids]%5)[:,None,None]*.05+np.arange(self.horizon,dtype=np.float32)[None,:,None]*.025+(ids%31)[:,None,None]*.001).astype(np.float32)

def resources():return dict(fd=len(list(Path('/proc/self/fd').iterdir())),threads=threading.active_count(),rss_bytes=int(next(x.split()[1] for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('VmRSS:')))*1024)
initial=resources();started=time.time();rows=[];count=8192
for case,dtype in enumerate(('u8','>u8','i8','>i8','u4','>u4')):
 horizon=4 if case<3 else 16;rng=np.random.default_rng(3600000+case);maximum=int(np.iinfo(dtype).max);boundaries=sorted({0,min(2**53-1,maximum),min(2**63-2,maximum),maximum});episode=[boundaries[row%len(boundaries)] for row in range(count)];step=[max(0,boundaries[(row+1)%len(boundaries)]-2) for row in range(count)];old_executor=old.ActionExecutor(count,1,horizon);new_executor=current.ActionExecutor(count,1,horizon);reference=oracle.IntegerReference(count);policies=[Plan(count,horizon) for _ in range(3)]
 for control in range(48):
  if control:
   modes=rng.integers(0,7,count)
   for row,mode in enumerate(modes):
    if mode==0:continue
    step[row]=(step[row]+(2 if mode==1 else 1))%(maximum+1)
    if mode==2:episode[row]=(episode[row]+1)%(maximum+1)
    elif mode==3:episode[row]=boundaries[int(rng.integers(len(boundaries)))];step[row]=0
   if control%7==0:
    selected=[0,count//2,count-1]
    for obj in (old_executor,new_executor,reference):obj.reset(selected)
  env_ids=np.repeat(np.arange(count),2)[::2] if case%2 else np.arange(count);obs=dict(env_id=env_ids,episode_id=np.asarray(episode,dtype=dtype),step_id=np.asarray(step,dtype=dtype));expected=reference.act(obs,policies[2])
  for obj,policy in zip((old_executor,new_executor),policies[:2]):
   actual=obj.act(obs,policy);np.testing.assert_array_equal(actual,expected);np.testing.assert_array_equal(policy.calls,policies[2].calls);assert actual.flags.owndata and not np.shares_memory(actual,obj.chunks);actual[:]=-1
 row=dict(dtype=dtype,num_envs=count,horizon=horizon,controls=48,environment_actions=count*48,status='passed');rows.append(row);print(json.dumps(row),flush=True)
 del old_executor,new_executor,reference,policies,expected,actual;gc.collect();r=resources();assert r['fd']==initial['fd'] and r['threads']==initial['threads']
report=dict(status='passed',python=sys.version,numpy=np.__version__,started_epoch=started,ended_epoch=time.time(),rows=rows,environment_actions=sum(r['environment_actions'] for r in rows),source_sha256={name:hashlib.sha256(Path(path).read_bytes()).hexdigest() for name,path in [('baseline',old.__file__),('candidate',current.__file__),('integer_oracle',oracle.__file__)]},initial=initial,final=resources(),scope='Six integer dtype variants with 8192 environments against baseline and independent Python integer queues; per-row exact actions and policy-call counts on every control, repeated/skipped/wrapped metadata, extreme IDs, partial explicit resets, strided IDs and caller-owned output mutation. Supplemental correctness check, not a timing/RSS benchmark.')
label=f'py{sys.version_info.major}{sys.version_info.minor}';(root/f'large-executor-oracle-{label}-numpy{np.__version__}.json').write_text(json.dumps(report,indent=2)+'\n')
