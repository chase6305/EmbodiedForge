import cProfile,hashlib,importlib.util,json,pstats,sys
from pathlib import Path
import embodiedforge.policies as current
root=Path(__file__).resolve().parent.parent

def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
old=module('embodiedforge._profile_r2_baseline',root/'baseline/embodiedforge/policies.py');b=module('profile_r2_benchmark',Path.cwd()/'benchmarks/action_executor.py')
rows=[]
for repeat in (0,16,1):
 for label,cls in [('baseline',old.ActionExecutor),('candidate',current.ActionExecutor)]:
  b.measure.__globals__['ActionExecutor']=cls;p=cProfile.Profile();p.enable();b.measure(num_envs=128,action_dim=2,horizon=16,steps=1000,metadata=True,repeat_every=repeat);p.disable();path=root/f'executor-{label}-repeat{repeat}.pstats';p.dump_stats(str(path));s=pstats.Stats(p)
  names=('reset','_reset_rows','unique');counts={name:sum(value[1] for key,value in s.stats.items() if key[2]==name and (name=='unique' or key[0]==cls.__module__ and False or key[0].endswith('policies.py'))) for name in names}
  rows.append(dict(label=label,repeat_every=repeat,calls=counts))
assert all(r['calls']['unique']==0 for r in rows if r['label']=='candidate')
report=dict(source_sha256={name:hashlib.sha256(Path(path).read_bytes()).hexdigest() for name,path in [('baseline',old.__file__),('candidate',current.__file__),('benchmark',b.__file__)]},rows=rows,scope='cProfile actual measure including 32 warmup, 1000 timed and two allocation calls; counts only, profiling timings are not benchmark results. Internal reset avoids public ID validation; external reset retains that validation.')
(root/'executor-profile.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
