import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
root=Path(__file__).resolve().parent.parent
load=lambda name:json.loads((root/name).read_text())
raster=load('render-replication.json')['cases'];executor=load('executor-comparison.json')['cases'];sparse=load('sparse-executor-comparison.json')['cases']
fig=plt.figure(figsize=(13.8,9.5),facecolor='#f6f8fb');grid=fig.add_gridspec(2,2,height_ratios=[1,.85]);ax=fig.add_subplot(grid[0,0]);memory=fig.add_subplot(grid[0,1]);reset=fig.add_subplot(grid[1,:])
for axis in (ax,memory,reset):
 axis.set_facecolor('#f6f8fb');axis.spines[['top','right']].set_visible(False);axis.spines[['left','bottom']].set_color('#c6d0dc');axis.tick_params(length=0,labelsize=10);axis.set_axisbelow(True)
labels=['N32 / 128px / depth','N32 / 128px / RGB + depth','N128 / 128px / RGB + depth','N32 / 128px / RGB control'];y=np.arange(4)
colors={'baseline':'#a6b5c6','candidate':'#356db0'}
for offset,name in [(-.17,'baseline'),(.17,'candidate')]:
 values=np.array([1000*r['median_seconds'][name]/r['frames'] for r in raster]);q=np.array([np.percentile([1000*v['seconds']/r['frames'] for v in r['runs'][name]],[25,75]) for r in raster]).T
 ax.barh(y+offset,values,height=.29,color=colors[name],label='Baseline' if name=='baseline' else 'Final',xerr=np.vstack([values-q[0],q[1]-values]),error_kw={'ecolor':'#52677e','capsize':2,'linewidth':.8})
 values=[r['median_peak_traced_bytes'][name]/1024**2 for r in raster];memory.barh(y+offset,values,height=.29,color=colors[name])
for axis in (ax,memory):axis.invert_yaxis();axis.grid(axis='x',color='#dfe5ed',linewidth=.7)
ax.set_yticks(y,labels);memory.set_yticks(y,[]);ax.legend(frameon=False,loc='lower right',fontsize=10)
ax.set_title('Actual CPU raster time per frame (IQR whiskers)',loc='left',fontsize=12,pad=16);memory.set_title('Separate single-frame allocation tracing',loc='left',fontsize=12,pad=16)
ax.set_xlabel('Milliseconds per frame');memory.set_xlabel('Peak traced MiB (not process RSS)')
for n,color in [(128,'#356db0'),(8192,'#339184')]:
 def full(repeat):return next(r['reduction_pct'] for r in executor if r['arguments']['num_envs']==n and r['arguments']['action_dim']==2 and r['arguments']['horizon']==16 and r['arguments']['metadata'] and r['arguments']['repeat_every']==repeat)
 def partial(repeat):return next(r['reduction_pct'] for r in sparse if r['num_envs']==n and r['repeat_every']==repeat and r['affected_rows']==1)
 values=[full(0),partial(16),partial(1),full(16),full(1)];reset.plot(range(5),values,'o-',color=color,linewidth=2,label=f'N{n} / A2 / H16')
 for index,value in enumerate(values):reset.annotate(f'{value:.1f}%',(index,value),xytext=(0,8 if n==128 else -15),textcoords='offset points',ha='center',fontsize=9,color=color)
reset.set_xticks(range(5),['Consecutive\nidentities','One row repeats\nevery 16 steps','One row repeats\nevery step','All rows repeat\nevery 16 steps','All rows repeat\nevery step']);reset.set_ylabel('Median elapsed time reduction (%)');reset.set_ylim(-7,58);reset.grid(axis='y',color='#dfe5ed',linewidth=.7);reset.axhline(0,color='#78899e',linewidth=.8);reset.legend(frameon=False,loc='upper left',fontsize=10);reset.set_title('Executor behavior depends on repeat frequency and affected rows',loc='left',fontsize=12,pad=16)
fig.suptitle('EmbodiedForge · second two-hour optimization',x=.07,y=.97,ha='left',fontsize=19,weight='bold',color='#18324e')
fig.text(.07,.075,'Nine alternating measured pairs per case. Precomputed policy chunks; no neural inference or physics in these panels.',fontsize=9,color='#4a5d73')
fig.text(.07,.045,'Shared CPU host. Continuous executor timing is nearly flat. Whole acquisition results include negative cases; no general training-throughput gain is established.',fontsize=9,color='#4a5d73')
fig.subplots_adjust(left=.24,right=.97,top=.86,bottom=.20,hspace=.65,wspace=.45)
fig.savefig('docs/platform-optimization-20261016-round2-twohour-performance.svg',metadata={'Date':None});fig.savefig('/tmp/ef-round2-performance.png',dpi=120)
