import gc,hashlib,importlib.util,json,statistics,sys
from pathlib import Path
root=Path(__file__).resolve().parent.parent

def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
old=module('r2_baseline_render',root/'baseline/embodiedforge/backends/render.py');new=module('r2_candidate_render',root/'scripts/render_prototype.py');b=module('r2_render_benchmark',Path.cwd()/'benchmarks/raster.py')
proof={label:hashlib.sha256(Path(path).read_bytes()).hexdigest() for label,path in [('baseline',old.__file__),('candidate',new.__file__),('benchmark',b.__file__)]}
cases=[(n,size,frames,channels) for n,size,frames in [(1,32,200),(32,128,50),(128,128,20),(8,512,12)] for channels in [('depth',),('rgb','depth'),('rgb','depth','instance_id','semantic_id')]]
cases.append((32,128,50,('rgb',)))
rows=[]
for n,size,frames,channels in cases:
 runs={name:[] for name in ('baseline','candidate')}
 for pair in range(10):
  order=[('baseline',old.RasterRenderer),('candidate',new.RasterRenderer)]
  if pair%2:order.reverse()
  for label,cls in order:
   b.measure.__globals__['RasterRenderer']=cls;gc.collect();r=b.measure(n,size,frames,channels)
   if pair:runs[label].append(r)
 assert len({r['sha256'] for v in runs.values() for r in v})==1
 med={name:statistics.median(r['seconds'] for r in v) for name,v in runs.items()};peaks={name:statistics.median(r['peak_traced_bytes'] for r in v) for name,v in runs.items()}
 row=dict(num_envs=n,image_size=size,frames=frames,channels=channels,runs=runs,median_seconds=med,median_peak_traced_bytes=peaks,seconds_reduction_pct=100*(1-med['candidate']/med['baseline']),traced_peak_reduction_pct=100*(1-peaks['candidate']/peaks['baseline']));rows.append(row);print(json.dumps({k:v for k,v in row.items() if k!='runs'}),flush=True)
report=dict(scope='Actual CPU RasterRenderer including disk labels and requested image conversion; positions vary deterministically by frame. One warmup plus nine alternating measured pairs. Timing excludes separate allocation trace and complete-image hash passes, construction, physics/sensors/web. All frame/image hashes match. Candidate file is an independent prototype; adoption requires its whole source hash to match final backends/render.py. Three recording/executor stress workers active on shared host; not a process RSS/training throughput metric.',source_sha256=proof,cases=rows)
(root/'render-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
