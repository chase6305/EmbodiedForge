"""Actual controller signals at completed-future accounting boundaries."""
import argparse,hashlib,inspect,json,os,signal,subprocess,sys,tempfile,time
from pathlib import Path
root=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--worker',action='store_true');p.add_argument('--signal',choices=('SIGINT','SIGTERM'));p.add_argument('--repetitions',type=int,default=20);a=p.parse_args()
if a.worker:
 import numpy as np
 import embodiedforge.data as data
 from embodiedforge import Config,VectorEnv
 fd=len(list(Path('/proc/self/fd').iterdir()))
 if a.signal=='SIGTERM':
  def terminate(signum,frame):raise SystemExit(128+signum)
  signal.signal(signal.SIGTERM,terminate)
 events={};injected=False
 code=data.EpisodeRecorder._collect_writes.__code__
 lines,start=inspect.getsourcelines(data.EpisodeRecorder._collect_writes)
 target=start+next(i for i,line in enumerate(lines) if line.strip()=='del self._writes[key]')
 def inject(frame,event,arg):
  global injected
  if frame.f_code is code and event=='line' and frame.f_lineno==target and not injected:
   injected=True;events['sent_epoch']=time.time();os.kill(os.getpid(),getattr(signal,a.signal))
  return inject
 with tempfile.TemporaryDirectory(prefix='ef-r2-accounting-signal-') as temporary:
  with VectorEnv(Config(num_envs=1,max_steps=1)) as env:
   writer=data.EpisodeRecorder(Path(temporary)/'run',env,write_workers=1)
   writer.append(env.observe(),env.step(np.zeros((1,2))))
   for future,_,_ in writer._writes.values():future.result(timeout=5)
   tids=[thread.native_id for thread in writer._executor._threads]
   caught=None;previous=sys.gettrace()
   try:
    sys.settrace(inject)
    try:writer.close()
    except BaseException as error:caught=error;events['caught_epoch']=time.time()
    finally:sys.settrace(previous)
    assert injected
    assert isinstance(caught,KeyboardInterrupt) if a.signal=='SIGINT' else isinstance(caught,SystemExit) and caught.code==143
    assert events['sent_epoch']<=events['caught_epoch']
    assert writer.closed and not writer._writes and writer.buffered_bytes==0
    manifest=json.loads((writer.root/'run.json').read_text())
    assert manifest['completed_episodes']==1,f"Duplicate completion count: {manifest['completed_episodes']}"
    assert manifest['status']=='closed' and len(list(data.read_episodes(writer.root)))==1
    deadline=time.monotonic()+.5
    while any(Path(f'/proc/self/task/{tid}').exists() for tid in tids) and time.monotonic()<deadline:time.sleep(.005)
    assert all(not Path(f'/proc/self/task/{tid}').exists() for tid in tids)
    result=dict(status='passed',signal=a.signal,exception=type(caught).__name__,events=events,source_sha256=hashlib.sha256(Path(data.__file__).read_bytes()).hexdigest(),native_writer_threads_gone=True)
   finally:sys.settrace(previous);writer.close()
 assert len(list(Path('/proc/self/fd').iterdir()))==fd
 result['fd_restored']=True;print(json.dumps(result),flush=True)
else:
 rows=[];negatives=[];started=time.time()
 for label,path,reps in [('baseline',root/'baseline',1),('candidate',Path.cwd()/'src',a.repetitions)]:
  for kind in ('SIGINT','SIGTERM'):
   for repeat in range(reps):
    env=dict(os.environ,PYTHONPATH=str(path.resolve()),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    r=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker','--signal',kind],env=env,capture_output=True,text=True,timeout=15)
    if label=='baseline':
     assert r.returncode!=0 and 'Duplicate completion count: 2' in r.stderr,r.stderr
     negatives.append(dict(signal=kind,returncode=r.returncode,stderr=r.stderr))
    else:
     assert r.returncode==0,r.stdout+r.stderr
     rows.append(json.loads(r.stdout))
 label=f'py{sys.version_info.major}{sys.version_info.minor}'
 report=dict(status='passed',python=sys.version,started_epoch=started,ended_epoch=time.time(),passed_cases=len(rows),baseline_negative_controls=negatives,rows=rows,scope='Real SIGINT/SIGTERM sent only to the isolated worker itself by a one-shot line tracer immediately before deleting a successfully accounted future. SIGTERM handler raises SystemExit143; no guarantee under default-killing SIGTERM or arbitrary bytecode cancellation. Real NPZ writes, manifest count/read-back, native writer thread exit and FD recovery checked; prior-round baseline deterministically counts its single episode twice.')
 (root/f'collection-signals-{label}.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status='passed',python=label,passed_cases=len(rows),baseline_expected_failures=len(negatives))),flush=True)
