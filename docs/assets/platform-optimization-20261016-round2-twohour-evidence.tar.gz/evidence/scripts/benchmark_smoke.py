import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent.parent
out=root/'smoke';out.mkdir(exist_ok=True)
env=dict(os.environ,PYTHONPATH=str(Path.cwd()/'src'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
rows=[]
for label,python in [('py310','/tmp/ef-ci310-20261014/bin/python'),('py312','/tmp/ef-ci312-20261014/bin/python'),('numpy124','/tmp/ef-numpy124-20261014/bin/python')]:
 for metadata,repeat in [(False,0),(True,0),(True,1),(True,16)]:
  dest=out/f'{label}-metadata{int(metadata)}-repeat{repeat}.json'
  command=[python,'benchmarks/action_executor.py','--num-envs','4','--horizon','4','--steps','64','--output',str(dest),'--repeat-every',str(repeat)]
  if metadata:command.append('--metadata')
  result=subprocess.run(command,env=env,capture_output=True,text=True,timeout=30);assert result.returncode==0,result.stdout+result.stderr
  d=json.loads(dest.read_text())
  step=0;previous=None;remaining=0;calls=0
  for control in range(72):
   if metadata and previous is not None and step!=previous+1:remaining=0
   if not remaining:
    remaining=4
    if control>=8:calls+=1
   remaining-=1;previous=step
   if metadata and (not repeat or (control+1)%repeat):step+=1
  assert d['timed_policy_calls']==calls,(d,calls)
  rows.append(dict(label=label,metadata=metadata,repeat_every=repeat,python=d['python'],numpy=d['numpy'],timed_policy_calls=d['timed_policy_calls'],action_sha256=d['action_sha256']))
 for args in [('--repeat-every','-1','--metadata'),('--repeat-every','1')]:
  dest=out/f'{label}-invalid.json'
  result=subprocess.run([python,'benchmarks/action_executor.py','--output',str(dest),*args],env=env,capture_output=True,text=True,timeout=30)
  assert result.returncode==2 and not dest.exists()
assert len({row['action_sha256'] for row in rows})==1
report=dict(status='passed',rows=rows,valid_cases=len(rows),invalid_cases=6,benchmark_sha256=hashlib.sha256(Path('benchmarks/action_executor.py').read_bytes()).hexdigest(),scope='Actual CLI in Python3.10/3.12/NumPy1.24; timed policy calls checked against scalar identity/chunk reference; default and repeat0/1/16, invalid flag combinations create no output.')
(root/'benchmark-smoke.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
