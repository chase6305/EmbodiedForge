"""Compound worker failures, caller interruption and optional body exceptions."""
import gc,hashlib,inspect,json,sys,tempfile,threading,time,weakref
from pathlib import Path
import numpy as np
import embodiedforge.data as data
from embodiedforge import Config,VectorEnv
root=Path(__file__).resolve().parent.parent
lines,start=inspect.getsourcelines(data.EpisodeRecorder._collect_writes);code=data.EpisodeRecorder._collect_writes.__code__;target=start+next(i for i,line in enumerate(lines) if line.strip()=='del self._writes[key]');refs=[]

def resources():return dict(fd=len(list(Path('/proc/self/fd').iterdir())),threads=threading.active_count(),rss_bytes=int(next(x.split()[1] for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('VmRSS:')))*1024)
def run(index):
 rng=np.random.default_rng(4600000+index);count=(2,3,8)[index%3];layout=('transitions','compact')[(index//3)%2];workers=(1,2)[(index//6)%2];body_failed=bool((index//12)%2);error_type=(KeyboardInterrupt,SystemExit,OSError)[(index//24)%3];primary=error_type('caller collection interruption');body=ValueError('original body failure');failed=sorted({0,int(rng.integers(count-1))});failures={row:OSError(f'worker {row} failed') for row in failed};injected=False
 def interrupt(frame,event,arg):
  nonlocal injected
  if frame.f_code is code and event=='line' and frame.f_lineno==target and frame.f_locals['key'][0]==count-1 and not injected:injected=True;raise primary
  return interrupt
 with tempfile.TemporaryDirectory(prefix='ef-r2-mixed-fault-') as tmp:
  with VectorEnv(Config(num_envs=count,max_steps=1)) as env:
   writer=data.EpisodeRecorder(Path(tmp)/'run',env,write_workers=workers,episode_format=layout);refs.append(weakref.ref(writer));write=writer._write_episode
   def mixed(key,rows):
    if key[0] in failures:raise failures[key[0]]
    return write(key,rows)
   writer._write_episode=mixed;writer.append(env.observe(),env.step(np.zeros((count,2))))
   for key,(future,_,_) in writer._writes.items():
    try:future.result(timeout=5)
    except OSError as error:assert error is failures[key[0]]
   previous=sys.gettrace()
   try:
    sys.settrace(interrupt)
    try:
     if body_failed:
      with writer:raise body
     else:writer.close()
    except BaseException as caught:assert caught is (body if body_failed else primary)
    else:raise AssertionError('Primary exception lost')
   finally:sys.settrace(previous);writer.close()
   assert injected and writer.closed and not writer._writes and not writer.pending and writer.buffered_bytes==0
   assert writer.failure is (body if body_failed else failures[0])
   if body_failed:assert writer.close_error is primary
   manifest=json.loads((writer.root/'run.json').read_text());assert manifest['status']=='failed' and manifest['completed_episodes']==count-len(failed)
   assert sorted(row['env_id'] for row in manifest['incomplete_episodes'])==failed
   assert len(list(data.read_episodes(writer.root)))==count-len(failed)
 return (count,layout,workers,body_failed,error_type.__name__)
initial=resources();started=time.time();coverage=set();samples=[]
for index in range(576):
 coverage.add(run(index));gc.collect();assert all(r() is None for r in refs);refs.clear();r=resources();assert r['fd']==initial['fd'] and r['threads']==initial['threads']
 if index%72==0:samples.append(dict(case=index+1,resources=r))
report=dict(status='passed',python=sys.version,numpy=np.__version__,started_epoch=started,ended_epoch=time.time(),cases=576,configurations=len(coverage),source_sha256=hashlib.sha256(Path(data.__file__).read_bytes()).hexdigest(),recorders_released_after_gc=576,initial=initial,final=resources(),samples=samples,scope='Real successful and failed background writers in the same recorder, interrupted successful-handle removal after earlier storage failures, optional original with-body failure. Exact manifest/readback counts, failed identities, first exception/failure state and secondary close error checked; all recorder weakrefs released after GC and per-case FD/Python-thread baseline restored. Small point-state payloads; no arbitrary-bytecode or RSS bound guarantee.')
label=f'py{sys.version_info.major}{sys.version_info.minor}';(root/f'mixed-collection-faults-{label}.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='samples'}),flush=True)
