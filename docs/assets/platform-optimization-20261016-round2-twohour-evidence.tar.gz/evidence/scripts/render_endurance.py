"""Dense geometry reference, exact outputs and owned raster frames."""
import argparse,gc,hashlib,importlib.util,itertools,json,threading,time,traceback
from pathlib import Path
import numpy as np
import embodiedforge.backends.render as current
from embodiedforge import Config
from embodiedforge.core import SceneSpec,SceneUpdate,StateSnapshot
root=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--until',type=float,default=1792137605);a=p.parse_args()
s=importlib.util.spec_from_file_location('r2_endurance_baseline_render',root/'baseline/embodiedforge/backends/render.py');old=importlib.util.module_from_spec(s);s.loader.exec_module(old)
proof={name:hashlib.sha256(Path(path).read_bytes()).hexdigest() for name,path in [('baseline',old.__file__),('candidate',current.__file__)]}
channels=[tuple(group) for n in range(5) for group in itertools.combinations(('rgb','depth','instance_id','semantic_id'),n)]
palette=np.array([[20,24,32],[70,155,255],[65,210,120]],np.uint8)

def resources():return dict(fd=len(list(Path('/proc/self/fd').iterdir())),threads=threading.active_count(),rss_bytes=int(next(x.split()[1] for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('VmRSS:')))*1024)
initial=resources();started=time.time();cases=pixels=frames=0;samples=[];coverage=set()
try:
 while time.time()<a.until:
  index=(cases*104729)%6048;size=(1,7,32,64,127,128,257)[index%7];selected=channels[(index//7)%16];count=(1,3,16)[(index//112)%3];dtype=(np.float32,np.float64,np.longdouble)[(index//336)%3];radius=(1e-12,.06,.1,.35,1.5,4.)[(index//1008)%6]
  rng=np.random.default_rng(2600000+cases);positions=rng.uniform(-2-radius,2+radius,(count,2)).astype(dtype);targets=rng.uniform(-2,2,(count,2)).astype(dtype)
  if cases%3==0:
   backing=np.zeros((count,4),dtype);backing[:,::2]=positions;positions=backing[:,::2]
  ids=np.array([],np.int64) if cases%11==0 else rng.integers(0,count,count+2)
  if cases%2:
   ids=np.repeat(ids,2)[::2]
  state=StateSnapshot(positions,np.zeros_like(positions),np.arange(count,dtype=np.float64),np.arange(count,dtype=np.int64));update=SceneUpdate(state,dict(agent=positions,target=targets));config=Config(num_envs=count,image_size=size,channels=selected)
  coord=(np.arange(size)+.5)*3/size-1.5;labels=np.zeros((len(ids),1,size,size),np.int32)
  for entity,centers,r in [(2,targets,.1),(1,positions,radius)]:
   mask=((coord[None,None,:]-centers[ids,0,None,None])**2+(-coord[None,:,None]-centers[ids,1,None,None])**2)<=r**2
   labels[:,0][mask]=entity
  reference={name:({'rgb':lambda:palette[labels],'depth':lambda:np.where(labels!=0,2.,0.).astype(np.float32),'instance_id':lambda:labels.copy(),'semantic_id':lambda:labels.copy()}[name])() for name in selected}
  if 'depth' in reference:reference['depth_valid']=labels!=0
  for cls in (old.RasterRenderer,current.RasterRenderer):
   renderer=cls();renderer.build(SceneSpec(radius=radius),config);renderer.sync(update);actual=renderer.render(ids)
   assert actual.images.keys()==reference.keys()
   for name,value in actual.images.items():
    assert value.dtype==reference[name].dtype and value.flags.owndata and value.flags.c_contiguous
    np.testing.assert_array_equal(value,reference[name])
    for other,array in actual.images.items():
     if name!=other:assert not np.shares_memory(value,array)
   for value in actual.images.values():value[:]=0
   again=renderer.render(ids)
   for name,value in again.images.items():np.testing.assert_array_equal(value,reference[name])
   np.testing.assert_array_equal(again.time,state.time[ids]);np.testing.assert_array_equal(again.version,state.version[ids]);renderer.close()
  cases+=1;frames+=len(ids);pixels+=len(ids)*size*size;coverage.add((size,selected,count,np.dtype(dtype).str,radius))
  if cases%25==0:gc.collect()
  r=resources();assert r['fd']==initial['fd'] and r['threads']==initial['threads']
  if not samples or time.time()-samples[-1]['epoch']>=15:
   sample=dict(epoch=time.time(),cases=cases,frames=frames,pixels=pixels,coverage=len(coverage),resources=r);samples.append(sample);(root/'render-endurance-progress.json').write_text(json.dumps(dict(status='running',started_epoch=started,until=a.until,**sample),indent=2)+'\n');print(json.dumps(sample),flush=True)
 assert proof['candidate']==hashlib.sha256(Path(current.__file__).read_bytes()).hexdigest()
 report=dict(status='passed',started_epoch=started,ended_epoch=time.time(),cases=cases,frames=frames,pixels=pixels,coverage=len(coverage),source_sha256=proof,initial=initial,final=resources(),samples=samples,scope='Actual baseline/current rendering versus independent dense geometry and palette/depth reference. 6048 shape/channel/count/coordinate-dtype/radius configurations, all 16 channel subsets; empty/repeated/strided environment selections and strided positions, float32/64/longdouble coordinates. Exact dtype/pixels, independent owned image arrays and next-frame integrity after caller mutation; capture metadata checked. New RNG per case; FD/Python threads after each case, RSS samples not a leak proof or hard budget.')
 (root/'render-endurance.json').write_text(json.dumps(report,indent=2)+'\n')
except BaseException as error:
 (root/'render-failure.json').write_text(json.dumps(dict(status='failed',epoch=time.time(),cases=cases,error=repr(error),traceback=traceback.format_exc()),indent=2)+'\n');raise
