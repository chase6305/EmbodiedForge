import gc,hashlib,importlib.util,json,statistics,sys,time
from pathlib import Path
import numpy as np
import embodiedforge.policies as current
root=Path(__file__).resolve().parent.parent
s=importlib.util.spec_from_file_location('embodiedforge._sparse_baseline',root/'baseline/embodiedforge/policies.py');old=importlib.util.module_from_spec(s);sys.modules[s.name]=old;s.loader.exec_module(old)

def measure(cls,count,frequency,affected,steps):
 obs=dict(env_id=np.arange(count),episode_id=np.zeros(count,np.int64),step_id=np.zeros(count,np.int64))
 chunks=(np.arange(count*16*2,dtype=np.float32)%31/31-.5).reshape(count,16,2)
 class Policy:
  calls=rows=0
  def act(self,observation):
   self.calls+=1;self.rows+=len(observation['env_id']);return chunks[observation['env_id']]
 p=Policy();e=cls(count,2,16)
 def act(control):
  obs['step_id']+=1
  if control%frequency==0:
   if affected==1:obs['step_id'][control%count]-=1
   else:obs['step_id'][:affected]-=1
  return e.act(obs,p)
 for control in range(32):act(control)
 p.calls=p.rows=0;started=time.perf_counter()
 for control in range(32,32+steps):action=act(control)
 seconds=time.perf_counter()-started
 assert action.flags.owndata and not np.shares_memory(action,e.chunks)
 return dict(seconds=seconds,policy_calls=p.calls,planned_rows=p.rows,action_sha256=hashlib.sha256(action.tobytes()).hexdigest())
rows=[]
for count,steps in [(128,10000),(8192,1000)]:
 for frequency,affected in [(16,1),(1,1),(16,count//4)]:
  runs={name:[] for name in ('baseline','candidate')}
  for pair in range(10):
   order=[('baseline',old.ActionExecutor),('candidate',current.ActionExecutor)]
   if pair%2:order.reverse()
   for label,cls in order:
    gc.collect();r=measure(cls,count,frequency,affected,steps)
    if pair:runs[label].append(r)
  assert len({(r['action_sha256'],r['policy_calls'],r['planned_rows']) for v in runs.values() for r in v})==1
  med={name:statistics.median(r['seconds'] for r in group) for name,group in runs.items()}
  row=dict(num_envs=count,repeat_every=frequency,affected_rows=affected,steps=steps,runs=runs,median_seconds=med,reduction_pct=100*(1-med['candidate']/med['baseline']));rows.append(row);print(json.dumps({k:v for k,v in row.items() if k!='runs'}),flush=True)
report=dict(scope='Supplemental sparse repeated-step identities; CPU act, observation increments/selected repeats and precomputed chunk gathering plus callback/row counters. One warmup plus nine alternating measured pairs; recording/executor stress active on shared host. Final action hash and policy/row counts match. Excludes physics/neural inference; no general training speed claim.',source_sha256={label:hashlib.sha256(Path(f).read_bytes()).hexdigest() for label,f in [('baseline',old.__file__),('candidate',current.__file__)]},cases=rows)
(root/'sparse-executor-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
