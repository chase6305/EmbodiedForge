"""Caller interruption cannot commit a completed background episode twice."""

import inspect
import json
import sys

import numpy as np
import pytest

from embodiedforge import Config, VectorEnv
from embodiedforge.data import EpisodeRecorder, read_episodes


@pytest.mark.parametrize("error_type", [KeyboardInterrupt, SystemExit, OSError])
@pytest.mark.parametrize("episode_format", ["transitions", "compact"])
def test_close_interrupted_after_completion_accounting_is_not_counted_twice(
    tmp_path, error_type, episode_format
):
    with VectorEnv(Config(num_envs=2, max_steps=1)) as env:
        writer = EpisodeRecorder(
            tmp_path / "run", env, write_workers=2, episode_format=episode_format
        )
        writer.append(env.observe(), env.step(np.zeros((2, 2))))
        primary = error_type("interrupt after accounting")
        code = EpisodeRecorder._collect_writes.__code__
        lines, start = inspect.getsourcelines(EpisodeRecorder._collect_writes)
        target = start + next(
            i for i, line in enumerate(lines) if line.strip() == "del self._writes[key]"
        )
        injected = False

        def interrupt(frame, event, arg):
            nonlocal injected
            if frame.f_code is code and event == "line" and frame.f_lineno == target and not injected:
                injected = True
                raise primary
            return interrupt

        previous = sys.gettrace()
        try:
            sys.settrace(interrupt)
            with pytest.raises(error_type) as caught:
                writer.close()
            assert caught.value is primary
        finally:
            sys.settrace(previous)
            writer.close()
        assert injected
        assert writer.closed and not writer._writes
        assert writer.buffered_bytes == 0
        manifest = json.loads((writer.root / "run.json").read_text())
        assert manifest["completed_episodes"] == 2
        assert len(list(read_episodes(writer.root))) == 2
